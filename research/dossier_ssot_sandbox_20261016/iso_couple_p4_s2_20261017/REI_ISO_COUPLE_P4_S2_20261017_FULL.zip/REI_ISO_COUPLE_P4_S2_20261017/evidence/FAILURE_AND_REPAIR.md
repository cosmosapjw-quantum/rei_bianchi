# Actual development failures and bounded repairs (2026-10-17)

1. Native constant-opacity diagnostic first failed Rust compilation because 
   `let mut (tuple)` is invalid in Rust: each binding requires its own `mut`.
   Repair: `let (mut a,mut b,mut c)=...`. Rebuilt and executed the 7-row oracle.
2. This is a *source-level compiler syntax issue*, not a physical model failure.
3. The original user-provided Rust tarball detached .asc signer public key was
   absent. GPG returned `NO_PUBKEY` for 85AB96E6FA1BE5FE. The toolchain was
   isolated under /mnt/data and rustc/cargo/clippy/rustfmt versions confirmed.
   Release signature authenticity: UNVERIFIED, distinct from successful builds.
4. No original PR150 source owner, P3 positive_age.rs or project checkpoint was edited.
5. The coupled native temporal order remained near first-order after the source
   clock correction; this is a scientific *HOLD for global second-order*, not a
   compiler or unit-test failure. The constant-opacity analytic test passed.

6. A global `cargo fmt --all -- --check` returned nonzero because immutable
   historical owner_src/rate_table.rs uses its original non-rustfmt layout.
   The formatting check is scoped to newly added files and the root lib.rs
   using `skip_children=true`. The 12 immutable owner Git blobs remain exact.
   This is representation metadata, not a code or science failure.
