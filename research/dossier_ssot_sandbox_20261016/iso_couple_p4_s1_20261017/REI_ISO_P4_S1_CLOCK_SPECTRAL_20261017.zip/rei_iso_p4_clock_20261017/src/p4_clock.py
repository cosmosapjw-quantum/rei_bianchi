"""Independent ISO-COUPLE-P4/S1 positive source-clock and spectral oracle.

Origin: rei_bianchi PR182 @ 3a2721e58fc8bd68cdbbc92ca4669bd57609695b.
This is Python sandbox research, NOT a replacement for native Rust owner.
Source model & Verner parameters are transcribed from the exact PR182 Git blobs
referenced by provenance.json; no extension beyond the source [13.6,100] eV.

Units: E and chi in eV, n in proper m^-3, kappa in s^-1, t in proper s,
photons/events per arbitrary reference comoving volume normalized to injected 1.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np
from numpy.polynomial.legendre import leggauss

SOURCE_ID="MD14_Z002_FESC_BB50K_13P6_100_V1"
SOURCE_EDGES=(13.6,24.59,54.42,100.0)
C=299_792_458.0
EV_J=1.602176634e-19
KB_EV_K=1.380649e-16 / 1.602176634e-12
# Thermal/binding thresholds are HHeModel::controlled_fixture, distinct from
# Verner fit onset ETH and the AxbiSource spectral segment boundaries.
# P3 manufactured delta chi_D = +0.0037 eV relative to the H FIXTURE threshold.
CHI_H=13.598434599702
CHIS=np.array([CHI_H,24.587389011,54.41776,CHI_H+0.0037], dtype=float)
N_PROPER=np.array([1000.0,300.0,100.0,25.0],dtype=float)
# Original Verner 1996 parameters: eth,e0,sigma0,ya,p,yw,y0,y1.
VERNER=np.array([
    [13.60,0.4298,5.475e4,32.88,2.963,0.,0.,0.],
    [24.59,13.61,949.2,1.469,3.188,2.039,0.4434,2.136],
    [54.42,1.720,1.369e4,32.88,2.963,0.,0.,0.],
],dtype=float)

class DomainError(ValueError):
    pass

def _domain(ok: bool, message: str) -> None:
    if not ok: raise DomainError(message)

def photon_shape(ev: np.ndarray|float) -> np.ndarray:
    e=np.asarray(ev,dtype=float)
    _domain(bool(np.all(np.isfinite(e)) and np.all((e>=SOURCE_EDGES[0])&(e<=SOURCE_EDGES[-1]))),"source energy outside [13.6,100] eV")
    return e*e/np.expm1(e/(KB_EV_K*50_000.0))

def md14_relative_emission(t:float,h:float=1.2e-16) -> float:
    """Source emission j(t)/j(0); fesc, normalization cancel; physical MD14 shape."""
    z=21.0*math.exp(-h*t)-1.0
    _domain(math.isfinite(t) and math.isfinite(z) and 4<=z<=20,"source z outside original 4..20")
    zp=1+z
    psi=.015*zp**2.7/(1+(zp/2.9)**5.6)
    psi0=.015*21**2.7/(1+(21/2.9)**5.6)
    return psi/psi0

def verner_sigma_m2(kind:int, energies:np.ndarray|float) -> np.ndarray:
    """Original outer shell reference, with D=HI above caller-provided D threshold."""
    _domain(kind in (0,1,2,3),"invalid absorber")
    e=np.asarray(energies,dtype=float)
    _domain(bool(np.all(np.isfinite(e)) and np.all((e>=0)&(e<=50000))),"cross-section energy domain")
    eth,e0,s0,ya,p,yw,y0,y1=VERNER[0 if kind==3 else kind]
    x=e/e0-y0
    y=np.hypot(x,y1)
    _domain(bool(np.all(y>0)),"Verner x,y invalid")
    sigma=s0*((x-1)**2+yw**2)*y**(p/2-5.5)*(1+np.sqrt(y/ya))**(-p)*1e-22
    return np.where((e>=eth)&((kind!=3)|(e>=CHIS[3])),sigma,0.0)

def simpson_native(lo:float,hi:float,energy_moment:bool)->float:
    """32-panel Simpson used by frozen AxbiSource; source shape is physical."""
    n=32
    e=np.linspace(lo,hi,n+1)
    weights=np.full(n+1,2.0);weights[1:-1:2]=4.;weights[0]=weights[-1]=1.
    f=photon_shape(e)*(e if energy_moment else 1)
    return float(np.dot(weights,f)*(hi-lo)/(3*n))

@dataclass(frozen=True)
class Spectrum:
    energy:np.ndarray
    fraction:np.ndarray
    method:str
    def __post_init__(self):
        _domain(self.energy.ndim==1 and self.energy.size==self.fraction.size and self.energy.size>0,"invalid spectrum shape")
        _domain(bool(np.all(np.isfinite(self.fraction)) and np.all(self.fraction>=0) and np.all(self.energy>=SOURCE_EDGES[0]) and np.all(self.energy<=SOURCE_EDGES[-1])),"invalid spectrum")
        _domain(abs(float(np.sum(self.fraction))-1.)<=2e-13,"source spectrum not normalized")

def spectral_nodes(subnodes:int=0, per_segment:int=16, split_d_threshold:bool=False)->Spectrum:
    """subnodes=0 returns EXACT P3 cell photon-number means; >=2 Gauss in log E."""
    _domain(1<=per_segment<=1024 and (subnodes==0 or 2<=subnodes<=64),"invalid cell/subquadrature")
    _domain(not (subnodes==0 and split_d_threshold),"native owner cell means cannot split the D threshold")
    ens=[];ws=[]
    if subnodes: nodes,weights=leggauss(subnodes)
    for a,b in zip(SOURCE_EDGES[:-1],SOURCE_EDGES[1:]):
        for j in range(per_segment):
            lo=a*(b/a)**(j/per_segment)
            hi=b if j+1==per_segment else a*(b/a)**((j+1)/per_segment)
            if subnodes==0:
                z=simpson_native(lo,hi,False)
                ens.append(simpson_native(lo,hi,True)/z);ws.append(z)
            else:
                # Critical extra split at the manufactured chi_D=13.602134599702 eV.
                # This edge falls INSIDE the first original H source cell.
                # Splitting it is an independent quadrature, not a source rewrite.
                cuts=[lo]
                if split_d_threshold and lo<CHIS[3]<hi: cuts.append(float(CHIS[3]))
                cuts.append(hi)
                for seglo,seghi in zip(cuts[:-1],cuts[1:]):
                    # Integrate photon shape dE = E d(log E), not d(log E) alone.
                    ul,ur=math.log(seglo),math.log(seghi)
                    u=(ul+ur)/2+(ur-ul)/2*nodes
                    e=np.exp(u)
                    w=(ur-ul)/2*weights*photon_shape(e)*e
                    ens.extend(e.tolist());ws.extend(w.tolist())
    w=np.asarray(ws);w/=np.sum(w)
    return Spectrum(np.array(ens),w,"native_cell_mean_simpson32" if subnodes==0 else f"logGauss{subnodes}"+("_DthresholdSplit" if split_d_threshold else ""))


def angle_nodes(nmu:int=8)->tuple[np.ndarray,np.ndarray]:
    _domain(nmu in (8,16,32),"PR150 source GL only 8/16/32")
    mu,w=leggauss(nmu)
    return mu,w/2


def ray_energy(eb:np.ndarray,mu:np.ndarray,elapsed:float,h:float,s:float)->np.ndarray:
    """Exact diagonal Bianchi-I Killing energy, each birth at elapsed=0."""
    _domain(elapsed>=0 and all(map(math.isfinite,(elapsed,h,s))),"invalid proper time/geometry")
    _domain(bool(np.all(eb>0) and np.all(np.abs(mu)<=1)),"invalid ray")
    x=s*elapsed
    ratio=math.exp(-h*elapsed)*np.sqrt((1-mu*mu)*math.exp(2*x)+mu*mu*math.exp(-4*x))
    return eb*ratio


def phi_and_missing(tau:np.ndarray)->tuple[np.ndarray,np.ndarray]:
    """phi=(1-exp(-tau))/tau, missing=1-phi, cancellation-safe at tau=0."""
    _domain(bool(np.all(np.isfinite(tau)) and np.all(tau>=0)),"negative or nonfinite optical depth")
    phi=np.empty_like(tau,dtype=float)
    missing=np.empty_like(tau,dtype=float)
    small=tau<1e-3
    x=tau[small]
    phi[small]=1-x/2+x*x/6-x**3/24+x**4/120-x**5/720+x**6/5040
    missing[small]=x/2-x*x/6+x**3/24-x**4/120+x**5/720-x**6/5040
    q=tau[~small]
    phi[~small]=-np.expm1(-q)/q
    missing[~small]=1-phi[~small]
    return phi,missing

@dataclass(frozen=True)
class Result:
    survivors:float
    absorbed:np.ndarray
    injected:float
    emitted_energy_ev:float
    survivor_energy_ev:float
    thermal_energy_ev:float
    binding_energy_ev:float
    geometric_work_ev:float
    number_residual:float
    energy_residual:float


def integrate(*,scheme:str,nsteps:int,spectrum:Spectrum|None=None,nmu:int=8,
              total_s:float=8e10,h:float=0.,shear:float=0.,density_scale:float=1.,
              rate_slopes:tuple[float,float,float,float]=(0.,0.,0.,0.),
              source_slope:float=0., physical_md14:bool=False, source_on:bool=True,
              initial_pulse:bool=False)->Result:
    """Shared photon transport with source/time/spectral convergence axes.

    Old pre-existing photons and continuously born photons see one competing pool.
    scheme='p3_full_step' reproduces P3's newborn-full-tau algebra at fixed opacity.
    scheme='phi_birth' analytically integrates newborn survival under slab-frozen j,k.
    This *independent* model freezes species fractions and T (not native chemistry).
    For h/shear != 0, birth substep ray-at-midpoint is a declared approximation.
    """
    _domain(scheme in ('p3_full_step','phi_birth'),"invalid scheme")
    _domain(nsteps>=1 and math.isfinite(total_s) and total_s>0 and density_scale>0 and math.isfinite(density_scale),"time/density domain")
    _domain(all(-.95<=x<=10. and math.isfinite(x) for x in rate_slopes) and math.isfinite(source_slope) and -.95<=source_slope<=10.,"time modulation nonnegative")
    _domain(source_on or initial_pulse,"no initial photons and no source")
    _domain(not ((h!=0 or shear!=0) and source_on),
            "birth-age-dependent Killing propagation not implemented: use initial_pulse only")
    if spectrum is None:spectrum=spectral_nodes()
    mu,wm=angle_nodes(nmu)
    e=spectrum.energy[:,None]*np.ones((1,len(mu)))
    mub=np.ones((len(e),1))*mu[None,:]
    photon_fraction=spectrum.fraction[:,None]*wm[None,:]
    alive=np.array(photon_fraction,copy=True) if initial_pulse else np.zeros_like(e)
    absorbed=np.zeros(4)
    injected=1.0 if initial_pulse else 0.
    energy_inj=float(np.sum(alive*e)) if initial_pulse else 0.
    energy_abs=0.;thermal=0.;binding=0.;geom=0.
    dt=total_s/nsteps
    for i in range(nsteps):
        a=i*dt;mid=(i+.5)*dt;b=(i+1)*dt
        birth_shape=md14_relative_emission(mid,h) if physical_md14 else 1.
        birth_total=(1+source_slope*mid/total_s)*birth_shape*dt/total_s if source_on else 0.
        birth=photon_fraction*birth_total
        injected+=float(np.sum(birth))
        energy_inj+=float(np.sum(birth*e))
        # After drift at midpoint, frozen opacity uses physically proper densities.
        # All photons in this isolated model share energy R(t) when source age is zero.
        energy_a=ray_energy(e,mub,a,h,shear)
        energy_mid=ray_energy(e,mub,mid,h,shear)
        energy_b=ray_energy(e,mub,b,h,shear)
        geom+=float(np.sum(alive*(energy_mid-energy_a)))
        k=np.stack([verner_sigma_m2(j,energy_mid) for j in range(4)])
        nscale=np.array([(1+rate_slopes[j]*mid/total_s) for j in range(4)])*density_scale*math.exp(-3*h*mid)
        k*= (N_PROPER*nscale*C)[:,None,None]
        ktot=np.sum(k,axis=0)
        tau=ktot*dt
        survive=np.exp(-tau)
        old_events=alive*(-np.expm1(-tau))
        if scheme=='p3_full_step':
            new_alive=(alive+birth)*survive
            new_events=birth*(-np.expm1(-tau))
        else:
            phi,missing=phi_and_missing(tau)
            new_alive=alive*survive+birth*phi
            new_events=birth*missing
        event_tot=old_events+new_events
        branch=np.divide(k,ktot[None],out=np.zeros_like(k),where=ktot[None]>0)
        de=branch*event_tot[None]
        absorbed+=np.sum(de,axis=(1,2))
        bind_steps=np.sum(de*CHIS[:,None,None],axis=(1,2))
        bind_energy=float(np.sum(bind_steps))
        phot_energy=float(np.sum(event_tot*energy_mid))
        binding+=bind_energy
        thermal+=phot_energy-bind_energy
        energy_abs+=phot_energy
        geom+=float(np.sum(new_alive*(energy_b-energy_mid)))
        alive=new_alive
    survivors=float(np.sum(alive))
    final_energy=ray_energy(e,mub,total_s,h,shear)
    surv_energy=float(np.sum(alive*final_energy))
    nres=survivors+float(np.sum(absorbed))-injected
    eres=surv_energy+thermal+binding-energy_inj-geom
    _domain(bool(np.all(np.isfinite(absorbed)) and np.all(absorbed>=0) and np.all(alive>=0)),"negative population")
    _domain(bool(thermal>=-5e-12*max(1,energy_inj)),"negative photoheat beyond floating-point")
    return Result(survivors,absorbed,injected,energy_inj,surv_energy,thermal,binding,geom,nres,eres)


def independent_ode_clock_reference(spectrum:Spectrum|None=None,
                                   rate_slopes:tuple[float,float,float,float]=(.4,-.2,.1,.25),
                                   source_slope:float=.65, total_s:float=8e10)->Result:
    """Independent adaptive DOP853 solve of the 5*NE state ODE, no phi stepping.

    The source and four absorber inventories are integrated simultaneously with
    time variable x=t/T; exactly the same manufactured frozen-gas physics.
    This benchmark does not include births' geometrical redshift / native gas RHS.
    """
    from scipy.integrate import solve_ivp
    sp=spectral_nodes() if spectrum is None else spectrum
    n=sp.energy.size
    sigma=np.stack([verner_sigma_m2(j,sp.energy) for j in range(4)])
    lambdaT=(N_PROPER*C*total_s)[:,None]*sigma
    def f(x,y):
        survivors=y[:n]
        k=lambdaT*(1+np.asarray(rate_slopes)[:,None]*x)
        absorbed_rate=k*survivors[None]
        return np.concatenate([sp.fraction*(1+source_slope*x)-np.sum(absorbed_rate,axis=0),
                               absorbed_rate.reshape(-1)])
    res=solve_ivp(f,(0.,1.),np.zeros(5*n),method='DOP853',rtol=3e-12,atol=2e-14)
    _domain(res.success,"independent high-accuracy ODE reference failed")
    y=res.y[:,-1];alive=y[:n];a=y[n:].reshape(4,n)
    absorbed=np.sum(a,axis=1)
    survivor=float(np.sum(alive))
    injected=1+source_slope/2
    energy_emitted=injected*float(np.dot(sp.fraction,sp.energy))
    survivor_energy=float(np.dot(alive,sp.energy))
    bind=float(np.sum(a*CHIS[:,None]))
    therm=float(np.sum(a*sp.energy[None]))-bind
    return Result(survivor,absorbed,injected,energy_emitted,survivor_energy,
                  therm,bind,0.,survivor+float(np.sum(absorbed))-injected,
                  survivor_energy+therm+bind-energy_emitted)


def compare_rows()->list[dict]:
    rows=[]
    base=spectral_nodes()
    # Clock axis at identical 48 owner-cell/GL8 discretization, time-varying
    # opacities/production as a MANUFACTURED smooth test, no Bianchi evolution.
    # An ADAPTIVE ODE reference is used instead of self-comparison to refined phi.
    ref=independent_ode_clock_reference(base)
    for n in (8,16,32,64,128,256):
        for scheme in ('p3_full_step','phi_birth'):
            r=integrate(scheme=scheme,nsteps=n,spectrum=base,
                        source_slope=.65,rate_slopes=(.4,-.2,.1,.25))
            rows.append(dict(lane='clock_manufactured',method=scheme,nsteps=n,spectral_q=0,nmu=8,
                surviving=r.survivors,ref_surv=ref.survivors,relative_error=abs(r.survivors-ref.survivors)/ref.survivors,
                max_event_rel=max(abs(r.absorbed-ref.absorbed)/np.maximum(ref.absorbed,1e-100)),
                photon_ledger=abs(r.number_residual)/max(r.injected,1e-100),
                energy_ledger=abs(r.energy_residual)/max(r.emitted_energy_ev,1e-100)))
    # Spectral axis: corrected clock, same nsteps/GL, native mean vs q2..32.
    ref=integrate(scheme='phi_birth',nsteps=128,spectrum=spectral_nodes(32,split_d_threshold=True))
    for q,split in [(0,False),(2,False),(4,False),(8,False),(16,False),(32,False),
                    (2,True),(4,True),(8,True),(16,True),(32,True)]:
        r=integrate(scheme='phi_birth',nsteps=128,spectrum=spectral_nodes(q,split_d_threshold=split))
        rows.append(dict(lane='spectrum_physical_fit',method='phi_birth_Dsplit' if split else 'phi_birth_unsplit',nsteps=128,spectral_q=q,nmu=8,
            surviving=r.survivors,ref_surv=ref.survivors,relative_error=abs(r.survivors-ref.survivors)/ref.survivors,
            max_event_rel=max(abs(r.absorbed-ref.absorbed)/np.maximum(ref.absorbed,1e-100)),
            photon_ledger=abs(r.number_residual)/max(r.injected,1e-100),
            energy_ledger=abs(r.energy_residual)/max(r.emitted_energy_ev,1e-100)))
    # Angle axis: prescribed off-shell sheared Killing map, redshift and
    # density scaled down to expose long photon's transport memory.
    ref=integrate(scheme='phi_birth',nsteps=256,spectrum=spectral_nodes(4,split_d_threshold=True),nmu=32,
                  total_s=1e14,h=1.2e-16,shear=.08*1.2e-16,density_scale=1e-4,
                  source_on=False,initial_pulse=True)
    for angular in (8,16,32):
        r=integrate(scheme='phi_birth',nsteps=256,spectrum=spectral_nodes(4,split_d_threshold=True),nmu=angular,
                  total_s=1e14,h=1.2e-16,shear=.08*1.2e-16,density_scale=1e-4,
                  source_on=False,initial_pulse=True)
        rows.append(dict(lane='angle_prescribed',method='phi_birth',nsteps=256,spectral_q=4,nmu=angular,
            surviving=r.survivors,ref_surv=ref.survivors,relative_error=abs(r.survivors-ref.survivors)/ref.survivors,
            max_event_rel=max(abs(r.absorbed-ref.absorbed)/np.maximum(ref.absorbed,1e-100)),
            photon_ledger=abs(r.number_residual)/max(r.injected,1e-100),
            energy_ledger=abs(r.energy_residual)/max(r.emitted_energy_ev,1e-100)))
    return rows
