# ISO-COUPLE-P4/S1: 출생–불투명도 시간계약과 D 문턱 양의 스펙트럼 적분

날짜: 2026-10-17 (KST). 연구 지위: **독립 Python sandbox, 부분 이론·수치 검증**. 전체 `ISO-COUPLE-P4` 또는 native EoR/P3 producer 수정으로 간주하지 않는다.

## Source/identity

P3 authority: `cosmosapjw-quantum/rei_bianchi`, Draft PR182 `3a2721e58fc8bd68cdbbc92ca4669bd57609695b`.
- 원본 `AxbiSource` `owner_src/axbi_sources.rs` Git blob `36d24eb13db3fc42321cb0ddb165e003c0a086c7`; `SOURCE_ID=MD14_Z002_FESC_BB50K_13P6_100_V1`; z 4..20; 50,000 K truncated blackbody E in [13.6,100] eV; three source energy segments each 16 logarithmic cells; Gauss–Legendre 8 angular quadrature; 32-panel Simpson photon-moment cell mean.
- 원본 `AtomicProvider` `owner_src/atomic_provider.rs` blob `62211d8910cd332fffa8f94c6989cae77128916e`, Verner et al. (1996) H I/He I/He II parameters and 1e-18 cm² conversion; D approximation `owner_src/deuterium_atomic.rs` blob `9d64984fe091b7e0ed1f13e63ce411b4d6ac5632` uses H photo fit above caller-supplied chi_D, NOT measured isotope-specific photo cross-section.
- Geometry `owner_src/bianchi_i.rs` blob `81dc54583b76e9dcba94c5bbc867243b04ad76b1`. P3 comparator `positive_age.rs` blob `1b715d14b0c0522ddc99f2805cb370c19faf1edd`, `source_age.rs` blob `a4b3365dfb249da92ae598752d7e91eb478b59a0`.
- P3 manufactured D threshold chi_D =13.602134599702 eV (delta chi=.0037 eV above fixture chi_H=13.598434599702 eV) is **not** experimentally adopted isotope binding. The four gas **binding energies** use original `HHeModel::controlled_fixture()` values `(13.598434599702, 24.587389011, 54.41776, 13.602134599702)` eV; these MUST NOT be conflated with Verner `Eth=(13.6,24.59,54.42)` eV or spectral source segment edges. No replacement for an independently sourced D threshold.

## Derived: correct positive source-clock operator

For a single fixed photon energy/direction with photon-number injection `j(t)` and competing nonnegative absorber opacities `kappa_j(t)=n_j(t)c sigma_j(E(t))`, the exact fixed-(j,kappa) time-slab map (Delta t>0) is:

- `tau = Delta t * sum_j kappa_j`.
- `Phi(tau) = (1-exp(-tau))/tau` with `Phi(0)=1`.
- `N' = N exp(-tau) + j Delta t Phi(tau)`.
- `A_j = [N(1-exp(-tau)) + j Delta t(1-Phi(tau))] kappa_j / sum kappa_j` for sum>0 (else zero).

This yields nonnegative `N', A_j`, exact photon conservation `N' + sum A_j = N + j Delta t`, and for E>=threshold_j, nonnegative thermal source `Q_j=(E-chi_j) A_j`, binding `B_j=chi_j A_j`. Under fixed E, `N'E + sum_j (Q_j+B_j)=NE+j Delta t E`.

P3's `PositiveAgeBridge::advance` injects a midpoint-born cohort and immediately calls `photo(dt)` with the entire slab dt. It therefore replaces the exact newborn `j Delta t Phi(tau)` by `j Delta t exp(-tau)`, with leading discrepancy `-0.5*j*kappa*(Delta t)^2 + O(dt^3)` per step. This creates first-order global birth-clock bias under smooth coefficients even when existing-photon attenuation is exponential-exact. *This is a constructive reference comparison, not an approved edit to P3 native owner.*

Use `-expm1(-tau)` and a small-`tau` polynomial for `Phi` and `1-Phi` to avoid subtractive cancellation. For smoothly varying `j,kappa`, substitute midpoint values. This is locally second-order for the full RHS flow where smooth; non-smooth spectral thresholds and ionization changes require separate event-aware and coupled studies.

## Derived: cell-mean and threshold error

Original P3 48 photon-count-weighted cell energy means conserve zeroth and first energy moments, but a channel event functional `F_j(E)` is nonlinear in `sigma(E)` and survival. In a smooth source cell:

`<F_j(E)> - F_j(<E>) = 0.5 F_j''(<E>) Var(E) + O(third central moment)`.

At an absorption threshold `chi_j` *within* the cell, the Taylor smoothness condition fails: an interval must be split at the threshold before applying high-order quadrature. P3's first H source cell contains the **manufactured** D threshold `13.602134599702 eV`; the three source's **fixed outer thresholds** [13.6,24.59,54.42,100] eV do not isolate D. This project implements both an unsplit log-Gauss quadrature and a threshold-split positive quadrature, retaining P3's original 48 photon-mean-cell result unchanged as the q=0 comparator. Nodes/weights are positive by construction and globally renormalized once.

## Actual measured test scope

- Clock lane: same P3 H/He/D photo fits and 48 original source cell means, GL8, normalized time interval 8e10 s, prescribed nonnegative rate factors `1+(.4,-.2,.1,.25)*t/T` and source `1+.65*t/T`. No expansion, gas chemistry or spectrally changing radiation field. Benchmark is **independent DOP853 solution** of 5*48 photon and absorber ODEs, rtol 3e-12, atol 2e-14. This manufactured modulation is not MD14 history.
- Spectral lane: fixed proper absorber densities `(HI,HeI,HeII,DI)=(1000,300,100,25) m^-3`, T=8e10 s, positive midpoint-opacity continuous newborn reference; compare native 48 cell means against logGauss 2/4/8/16/32 per original cell, both unsplit and split exactly at manufactured chi_D. This is a *frozen gas* spectral oracle, not live H/He/D chemistry.
- Angle lane: **one pulse at t=0 only**, Bianchi-I prescribed `H=1.2e-16 s^-1`, `shear=+0.08 H`, `t_end=1e14 s`, density scale 1e-4 to expose the long attenuation/redshift dynamics, exactly transported Killing photon energies. This is off-shell and not normal source-on Bianchi gas; GL8/16/32 time/spectral fixed comparison. Because finite quadrature gives non-monotonic per-species errors, angular convergence is **UNRESOLVED**, not admitted.
- Multibirth + time-dependent Killing geometry (true source age per birth) is explicitly **NOT_IMPLEMENTED**; call rejects this scope, preventing a false energy closure claim. CMB, CX, full H/He/D collision and recombination histories, actual MD14 emissivity source-on redshifting transport and native on-shell BASS all remain HOLD.

## Decision

`ISO-COUPLE-P4/S1 = PASS_SCOPED_PYTHON_SOURCE_CLOCK_AND_FROZEN_SPECTRAL`; parent ISO-COUPLE-P4 remains `PARTIAL`. The first full P4 dependent work is a Rust owner-compatible opt-in mapping of `Phi` to source birth (no ownership duplication), then true cohort-specific birth times and event-aware threshold crossings. Original P3 owner 68/68 Rust test receipts do **not** transfer to this Python modification. No Rust build was performed in this sandbox; Rustc/Cargo are absent. No production accuracy claim.

## Literature

- Verner et al., *Atomic Data for Astrophysics II*, ApJ 465, 487 (1996), DOI: https://doi.org/10.1086/177435.
- Norman et al., *Fully coupled simulation of cosmic reionization I: numerical methods and tests*, ApJS 216, 16 (2015), DOI: https://doi.org/10.1088/0067-0049/216/1/16. Relevant method comparison, not evidence that P4 code matches Enzo.
- Savin (2002), *Rate Coefficients for D(1s)+H+ Charge Transfer*, DOI: https://doi.org/10.1086/324218. H/D CX is the frozen upstream P2 chemistry source, not evaluated in this P4/S1 frozen-gas oracle.
