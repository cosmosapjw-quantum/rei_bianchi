#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHONPATH=src python -m pytest -q tests
PYTHONPATH=src python - <<'PY'
import csv, json, sys, platform
from pathlib import Path
from p4_clock import compare_rows
rows=compare_rows(); output=Path('evidence/p4_error_axes.csv')
with output.open('w',newline='') as f:
    wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
Path('evidence/p4_results.json').write_text(json.dumps(dict(schema='rei.iso.p4.s1.sandbox.v1',python=sys.version,platform=platform.platform(),rows=rows),indent=2)+'\n')
for r in rows: print(r['lane'],r['method'],r['nsteps'],r['spectral_q'],r['nmu'],f"survivor_rel={r['relative_error']:.5g}",f"event_rel={r['max_event_rel']:.5g}")
PY
