# `rei_bianchi` ISO-COUPLE-P4/S1 sandbox package

**2026-10-17.** Adds an independently executed, zero-network Python scientific reference for the **newborn photon exposure clock** and **D-threshold spectral splitting** on the exact PR182 source model and source ownership definitions. This package neither mutates production Rust nor claims the native full Bianchi EoR is solved.

- `src/p4_clock.py`: positive four-channel photon owner, original native 48 source cell means, optional threshold-aware log-Gauss subquadrature, bounded source clock propagators and independent DOP853 ODE comparator.
- `tests/test_p4_clock.py`: executable tests: analytic constant-coefficient control; independent ODE reference; photon-number, energy, threshold and domain failure controls; manufactured convergence; explicit rejection of false multibirth Bianchi age mapping.
- `docs/P4_THEORY_AND_SCOPE_KO.md`: derivation and source identity.
- `evidence/p4_error_axes.csv`, `evidence/p4_results.json`, `evidence/stage_p4_s1_execution.log`: measured benchmark and scoped result.
- `contracts/DAG_PROGRESS.json`, `contracts/SOURCE_PROVENANCE.json`, `contracts/RELEASE_STATUS.json`: checkpoint and protected identity.
- `manifest.sha256`: hashes of members (itself excluded); `PACKAGE_SHA256.txt` is external ZIP checksum.

## Reproduction

Python 3.13, numpy 2.3, scipy 1.17 and pytest 8+; no network and no native Rust are needed.

```sh
./scripts_run.sh
```

`PYTHONPATH=src python -m pytest -q tests` validates the source. `scripts_run.sh` writes complete results and a command log can be captured as `./scripts_run.sh > evidence/stage_p4_s1_execution.log 2>&1`. If a result contract changes, regenerate receipt, not the historical original PR182 evidence.

## Admission

`PASS_SCOPED_PYTHON_SOURCE_CLOCK_AND_FROZEN_SPECTRAL`. Standalone modified-multirate reference. `P4_FULL`, `FLRW-CONV`, `BI-SIGNED`, `FULL_EOR`, native Rust source-on and source-age/opacity-clock admission: **HOLD**.
