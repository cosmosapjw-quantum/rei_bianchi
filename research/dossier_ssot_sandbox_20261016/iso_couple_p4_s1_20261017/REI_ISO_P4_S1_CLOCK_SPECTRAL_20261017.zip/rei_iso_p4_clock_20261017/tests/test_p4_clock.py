import math
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import numpy as np
import pytest
from p4_clock import (spectral_nodes,angle_nodes,verner_sigma_m2,DomainError,
                      ray_energy,integrate,phi_and_missing,SOURCE_EDGES,photon_shape,compare_rows,CHIS,CHI_H)

@pytest.mark.parametrize('q',[0,2,4,8])
def test_positive_normalized_spectral(q):
    sp=spectral_nodes(q)
    assert len(sp.energy)==48*(1 if q==0 else q)
    assert all(np.diff(sp.energy)>0)
    assert abs(sum(sp.fraction)-1)<2e-13

@pytest.mark.parametrize('n',[8,16,32])
def test_angular_GL_normalization(n):
    mu,w=angle_nodes(n)
    assert abs(sum(w)-1)<2e-15
    assert abs(sum(mu*mu*w)-1/3)<2e-14

@pytest.mark.parametrize('energy,kind,expected_zero',[
    (13.59,0,True),(13.602,3,True),(13.604,3,False),
    (24.58,1,True),(24.6,1,False),(54.4,2,True),(54.5,2,False)])
def test_exact_threshold_gates(energy,kind,expected_zero):
    val=float(verner_sigma_m2(kind,energy))
    assert (val==0)==expected_zero

@pytest.mark.parametrize('tau',[0.,1e-14,1e-8,1e-4,.3,5.,70.,1e3])
def test_phi_positive_and_identity(tau):
    p,m=phi_and_missing(np.array([tau]))
    assert 0<=p[0]<=1 and 0<=m[0]<=1
    assert abs(p[0]+m[0]-1)<4e-15
    if tau==0: assert p[0]==1 and m[0]==0
    else: assert abs(tau*p[0]-(-math.expm1(-tau)))<5e-12

def test_exact_killing_FLRW_and_signed_quadrupole():
    e=np.array([[30.0]])
    mu=np.array([[.7]])
    assert abs(ray_energy(e,mu,1e14,1.2e-16,0)[0,0]/30-math.exp(-.012))<3e-15
    up=ray_energy(e,mu,1e14,1.2e-16,.08*1.2e-16)[0,0]
    dn=ray_energy(e,mu,1e14,1.2e-16,-.08*1.2e-16)[0,0]
    assert up!=dn

@pytest.mark.parametrize('scheme',['p3_full_step','phi_birth'])
def test_competing_photon_charge_energy_ledgers(scheme):
    r=integrate(scheme=scheme,nsteps=16)
    assert r.injected>0 and r.survivors>=0
    assert np.all(r.absorbed>=0)
    assert abs(r.number_residual)/r.injected<3e-13
    assert abs(r.energy_residual)/r.emitted_energy_ev<3e-13
    assert r.thermal_energy_ev>=0

def test_analytic_constant_coefficient_birth_clock():
    # At constant opacity/emissivity phi_birth is exactly independent of time grid.
    a=integrate(scheme='phi_birth',nsteps=1)
    b=integrate(scheme='phi_birth',nsteps=64)
    old=integrate(scheme='p3_full_step',nsteps=1)
    assert abs(a.survivors-b.survivors)<4e-14
    assert np.max(abs(a.absorbed-b.absorbed))<4e-14
    assert old.survivors<a.survivors

def test_manufactured_changing_rates_convergence():
    kw=dict(source_slope=.65,rate_slopes=(.4,-.2,.1,.25))
    ref=integrate(scheme='phi_birth',nsteps=4096,**kw)
    clock=[];old=[]
    for n in (16,32,64):
        clock.append(abs(integrate(scheme='phi_birth',nsteps=n,**kw).survivors-ref.survivors))
        old.append(abs(integrate(scheme='p3_full_step',nsteps=n,**kw).survivors-ref.survivors))
    assert clock[0]/clock[1]>3.3 and clock[1]/clock[2]>3.2
    assert old[0]/old[1]>1.6 and old[1]/old[2]>1.6

def test_spectral_quadrature_and_photon_counts():
    kwargs=dict(scheme='phi_birth',nsteps=64)
    coarse=integrate(spectrum=spectral_nodes(0),**kwargs)
    accurate=integrate(spectrum=spectral_nodes(16),**kwargs)
    refine=integrate(spectrum=spectral_nodes(32),**kwargs)
    assert abs(accurate.survivors-refine.survivors)<1e-6
    assert abs(coarse.survivors-refine.survivors)>1e-7

@pytest.mark.parametrize('bad',[-1.,float('nan'),float('inf')])
def test_fail_closed_negative_tau(bad):
    with pytest.raises(DomainError):phi_and_missing(np.array([bad]))

@pytest.mark.parametrize('nsteps',[-2,0])
def test_invalid_steps(nsteps):
    with pytest.raises(DomainError):integrate(scheme='phi_birth',nsteps=nsteps)

def test_invalid_spectrum_energy_not_imputed():
    with pytest.raises(DomainError):photon_shape([13.59])
    with pytest.raises(DomainError):verner_sigma_m2(0,-.1)



def test_threshold_split_stabilizes_deuterium_event():
    kw=dict(scheme='phi_birth',nsteps=32)
    r4=integrate(spectrum=spectral_nodes(4,split_d_threshold=True),**kw)
    r8=integrate(spectrum=spectral_nodes(8,split_d_threshold=True),**kw)
    r32=integrate(spectrum=spectral_nodes(32,split_d_threshold=True),**kw)
    assert abs(r4.absorbed[3]-r32.absorbed[3]) < 1e-7
    assert abs(r8.absorbed[3]-r32.absorbed[3]) < 1e-9


def test_sheared_pulse_exact_energy_ledger():
    r=integrate(scheme='phi_birth',nsteps=128,spectrum=spectral_nodes(4,split_d_threshold=True),
                total_s=1e14,h=1.2e-16,shear=.08*1.2e-16,
                density_scale=1e-4,source_on=False,initial_pulse=True)
    assert abs(r.number_residual)/r.injected < 3e-13
    assert abs(r.energy_residual)/r.emitted_energy_ev < 3e-13


def test_no_fake_multibirth_ray_age():
    with pytest.raises(DomainError,match='birth-age'):
        integrate(scheme='phi_birth',nsteps=8,h=1.2e-16)


def test_independent_DOP853_source_ODE_reference():
    from p4_clock import independent_ode_clock_reference
    ref=independent_ode_clock_reference()
    kw=dict(source_slope=.65,rate_slopes=(.4,-.2,.1,.25))
    refined=integrate(scheme='phi_birth',nsteps=4096,**kw)
    assert abs(ref.survivors-refined.survivors)<4e-9
    assert max(abs(ref.absorbed-refined.absorbed))<3e-9
    assert abs(ref.number_residual)<2e-11
    assert abs(ref.energy_residual)/ref.emitted_energy_ev<2e-11


def test_fixture_binding_vs_verner_threshold_not_confused():
    # Source-locked from immutable PR182 owner_src/hhe_events.rs
    assert CHI_H == 13.598434599702
    assert abs(CHIS[3] - 13.602134599702)<2e-15
    assert CHIS[0] < SOURCE_EDGES[0] < CHIS[3] < 13.61
    assert CHIS[1] < 24.59 and CHIS[2] < 54.42
    # Binding edge != Verner fit edge: the original owner imposes both guards.
    assert verner_sigma_m2(1, 24.588) == 0
    assert verner_sigma_m2(2, 54.419) == 0
    assert float(verner_sigma_m2(3, CHIS[3]-1e-6)) == 0
    assert float(verner_sigma_m2(3, CHIS[3]+1e-6)) > 0


def test_reproduces_source_native_simpson_normalization_receipt():
    """Finite-quadrature reconstruction of the documented source-only P3 receipt.

    Float summation order is not Git byte identity; compare numerical identities.
    """
    from p4_clock import simpson_native
    norm = 0.0
    for a, b in zip(SOURCE_EDGES[:-1],SOURCE_EDGES[1:]):
        for j in range(16):
            lo = a*(b/a)**(j/16)
            hi = b if j == 15 else a*(b/a)**((j+1)/16)
            norm += simpson_native(lo,hi,False)
    n=4096
    e=np.linspace(SOURCE_EDGES[0],SOURCE_EDGES[-1],n+1)
    w=np.full(n+1,2.);w[1:-1:2]=4.;w[0]=w[-1]=1.
    reference=float(np.dot(w,photon_shape(e))*(e[-1]-e[0])/(3*n))
    original_p3_receipt=3.500755241248044e-12
    assert abs(abs(norm/reference-1)-original_p3_receipt)<3e-15
