#!/usr/bin/env python3
"""Independent exact-integral cell-mean diagnosis, not a new source provider."""
from pathlib import Path
import json,math
from scipy.integrate import quad
from scipy.optimize import brentq
from analyze_p7 import shape,CHI
ROOT=Path(__file__).resolve().parents[1]
def mean(n):
    a=13.6;b=a*(24.59/a)**(1/n)
    return quad(lambda e:e*shape(e),a,b,epsabs=1e-13,epsrel=3e-13)[0]/quad(shape,a,b,epsabs=1e-13,epsrel=3e-13)[0]
data={'chi_D_eV':float(CHI[3]),'source_HI_edge_eV':13.6,
      'conditional_mean_E_eV':{str(n):mean(n) for n in (16,32,64,128,1024)},
      'continuous_n_at_first_mean_equal_D':brentq(lambda n:mean(n)-CHI[3],1024.,4096.),
      'birth_photon_fraction_below_D':quad(shape,13.6,float(CHI[3]))[0]/quad(shape,13.6,100.)[0],
      'owner_cell_cap':1024,
      'proof':'For any positive w, M(b)=int_a^b E w/int_a^b w has Mprime=w(b)(b-M)/int_a^b w>0. b(n) decreases with n; minimum accepted first-cell mean is therefore at maximum n. Even n1024 mean exceeds chiD. This explains an unresolved D edge for THIS cell-mean discretization, not a no-go for spectral transport.',
      'scope':'Static original truncated50k blackbody, first13.6-24.59eV segment; independent SciPy integral, not exact isotope data.'}
assert data['conditional_mean_E_eV']['1024']>CHI[3]
(ROOT/'evidence/EDGE_DIAGNOSIS.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data,indent=2))
