#!/usr/bin/env python3
"""Source-native scoped convergence, independent fixed-physics oracle checks.
A refinement difference is NOT an a priori global error certificate.
"""
from __future__ import annotations
import csv,json,math,sys
from pathlib import Path
import numpy as np
from scipy.integrate import quad,quad_vec
from numpy.polynomial.legendre import leggauss
ROOT=Path(__file__).resolve().parents[1]
OBS=('photons_com3','HI','HeI','HeII','DI','T_K','q2_E','mean_age_s')
INPUT=('scenario','nsteps','cells','angles','birth','opacity','split','shear_ratio','H_s','duration_s','full_chemistry')
CHI=np.array([13.598434599702,24.587389011,54.41776,13.602134599702])
EDGES=(13.6,CHI[3],24.59,54.42,100.)
C=299792458.;KT=50000.*1.380649e-23/1.602176634e-19

def order(q: list[float]) -> dict:
    if len(q)!=3 or not all(math.isfinite(x) for x in q):raise ValueError('three finite levels required')
    d0=q[0]-q[1];d1=q[1]-q[2]
    floor=64*np.finfo(float).eps*max(abs(x) for x in q)
    result={'differences':[d0,d1],'floating_scale_floor':float(floor)}
    if min(abs(d0),abs(d1))<=floor:return dict(result,status='ROUND_OFF_OR_STAGNATION',p=None)
    if (d0>0)!=(d1>0):return dict(result,status='NONMONOTONE_NO_ORDER_ADMITTED',p=None)
    p=math.log2(abs(d0/d1))
    return dict(result,status='OBSERVED_ASYMPTOTIC_CANDIDATE' if p>0 else 'NOT_DECREASING',p=p)

def same_axis(a: dict,b: dict,axis: str) -> dict:
    changed=[k for k in INPUT if a[k]!=b[k]]
    if changed!=[axis]:raise ValueError(f'not one-axis change: {changed}, expected{axis}')
    return {'coarse':a['id'],'fine':b['id'],'changed_axis':axis,
      'absolute_difference':{v:float(a[v])-float(b[v]) for v in OBS},
      'relative_difference_to_finite_fine':{v:((float(a[v])-float(b[v]))/abs(float(b[v])) if float(b[v])!=0 else None) for v in OBS},
      'interpretation':'paired finite-grid sensitivity, not certified continuum error'}

def sigma(e: float)->np.ndarray:
    pars=((13.6,.4298,5.475e4,32.88,2.963,0.,0.,0.),
          (24.59,13.61,949.2,1.469,3.188,2.039,.4434,2.136),
          (54.42,1.720,1.369e4,32.88,2.963,0.,0.,0.))
    out=[]
    for eth,e0,s0,ya,p,yw,y0,y1 in pars:
        if e<eth:out.append(0.);continue
        x=e/e0-y0;y=math.sqrt(x*x+y1*y1)
        out.append(s0*((x-1)**2+yw*yw)*y**(p/2-5.5)*(1+math.sqrt(y/ya))**(-p)*1e-22)
    out.append(out[0] if e>=CHI[3] else 0.)
    return np.array(out)

def shape(e):return e*e/math.expm1(e/KT)

def static_reference()->tuple[dict,float]:
    norm=quad(shape,13.6,100.,epsabs=1e-11,epsrel=2e-13)[0]
    density=np.array([1000.,300.,100.,25.]);duration=8e10
    def f(e):
        rates=C*density*sigma(e);k=sum(rates);tau=k*duration
        phi=-math.expm1(-tau)/tau if tau else 1.
        events=(1-phi)*rates/k if k else np.zeros(4)
        heat=float(np.dot(events,e-CHI));binding=float(np.dot(events,CHI))
        return shape(e)/norm*np.array([phi,*events,e,phi*e,(1-phi)*e,heat,binding])
    result=np.zeros(10);err=0.
    for l,h in zip(EDGES,EDGES[1:]):
        val,ee=quad_vec(f,l,h,epsabs=1e-13,epsrel=2e-13)
        result+=val;err+=ee
    keys=('survive','HI','HeI','HeII','DI','mean_E_eV','surv_E_eV','abs_E_eV','heat_eV','binding_eV')
    return dict(zip(keys,map(float,result))),float(err)

def transparent_reference(shear_ratio:float,nmu:int=128)->dict:
    mu,w=leggauss(nmu);w*=.5;h=2e-15;T=1e14;s=shear_ratio*h
    def f(u):
        zp=21.*math.exp(-h*T*u)
        sfr=zp**2.7/(1+(zp/2.9)**5.6)
        age=T*(1-u)
        gt=math.exp(-(h-s)*age);gl=math.exp(-(h+2*s)*age)
        g=np.sqrt((1-mu**2)*gt*gt+mu**2*gl*gl)
        m=mu*gl/g;p2=(3*m*m-1)/2
        return sfr*np.array([1.,np.dot(w,g),np.dot(w,g*p2),1-u])
    v,err=quad_vec(f,0.,1.,epsabs=1e-13,epsrel=2e-13)
    logyield=1/(.00038*.002**.227+.01858)-math.log10(2.55)
    amp=.2*10**logyield*.015/(3.085677581491367e24)**3*1e6
    return dict(q2_E=float(v[2]/v[1]),mean_age_s=float(T*v[3]/v[0]),emitted_com3=float(amp*T*v[0]),quadrature_error_estimate=float(err),reference_angular_nodes=nmu)

def analyze(root:Path=ROOT)->dict:
    plan=json.loads((root/'contracts/NUMERICAL_MATRIX.json').read_text())
    rows={}; missing={}
    for p in plan:
        path=root/'evidence/rows'/f"{p['id']}.csv"
        if not path.exists():
            state=json.loads((root/'evidence/rows'/f"{p['id']}.run.json").read_text())
            assert state['status']=='DEFERRED_RESOURCE_BOUND',state
            missing[p['id']]=state;continue
        rr=list(csv.DictReader(path.open()));assert len(rr)==1 and rr[0]['id']==p['id'] and None not in rr[0]
        r=rr[0];rows[r['id']]=r
        assert r['cells']==str(p['e']) and r['split']==str(p['s'])
        numeric=[float(v) for k,v in r.items() if k not in ('id','scenario','full_chemistry')]
        assert all(math.isfinite(v) for v in numeric)
        if p['scenario']=='static':
            assert abs(float(r['survive'])+sum(float(r[k]) for k in ('HI','HeI','HeII','DI'))-1)<3e-13
        else:
            for k,pkey in [('nsteps','n'),('angles','a'),('birth','b'),('opacity','m')]:assert r[k]==str(p[pkey])
            assert float(r['max_number_ledger'])<3e-10 and float(r['max_energy_ledger'])<3e-10
            assert float(r['source_norm'])<1e-7
            assert 0<=float(r['mean_age_s'])<=float(r['duration_s'])
            if r['full_chemistry']=='true':assert all(float(r[k])>0 for k in ('RR_com3','CX_abs_com3','FF_J','CMB_abs_J'))
            else:assert all(float(r[k])==0 for k in ('RR_com3','CX_abs_com3','FF_J','CMB_abs_J'))
    assert len(rows)==38 and len(missing)==2,(len(rows),missing)
    order_records={}
    for family,ns in [('time_mean',[8,16,32,64,128]),('time_split',[8,16,32])]:
        series=[rows[f'{family}_{n}'] for n in ns]
        for a,b in zip(series,series[1:]):same_axis(a,b,'nsteps')
        order_records[family]={key:[order([float(r[key]) for r in series[i:i+3]]) for i in range(len(series)-2)] for key in OBS}
    pairs=[]
    for a,b,axis in [('birth_2','time_split_16','birth'),('opacity_1','opacity_2','opacity'),('opacity_2','opacity_4','opacity'),('opacity_4','time_split_16','opacity'),('time_split_16','opacity_16','opacity'),('time_split_16','spec_split_32','cells'),('spec_split_32','spec_split_64','cells'),('spec_mean_16','spec_mean_32','cells'),('spec_mean_32','spec_mean_64','cells'),('spec_mean_16','time_split_16','split'),('time_split_8','angle16_n8','angles'),('angle16_n8','angle32_n8','angles'),('time_split_16','angle_16','angles'),('trans_angle_8','trans_angle_16','angles'),('trans_angle_16','trans_angle_32','angles'),('trans_birth2','trans_angle_32','birth')]:
        pairs.append(same_axis(rows[a],rows[b],axis))
    static,estimate=static_reference()
    static_compare=[]
    for id,r in rows.items():
        if id.startswith('static_'):
            err={k:(float(r[k])-static[k])/abs(static[k]) for k in static}
            static_compare.append(dict(id=id,cells=int(r['cells']),split=int(r['split']),relative_errors=err,max_species_relative_error=max(abs(err[k]) for k in ('HI','HeI','HeII','DI'))))
    # Highest split spectrum checked against an independent continuous integral.
    fine=next(r for r in static_compare if r['id']=='static_e128_s1')
    assert fine['max_species_relative_error']<1e-10,fine
    transparent=[]
    for id,r in rows.items():
        if id.startswith('trans_'):
            ref=transparent_reference(float(r['shear_ratio']))
            ref256=transparent_reference(float(r['shear_ratio']),256)
            assert abs(ref['q2_E']-ref256['q2_E'])<2e-13
            transparent.append(dict(id=id,reference=ref,q2_absolute_error=float(r['q2_E'])-ref['q2_E'],age_relative_error=float(r['mean_age_s'])/ref['mean_age_s']-1,emitted_relative_error=float(r['emitted_com3'])/ref['emitted_com3']-1))
    mixed={v:((float(rows['time_split_32'][v])-float(rows['time_split_16'][v]))-(float(rows['mixed_mean32'][v])-float(rows['spec_mean_16'][v]))) for v in OBS}
    native=[r for k,r in rows.items() if not k.startswith('static')]
    return dict(schema='rei.iso.p4.s7.analysis.v1',status='PASS_SCOPED_SEPARATED_RESOLUTION_AND_INDEPENDENT_ORACLES',complete_rows=len(rows),native_histories=len(native),static_rows=len(static_compare),deferred=missing,
       observed_orders=order_records,one_axis_pairs=pairs,static_continuous_reference=static,static_reference_error_estimate=estimate,static_comparison=static_compare,transparent_comparison=transparent,mixed_time_spectral_difference=mixed,
       max_number_ledger=max(float(r['max_number_ledger']) for r in native),max_energy_ledger=max(float(r['max_energy_ledger']) for r in native),
       absolute_error_certification=False,global_eor='HOLD',on_shell_BASS_intake='NOT_PERFORMED_SELECTED_SEPARATED_CONVERGENCE_UNIT',birth_axis='TWO_LEVEL_SENSITIVITY_ONLY_GL2_VS_GL4')

if __name__=='__main__':
    root=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT
    try:result=analyze(root)
    except (AssertionError,ValueError,OSError) as e:print('VALIDATION_FAILED',repr(e),file=sys.stderr);raise
    (root/'evidence/SCIENCE_RESULTS.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:result[k] for k in ('status','complete_rows','native_histories','max_number_ledger','max_energy_ledger')}))
    print('static',[(r['id'],r['max_species_relative_error']) for r in result['static_comparison']])
    print('transparent',[(r['id'],r['q2_absolute_error']) for r in result['transparent_comparison']])
