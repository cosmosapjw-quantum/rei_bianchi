from pathlib import Path
import sys,math
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from analyze_p7 import order,same_axis,INPUT

def test_exact_first_order_plus_fixed_other_axis_bias():
    q=[4.+.3+2*h for h in [1.,.5,.25]]
    assert math.isclose(order(q)['p'],1.,abs_tol=1e-13)
def test_turning_sequence_is_not_misreported_as_high_order():
    result=order([1.,1.00001,1.00000999])
    assert result['p'] is None and result['status']=='NONMONOTONE_NO_ORDER_ADMITTED'
def test_roundoff_cannot_be_promoted_to_convergence():
    assert order([1.,1.,1.])['status']=='ROUND_OFF_OR_STAGNATION'
def test_nonfinite_levels_fail_closed():
    with pytest.raises(ValueError):order([1.,float('nan'),2.])
def test_two_changed_axes_are_rejected():
    a={k:'1' for k in INPUT};b=dict(a);b['birth']='2';b['angles']='2'
    with pytest.raises(ValueError):same_axis(a,b,'birth')
