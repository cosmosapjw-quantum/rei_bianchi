#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
export CARGO_BUILD_JOBS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export RUST_BACKTRACE=0
cd "$ROOT"
python scripts/verify_sources.py
python -m pytest -q scripts/tests
cd rei_iso_couple_p4_s7
cargo test --offline --locked --all-targets -- --test-threads=1
cargo clippy --offline --locked --all-targets -- -D warnings
rustfmt --edition 2024 --check src/resolution_study.rs tests/p7_resolution.rs examples/p7_convergence.rs
cargo build --offline --locked --release --example p7_convergence
cd "$ROOT"
if [[ "${1:-targeted}" == full ]]; then
    if [[ -d evidence/rows ]]; then mv evidence/rows "evidence/rows_before_replay_$(date +%s)"; fi
    python scripts/run_matrix.py all
else
    # Preserve expensive evidence and reproduce a representative new GL32 row.
    rei_iso_couple_p4_s7/target/release/examples/p7_convergence angle32_n8 coupled 8 16 32 4 8 1 0.06 > evidence/TARGETED_REPLAY.csv
    python - <<'PY'
import csv
from pathlib import Path
old=list(csv.DictReader(Path('evidence/rows/angle32_n8.csv').open()))[0]
new=list(csv.DictReader(Path('evidence/TARGETED_REPLAY.csv').open()))[0]
assert old.keys()==new.keys()
for key in old:
    if key!='wall_s':assert old[key]==new[key],(key,old[key],new[key])
print('PASS: fresh GL32 positive row scientific columns match; timing excluded')
PY
fi
python scripts/analyze_p7.py
python scripts/edge_diagnosis.py
