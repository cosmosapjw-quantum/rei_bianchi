#!/usr/bin/env python3
"""One bounded process per independent row; interrupted rows never admitted."""
import csv,json,subprocess,time,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PLAN=[]
def row(id,scenario='coupled',n=16,e=16,a=8,b=4,m=8,s=1,sh=.06):
    PLAN.append(dict(id=id,scenario=scenario,n=n,e=e,a=a,b=b,m=m,s=s,sh=sh))
for n in (8,16,32,64,128): row(f'time_mean_{n}',n=n,b=2,m=4,s=0)
for n in (8,16,32,64): row(f'time_split_{n}',n=n)
row('birth_2',b=2)
for m in (1,2,4,16): row(f'opacity_{m}',m=m)
for e in (32,64):row(f'spec_split_{e}',e=e)
for e in (16,32,64):row(f'spec_mean_{e}',e=e,s=0)
for a in (16,32):row(f'angle_{a}',a=a)
for a in (16,32):row(f'angle{a}_n8',n=8,a=a)
row('flrw_mean',b=2,m=4,s=0,sh=0.)
row('minus_mean',b=2,m=4,s=0,sh=-.06)
row('mixed_mean32',n=32,s=0)
for a in (8,16,32):row(f'trans_angle_{a}',scenario='transparent',n=8,a=a,m=1,s=0,sh=1.5)
row('trans_zero',scenario='transparent',n=8,m=1,s=0,sh=0.)
row('trans_minus',scenario='transparent',n=8,a=32,m=1,s=0,sh=-1.5)
row('trans_birth2',scenario='transparent',n=8,a=32,b=2,m=1,s=0,sh=1.5)
for e in (16,32,64,128):
    for s in (0,1):row(f'static_e{e}_s{s}',scenario='static',n=1,e=e,s=s)
(ROOT/'contracts/NUMERICAL_MATRIX.json').write_text(json.dumps(PLAN,indent=2)+'\n')
(ROOT/'evidence/rows').mkdir(exist_ok=True)
exe=ROOT/'rei_iso_couple_p4_s7/target/release/examples/p7_convergence'
select=sys.argv[1:] or [r['id'] for r in PLAN]
if select==['--list']:
    print('\n'.join(f"{i}: {r['id']}" for i,r in enumerate(PLAN)));raise SystemExit(0)
chosen=[r for r in PLAN if r['id'] in select or 'all' in select]
assert chosen,select
DEFERRED={'time_split_64':'Observed N32 split14.64s, quadratic extrapolation exceeds45s per-row bound',
          'angle_32':'N16 angular refinement was interrupted; matched GL8/16/32 test moved to N8 within bound'}
for r in chosen:
    out=ROOT/'evidence/rows'/f"{r['id']}.csv"
    if out.exists():
        previous=list(csv.DictReader(out.open()))
        assert len(previous)==1 and previous[0]['id']==r['id'] and None not in previous[0]
        print('RETAIN_COMPLETE',r['id']);continue
    if r['id'] in DEFERRED:
        (ROOT/'evidence/rows'/f"{r['id']}.run.json").write_text(json.dumps({'id':r['id'],'status':'DEFERRED_RESOURCE_BOUND','reason':DEFERRED[r['id']]},indent=2)+'\n')
        print('DEFERRED',r['id']);continue
    args=[str(exe)]+[str(r[k]) for k in ['id','scenario','n','e','a','b','m','s','sh']]
    start=time.monotonic();state={'id':r['id'],'command':args,'timeout_s':45}
    try:
        p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=45)
        state.update(returncode=p.returncode,wall_s=time.monotonic()-start)
        (ROOT/'evidence/rows'/f"{r['id']}.stderr").write_text(p.stderr)
        if p.returncode:state['status']='FAILED';print('FAILED',r['id'],p.stderr[-500:])
        else:
            rows=list(csv.DictReader(p.stdout.splitlines()))
            assert len(rows)==1 and rows[0]['id']==r['id'] and None not in rows[0],r
            out.write_text(p.stdout);state['status']='COMPLETE';print('COMPLETE',r['id'],round(state['wall_s'],3))
    except subprocess.TimeoutExpired as e:
        state.update(status='TIMEOUT_NOT_ADMITTED',wall_s=time.monotonic()-start)
        (ROOT/'evidence/rows'/f"{r['id']}.partial").write_text(str(e.stdout or ''))
        print('TIMEOUT',r['id'])
    (ROOT/'evidence/rows'/f"{r['id']}.run.json").write_text(json.dumps(state,indent=2)+'\n')
    sys.stdout.flush()
