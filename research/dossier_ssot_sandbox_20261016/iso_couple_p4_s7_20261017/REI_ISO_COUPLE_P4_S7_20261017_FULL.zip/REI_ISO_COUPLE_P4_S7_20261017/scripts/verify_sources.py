#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[1];C=R/'rei_iso_couple_p4_s7'
p=json.loads((R/'contracts/SOURCE_LOCK.json').read_text())
for name,digest in p['parent_crate_files_sha256'].items():
    data=(C/name).read_bytes()
    if name=='src/lib.rs':
        suffix=p['expected_lib_suffix'].encode();assert data.endswith(suffix);data=data[:-len(suffix)]
    assert hashlib.sha256(data).hexdigest()==digest,name
print('PASS:57 parent crate files including exact lib suffix removal;12 physical owners unchanged')
