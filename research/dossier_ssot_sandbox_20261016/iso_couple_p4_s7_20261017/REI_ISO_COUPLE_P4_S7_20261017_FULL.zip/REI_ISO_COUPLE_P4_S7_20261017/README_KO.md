# REI ISO-COUPLE P4/S7, 2026-10-17

시간/출생시각/opacity/분광/각도 resolution을 독립적으로 비교한 source-native Rust 연구 패키지다. Parent PR188 HEAD9f9837c0587e616ec351980fdbaab6dea799d027. 원본57-file crate를 보존했고 lib.rs의 module export와 신규 positive-only adapter/observer/reference/tests/runner만 추가했다.

## 결과

119 Rust tests와5 Python analysis tests PASS. 40계획 중38완료(30 native histories,8 frozen spectral references),2 high-cost points는 deferred로 명시했다. 가장 중요한 결과는 (1) 총 photon survivor가 안정돼 보여도 DI/온도는 약1차 시간수렴, (2) 원 cellmean을16→128로 촘촘하게 해도 unresolved D edge 오차가 약3.5e-4에 남고, 문턱분할GL3는 독립 연속적분으로 수렴, (3) 큰 비등방성 transparent 대조군에서 angular GL8/16/32 및 birthGL2/4 오차를 분리한 것이다.

전체 유도·숫자·가정은 `docs/THEORY_AND_RESULTS_KO.md`, machine-readable 결과는 `evidence/SCIENCE_RESULTS.json`, 실행 matrix는 `contracts/NUMERICAL_MATRIX.json`, 실제 원시 행/exit 기록은 `evidence/rows/`에 있다. `EDGE_DIAGNOSIS.json`은 첫 source cell 평균과 D threshold의 간격을 독립적분으로 설명한다.

## 실행

Rust1.94.1 user bundle을 별도 prefix에 설치한 환경에서:

```bash
export PATH=/mnt/data/rust-1.94.1-prefix/bin:$PATH
export LD_LIBRARY_PATH=/mnt/data/rust-1.94.1-prefix/lib:${LD_LIBRARY_PATH:-}
bash scripts/RUN_STAGE_P4_S7.sh
```

기본 실행은 전체119 tests/Clippy/5 analysis tests/source identities/38행 수치 검증과 선택한 fresh native row 재현을 수행한다. 전체38행을 처음부터 다시 만들려면 `RUN_STAGE_P4_S7.sh full`을 사용한다. 각 native subprocess는45초 cap, 일부 큰 설정은 deferred 정책으로 실행하지 않는다. 하나의 장시간 ChatGPT tool call보다는 runner를 bounded row별로 호출할 수 있다. Rust 외부 crate dependency 없음. Python 요구사항은numpy,scipy,pytest이고 실제 버전은 ENVIRONMENT.json에 있다.

## 판정

PASS_SCOPED_SEPARATED_RESOLUTION_AND_INDEPENDENT_ORACLES. FullP4 PARTIAL, SA01/02/FLRW-CONV/BI-SIGNED/FULL_EOR HOLD. 제조된 D defect,20K bath, prescribed geometry를 물리적 EoR 입력으로 승격하지 않는다. 보존과 수렴, finite-grid 차이와 continuum error certificate를 구분했다. 원래 chemistry map/반사 cache/광학단면적은 변경하지 않았다.

## 보존 상태

이번 세션은 GitHub/Drive/Dropbox 연결 조회는 가능하지만 업로드·커밋 생성 도구가 노출되지 않았다. 세 서비스에 새 백업을 완료했다고 주장하지 않는다. `BACKUP_STATE.json`에 exact blocker와 다음 게시 대상이 있다. 별도의 standalone git bundle과 add-only patch는 로컬 보존물이며 upstream history/새 remote PR이 아니다. 현재는 sealed source/evidence ZIP가 재개 기준이다.

## 복원 검증 범위

Seed ZIP207개 payload를 새 경로에서 복원해 전체119 Rust/5 Python tests, Clippy, scoped format, release build를 통과했다. 대표 GL32 native1행 재실행과 전체38행 재분석·독립 reference 재계산을 구분해 `evidence/CLEAN_RESTORE_VERIFICATION.json`에 기록했다. `NATIVE_MATRIX.csv`30행과 `STATIC_MATRIX.csv`8행은 원시 행의 편의용 합본이다. 재게시 계약은 `docs/PUBLICATION_CONTRACT_KO.md`에 있다.
