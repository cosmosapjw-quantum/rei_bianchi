# P4/S7 보존 및 재게시 계약

현재 세 서비스는 installed/enabled이고 읽기 도구는 동작한다. 이번 runtime에 GitHub commit/branch 생성, Google Drive upload, Dropbox upload submission 동작이 노출되지 않아 새 remote write를 수행하지 못했다. 이는 권한 거부를 확인했다는 뜻이 아니다. 새 PR 번호나 원격 백업 id는 없다.

로컬 전달물은 FULL ZIP, 새 stage 경로에만 파일을 추가하는 patch, standalone stage-only git bundle이다. Bundle의 local root commit은 원 rei_bianchi 저장소의 ancestor history를 포함하지 않는다. upstream HEAD를 위조하거나 새 remote commit으로 취급하지 않는다. 정확한 기반점은 PR188 HEAD 9f9837c0587e616ec351980fdbaab6dea799d027이다.

추후 게시 시 source/inputs의 근거는 SOURCE_LOCK.json이다. 대상 경로는 research/dossier_ssot_sandbox_20261016/iso_couple_p4_s7_20261017. 원래 production, 다른 stage와 branch에 overwrite하지 않는다. GitHub branch를 생성할 수 있는 환경에서 해당 parent로 시작해 add-only patch를 적용하고 tests/manifest 확인 후 commit/push한다. 현재 명령을 실행했다고 주장하지 않는다.

```bash
git switch -c research/rei-iso-couple-p4-s7-separated-convergence-20261017 9f9837c0587e616ec351980fdbaab6dea799d027
git apply --check /path/to/REI_ISO_COUPLE_P4_S7_20261017_ADD_ONLY.patch
git apply /path/to/REI_ISO_COUPLE_P4_S7_20261017_ADD_ONLY.patch
```

Google Drive 예정 parent:1phclg92jkhC5KgvnXhks8GbOFlya4qGe. Dropbox 예정 parent:/bianchi/rei_bianchi/research/REI_BASS_HIERARCHY_BACKUPS. 동일 FULL ZIP을 저장하되 remote ACK와 content hash, 실제 raw restore를 별도로 기록한다. 자동·백그라운드 게시를 예약하지 않았다.

Standalone bundle은 빈 디렉터리에서 git clone으로 복구 가능하지만 원 repo의 전체 백업이 아니다. 실제 local bundle verify와 restore payload hash 검산 결과는 외부 DELIVERY_RECEIPT.json에 있다.
