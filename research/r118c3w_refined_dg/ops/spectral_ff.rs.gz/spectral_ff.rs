//! Isotropic FLRW reference x=E/(k_B T_gamma), signed occupation distortion.
//! Research subflow: no angular transport or implicit general gas coupling.
use crate::{ff_balance::gaunt, ForwardError};
fn bad() -> ForwardError {
    ForwardError::InvalidInput("SPECTRAL_FF_DOMAIN")
}
#[derive(Clone, Debug)]
pub struct SpectralFf {
    x: Vec<f64>,
    delta: Vec<f64>,
    dl: f64,
    c3o_cov:Vec<f64>,
    c3o_cov_work:f64,
}
#[derive(Debug, Clone, Copy)]
pub struct Exchange {
    pub net: f64,
    pub emission: f64,
    pub thin_net: f64,
    pub planck_abs: f64,
    pub max_tau: f64,
    pub thick_cells: usize,
    pub absolute_ratio: f64,
}
fn mixed(t: f64, f: f64, u: f64) -> Result<f64, ForwardError> {
    let g2 = 13.605693122994 / (8.617333262145e-5 * t);
    Ok((1. - f) * gaunt(g2, u)? + f * gaunt(4. * g2, u)?)
}
fn norm(t: f64, f: f64) -> Result<f64, ForwardError> {
    let lo = 1e-10_f64.ln();
    let dl = (60_f64.ln() - lo) / 2048.;
    let mut v = 0.;
    for i in 0..=2048 {
        let x = (lo + dl * i as f64).exp();
        let w = if i == 0 || i == 2048 {
            1.
        } else if i % 2 == 0 {
            2.
        } else {
            4.
        };
        v += w * x * (-x).exp() * mixed(t, f, x)?;
    }
    Ok(v * dl / 3.)
}
fn pl(x: f64) -> f64 {
    1. / x.exp_m1()
}
impl SpectralFf {
    pub fn new(xmin: f64, xmax: f64, n: usize) -> Result<Self, ForwardError> {
        if !xmin.is_finite() || !xmax.is_finite() || xmin <= 0. || xmax <= xmin || n < 16 {
            return Err(bad());
        }
        let dl = (xmax / xmin).ln() / n as f64;
        Ok(Self {
            x: (0..n)
                .map(|i| xmin * ((i as f64 + 0.5) * dl).exp())
                .collect(),
            delta: vec![0.; n],
            dl,
            c3o_cov:vec![0.;n],
            c3o_cov_work:0.,
        })
    }
    pub fn nodes(&self) -> &[f64] {
        &self.x
    }
    pub fn distortion(&self) -> &[f64] {
        &self.delta
    }
    /// Load a signed distortion only on the same immutable frequency grid.
    /// The caller binds grid identity; invalid payloads leave state unchanged.
    pub fn restore_distortion(&mut self, d: &[f64]) -> Result<(), ForwardError> {
        if d.len() != self.x.len()
            || d.iter()
                .zip(&self.x)
                .any(|(&v, &x)| !v.is_finite() || v + pl(x) < 0. || !(v + pl(x)).is_finite())
        {
            return Err(bad());
        }
        self.delta.copy_from_slice(d);
        Ok(())
    }
    fn phase(&self, x: f64, bb: f64) -> f64 {
        bb * 15. / std::f64::consts::PI.powi(4) * x.powi(4) * self.dl
    }
    pub fn energy(&self, bb: f64) -> Result<f64, ForwardError> {
        if !bb.is_finite() || bb <= 0. || self.x.len() != self.delta.len() {
            return Err(bad());
        }
        Ok(self
            .x
            .iter()
            .zip(&self.delta)
            .map(|(&x, &d)| self.phase(x, bb) * d)
            .sum())
    }
    /// B is the original gross integrated emission per H over the frozen step.
    /// Absolute normalization replaces B only when explicitly selected.
    pub fn advance(
        &mut self,
        t: f64,
        tc: f64,
        frac: f64,
        b: f64,
        bb: f64,
        absolute: bool,
    ) -> Result<Exchange, ForwardError> {
        if ![t, tc, frac, b, bb].iter().all(|x| x.is_finite())
            || t <= 0.
            || tc <= 0.
            || bb <= 0.
            || b < 0.
            || !(0. ..=1.).contains(&frac)
            || self.x.len() != self.delta.len()
        {
            return Err(bad());
        }
        let gnorm = norm(t, frac)?;
        let ratio = 1.4255566872911698e-27 * gnorm
            / (1.43e-27 * (1.1 + 0.34 * (-(5.5 - t.log10()).powi(2) / 3.).exp()));
        let b = if absolute { b * ratio } else { b };
        let r = tc / t;
        let mut q = Exchange {
            net: 0.,
            emission: 0.,
            thin_net: 0.,
            planck_abs: 0.,
            max_tau: 0.,
            thick_cells: 0,
            absolute_ratio: ratio,
        };
        let mut next = self.delta.clone();
        for (i, &x) in self.x.iter().enumerate() {
            let u = r * x;
            let p = self.phase(x, bb);
            let g = mixed(t, frac, u)?;
            let amp = b / gnorm * u * g * self.dl;
            let birth = amp * (-u).exp();
            let tau = amp * (-(-u).exp_m1()) / p;
            let fp = pl(x);
            let fe = pl(u);
            let d = self.delta[i];
            if ![tau, d, fp, fe, p].iter().all(|v| v.is_finite()) || tau < 0. || fp + d < 0. {
                return Err(bad());
            }
            let dd = (fe - fp - d) * (-(-tau).exp_m1());
            // When relaxation rounds to complete thermalization, use exact target
            // distortion rather than subtracting nearly equal large occupations.
            next[i] = if tau > 36. {
                fe - fp + (d - (fe - fp)) * (-tau).exp()
            } else {
                d + dd
            };
            if next[i] + fp < 0. || !next[i].is_finite() {
                return Err(bad());
            }
            q.net += p * (next[i] - d);
            q.emission += birth;
            let abs = p * tau * fp;
            q.planck_abs += abs;
            q.thin_net += birth - abs;
            q.max_tau = q.max_tau.max(tau);
            q.thick_cells += usize::from(tau >= 1.);
        }
        self.delta = next;
        Ok(q)
    }
}

/// Isotropic reference blackbody energy per H in eV, with nH in cm^-3.
pub fn blackbody_per_h(tc: f64, nh: f64) -> Result<f64, ForwardError> {
    let a = 8. * std::f64::consts::PI.powi(5) * 1.380649e-23_f64.powi(4)
        / (15. * 6.62607015e-34_f64.powi(3) * 299792458_f64.powi(3));
    let e = a * tc.powi(4) / (nh * 1e6) / 1.602176634e-19;
    if !e.is_finite() || e <= 0. {
        return Err(bad());
    }
    Ok(e)
}

// C3J isolated shadow only. Number weights x^3 dl match this native FF grid.
impl SpectralFf {
    fn c3j_sweep(&mut self, theta:f64, dt:f64, parity:usize, bb:f64)->Result<f64,ForwardError>{
        let mut energy=0.;
        for i in (parity..self.x.len()-1).step_by(2){
            let j=i+1;let xi=self.x[i];let xj=self.x[j];let dx=xj-xi;
            let ci=xi.powi(3)*self.dl;let cj=xj.powi(3)*self.dl;
            let fi0=pl(xi);let fj0=pl(xj);let u=self.delta[i];let v=self.delta[j];
            let fi=fi0+u;let fj=fj0+v;
            if fi<0.||fj<0.||!fi.is_finite()||!fj.is_finite(){return Err(bad())}
            let dd=dx/theta;let q=(-dd).exp();let b=-(-dd).exp_m1();let g=(xi*xj).powi(2)*dd/(dx*b);
            let j0=-g*fi0*(1.+fj0)*(-dx).exp()*(dx*(1.-1./theta)).exp_m1();
            let extra=g*b*self.c3o_cov[i];
            let flux=extra+j0+g*((1.+b*fi0)*v+(-q+b*fj0)*u+b*u*v);
            let m=ci*fi+cj*fj;let aa=g*b/(ci*cj);
            let bbcoef=g*(-(1.+b*fi)/cj+(-q+b*fj)/ci);
            let bt=g*(-1./cj-q/ci+b*m/(ci*cj));let cc=g*m/cj;
            let disc=(bt*bt+4.*aa*cc+4.*aa*extra).sqrt();let z=-(-disc*dt).exp_m1();
            let den=disc*(2.-z)-bbcoef*z;
            if !den.is_finite()||den<=0.{return Err(bad())}
            let mut transfer=2.*flux*z/den;
            let lo=-ci*fi;let hi=cj*fj;let tol=64.*f64::EPSILON*m;
            if !transfer.is_finite()||transfer<lo-tol||transfer>hi+tol{return Err(bad())}
            transfer=transfer.max(lo).min(hi);
            self.delta[i]+=transfer/ci;self.delta[j]-=transfer/cj;
            energy-=bb*15./std::f64::consts::PI.powi(4)*dx*transfer;
            // stable separate first-order attribution (not difference of rounded transfers)
            self.c3o_cov_work-=bb*15./std::f64::consts::PI.powi(4)*dx*extra*dt;
        }
        Ok(energy)
    }
    pub fn advance_compton(&mut self,theta:f64,clock:f64,bb:f64)->Result<f64,ForwardError>{
        if theta<=0.||clock<0.||bb<=0.||![theta,clock,bb].iter().all(|v|v.is_finite()){return Err(bad())}
        // Trial only: if a later sweep fails leave receiver byte-identical.
        let mut trial=self.clone();
        let mut q=trial.c3j_sweep(theta,clock/2.,0,bb)?;
        q+=trial.c3j_sweep(theta,clock,1,bb)?;
        q+=trial.c3j_sweep(theta,clock/2.,0,bb)?;
        if trial.delta.iter().zip(&trial.x).any(|(v,x)|!v.is_finite()||v+pl(*x)<0.){return Err(bad())}
        *self=trial;Ok(q)
    }
    pub fn set_c3o_covariance(&mut self,cov:&[f64])->Result<(),ForwardError>{
        if cov.len()!=self.x.len()||cov.iter().any(|v|!v.is_finite()){return Err(bad())}
        self.c3o_cov.copy_from_slice(cov);Ok(())
    }
    pub fn c3o_cov_work(&self)->f64{self.c3o_cov_work}
    pub fn c3j_number(&self)->f64{
        self.x.iter().zip(&self.delta).map(|(x,d)|x.powi(3)*self.dl*d).sum()
    }
}
#[cfg(test)]
mod c3j_checks {
    use super::*;
    #[test]
    fn covariance_response_and_conservation(){
        let mut s=SpectralFf::new(1e-3,10.,128).unwrap();
        let mut c=vec![0.;128];c[60]=1e-4;
        s.set_c3o_covariance(&c).unwrap();
        let q=s.advance_compton(1.,1e-9,1e7).unwrap();
        assert!(q<0. && s.c3o_cov_work()<0.);
        assert!((s.energy(1e7).unwrap()-q).abs()<1e-14);
        assert!(s.c3j_number().abs()<1e-20);
        let d=s.distortion().to_vec();assert!(s.set_c3o_covariance(&[0.]).is_err());assert_eq!(d,s.distortion());
    }
    #[test]
    fn equilibrium_and_conservation(){
        let mut s=SpectralFf::new(1e-10,60.,1024).unwrap();
        assert_eq!(s.advance_compton(1.,1e-8,1e7).unwrap(),0.);
        assert!(s.distortion().iter().all(|x|*x==0.));
        let q=s.advance_compton(0.3,1e-8,1e7).unwrap();
        assert!(q<0.);assert!((s.energy(1e7).unwrap()-q).abs()<1e-13*q.abs());
        assert!(s.c3j_number().abs()<1e-21);
        let d=s.distortion().to_vec();assert!(s.advance_compton(-1.,1e-8,1e7).is_err());assert_eq!(d,s.distortion());
    }
}
