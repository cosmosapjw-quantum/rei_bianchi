# RUN04 resume: P4-S4C-BIRTH-OPTICAL-LAYER

Read docs/REPORT_KO.md, contracts/DAG_PROGRESS.json, evidence/NUMERICAL_SUMMARY.json. Verify manifest before using the files. This is this thread's atomic/nuclear branch, not an instruction to switch to an external production branch.

Completed: source-locked BASS164/165 121/241 donor, monotone Hermite threshold proof, Rust source-native H/He/D dynamic gas and actual MD14/BB50k photons, 108 tests, 128 independent geometry comparisons, 22 native rows. Source-only on-shell donor, not new EFE–RT–gas feedback solution. Original Rust owners unchanged.

Next bounded task: construct an optical-layer-aware birth integrator at identical source/cosmology/IC. At signed N16→32 survivor differs 18.2008%; GL2→GL4 at matched N8/slices8 differs 47.1825% relative to GL4. Do not accept tiny gas-temperature or number/energy ledger errors as a survivor accuracy bound. Do not rerun old broad histories. Separate time, birth, angle, spectrum. Keep explicit CMB bath T0/a and manufactured isotope defect visible.

Use sandbox only. No local/Codex/NCP/SSH. Current Rust1.94.1 offline prefix is an external toolchain input, not archived here; verify compiler availability instead of assuming it persists. One build job, 4GiB host cap, individual commands bounded. Tests are in code/rei_bass_coupled; scripts/REPLAY_OFFLINE.sh rebuilds and verifies the small representative row. The full 22-run replay is optional scripts/run_campaign.py and writes task-local evidence.

Every subsequent research turn must perform GitHub task-source delivery, Google Drive full backup and Dropbox full backup, with exact object identifiers and actual status. Use the existing BASS_DERIVATION_DOSSIERS_20260912 destinations after readback. Do not mutate original provider files/main/other branch checkpoints. Full recovery metadata is external DELIVERY_RECEIPT.json; upload acknowledgment is not download or restore verification.
