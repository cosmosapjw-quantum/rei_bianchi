from pathlib import Path
import csv,json,math
root=Path(__file__).resolve().parents[1]
rows=list(csv.DictReader((root/'evidence/coupled_campaign.csv').open()))
def sel(case='SIGNED_MINUS',n=8,grid=121,spectrum='OriginalCellMean',event='true',slices=2,birth=2):
 a=[r for r in rows if r['case']==case and int(r['steps'])==n and int(r['grid'])==grid and r['spectrum']==spectrum and r['event']==event and int(r['slices'])==slices and int(r['birth'])==birth]
 assert len(a)==1,(case,n,grid,spectrum,event,slices,birth);return a[0]
fields=['T_k','survivor_com3','absorbed_com3','x_hii','x_dii','HI_com3','HeI_com3','HeII_com3','DI_com3']
def rel(a,b):return {f:(float(b[f])-float(a[f]))/abs(float(b[f])) for f in fields}
res={'completed_runs':len(rows),'max_residuals':{k:max(float(r[k]) for r in rows) for k in ['photon_res','baryon_res','energy_step_res','work_gap_J_com3']},'last_adjacent_time_difference':{c:rel(sel(c,16),sel(c,32)) for c in ['COLD_FLRW','SIGNED_MINUS']},'geometry_121_to_241':{c:rel(sel(c),sel(c,grid=241)) for c in ['COLD_FLRW','SIGNED_MINUS']},'spectrum_mean_to_GL3':rel(sel(),sel(spectrum='SplitPositiveGauss3')),'threshold_off_to_on':rel(sel(spectrum='SplitPositiveGauss3',event='false'),sel(spectrum='SplitPositiveGauss3')),'opacity_slices_2_to_8':rel(sel(spectrum='SplitPositiveGauss3'),sel(spectrum='SplitPositiveGauss3',slices=8)),'birth_GL2_to_GL4':rel(sel(spectrum='SplitPositiveGauss3',slices=8),sel(spectrum='SplitPositiveGauss3',slices=8,birth=4)),'mixed_axis_time_sequence':{},'decision':'PASS_SCOPED_SOURCE_ONLY_BASS_GEOMETRY_DYNAMIC_HHED_COUPLING','continuum_accuracy':'HOLD; adjacent differences are not continuum errors','initial_state':'explicit warm test prescription, not rec_bianchi data'}
for c in ['COLD_FLRW','SIGNED_MINUS']:
 s=[sel(c,n) for n in [2,4,8,16,32]]
 res['mixed_axis_time_sequence'][c]={f:{'values':[float(r[f]) for r in s],'successive_difference_ratios':[(float(s[i+1][f])-float(s[i][f]))/(float(s[i+2][f])-float(s[i+1][f])) for i in range(3)]} for f in ['T_k','survivor_com3']}
(root/'evidence/NUMERICAL_SUMMARY.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps({k:res[k] for k in ['max_residuals','geometry_121_to_241','threshold_off_to_on','birth_GL2_to_GL4']},indent=2))
