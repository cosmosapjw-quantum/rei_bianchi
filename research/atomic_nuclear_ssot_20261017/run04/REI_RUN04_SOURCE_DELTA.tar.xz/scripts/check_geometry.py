"""Independent original BASS165 Python receiver vs new Rust receiver, same input bytes."""
from pathlib import Path
import sys,csv,json,math
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'inputs'))
from source_table import BackgroundTable
refs={n:BackgroundTable(root/'inputs'/f/'PRODUCER_RECEIPT.json',root/'inputs'/f/'PROPOSED_REI_BACKGROUND.csv') for n,f in [(121,'bass164'),(241,'bass241')]}
errors={k:0. for k in ['h_relative','b_absolute','s_over_H_absolute','clock_relative','x_roundtrip_absolute']}
rows=list(csv.DictReader((root/'evidence/geometry_probe.csv').open()))
for r in rows:
 p=refs[int(r['grid'])].point_at_x(r['case'],float(r['x']))
 h=float(r['h_per_s']);s=float(r['s_per_s'])
 values={'h_relative':abs(h/p.h_per_s-1.),'b_absolute':abs(float(r['b'])-p.b),'s_over_H_absolute':abs(s/h-p.s_per_s/p.h_per_s),'clock_relative':abs(float(r['time_s'])-p.time_s)/max(1.,abs(p.time_s)),'x_roundtrip_absolute':abs(float(r['x_roundtrip'])-float(r['x']))}
 for k,v in values.items():errors[k]=max(errors[k],v)
limits={'h_relative':3e-13,'b_absolute':3e-14,'s_over_H_absolute':3e-13,'clock_relative':3e-13,'x_roundtrip_absolute':4e-15}
res={'rows':len(rows),'original_python_source':'inputs/source_table.py','comparison':'same immutable source Hermite and GL8, independent implementations','max_errors':errors,'acceptance':limits,'verdict':'PASS' if all(errors[k]<limits[k] for k in limits) else 'FAIL'}
(root/'evidence/GEOMETRY_INDEPENDENT.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps(res,indent=2));assert res['verdict']=='PASS'
