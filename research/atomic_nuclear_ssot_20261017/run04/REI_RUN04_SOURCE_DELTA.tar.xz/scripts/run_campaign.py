"""Bounded serial native campaign. No network, no local/NCP calls, no hidden reruns."""
from pathlib import Path
import csv,json,subprocess,time,sys,os
root=Path(__file__).resolve().parents[1]
binary=root/'code/rei_bass_coupled/target/release/examples/bass_coupled_campaign'
out=root/'evidence/campaign';out.mkdir(exist_ok=True)
cases=[(c,n,121,'mean','on',2,2) for c in ('COLD_FLRW','WARM_ISOTROPIC','SIGNED_PLUS','SIGNED_MINUS') for n in (2,4,8)]
cases += [(c,n,121,'mean','on',2,2) for c in ('COLD_FLRW','SIGNED_MINUS') for n in (16,32)]
cases += [(c,8,241,'mean','on',2,2) for c in ('COLD_FLRW','SIGNED_MINUS')]
cases += [('SIGNED_MINUS',8,121,'split','on',2,2),('SIGNED_MINUS',8,121,'split','off',2,2),('SIGNED_MINUS',8,121,'split','on',8,2),('SIGNED_MINUS',8,121,'split','on',8,4)]
records=[];rows=[];started=time.monotonic()
for i,args in enumerate(cases):
 name=f'{i:02d}_'+ '_'.join(map(str,args)); cmd=[str(binary),*map(str,args)]
 t=time.monotonic()
 try:
  p=subprocess.run(cmd,capture_output=True,text=True,timeout=35)
  (out/(name+'.stdout.csv')).write_text(p.stdout);(out/(name+'.stderr.log')).write_text(p.stderr)
  rec={'case':list(args),'command':cmd,'exit':p.returncode,'wall_s':time.monotonic()-t}
  if p.returncode==0:
   rr=list(csv.DictReader(p.stdout.splitlines()));assert len(rr)==1;rows+=rr
 except subprocess.TimeoutExpired as e:
  rec={'case':list(args),'command':cmd,'exit':None,'wall_s':time.monotonic()-t,'failure':'RUNTIME_WALL_LIMIT'}
  (out/(name+'.timeout.log')).write_text(str(e))
 records.append(rec)
 (root/'evidence/CAMPAIGN_EXECUTION.json').write_text(json.dumps({'runs':records,'total_wall_s':time.monotonic()-started},indent=2)+'\n')
 if rows:
  with (root/'evidence/coupled_campaign.csv').open('w',newline='') as f:
   w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
 print(name,rec['exit'],round(rec['wall_s'],4),flush=True)
 if rec['exit']!=0:sys.exit(1)
print('completed',len(rows),'elapsed',time.monotonic()-started)
