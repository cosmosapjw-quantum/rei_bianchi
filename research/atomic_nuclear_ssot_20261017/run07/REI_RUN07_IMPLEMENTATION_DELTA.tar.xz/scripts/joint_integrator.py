"""Independent time integration of RUN07 native joint RHS, fixed local slab.

No atomic coefficients are fitted in Python. Same source-native 48 energies;
no geometry evolution/redshift in this controlled local problem.
"""
from __future__ import annotations
import json, pathlib, selectors, subprocess, time
import numpy as np
from scipy.integrate import solve_ivp
ROOT=pathlib.Path(__file__).resolve().parents[1]
SERVER=ROOT/'code/rei_bass_coupled/target/release/examples/joint_slab_server'
EV=1.602176634e-19; KB=1.380649e-23; C=299792458.
LO=np.array([1,10,11,3]); HI=np.array([2,11,12,4]); CHARGE=np.array([0,0,1,0,1,0,1,0,1,2,0,1,2])
class NativeError(RuntimeError):pass
class JointServer:
    def __init__(self,path=SERVER):
        self.proc=subprocess.Popen([str(path)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
        self.calls=0; self.proc.stdin.write('INIT\n');self.proc.stdin.flush();self.fixture=json.loads(self._read())
        self.m=len(self.fixture['energies_eV']);self.eidx=27+self.m;self.dim=self.eidx+10
    def _read(self):
        with selectors.DefaultSelector() as s:
            s.register(self.proc.stdout,selectors.EVENT_READ)
            if not s.select(timeout=8):raise TimeoutError('native joint RHS timeout')
        line=self.proc.stdout.readline()
        if not line:raise NativeError('native process ended: '+self.proc.stderr.read())
        return line
    def rhs(self,state,gas_mask=7,photo=True):
        state=np.asarray(state,dtype=float)
        if state.shape!=(self.dim,)or not np.isfinite(state).all():raise ValueError('joint state shape/finite')
        inp=np.r_[state[:14],state[27:self.eidx]]
        self.proc.stdin.write(f'RHS {gas_mask} {int(photo)} '+' '.join(format(v,'.17e') for v in inp)+'\n');self.proc.stdin.flush()
        line=self._read();self.calls+=1
        if not line.startswith('OK '):raise NativeError(line.strip())
        out=np.fromstring(line[3:],sep=' ')
        if len(out)!=self.dim or not np.isfinite(out).all():raise NativeError('invalid native vector')
        return out
    def close(self):
        if self.proc.poll() is None:
            try:self.proc.stdin.write('QUIT\n');self.proc.stdin.flush();self.proc.wait(timeout=2)
            except (BrokenPipeError,subprocess.TimeoutExpired):self.proc.kill();self.proc.wait()
        for s in (self.proc.stdin,self.proc.stdout,self.proc.stderr):s.close()
    def __enter__(self):return self
    def __exit__(self,*args):self.close()

def initial(server):
    y=np.zeros(server.dim);y[:14]=server.fixture['state'];return y

def scaling(server):
    f=server.fixture;nh=sum(f['state'][1:3]);sc=np.full(server.dim,nh)
    sc[13:16]=nh*EV;sc[26]=nh*EV;sc[server.eidx+4:server.eidx+8]=nh*EV;sc[-1]=nh*EV
    sc[27:server.eidx]=np.maximum(np.array(f['source_m3_s'])*f['dt_s'],nh*1e-25)
    return sc

def integrate(server,y0,dt,method='Radau',mask=7,photo=True,rtol=3e-10,max_step=.2):
    if not np.isfinite(dt) or dt<=0:raise ValueError('positive proper time required')
    sc=scaling(server);y0=np.asarray(y0);atol=np.full(server.dim,1e-19)
    atol[:13]=1e-17;atol[13]=1e-13;atol[27:server.eidx]=1e-14
    before=server.calls; start=time.perf_counter()
    def rhs(_t,y):
        if time.perf_counter()-start>32:raise TimeoutError('bounded joint integration wall cap32s')
        return dt*server.rhs(y*sc,mask,photo)/sc
    # Explicit reference cannot rely on stiff solver stability. Optical bound
    # uses all nuclei available to each absorber, not just its initial fraction.
    f=server.fixture;n=np.array(f['state'][:13]);nmax=np.array([sum(n[1:3]),sum(n[10:13]),sum(n[10:13]),sum(n[3:5])]);kmax=max(C*np.array(f['sigma_m2'])@nmax)
    mx=min(max_step,0.4/max(kmax*dt,1.)) if method=='DOP853' and photo else max_step
    sol=solve_ivp(rhs,(0.,1.),y0/sc,method=method,rtol=rtol,atol=atol,max_step=mx,first_step=min(1e-4,mx))
    if not sol.success or sol.t[-1]!=1:raise NativeError(str(sol.message))
    ys=sol.y*sc[:,None];final=ys[:,-1]
    # No clipping; the strict native boundary also rejects negative trial inputs.
    if (ys[:13]<0).any() or (ys[27:server.eidx]<0).any() or (ys[13]<=0).any():raise NativeError('nonpositive accepted state')
    return final,dict(method=method,mask=mask,photo=photo,rtol=rtol,nfev=sol.nfev,njev=sol.njev,nlu=sol.nlu,accepted=len(sol.t),native_calls=server.calls-before,wall_s=time.perf_counter()-start,min_photon=float(ys[27:server.eidx].min()))

def stable_phi(tau):
    tau=np.asarray(tau);out=np.empty_like(tau);tiny=np.abs(tau)<1e-4;x=tau[tiny]
    out[tiny]=1-x/2+x*x/6-x**3/24+x**4/120-x**5/720
    np.divide(-np.expm1(-tau),tau,out=out,where=~tiny)
    return out

def frozen_photo(server,y0,dt):
    f=server.fixture;eidx=server.eidx;y=y0.copy();n=y0[LO];ener=np.array(f['energies_eV']);chi=np.array(f['chi_eV']);j=np.array(f['source_m3_s']);k=C*np.array(f['sigma_m2'])*n[None,:];tot=k.sum(axis=1);tau=tot*dt;phi=stable_phi(tau)
    old=y0[27:eidx];born=j*dt
    remainder=np.empty_like(tau);tiny=tau<1e-4;x=tau[tiny]
    remainder[tiny]=x/2-x*x/6+x**3/24-x**4/120+x**5/720;remainder[~tiny]=1-phi[~tiny]
    absorbed=old*(-np.expm1(-tau))+born*remainder
    event=absorbed[:,None]*np.divide(k,tot[:,None],out=np.zeros_like(k),where=tot[:,None]>0)
    ev=event.sum(axis=0);heat=(event*(ener[:,None]-chi[None,:])).sum(axis=0)*EV
    y[27:eidx]=old*np.exp(-tau)+born*phi
    for a in range(4):y[LO[a]]-=ev[a];y[HI[a]]+=ev[a]
    y[13]+=heat.sum();y[eidx:eidx+4]+=ev;y[eidx+4:eidx+8]+=heat;y[-2]+=born.sum();y[-1]+=born@ener*EV
    if (y[:13]<0).any():raise NativeError('frozen photo neutral depletion: rejected, no clipping')
    return y

def split_run(server,n,kind='frozen_lie',rtol=3e-10):
    if not isinstance(n,int) or isinstance(n,bool) or n<=0 or kind not in ('frozen_lie','dynamic_lie','strang'):
        raise ValueError('positive integer step count and known split mode required')
    if not np.isfinite(rtol) or rtol<=0:raise ValueError('positive finite rtol required')
    y=initial(server);dt=server.fixture['dt_s']/n;receipt=[];t=time.perf_counter()
    for _ in range(n):
        if kind=='strang':y,r=integrate(server,y,dt/2,mask=7,photo=False,rtol=rtol);receipt.append(r)
        if kind=='frozen_lie':y=frozen_photo(server,y,dt)
        else:y,r=integrate(server,y,dt,mask=0,photo=True,rtol=rtol);receipt.append(r)
        y,r=integrate(server,y,dt/(2 if kind=='strang' else 1),mask=7,photo=False,rtol=rtol);receipt.append(r)
    return y,dict(kind=kind,steps=n,wall_s=time.perf_counter()-t,substeps=receipt)

def observables(server,y):
    f=server.fixture;p=server.eidx;nh=sum(y[1:3]);nd=sum(y[3:5]);he=sum(y[10:13]);initial=np.array(f['state']);chi=np.array(f['chi_eV']);e=np.array(f['energies_eV']);
    bindvec=np.zeros(13);bindvec[2]=chi[0];bindvec[4]=chi[3];bindvec[11]=chi[1];bindvec[12]=chi[1]+chi[2]
    old_energy=initial[13]+initial[:13]@bindvec*EV
    energy=y[13]+sum(y[14:16])+y[:13]@bindvec*EV+y[27:p]@e*EV
    residual=energy-old_energy-y[-1]
    pred=initial[:13].copy();edge_net=y[16:20]-y[20:24]+y[p:p+4]
    for a in range(4):pred[LO[a]]-=edge_net[a];pred[HI[a]]+=edge_net[a]
    pred[11]-=y[24];pred[10]+=y[24]
    pred[2]-=y[25];pred[1]+=y[25];pred[3]-=y[25];pred[4]+=y[25]
    temp=2*y[13]/(3*KB*((1+CHARGE)@y[:13]))
    return dict(T_K=float(temp),x_HII=float(y[2]/nh),x_DII=float(y[4]/nd),x_HeII=float(y[11]/he),x_HeIII=float(y[12]/he),survivor_m3=float(sum(y[27:p])),absorbed_HI_m3=float(y[p]),absorbed_HeI_m3=float(y[p+1]),absorbed_HeII_m3=float(y[p+2]),absorbed_DI_m3=float(y[p+3]),thermal_J_m3=float(y[13]),photoheat_J_m3=float(sum(y[p+4:p+8])),born_m3=float(y[-2]),born_J_m3=float(y[-1]),photon_ledger_rel=float(abs(sum(y[27:p])+sum(y[p:p+4])-y[-2])/max(y[-2],1e-300)),energy_ledger_rel_total=float(abs(residual)/old_energy),energy_ledger_rel_source=float(abs(residual)/max(y[-1],1e-300)),species_event_rel_H=float(max(abs(y[:13]-pred))/nh),species_event_D_fraction=float(max(abs(y[3:5]-pred[3:5]))/nd),nuclei_relative_max=float(max(abs(nh-sum(initial[1:3]))/nh,abs(nd-sum(initial[3:5]))/nd,abs(he-sum(initial[10:13]))/he)))
