"""One fresh independent joint solve; never relabel a 25-case full replay."""
import hashlib,json
import numpy as np
from joint_integrator import ROOT,JointServer,initial,integrate,observables
with JointServer() as s:
 y,execution=integrate(s,initial(s),s.fixture['dt_s'])
 expected=np.array(json.loads((ROOT/'evidence/Radau_n1/result.json').read_text())['state'])
 assert np.array_equal(y,expected),'Deterministic local replay differs; inspect before accepting'
 result={'status':'PASS_JOINT_REFERENCE_STATE_EXACT_FLOAT64_EQUAL','physics_state_equal':True,'shape':len(y),'execution':execution,'observables':observables(s,y),'full_campaign_repeated':False}
print(json.dumps(result,indent=2))
