"""Regenerate deterministic result tables without repeating numerical integrations."""
from __future__ import annotations
import csv, json, math, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
E = ROOT / 'evidence'
ref_record = json.loads((E / 'Radau_tight/result.json').read_text())
ref = ref_record['observables']
keys = ['T_K', 'x_HII', 'x_DII', 'x_HeII', 'x_HeIII', 'survivor_m3',
        'absorbed_HI_m3', 'absorbed_HeI_m3', 'absorbed_HeII_m3', 'absorbed_DI_m3',
        'thermal_J_m3', 'photoheat_J_m3']
records=[]
for path in sorted(E.glob('*/result.json')):
    d=json.loads(path.read_text());o=d['observables']
    row={'id':path.parent.name,'method':d['mode'],'steps':d['steps'],'rtol':d['rtol'],**o}
    for k in keys:
        row[k+'_error']=o[k]-ref[k]
        row[k+'_relative_error']=(o[k]-ref[k])/ref[k]
    row['wall_s']=d['execution']['wall_s']
    records.append(row)
records.sort(key=lambda r: (r['method'],r['steps'],r['id']))
assert len(records)==25, 'Different run inventory: inspect before reusing claims'
with (E/'JOINT_COMPARISON.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
orders=[]
for kind in ['frozen_lie','dynamic_lie','strang']:
    rows=[r for r in records if r['method']==kind]
    for a,b in zip(rows[:-1],rows[1:]):
        item={'method':kind,'n_coarse':a['steps'],'n_fine':b['steps']}
        for k in keys:
            ec,ef=a[k+'_error'],b[k+'_error']
            item[k+'_observed_order']=None if ec==0 or ef==0 else math.log(abs(ec/ef),b['steps']/a['steps'])
        orders.append(item)
with (E/'OBSERVED_ORDERS.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(orders[0]));w.writeheader();w.writerows(orders)
lookup={r['id']:r for r in records}
reference_comparison={}
for label in ['Radau_n1','DOP853_n1']:
    r=lookup[label]
    reference_comparison[label]={k:{'absolute':abs(r[k+'_error']),'relative':abs(r[k+'_relative_error'])} for k in keys}
rd=lookup['Radau_n1'];dp=lookup['DOP853_n1']
reference_comparison['Radau_vs_DOP853']={k:{'absolute':abs(rd[k]-dp[k]),'relative':abs(rd[k]-dp[k])/abs(dp[k])} for k in keys}
ledger_keys=['photon_ledger_rel','energy_ledger_rel_total','energy_ledger_rel_source',
             'species_event_rel_H','species_event_D_fraction','nuclei_relative_max']
summary={
    'schema':'rei.atomic.nuclear.run07.numeric.v1',
    'scope':'fixed proper volume, fixed geometry, 48 fixed native energy means, continuous frozen-rate MD14/BB50k source; dynamic nonlinear gas and photons',
    'reference_method':'Radau rtol=3e-12; separately compared to Radau3e-10 and DOP8533e-10; not a rigorous enclosure',
    'reference_observables':ref,
    'reference_comparison':reference_comparison,
    'completed_runs':25,'split_rows':22,'reference_rows':3,
    'method_inventory':{k:sum(r['method']==k for r in records) for k in sorted(set(r['method'] for r in records))},
    'max_ledgers':{k:max(r[k] for r in records) for k in ledger_keys},
    'wall_s_sum_completed_numerical_integrations':sum(r['wall_s'] for r in records),
    'wall_excludes':'build, tests, source discovery, independent RHS checks, restore and I/O outside timed integration',
    'coarse_examples':{k:{x:lookup[k][x] for x in ['T_K_error','survivor_m3_relative_error','x_DII_error']} for k in ['frozen_lie_n1','dynamic_lie_n1','strang_n1']},
    'finest_strang':{x:lookup['strang_n128'][x] for x in ['T_K_error','survivor_m3_relative_error','x_DII_error']},
    'finest_orders':{kind:[o for o in orders if o['method']==kind][-1] for kind in ['frozen_lie','dynamic_lie','strang']},
    'depletion_scope':'initial gas mildly depleted in baseline; no new strongly depleted full-gas campaign; prior RUN06 exact photo-pair stress retained',
    'global_bianchi_comparator':'NOT_RUN; no silent comparison with expanding RUN05/06 trajectory',
    'byte_identity_and_science_status_are_separate':True,
}
(E/'NUMERICAL_SUMMARY.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:summary[k] for k in ['completed_runs','max_ledgers','wall_s_sum_completed_numerical_integrations','coarse_examples','finest_strang','finest_orders']},indent=2))
