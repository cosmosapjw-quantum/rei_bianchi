from pathlib import Path
import argparse,json,time,traceback,numpy as np
from joint_integrator import *
p=argparse.ArgumentParser();p.add_argument('--mode',default='Radau',choices=['Radau','DOP853','frozen_lie','dynamic_lie','strang']);p.add_argument('--steps',type=int,default=1);p.add_argument('--rtol',type=float,default=3e-10);p.add_argument('--name',default=None);args=p.parse_args()
out=ROOT/'evidence'/(args.name or f'{args.mode}_n{args.steps}');out.mkdir(parents=True,exist_ok=False)
try:
 with JointServer() as s:
  if args.mode in ['Radau','DOP853']:y,receipt=integrate(s,initial(s),s.fixture['dt_s'],method=args.mode,rtol=args.rtol)
  else:y,receipt=split_run(s,args.steps,args.mode,args.rtol)
  result={'mode':args.mode,'steps':args.steps,'rtol':args.rtol,'scope':'LOCAL_FROZEN_GEOMETRY_AND_48_FIXED_ENERGIES_CONTINUOUS_NATIVE_SOURCE','state':y.tolist(),'observables':observables(s,y),'execution':receipt}
  (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
  print(json.dumps({k:v for k,v in result.items() if k not in ['state','execution']}));print('wall',receipt['wall_s'])
except Exception as e:
 (out/'FAILURE.txt').write_text(traceback.format_exc());raise
