"""RUN07 focused tests: native boundary and independent assembly, not new data fits."""
import json
import pathlib
import sys
import unittest

import mpmath as mp
import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import joint_integrator as joint
from gas_integrator_parent import GasServer


class JointTests(unittest.TestCase):
    def test_invalid_controls_reject_before_any_rhs(self):
        with joint.JointServer() as s:
            for n, mode in [(-1, 'strang'), (0, 'strang'), (2, 'misspelled')]:
                with self.assertRaises(ValueError):
                    joint.split_run(s, n, mode)
            self.assertEqual(s.calls, 0)

    def test_exact_source_shape_and_current_export(self):
        with joint.JointServer() as s:
            stored = json.loads((ROOT / 'inputs/LOCAL_NATIVE48.json').read_text())
            self.assertEqual(s.fixture, stored)
            self.assertEqual(s.m, 48)
            self.assertEqual(s.dim, 85)
            self.assertTrue(np.all(np.asarray(s.fixture['source_m3_s']) > 0))
            self.assertGreater(s.fixture['dt_s'], 0)

    def test_python_photo_assembly_matches_native_over_24_states(self):
        rng = np.random.default_rng(7017)
        with joint.JointServer() as s, GasServer() as g:
            f = s.fixture
            sigma = np.asarray(f['sigma_m2'])
            energies = np.asarray(f['energies_eV'])
            chi = np.asarray(f['chi_eV'])
            source = np.asarray(f['source_m3_s'])
            for _ in range(24):
                y = joint.initial(s)
                for indices in ([1, 2], [3, 4], [10, 11, 12]):
                    total = sum(y[indices])
                    y[indices] = total * rng.dirichlet(np.ones(len(indices)))
                temperature = np.exp(rng.uniform(np.log(2e3), np.log(8e4)))
                y[13] = 1.5 * joint.KB * ((1 + joint.CHARGE) @ y[:13]) * temperature
                y[27:s.eidx] = source * f['dt_s'] * np.exp(rng.uniform(-4, 2, s.m))
                expected = np.zeros(s.dim)
                expected[:27] = g.rhs(y[:14], f['Tcmb_K'])[:27]
                rates = joint.C * sigma * y[joint.LO][None, :] * y[27:s.eidx, None]
                edge_events = rates.sum(axis=0)
                expected[27:s.eidx] = source - rates.sum(axis=1)
                np.add.at(expected, joint.LO, -edge_events)
                np.add.at(expected, joint.HI, edge_events)
                heat = (rates * (energies[:, None] - chi[None, :])).sum(axis=0) * joint.EV
                expected[13] += sum(heat)
                expected[s.eidx:s.eidx + 4] = edge_events
                expected[s.eidx + 4:s.eidx + 8] = heat
                expected[-2] = sum(source)
                expected[-1] = source @ energies * joint.EV
                got = s.rhs(y)
                # Roundoff test for separately ordered algebra, not a continuum bound.
                scale = np.maximum(np.maximum(np.abs(expected), np.abs(got)), 1e-290)
                self.assertLess(float(np.max(np.abs(expected - got) / scale)), 3e-12)

    def test_stable_phi_against_70_digit_integral(self):
        with mp.workdps(70):
            for tau in [0., 1e-14, 1e-8, 1e-4, 1., 10., 1e3, 1e12]:
                exact = mp.mpf(1) if tau == 0 else -mp.expm1(-mp.mpf(tau)) / mp.mpf(tau)
                got = float(joint.stable_phi(np.array([tau]))[0])
                self.assertLess(abs(float((mp.mpf(got) - exact) / exact)), 8e-16)

    def test_continuous_birth_has_no_instant_absorption(self):
        with joint.JointServer() as s:
            y = joint.initial(s)
            r = s.rhs(y, gas_mask=0, photo=True)
            np.testing.assert_array_equal(r[27:s.eidx], s.fixture['source_m3_s'])
            np.testing.assert_array_equal(r[s.eidx:s.eidx + 8], np.zeros(8))
            np.testing.assert_array_equal(r[:27], np.zeros(27))

    def test_saved_references_and_all_completed_ledgers(self):
        ref = json.loads((ROOT / 'evidence/Radau_tight/result.json').read_text())['observables']
        for name in ['Radau_n1', 'DOP853_n1']:
            data = json.loads((ROOT / f'evidence/{name}/result.json').read_text())['observables']
            self.assertLess(abs(data['T_K'] - ref['T_K']), 1e-7)
            for key in ['survivor_m3', 'absorbed_HI_m3', 'absorbed_HeI_m3', 'absorbed_HeII_m3', 'absorbed_DI_m3']:
                self.assertLess(abs(data[key] / ref[key] - 1), 1e-8)
        paths = list((ROOT / 'evidence').glob('*/result.json'))
        self.assertEqual(len(paths), 25)
        for path in paths:
            data = json.loads(path.read_text())
            obs = data['observables']
            self.assertLess(obs['photon_ledger_rel'], 2e-11)
            self.assertLess(obs['energy_ledger_rel_source'], 2e-9)
            self.assertLess(obs['nuclei_relative_max'], 2e-11)
            self.assertLess(obs['species_event_D_fraction'], 2e-10)
            self.assertTrue(np.isfinite(data['state']).all())


if __name__ == '__main__':
    unittest.main()
