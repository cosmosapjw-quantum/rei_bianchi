#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)";cd "$ROOT"
if [[ -n "${RUST_BIN:-}" ]]; then export PATH="$RUST_BIN:$PATH";fi
export CARGO_BUILD_JOBS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
M=code/rei_bass_coupled/Cargo.toml
case "${1:-verify}" in
verify) sha256sum -c SHA256SUMS.txt; python scripts/verify_sources.py;;
build) rustc --version;cargo build --release --offline --locked --manifest-path "$M" --example gas_rhs_server --example source_support_server --example retarded_joint_server --example fixed_packet_campaign;;
tests) cargo test --offline --locked --all-targets --manifest-path "$M";python scripts/test_source_support.py;python scripts/test_retarded.py;;
lint) cargo clippy --offline --locked --all-targets --manifest-path "$M" -- -D warnings;rustfmt --check --edition 2024 code/rei_bass_coupled/src/source_support.rs code/rei_bass_coupled/tests/source_support.rs code/rei_bass_coupled/examples/source_support_server.rs;;
reference) python scripts/replay09_reference.py;;
*) echo 'Usage: bash scripts/REPLAY_OFFLINE.sh verify|build|tests|lint|reference' >&2;exit 2;;
esac
