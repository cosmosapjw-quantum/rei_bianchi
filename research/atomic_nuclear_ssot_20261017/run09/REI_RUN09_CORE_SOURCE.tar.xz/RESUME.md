# RUN09 resume: bounded source-support scan completed

Read docs/REPORT_KO.md, contracts/DAG_PROGRESS.json, evidence/NUMERICAL_SUMMARY.json; validate SHA256SUMS.txt and contracts/UNCHANGED_SOURCE_RUN09.json. RUN08 archive in provenance/RUN08.zip preserves the original45/26 DAGs and prior results.

Completed: native equal subdivision of original graded GL4 panels, SAME fixed geometry/atomic/IC/spectral48/angular8; r1/2/4/6 ->40/80/160/240 birth times,7 joint DOP853 configurations including tighter tolerances and full/reflection control. Original r1 packet tuple SHA7d29d5c9... exactly matched. Do not relabel finest r6 as exact continuum source. Source total moments converge much faster than some gas/event outputs. MP60 nonlinear impulse witness is not the HHeD system.

Next: P4-S4C-SPECTRAL-EDGE-SUPPORT. Use r4 support as a resource-bounded working choice with measured r4/r6 output differences (not error bounds). First refine just the original spectral source cell containing H/D edge with positive quadrature and preserve per-cell source count; keep native atomic thresholds/bindings distinct. Compare joint solutions before mixing time-step/angle changes. Keep all fullEoR/feedback/nuclear gates open.

R8 packet is exported but joint endpoint absent after outer45s interruption. No blind retry. Original scalar/photo/gas/geometry solvers remain unchanged. Per-case38s plus preparation can exceed outer wall; export is a separate command. Completed r6 joint wall~24s; max measured complete-process RSS~1.21GiB. No source clipping/renormalization. No local/Codex/NCP/SSH/native subagents.

Run scripts/REPLAY_OFFLINE.sh verify|build|tests|lint|reference in separate commands. External Rust1.94.1 and PythonNumPy/SciPy/mpmath required. Reference replays r2 paired3e-11 and exact endpoint equality; all7case campaign is not required for restoration.

Publish task source to GitHub and full recovery ZIP to the established Drive/Dropbox destinations every research turn. External DELIVERY_RECEIPT.json records actual new IDs and validation levels; do not reseal final ZIP after upload. Git-only standalone restoration of earlier missing RUN06 source has not been established by this task.
