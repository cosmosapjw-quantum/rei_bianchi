#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
: "${REI_F4_PARENT_ROOT:?Set REI_F4_PARENT_ROOT to the extracted original PR313 source master directory}"
: "${REI_F4_PARENT_ZIP:?Set REI_F4_PARENT_ZIP to original immutable PR313 master ZIP}"
python -m unittest discover -s "$ROOT/tests" -q
python "$ROOT/code/verify_release.py" --root "$ROOT"
echo REI_F4_SCOPED_VERIFY_PASS
