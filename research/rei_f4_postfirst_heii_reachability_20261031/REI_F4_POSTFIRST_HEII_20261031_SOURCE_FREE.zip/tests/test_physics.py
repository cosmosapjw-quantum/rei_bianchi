"""Bounded scientific validation with original source. No original HeII CCC sigma claimed."""
import sys,math,unittest,random,json,os
from pathlib import Path
import numpy as np,pandas as pd
from scipy.integrate import cumulative_trapezoid, trapezoid, quad
from numpy.polynomial.legendre import leggauss
ROOT=Path(__file__).resolve().parents[1]
SRC=Path(os.environ.get('REI_F4_PARENT_ROOT','/mnt/data/rei_f4_work/REI_F4_CCC6_FIRST_EVENT_20261031'))
MASTER=Path(os.environ.get('REI_F4_PARENT_ZIP','/mnt/data/REI_F4_CCC6_FIRST_EVENT_20261031_FULL.zip'))
sys.path.insert(0,str(ROOT/'code'))
import compute as c

class Physics(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.p,cls.m,cls.arr,cls.chem,cls.th,cls.pl,cls.coul,cls.data,cls.owner,cls.meta,cls.bands,cls.orig=c.load_parent(SRC)
  cls.E=cls.m.energy_nodes(cls.data,1700)
  cls.sig=cls.m.sigma_samples(cls.data,cls.owner,cls.E)
  out=ROOT/'results'
  cls.result=json.loads((out/'RESULTS.json').read_text())
  cls.a=pd.read_csv(out/'POSTFIRST_BASS193_192.csv')
  cls.b=pd.read_csv(out/'POSTFIRST_SOURCE_BANDS_3840.csv')
  cls.mon=pd.read_csv(out/'POSTFIRST_MONO_1544.csv')
 def test_01_original_source_identity(self):
  import hashlib
  b=MASTER.read_bytes()
  self.assertEqual(hashlib.sha256(b).hexdigest(),c.PARENT_SHA)
 def test_02_dimensions(self):self.assertEqual((len(self.a),len(self.b),len(self.mon)),(192,3840,1544))
 def test_03_baryon_initial_electrons(self):self.assertAlmostEqual(self.result['first_electrons_per_b'],4.374110632809567e-12,delta=1e-22)
 def test_04_source_energy(self):self.assertAlmostEqual(self.result['initial_energy_eV_per_b'],6.749242464433258e-11,delta=1e-21)
 def test_05_source_mean_ledger(self):
  s=sum(self.result['energy_mean_breakdown_eV_per_b'].values())
  self.assertLess(abs(s-self.result['initial_energy_eV_per_b']),3e-25)
  self.assertLess(self.a.energy_mean_closure_residual_eV_per_b.abs().sum(),1e-22)
 def test_06_each_band_point_ledger(self):
  for _,r in self.b.iterrows():
   obs=sum(r[f+'_mean_per_b'] for f in c.FIELDS)
   self.assertLess(abs(obs-r.source_M_eV_per_b),1e-24+2e-12*abs(r.source_M_eV_per_b))
 def test_07_every_mono_ledger(self):
  self.assertLess(float(self.mon.energy_closure_abs_eV.max()),2e-12)
  for _,r in self.mon.iterrows():self.assertLess(abs(sum(r[f] for f in c.FIELDS)-r.electron_E0_eV),2e-12)
 def test_08_probabilities_and_energy_nonnegative(self):
  self.assertTrue(((self.mon.any_selected_event_p>=0)&(self.mon.any_selected_event_p<=1+1e-14)).all())
  for f in c.FIELDS:self.assertGreater(self.mon[f].min(),-1e-13)
 def test_09_charge_conservation_H_He(self):
  np.testing.assert_allclose(self.a.HI_ion_first_per_b+self.a.HeI_ion_first_per_b,self.a.first_ion_charge_electrons_per_b,rtol=0,atol=5e-28)
  self.assertLess(abs(self.result['charge_residual_per_b']),1e-26)
 def test_10_heii_ion_source_only_li(self):
  self.assertEqual(float(self.b.loc[self.b.first_absorber!='Li_I','HeII_ion_eligible_upper_per_b'].sum()),0.)
  self.assertGreater(float(self.b.loc[self.b.first_absorber=='Li_I','HeII_ion_eligible_upper_per_b'].sum()),0.)
 def test_11_heii_n3_source_only_li(self):
  self.assertEqual(float(self.b.loc[self.b.first_absorber!='Li_I','HeII_n3_eligible_upper_per_b'].sum()),0.)
 def test_12_heii_n2_source_H(self):
  self.assertGreater(self.b.loc[self.b.first_absorber=='H_I','HeII_n2_eligible_upper_per_b'].sum(),1e-13)
 def test_13_HeII_reachability_hierarchy(self):
  d=self.result['HeII_reachability_electrons_per_b'];caps=list(c.CAPS)
  for name in caps:
   self.assertLessEqual(d[name]['lower'],d[name]['upper']+1e-35)
   self.assertLessEqual(d[name]['upper'],self.result['first_electrons_per_b'])
  for a,b in zip(caps,caps[1:]):
   self.assertLessEqual(d[b]['lower'],d[a]['lower']+1e-35)
   self.assertLessEqual(d[b]['upper'],d[a]['upper']+1e-35)
 def test_14_threshold_exact_source_support(self):
  chi=c.HEII_ION; Emax=self.m.E_PAIR
  self.assertLess(Emax-self.m.CHI['H_I'],chi)
  self.assertLess(Emax-self.m.CHI['He_I'],c.HEII_N2)
  self.assertGreater(Emax-self.m.CHI['Li_I'],chi)
  self.assertLess(Emax-self.m.CHI['H_I'],c.HEII_N3)
 def test_15_hydrogenic_threshold_N3(self):
  self.assertAlmostEqual(c.HEII_N3,c.HEII_ION*(1.-1./9.),places=13)
 def test_16_helium_ion_density_is_nonzero(self):
  self.assertGreater(self.result['HeII_density_cm3_range'][1],1e-5)
 def test_17_NIST_H_I_ion_energy_repair(self):
  self.assertAlmostEqual(self.result['HI_ion_threshold_energy_correction_eV_per_b'],(c.HI_ION_NIST-13.6058)*self.a.HI_ion_first_per_b.sum(),delta=2e-28)
  self.assertLess(self.result['HI_ion_threshold_energy_correction_eV_per_b'],0.)
 def test_18_stable_cell_mean_exp(self):
  for d in (1e-10,1e-6,1e-3,.1,1.,20.):
   val=quad(lambda x: x*d*math.exp(-d*x),0,1,epsabs=1e-13)[0]/(-math.expm1(-d))
   self.assertAlmostEqual(c.f_exponential(d),val,delta=5e-9)
 def test_19_moment_bounds_random_two_points(self):
  rng=random.Random(391201)
  for _ in range(300):
   lo=rng.uniform(0,20);hi=lo+rng.uniform(0.1,60)
   x=lo+rng.random()*(hi-lo);y=lo+rng.random()*(hi-lo);w=rng.random();mu=w*x+(1-w)*y
   for threshold in (5.,40.81332,48.37134,54.41776):
    lower,upper=c.frac_interval_above(lo,hi,mu,threshold)
    actual=w*float(x>threshold)+(1-w)*float(y>threshold)
    self.assertLessEqual(lower-actual,1e-11);self.assertLessEqual(actual-upper,1e-11)
 def test_20_six_selected_only_not_full(self):
  self.assertFalse(self.result['HeII_sigma_read'])
  self.assertFalse(self.result['HeII_probability_computed'])
  self.assertFalse(self.result['full_cascade'])
  self.assertEqual(self.result['canonical_delta'],0)
 def test_21_independent_energy_quadrature(self):
  # Distinct integration route: directly integrate the continuous energy hazard
  # times exact cumulative survival, rather than using the cell exponential recurrence.
  for epoch in (40,60,80,120,180):
   j=epoch-1
   ne=float(self.coul.n_e_m3.iloc[epoch])*1e-6
   nh=float(self.coul.n_b_m3.iloc[epoch])*1e-6*float(self.th.nHref_over_nb.iloc[j]);
   hi=nh*(1.-float(self.chem.xHII_end.iloc[j]));he=nh*float(self.chem.helium_per_H_ref.iloc[j])*float(self.chem.xHeI_end.iloc[j])
   out,p,_=c.ledger_nodes(self.E,self.sig,ne,hi,he,self.m)
   _,_,h=self.m.first_probs(self.E,self.sig,ne,hi,he)
   htot=h.sum(axis=0);H=cumulative_trapezoid(htot,self.E,initial=0.)
   # Piecewise linear energy hazard, accurate Gauss nodes within every cell.
   # Coarse endpoint trapezoid over-counts an optically thick boundary layer.
   xi,weights=leggauss(48);q=(xi+1.)/2.
   de=np.diff(self.E)[:,None]; nodes=self.E[:-1,None]+de*q
   hnodes=htot[:-1,None]+(htot[1:]-htot[:-1])[:,None]*q
   Hnodes=H[:-1,None]+de*(htot[:-1,None]*q+.5*(htot[1:]-htot[:-1])[:,None]*q**2)
   rate=hnodes*np.exp(Hnodes-H[-1]); dw=de*weights/2.
   prob_quad=float(np.sum(dw*rate))
   moment_quad=float(np.sum(dw*rate*nodes))
   prob_recur=p[:6,-1].sum();moment_recur=out[1,-1]+out[2,-1]
   self.assertLess(abs(prob_quad-prob_recur),2e-10*max(1e-12,prob_recur))
   self.assertLess(abs(moment_quad-moment_recur),1e-6*max(1e-12,moment_recur))
 def test_22_pr312_coulomb_reproduction(self):
  old=2.293087507e-11
  got=self.result['energy_mean_breakdown_eV_per_b']['Coulomb_pre_first_eV']
  self.assertLess(abs(got-old)/old,5e-6)
 def test_23_no_negative_event_transfer(self):
  self.assertTrue((self.a['atomic_threshold_eV_mean_per_b']>=0).all())
  self.assertTrue((self.a['Coulomb_pre_first_eV_mean_per_b']>=0).all())
 def test_24_dag_not_modified(self):
  self.assertEqual(self.result['working_DAG'],'33/88');self.assertEqual(self.result['physical_fast_DAG'],'4/7')
if __name__=='__main__':unittest.main()
