#!/usr/bin/env python3
"""Scientific figures of the real source conditional ledgers, independent of private sources."""
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
a=pd.read_csv(ROOT/'results/POSTFIRST_BASS193_192.csv')
f=['Coulomb_pre_first_eV','atomic_threshold_eV','post_first_electrons_eV','no_selected_cutoff_eV']
labels=['Coulomb before first CCC6 event','Atomic excitation/ionization threshold','Electrons after selected first event','No selected event: cutoff electrons']
valid=a.source_M_eV_per_b>0;z=a.z_low.to_numpy();E=a.source_M_eV_per_b.to_numpy()
fig,ax=plt.subplots(figsize=(11,5.5),layout='constrained')
for name,label in zip(f,labels):
 y=np.full(len(a),np.nan);y[valid.to_numpy()]=a.loc[valid,name+'_mean_per_b']/E[valid.to_numpy()]
 ax.plot(z,y,lw=1.6,label=label)
ax.set(xlabel='Redshift z (frozen BASS193; decreasing cosmological time)',ylabel='Fraction of original primary-photoelectron kinetic energy',title='Physical Fast F4: source-owned partial first-event energy ledger')
ax.set_ylim(-.01,1.02);ax.legend(fontsize=8,loc='upper left');ax.grid(True,alpha=.2)
for ext in ('png','svg'):fig.savefig(OUT/('F4_POSTFIRST_ENERGY_LEDGER.'+ext),dpi=180)
plt.close(fig)
fig,ax=plt.subplots(figsize=(11,5.5),layout='constrained')
for n,label in [('HeII_n2_eligible','He II 1s→n=2 threshold'),('HeII_n3_eligible','He II 1s→n=3 threshold'),('HeII_ion_eligible','He II ground-state ionization')]:
 hi=a[n+'_upper_per_b'].to_numpy();lo=a[n+'_lower_per_b'].to_numpy()
 ax.plot(z,np.maximum(hi,1e-38),lw=1.8,label=label+' upper')
 ax.plot(z,np.maximum(lo,1e-38),ls=':',lw=1.1,label=label+' lower')
ax.set(xlabel='Redshift z',ylabel='Kinematically eligible primary electrons / original baryon',yscale='log',ylim=(1e-29,1e-11),title='He II source reachability: threshold and N/M bounds only, NOT collision events')
ax.legend(fontsize=7,loc='upper right');ax.grid(True,alpha=.2)
for ext in ('png','svg'):fig.savefig(OUT/('F4_HEII_KINEMATIC_REACHABILITY.'+ext),dpi=180)
plt.close(fig)
print('saved 2 PNG + 2 SVG')
