#!/usr/bin/env python3
"""Verify all source-free published payload files against manifest; no private source required."""
import argparse,hashlib,json
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--root',default=str(Path(__file__).resolve().parents[1]));v=ap.parse_args()
root=Path(v.root);entries=json.loads((root/'evidence/SHA256_MANIFEST.json').read_text());bad=[]
for rel,meta in sorted(entries.items()):
 p=root/rel
 if not p.is_file():bad.append('MISSING '+rel);continue
 b=p.read_bytes()
 if len(b)!=meta['bytes'] or hashlib.sha256(b).hexdigest()!=meta['sha256']:bad.append('HASH '+rel)
print('SCOPED_SOURCE_FREE_MANIFEST',len(entries),'FAIL',len(bad))
if bad:
 print('\n'.join(bad));raise SystemExit(1)
