#!/usr/bin/env python3
"""Frozen BASS193 source-moment post-CCC6 first-event energy/charge ledger and
He II collision *kinematic reachability*. No new IVP and no claimed He II cross sections.

Authoritative source is PR313 private master with exact published SHA. The CCC6
collision probabilities are a six-channel partial kernel from the immutable PR311
reduced EXHALE data, NOT the complete Curtin 2026 atomic tables.
"""
import argparse, hashlib, importlib.util, json, math, pathlib, sys
import numpy as np, pandas as pd

ROOT=pathlib.Path(__file__).resolve().parents[1]
PARENT_SHA='4e8d4602cd2a8105c957fbda90eff23dede3eb7688013eb9d987fa58f870cdd4'
PARENT_HEAD='47f34ccb68f02262f40cd3dfd198aa97abd35183'
HEII_ION=54.417760    # NIST 4He II, eV. Ground state.
HEII_N2=HEII_ION*(1.-1./4.) # hydrogenic, neglect fine/recoil splittings
HEII_N3=HEII_ION*(1.-1./9.)
HI_ION_NIST=13.598434599702
FIELDS=['Coulomb_pre_first_eV','atomic_threshold_eV','post_first_electrons_eV','no_selected_cutoff_eV']
CAPS={'HeII_n2_eligible':HEII_N2,'HeII_n3_eligible':HEII_N3,'HeII_ion_eligible':HEII_ION}


def sha(path):return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def load_parent(source_root):
    p=pathlib.Path(source_root).resolve()
    if not (p/'code/run.py').is_file(): raise FileNotFoundError('Original PR313 source extraction required')
    spec=importlib.util.spec_from_file_location('pr313_ccc6_source',p/'code/run.py')
    parent=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(parent)
    arr,chem,th,pl,coul,data,owner,meta=parent.input_load()
    bands=pd.read_csv(p/'results/BASS_CCC6_FIRST_EVENT_SOURCE_BANDS_3840.csv')
    origins=pd.read_csv(p/'results/BASS_CCC6_FIRST_EVENT_ARRIVAL_192.csv')
    assert len(bands)==3840 and len(origins)==192 and len(coul)==193
    return p,parent,arr,chem,th,pl,coul,data,owner,meta,bands,origins


def frac_interval_above(lo,hi,mu,threshold):
    """Optimal moment-only lower and upper mass fractions at E>threshold.
    Endpoint-equality convention matters only for a point atom at threshold,
    where a physical cross-section vanishes. Conservative closure used.
    """
    if hi<=threshold: return 0.,0.
    if lo>threshold: return 1.,1.
    if hi<=lo:
        z=float(lo>threshold);return z,z
    mu=max(lo,min(hi,mu))
    lower=max(0.,(mu-threshold)/(hi-threshold)) if hi>threshold else 0.
    upper=min(1.,(mu-lo)/(threshold-lo)) if lo<threshold else 1.
    return float(lower),float(upper)


def f_exponential(d):
    """Mean normalized distance traversed before an event in a finite cell.
    For e-high to e-low with cell integrated hazard d,
      E[event|event in cell]=Ehigh-(Ehigh-Elow)*f(d).
    f(d)=1/d-1/expm1(d), with stable weak/strong limits.
    """
    if d<0:raise ValueError('negative hazard')
    if d<0.005:return 0.5-d/12+d**3/720-d**5/30240
    if d>45:return 1./d
    return 1./d-1./math.expm1(d)


def ledger_nodes(E,sigmas,ne,nh,nhe,parent,correct_hi_binding=True):
    """One recurrence, two moments. Events are competing selected CCC6 only.
    Each selected collision leaves all post-collision electron kinetic E-chi
    (undivided for ionization), not presumed gas heat.
    """
    p,nu,h=parent.first_probs(E,sigmas,ne,nh,nhe)
    dE=np.diff(E)
    dh=.5*(h[:,:-1]+h[:,1:])*dE[None,:]
    G=np.zeros((6,len(E)))
    for i in range(len(dE)):
        da=dh[:,i]; d=float(da.sum())
        if d<=0:
            G[:,i+1]=G[:,i]
            continue
        decay=math.exp(-d) if d<745 else 0.
        w=-math.expm1(-d)
        ebar=E[i+1]-dE[i]*f_exponential(d)
        G[:,i+1]=decay*G[:,i]+(da/d)*w*ebar
    chi=np.array([parent.THRESH[k] for k in parent.CHANNELS])
    # The parent used 13.6058 eV for H I ionization in its threshold floor.
    # Replace only the *energy ledger* binding by the NIST ground-state value.
    # Cross sections and first-event probabilities remain unchanged.
    if correct_hi_binding:chi[parent.CHANNELS.index('HI_ion')]=HI_ION_NIST
    Q=chi@p[:6]
    Gsum=G.sum(axis=0)
    K_selected=Gsum-Q
    K_cutoff=parent.LOW*p[6]
    C_pre=E-Gsum-K_cutoff
    out=np.vstack([C_pre,Q,K_selected,K_cutoff])
    assert np.isfinite(out).all() and np.min(out)>-2e-11
    out=np.maximum(out,0.)
    assert np.max(abs(out.sum(axis=0)-E))<5e-11
    # source-wise charge jump: e + HII + HeII, same ionization counts
    idxH=parent.CHANNELS.index('HI_ion');idxHe=parent.CHANNELS.index('HeI_ion')
    free_e=p[idxH]+p[idxHe]
    return out,p,free_e


def at_energy(E,arr,points,LOW):
    # For E<13.7 eV, scoped kernel has no counted event or Coulomb before event.
    # All energy stays in the (NOT_HEAT) unresolved residual electron pool.
    # The E=LOW definition agrees with the parent kernel.
    points=np.asarray(points,float)
    return np.where(points<LOW, (points if arr is None else 0.),np.interp(points,E,arr))


def band_bounds(E,kernel,lo,hi,mu,parent,field):
    if hi<=lo: return np.zeros(3) if field!=3 else np.array([lo]*3)
    # Extra kinematic knot E=13.7 ensures exact interpolation at the cutoff.
    knots=np.unique(np.r_[lo,parent.LOW,E[(E>max(lo,parent.LOW))&(E<hi)],hi]) if lo<parent.LOW and hi>parent.LOW else np.unique(np.r_[lo,E[(E>lo)&(E<hi)],hi])
    vals=np.interp(np.maximum(knots,parent.LOW),E,kernel)
    under=knots<parent.LOW
    vals[under]=knots[under] if field==3 else 0.
    return parent.moment_bounds(knots,vals,lo,hi,mu)


def compute(source_root,grid=1500,output_dir=ROOT):
    p,m,arr,chem,th,pl,coul,data,owner,meta,bands,origins=load_parent(source_root)
    E=m.energy_nodes(data,grid)
    sig=m.sigma_samples(data,owner,E)
    result_bands=[]; result_arr=[];mono=[];min_g=1.;max_residual=0.
    fields_per_epoch=[]
    for epoch in range(193):
        j=epoch-1
        if j>=0:
            n_h=float(coul.n_b_m3.iloc[epoch])*1e-6*float(th.nHref_over_nb.iloc[j]);fr=chem.iloc[j]
            nHI=n_h*(1-float(fr.xHII_end))
            nHe_total=n_h*float(fr.helium_per_H_ref)
            nHeI=nHe_total*float(fr.xHeI_end)
            nHeII=nHe_total*float(fr.xHeII_end)
            nHeIII=nHe_total*float(fr.xHeIII_end)
            assert abs(nHeI+nHeII+nHeIII-nHe_total)<1e-12*max(1e-20,nHe_total)
            assert abs(nHI-float(origins.nHI_cm3.iloc[j]))<1.2e-12*max(1e-30,nHI)
            # PR313 CSV serializes helium abundance at ~1e-16 absolute, which
            # can be ~1e-12 relative; verify against that representation budget.
            assert abs(nHeI-float(origins.nHeI_cm3.iloc[j]))<1.2e-12*max(1e-30,nHeI)
        else:
            n_h=float(coul.n_b_m3.iloc[0])*1e-6*float(th.nHref_over_nb.iloc[0]);fr=chem.iloc[0]
            nHI=n_h*(1-float(fr.xHII_start));nHe_total=n_h*float(fr.helium_per_H_ref)
            nHeII=nHe_total*float(fr.xHeII_start);nHeIII=nHe_total*float(fr.xHeIII_start)
            nHeI=nHe_total-nHeII-nHeIII
        ne=float(coul.n_e_m3.iloc[epoch])*1e-6
        ledger,prob,charge=ledger_nodes(E,sig,ne,nHI,nHeI,m)
        fields_per_epoch.append((ledger,prob,charge))
        for e0 in [10.,13.7,18.,22.,30.,45.,55.,m.E_PAIR]:
            if e0>m.E_PAIR:continue
            vals=[float(np.interp(e0,E,ledger[f])) if e0>=m.LOW else (e0 if f==3 else 0.) for f in range(4)]
            pp=float(np.interp(max(e0,m.LOW),E,prob[:6].sum(axis=0))) if e0>=m.LOW else 0.
            mono.append(dict(epoch=epoch,z=float(coul.z.iloc[epoch]),electron_E0_eV=e0,nHeII_cm3=nHeII,nHeIII_cm3=nHeIII,nHeI_cm3=nHeI,ne_full_BASS_cm3=ne,any_selected_event_p=pp,first_ion_charge_electrons_p=float(np.interp(max(e0,m.LOW),E,charge)) if e0>=m.LOW else 0.,**{f:v for f,v in zip(FIELDS,vals)},energy_closure_abs_eV=abs(sum(vals)-e0)))
        if j<0:continue
        actual=origins.iloc[j]
        rows=bands[bands.arrival_interval==j]
        assert len(rows)==20
        agg=np.zeros((4,3)); caps={name:np.zeros(2) for name in CAPS}
        charge_from_bands=0.;incoming_N=0.; incoming_M=0.
        for _,r in rows.iterrows():
            N=float(r.source_electron_count_per_b);M=float(r.source_kinetic_eV_per_b)
            lo=float(r.source_support_min_eV); hi=float(r.source_support_max_eV)
            mu=float(r.source_mean_e_eV) if N>0 else 0.
            bnds=np.zeros((4,3))
            if N>0:
                for f in range(4):bnds[f]=m.moment_bounds(E,ledger[f],lo,hi,mu) if lo>=m.LOW else band_bounds(E,ledger[f],lo,hi,mu,m,f)
                assert np.all(bnds[:,0]<=bnds[:,1]+2e-12) and np.all(bnds[:,1]<=bnds[:,2]+2e-12)
                # The four mean-collocated energy moments satisfy E0 at exactly mu.
                en_res=abs(float(bnds[:,1].sum())-mu)
                max_residual=max(max_residual,en_res)
                assert en_res<6e-11,(j,r.first_absorber,r.energy_band,en_res)
            weighted=N*bnds
            agg+=weighted
            incoming_N+=N;incoming_M+=M
            capfields={}
            for name,t in CAPS.items():
                a,b=frac_interval_above(lo,hi,mu,t) if N>0 else (0.,0.)
                assert -1e-15<=a<=b+1e-15<=1.+1e-15
                caps[name]+=N*np.array([a,b]);capfields[name+'_lower_per_b']=N*a;capfields[name+'_upper_per_b']=N*b
            charge_from_bands+=float(r.HI_ion_mean+r.HeI_ion_mean)
            row=dict(arrival_interval=j,z_low=float(r.z_low),first_absorber=r.first_absorber,energy_band=r.energy_band,source_N_per_b=N,source_M_eV_per_b=M,nHeII_cm3=nHeII)
            for field in range(4):
                for k,kname in enumerate(('lower','mean','upper')):row[FIELDS[field]+'_'+kname+'_per_b']=float(weighted[field,k])
            row.update(capfields);result_bands.append(row)
        assert abs(incoming_N-float(actual.photoelectron_N_per_b))<2e-23
        assert abs(incoming_M-float(actual.photoelectron_E_eV_per_b))<3e-22
        assert abs(float(agg[:,1].sum())-incoming_M)<2e-20
        entry=dict(arrival_interval=j,z_high=float(actual.z_high),z_low=float(actual.z_low),nHeII_cm3=nHeII,nHeIII_cm3=nHeIII,nHeI_cm3=nHeI,ne_full_BASS_cm3=ne,source_N_per_b=incoming_N,source_M_eV_per_b=incoming_M,first_ion_charge_electrons_per_b=charge_from_bands,HI_ion_first_per_b=float(actual.HI_ion_mean),HeI_ion_first_per_b=float(actual.HeI_ion_mean),charge_closure_residual_per_b=charge_from_bands-float(actual.HI_ion_mean+actual.HeI_ion_mean))
        for f in range(4):
            for k,kname in enumerate(('lower','mean','upper')):entry[FIELDS[f]+'_'+kname+'_per_b']=float(agg[f,k])
        for name,cap in caps.items():entry[name+'_lower_per_b']=float(cap[0]);entry[name+'_upper_per_b']=float(cap[1])
        entry['energy_mean_closure_residual_eV_per_b']=float(agg[:,1].sum()-incoming_M)
        result_arr.append(entry)
    a=pd.DataFrame(result_arr);b=pd.DataFrame(result_bands);mo=pd.DataFrame(mono)
    out=pathlib.Path(output_dir)/'results';out.mkdir(parents=True,exist_ok=True)
    for name,df in [('POSTFIRST_BASS193_192.csv',a),('POSTFIRST_SOURCE_BANDS_3840.csv',b),('POSTFIRST_MONO_1544.csv',mo)]:df.to_csv(out/name,index=False,float_format='%.17g')
    E0=float(a.source_M_eV_per_b.sum())
    result=dict(schema='REI_F4_SOURCE_CONDITIONAL_POSTFIRST_CCC6_ENERGY_CHARGE_HEII_REACHABILITY_V1',parent_pr=313,parent_sha=PARENT_HEAD,original_source_sha256=PARENT_SHA,original_BASS_epochs=193,original_source_arrivals=192,original_source_bands=3840,first_electrons_per_b=float(a.source_N_per_b.sum()),initial_energy_eV_per_b=E0,energy_mean_breakdown_eV_per_b={x:float(a[x+'_mean_per_b'].sum()) for x in FIELDS},energy_closure_residual_eV_per_b=float(sum(a[x+'_mean_per_b'].sum() for x in FIELDS)-E0),max_mono_energy_residual_eV=float(mo.energy_closure_abs_eV.max()),max_band_mean_energy_residual_eV=float(max_residual),charge_electrons_from_HI_HeI_first_ion_per_b=float(a.first_ion_charge_electrons_per_b.sum()),charge_residual_per_b=float(a.charge_closure_residual_per_b.sum()),HeII_density_cm3_range=[float(a.nHeII_cm3.min()),float(a.nHeII_cm3.max())],HeII_thresholds_eV=dict(n2=HEII_N2,n3=HEII_N3,ion=HEII_ION),HeII_reachability_electrons_per_b={name:{'lower':float(a[name+'_lower_per_b'].sum()),'upper':float(a[name+'_upper_per_b'].sum())} for name in CAPS},HI_ion_threshold_parent_eV=13.6058,HI_ion_threshold_NIST_eV=HI_ION_NIST,HI_ion_threshold_energy_correction_eV_per_b=float((HI_ION_NIST-13.6058)*a.HI_ion_first_per_b.sum()),channel_numerics='UNCHANGED_6CCC_SOURCE_KERNEL',HeII_sigma_read=False,HeII_probability_computed=False,full_cascade=False,temperature_evolution=False,native_full_FJ=False,working_DAG='33/88',central_DAG='28/88',physical_fast_DAG='4/7',canonical_delta=0,production='HOLD')
    (out/'RESULTS.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--source-root',required=True);ap.add_argument('--grid',type=int,default=1500);ap.add_argument('--out',default=str(ROOT));v=ap.parse_args()
    print(json.dumps(compute(v.source_root,v.grid,v.out),indent=2))
