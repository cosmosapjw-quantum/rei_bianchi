//! Native live REI source/chemistry on accepted BASS geometry. Restore
//! F08 characteristic-born packets without the historical hot-FT03 domain
//! restriction. Actual chemistry uses the shared REI AXBI stage, not xe table.
//! Geometry is frozen to the accepted BASS trajectory; CMB Thomson is a
//! tracer driven by live charge, with isotropic CMB thermal bath retained.
use super::replay::StepRecord;
use super::{
    birth_packets::{
        rate_moment_error, sum, BirthPackets, CompressionLedger, RateGuard, TransportLedger,
    },
    geometric_one, initial_sky, scatter_with, CollisionScheme, Photon,
};
use crate::kinetic::lie_history::RayNode;
use rec_microphysics::thomson_history::C_SIGMA_T_M3_S;
use rei_microphysics::{
    axbi_driver::{packet_chemistry_stage, PacketStageInput},
    axbi_sources::AxbiSource,
    coupled_primary::PrimaryPacket,
    igm_state::{w_erg_per_h_to_ev, IgmGasState},
    Absorber, AtomicProvider, HHeModel,
};

#[derive(Clone, Copy, Debug)]
pub struct LiveInput {
    pub a0: f64,
    pub h0_s: f64,
    pub nh0_m3: f64,
    pub f_he: f64,
    pub tcmb0_k: f64,
    pub initial_gas: IgmGasState,
    pub escape_fraction: f64,
    pub energy_subdivisions: usize,
    pub n_mu: usize,
}
/// eV per H nucleus; spatial component is c times axial momentum.
#[derive(Clone, Debug, Default)]
pub struct AbsorptionBudget {
    pub energy: f64,
    pub pz: f64,
    pub binding: f64,
    pub heat: f64,
    pub events: [f64; 3],
    /// Per-H energy deposition in HI, HeI, HeII from the accepted photon events.
    pub heat_by_absorber: [f64; 3],
    pub max_packet_loss: f64,
}
/// Reconstruct actual accepted BE per-species event counts using the original
/// rates and final gas. Compare to observed packet differences, not a second
/// copy of the REI ledger. This diagnoses material deposition; no velocity update.
pub fn absorption_budget(
    p: &BirthPackets,
    stocks: &[f64],
    gas: IgmGasState,
    nh_cm3: f64,
    fhe: f64,
    dt: f64,
    angular_reduced: bool,
) -> Result<AbsorptionBudget, String> {
    if stocks.len() != p.packets.len()
        || !nh_cm3.is_finite()
        || nh_cm3 <= 0.
        || !fhe.is_finite()
        || fhe <= 0.
        || !dt.is_finite()
        || dt <= 0.
    {
        return Err("UV absorption budget domain".into());
    }
    let nhe = nh_cm3 * fhe;
    gas.eos(nh_cm3, nhe).map_err(|e| e.to_string())?;
    let [x, y, z] = gas.fractions;
    let n = [nh_cm3 * (1. - x), nhe * (1. - y - z), nhe * y];
    let provider = AtomicProvider::reference();
    let c = HHeModel::controlled_fixture();
    let species = [Absorber::HI, Absorber::HeI, Absorber::HeII];
    let mut a = AbsorptionBudget::default();
    let mut es = Vec::new();
    let mut ps = Vec::new();
    for (p0, &n1) in p.packets.iter().zip(stocks) {
        if p0.ray >= p.directions.len()
            || !n1.is_finite()
            || n1 < 0.
            || !p0.per_h.is_finite()
            || p0.per_h < 0.
            || n1 > p0.per_h
        {
            return Err("UV absorption stock domain".into());
        }
        let loss = p0.per_h - n1;
        let en = loss * p0.energy_ev;
        es.push(en);
        ps.push(if angular_reduced {
            0.
        } else {
            en * p.directions[p0.ray][2]
        });
        let mut ev = 0.;
        for j in 0..3 {
            let sig = provider
                .cross_section(species[j], p0.energy_ev)
                .map_err(|e| e.to_string())?;
            let count = dt * c.c_cm_s * n[j] * sig * n1;
            a.events[j] += count;
            ev += count;
            a.binding += count * c.threshold_ev[j];
            let deposited = count * (p0.energy_ev - c.threshold_ev[j]);
            a.heat += deposited;
            a.heat_by_absorber[j] += deposited;
        }
        a.max_packet_loss = a
            .max_packet_loss
            .max((ev - loss).abs() / p0.per_h.max(1e-300));
    }
    a.energy = sum(es.into_iter());
    a.pz = sum(ps.into_iter());
    Ok(a)
}
#[derive(Clone, Debug, Default)]
pub struct FourLedger {
    pub emitted_pz: f64,
    pub absorbed_pz: f64,
    pub boundary_pz: f64,
    pub geometry_pz: f64,
    pub absorbed_energy: f64,
    pub binding_energy: f64,
    pub heat_energy: f64,
    pub max_event_gap: f64,
    pub max_absorption_energy_gap: f64,
    pub max_packet_loss: f64,
    pub max_crossing_error: f64,
    pub current_pz: f64,
    pub momentum_defect: f64,
}
#[derive(Clone, Debug, Default)]
pub struct LiveLedger {
    pub emitted_n: f64,
    pub emitted_u: f64,
    pub absorbed_n: f64,
    pub escaped_u: f64,
    pub boundary_n: f64,
    pub boundary_u: f64,
    pub thermal_work: f64,
    pub redshift_work: f64,
    pub cmb_input: f64,
    pub photo_events: [f64; 3],
    pub compression: CompressionLedger,
    pub compression_removed: usize,
    pub max_final_rate_error: f64,
    pub four: FourLedger,
}
#[derive(Clone, Debug)]
pub struct LiveRow {
    pub eta: f64,
    pub time_s: f64,
    pub h_s: f64,
    pub nh_m3: f64,
    pub gas: IgmGasState,
    pub tm_k: f64,
    pub xe: f64,
    pub photons_n: f64,
    pub photons_u: f64,
    pub packets: usize,
    pub opacity: f64,
    pub tau: f64,
    pub number_defect: f64,
    pub energy_defect: f64,
    pub root_residual: f64,
    pub max_support_error: f64,
    pub ledger: LiveLedger,
}
pub struct LiveResult {
    pub history: Vec<LiveRow>,
    pub photons: BirthPackets,
    pub cmb: Vec<Photon>,
    pub rhs: usize,
    pub isotropic_uv_reduced: bool,
}
fn midpoint(a: &RayNode, b: &RayNode) -> RayNode {
    RayNode {
        eta: (a.eta + b.eta) * 0.5,
        shear: std::array::from_fn(|i| {
            std::array::from_fn(|j| (a.shear[i][j] + b.shear[i][j]) * 0.5)
        }),
        n: a.n,
        a: a.a,
        rotation: a.rotation,
        hubble_ratio: (a.hubble_ratio * b.hubble_ratio).sqrt(),
        ..a.clone()
    }
}
fn thermal(g: IgmGasState) -> Result<f64, String> {
    w_erg_per_h_to_ev(g.w_erg_per_h).map_err(|e| e.to_string())
}
fn binding(y: IgmGasState, fhe: f64) -> f64 {
    let c = HHeModel::controlled_fixture().threshold_ev;
    c[0] * y.fractions[0] + fhe * (c[1] * y.fractions[1] + (c[1] + c[2]) * y.fractions[2])
}
fn apply_transport(l: &mut LiveLedger, m: TransportLedger, reduced: bool) {
    l.boundary_n += m.boundary_n;
    l.boundary_u += m.boundary_u;
    l.redshift_work += m.redshift_work;
    if !reduced {
        l.four.boundary_pz += m.boundary_pz;
        l.four.geometry_pz += m.redshift_pz;
    }
    l.four.max_crossing_error = l.four.max_crossing_error.max(m.crossing_energy_error);
}
fn coordinates(n: &RayNode, input: &LiveInput) -> (f64, f64, f64) {
    (
        input.a0 * n.eta.exp(),
        input.h0_s * n.hubble_ratio,
        input.nh0_m3 * (-3. * n.eta).exp(),
    )
}
fn snapshot(
    n: &RayNode,
    input: &LiveInput,
    gas: IgmGasState,
    p: &BirthPackets,
    ledger: &LiveLedger,
    t: f64,
    tau: f64,
    initial_e: f64,
    res: f64,
    support: f64,
) -> Result<LiveRow, String> {
    let (_, h, nh) = coordinates(n, input);
    let eos = gas
        .eos(nh * 1e-6, nh * 1e-6 * input.f_he)
        .map_err(|e| e.to_string())?;
    let xe = eos.electron_density_cm3 / (nh * 1e-6);
    let opacity = C_SIGMA_T_M3_S * nh * xe / h;
    let (count, energy) = p.inventory();
    let nd = count + ledger.absorbed_n + ledger.boundary_n - ledger.emitted_n;
    let ed = thermal(gas)?
        + binding(gas, input.f_he)
        + energy
        + ledger.escaped_u
        + ledger.boundary_u
        + ledger.thermal_work
        + ledger.redshift_work
        - ledger.emitted_u
        - ledger.cmb_input
        - initial_e;
    if !opacity.is_finite()
        || opacity < 0.
        || !ed.is_finite()
        || !nd.is_finite()
        || nd.abs() > 1e-8 * ledger.emitted_n.max(1.)
        || ed.abs() > 1e-8 * ledger.emitted_u.max(1.)
    {
        return Err(format!(
            "live REI ledger residual number={nd:e} energy={ed:e}"
        ));
    }
    Ok(LiveRow {
        eta: n.eta,
        time_s: t,
        h_s: h,
        nh_m3: nh,
        gas,
        tm_k: eos.temperature_k,
        xe,
        photons_n: count,
        photons_u: energy,
        packets: p.packets.len(),
        opacity,
        tau,
        number_defect: nd,
        energy_defect: ed,
        root_residual: res,
        max_support_error: support,
        ledger: ledger.clone(),
    })
}
pub fn evolve(records: &[StepRecord], input: LiveInput) -> Result<LiveResult, String> {
    evolve_with_compression(records, input, None)
}
pub fn evolve_with_compression(
    records: &[StepRecord],
    input: LiveInput,
    width: Option<f64>,
) -> Result<LiveResult, String> {
    evolve_rate_checked(records, input, width, None)
}
/// Optional per-step nonlinear moment control; not a trajectory-wide bound.
pub fn evolve_rate_checked(
    records: &[StepRecord],
    input: LiveInput,
    width: Option<f64>,
    rate_tol: Option<f64>,
) -> Result<LiveResult, String> {
    evolve_rate_checked_with_observer(records, input, width, rate_tol, |_, _, _| Ok(()))
}

/// Call the observer exactly once per accepted step after all gas, UV and CMB updates.
/// The callback receives read-only endpoints and this step's species-resolved absorption.
pub fn evolve_rate_checked_with_observer(
    records: &[StepRecord],
    input: LiveInput,
    width: Option<f64>,
    rate_tol: Option<f64>,
    mut accepted: impl FnMut(&LiveRow, &LiveRow, &AbsorptionBudget) -> Result<(), String>,
) -> Result<LiveResult, String> {
    if rate_tol.is_some() && width.is_none() {
        return Err("rate guard requires compression width".into());
    }
    if rate_tol.is_some_and(|t| !t.is_finite() || !(2e-10..=0.01).contains(&t)) {
        return Err("rate guard tolerance".into());
    }
    if records.is_empty()
        || records[0].left.eta != 0.
        || input.a0 != 1. / 21.
        || ![input.h0_s, input.nh0_m3, input.f_he, input.tcmb0_k]
            .iter()
            .all(|v| v.is_finite() && *v > 0.)
        || records.windows(2).any(|p| p[0].right.eta != p[1].left.eta)
        || records.iter().any(|r| {
            !r.first.is_empty()
                || !r.second.is_empty()
                || r.left.hubble_ratio <= 0.
                || r.right.hubble_ratio <= 0.
        })
    {
        return Err("expected continuous collision-free BASS geometry from zbar20".into());
    }
    let src = AxbiSource::new(
        input.nh0_m3 * 1e-6 * input.a0.powi(3),
        input.escape_fraction,
        input.energy_subdivisions,
        input.n_mu,
    )
    .map_err(|e| e.to_string())?;
    let dirs: Vec<[f64; 3]> = src
        .angular_cells
        .iter()
        .map(|a| [(1. - a.mu * a.mu).sqrt(), 0., a.mu])
        .collect();
    let weights: Vec<f64> = src.angular_cells.iter().map(|a| a.count_fraction).collect();
    let cells: Vec<_> = src
        .spectral_cells
        .iter()
        .map(|c| (c.energy_ev, c.photon_fraction))
        .collect();
    // The UV equation in exactly isotropic non-tilted geometry with
    // an isotropic source and empty initial UV inventory is scalar in angle.
    // A common spectrum avoids independently rounded threshold decisions.
    // Keep the full CMB transport and the original angular quadrature.
    let isotropic_uv_reduced = width.is_some()
        && records.iter().all(|r| {
            [&r.left, &r.right].iter().all(|n| {
                n.shear.iter().flatten().all(|&x| x == 0.)
                    && n.n.iter().flatten().all(|&x| x == 0.)
                    && n.a == [0.; 3]
                    && n.rotation == [0.; 3]
            })
        });
    let mut p = if isotropic_uv_reduced {
        BirthPackets::new(vec![[0., 0., 1.]], vec![1.])?
    } else {
        BirthPackets::new(dirs.clone(), weights.clone())?
    };
    let mut gas = input.initial_gas;
    let mut ledger = LiveLedger::default();
    let initial_e = thermal(gas)? + binding(gas, input.f_he);
    let (mut t, mut tau, mut support) = (0_f64, 0_f64, 0_f64);
    let mut counter = 0;
    let mut cmb = initial_sky(input.n_mu, 8)?;
    let mut history = vec![snapshot(
        &records[0].left,
        &input,
        gas,
        &p,
        &ledger,
        t,
        tau,
        initial_e,
        0.,
        support,
    )?];
    for record in records {
        let l = &record.left;
        let r = &record.right;
        let m = midpoint(l, r);
        let h = r.eta - l.eta;
        let (a0, h0, _) = coordinates(l, &input);
        let (am, hm, nh) = coordinates(&m, &input);
        let (a1, h1, _) = coordinates(r, &input);
        if !(h > 0. && h0 > 0. && h1 > 0. && am.is_finite() && a1 <= 0.2 + 1e-15) {
            return Err("live REI clock outside AXBI domain".into());
        }
        let dt = h * (1. / h0 + 4. / hm + 1. / h1) / 6.;
        // Geometry and adiabatic work half map.
        let q = p.transport(l, &m)?;
        support = support.max(q.max_support_error);
        apply_transport(&mut ledger, q, isotropic_uv_reduced);
        let old = thermal(gas)?;
        gas = gas.adiabatic_to(a0, am).map_err(|e| e.to_string())?;
        ledger.thermal_work += old - thermal(gas)?;
        let source = src.at_redshift(1. / am - 1.).map_err(|e| e.to_string())?;
        let (sn, su) = p.inject(m.eta, source.per_h_s, dt, &cells)?;
        ledger.emitted_n += sn;
        ledger.emitted_u += su;
        if !isotropic_uv_reduced {
            ledger.four.emitted_pz +=
                su * sum(p.weights.iter().zip(&p.directions).map(|(w, d)| w * d[2]));
        }
        let pre = rate_tol.map(|_| p.packets.clone());
        let guard = |gas: IgmGasState| {
            let [x, y, z] = gas.fractions;
            let h = nh * 1e-6;
            let he = h * input.f_he;
            RateGuard {
                absorber_cm3: [h * (1. - x), he * (1. - y - z), he * y],
                dt_s: dt,
            }
        };
        if let Some(w) = width {
            let q = if let Some(tol) = rate_tol {
                p.compress_rate_checked(w, guard(gas), tol * 0.5)?
            } else {
                p.compress(w)?
            };
            ledger.compression.max_rate_relative = ledger
                .compression
                .max_rate_relative
                .max(q.max_rate_relative);
            ledger.compression.rate_splits += q.rate_splits;
            ledger.compression_removed += q.before - q.after;
            ledger.compression.before = ledger.compression.before.max(q.before);
            ledger.compression.after = ledger.compression.after.max(q.after);
            ledger.compression.max_number_relative = ledger
                .compression
                .max_number_relative
                .max(q.max_number_relative);
            ledger.compression.max_energy_relative = ledger
                .compression
                .max_energy_relative
                .max(q.max_energy_relative);
            ledger.compression.max_log_span = ledger.compression.max_log_span.max(q.max_log_span);
        }
        let inputs: Vec<_> = p
            .packets
            .iter()
            .map(|p| PrimaryPacket {
                energy_ev: p.energy_ev,
                per_h: p.per_h,
            })
            .collect();
        let q = packet_chemistry_stage(
            PacketStageInput {
                n_h_cm3: nh * 1e-6,
                n_he_cm3: nh * 1e-6 * input.f_he,
                tcmb_k: input.tcmb0_k / am,
            },
            gas,
            &inputs,
            dt,
            &mut counter,
            20_000_000,
        )
        .map_err(|e| format!("REI packet stage eta={:e}: {e}", m.eta))?;
        if let (Some(tol), Some(before)) = (rate_tol, &pre) {
            let err = rate_moment_error(before, &p.packets, guard(q.gas))?;
            if err > tol {
                return Err(format!(
                    "final-state rate compression mismatch {err:e} > {tol:e}"
                ));
            }
            ledger.max_final_rate_error = ledger.max_final_rate_error.max(err);
        }
        let direct_loss = sum(inputs.iter().zip(&q.stocks).map(|(a, b)| a.per_h - b));
        if (direct_loss - q.ledgers.absorbed_n).abs() > 1e-10 * ledger.emitted_n.max(1.) {
            return Err("live REI event count mismatch".into());
        }
        let a = absorption_budget(
            &p,
            &q.stocks,
            q.gas,
            nh * 1e-6,
            input.f_he,
            dt,
            isotropic_uv_reduced,
        )?;
        let eg = (a.binding + a.heat - a.energy).abs() / a.energy.max(1e-20);
        let gap = sum(a
            .events
            .iter()
            .zip(q.ledgers.photo_events)
            .map(|(x, y)| (x - y).abs()))
            / q.ledgers.absorbed_n.max(1e-20);
        if gap > 1e-10 || eg > 1e-8 || a.max_packet_loss > 1e-12 {
            return Err(format!("UV absorption budget gap {gap:e} {eg:e}"));
        }
        ledger.four.max_event_gap = ledger.four.max_event_gap.max(gap);
        ledger.four.max_absorption_energy_gap = ledger.four.max_absorption_energy_gap.max(eg);
        ledger.four.max_packet_loss = ledger.four.max_packet_loss.max(a.max_packet_loss);
        ledger.four.absorbed_energy += a.energy;
        ledger.four.absorbed_pz += a.pz;
        ledger.four.binding_energy += a.binding;
        ledger.four.heat_energy += a.heat;
        gas = q.gas;
        for (p, n) in p.packets.iter_mut().zip(q.stocks) {
            p.per_h = n;
        }
        ledger.absorbed_n += q.ledgers.absorbed_n;
        ledger.escaped_u += q.ledgers.escaped_u;
        ledger.cmb_input += q.ledgers.cmb_input;
        for i in 0..3 {
            ledger.photo_events[i] += q.ledgers.photo_events[i]
        }
        let root = q.max_residual;
        let q = p.transport(&m, r)?;
        support = support.max(q.max_support_error);
        apply_transport(&mut ledger, q, isotropic_uv_reduced);
        let old = thermal(gas)?;
        gas = gas.adiabatic_to(am, a1).map_err(|e| e.to_string())?;
        ledger.thermal_work += old - thermal(gas)?;
        ledger.four.current_pz = if isotropic_uv_reduced {
            0.
        } else {
            sum(p
                .packets
                .iter()
                .map(|v| v.per_h * v.energy_ev * p.directions[v.ray][2]))
        };
        ledger.four.momentum_defect = ledger.four.current_pz
            + ledger.four.absorbed_pz
            + ledger.four.boundary_pz
            + ledger.four.geometry_pz
            - ledger.four.emitted_pz;
        if ledger.four.momentum_defect.abs() > 1e-10 * ledger.emitted_u.max(1e-30) {
            return Err("UV axial momentum ledger".into());
        }
        // Actual newly evolved endpoint charge, not tabulated xe.
        let last = history.last().unwrap();
        let n = snapshot(
            r,
            &input,
            gas,
            &p,
            &ledger,
            t + dt,
            tau,
            initial_e,
            root,
            support,
        )?;
        let k0 = last.opacity;
        let k1 = n.opacity;
        let d0 = h * (3. * k0 + k1) / 8.;
        let d1 = h * (k0 + 3. * k1) / 8.;
        if d0 > 0. {
            scatter_with(&mut cmb, d0, [0.; 3], CollisionScheme::Sdirk2)?;
        }
        for c in &mut cmb {
            geometric_one(c, l, r)?;
        }
        if d1 > 0. {
            scatter_with(&mut cmb, d1, [0.; 3], CollisionScheme::Sdirk2)?;
        }
        tau += d0 + d1;
        t += dt;
        let row = LiveRow { tau, ..n };
        accepted(last, &row, &a)?;
        history.push(row);
    }
    if isotropic_uv_reduced {
        let mut lifted = BirthPackets::new(dirs, weights.clone())?;
        let norm = sum(weights.iter().copied());
        for (ray, w) in weights.iter().enumerate() {
            for packet in &p.packets {
                lifted.packets.push(super::birth_packets::Packet {
                    ray,
                    per_h: packet.per_h * w / norm,
                    ..*packet
                });
            }
        }
        p = lifted;
    }
    Ok(LiveResult {
        isotropic_uv_reduced,
        history,
        photons: p,
        cmb,
        rhs: counter,
    })
}
