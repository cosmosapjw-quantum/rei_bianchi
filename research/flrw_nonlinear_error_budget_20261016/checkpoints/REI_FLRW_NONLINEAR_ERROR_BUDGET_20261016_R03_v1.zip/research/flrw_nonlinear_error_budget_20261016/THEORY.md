# Nonlinear residual and adaptive-error diagnostic budget

## R1 — position and scope

This unit constructs a deterministic diagnostic that maps an actual four-component backward-Euler residual and Jacobian into the coordinate scaling used by the existing adaptive comparison. It reports a linearized Newton correction, conditioning and linear-system backward error. Missing stage residual/Jacobian data yields HOLD for actual-stage attribution. Production source005, the active source009 runner, their tolerances and their states are unchanged.

Read-only GitHub intake is pinned at `fdfda0fec423ccb7175552c7dc066be93ce347e1`; exact blob identities and inspected source excerpts are in `evidence/SOURCE_PIN.json` and `evidence/SOURCE_EXCERPTS.txt`. The current `ResidualContext.evaluate` orders unknowns as `(x_HII,x_HeII,x_HeIII,w_eV_per_H)` and evaluates `R=y-y_old-dt*f(y)`, with prepared absorption fixed throughout each chemical-stage Newton solve. The existing termination threshold is 1e-11 in its own residual scaling, and the adaptive target is 1e-5 in a different state scaling.

The source007 independent review observed larger temperature differences after refinement, accepted-stage maximum Newton residuals near 9e-17 for h/2 and 7.36e-12 or 9.05e-12 for h/4, and nonidentical actual endpoint bits. It identified nonlinear termination as a supported confounder, without proving its contribution. The saved maximum alone does not identify a residual vector, a Jacobian, a stage or a linearized state correction. The new diagnostic fills that explicit computation and input contract, with synthetic fixtures testing its mathematics independently of the active runner.

The existing full005 PL result at commit `0c3958d11d654513eb23cf462d5148e87ba6c9de` is reused: saved-PL Tgas supremum 0.24946455408644397 K and RMS 0.1128202745602529 K. Its postprocessing cumulative debit 156.5376037069618 s of 300 s and original deadline remain its own retained allocation. No PL check, solver campaign or full-data reduction is repeated here.

Completion requires a derived scale transformation, an explicit distinction between residual and state error, a backward-Euler full/half-step example, independent algebra/fixture checks, and a standard-library implementation contract accepting actual stage packets. This unit may create only new files under `research/flrw_nonlinear_error_budget_20261016/`; no production Rust or canonical campaign file is mutated. Actual-stage diagnosis remains NOT_RUN until a correctly identified packet is supplied by its owner.

## R2 — source and literature mapping

The pinned code gives four directly used facts. `ResidualContext.evaluate` (driver lines 256–287) evaluates a backward-Euler chemical residual with active photon absorption computed from the candidate gas and fixed prepared quadrature. `Driver::norm` (792–798) leaves the three fraction residuals unscaled and divides the energy residual by `max(|w_old|,|w|,1e-6)`. `chemical_stage` (831–834) accepts this norm at 1e-11. `error_metric` (973–981) instead divides each fraction difference by `max(|x_half|,1e-5)` and energy difference by `max(|w_half|,1e-6)`. Photon-number and photon-energy comparisons are additional components of the production adaptive metric; this unit's four-variable correction addresses the chemical block only.

`igm_state.rs` defines `w=(3/2) k_B T (1+f_He+x_HII+f_He(x_HeII+2x_HeIII))` per H nucleus. It also makes the adiabatic map exact at fixed fractions. These definitions determine the thermal projection used below, without adding an independent energy owner. The source007 review is reused as an actual observation of unresolved mixed truncation/termination effects. Source009's independent review authorizes two short runs after implementation checks; its decision label alone is not evidence that those histories finished.

On 2026-10-16 the controller used Exa to retrieve the official [CVODE mathematics description, §3.2.1.1](https://sundials.readthedocs.io/en/latest/cvode/Mathematics_link.html). It ties nonlinear stopping to the local error test in a weighted norm. That supports the question of matching residual/correction scales, while the current REI solver uses its own max norm and algorithm. The unit does not adopt CVODE constants, convergence results or its WRMS norm. SciSpace returned Enright and Seward (1989), DOI `10.1007/BF02243229`, and Rodrigues (2017), arXiv `1705.04870`, as contextual leads; discovery abstracts provide no premise for the derivations here. Primary Wolfram double-step documentation supplies method context. Only compact search metadata are published, not source page text.

Root's independently executed backward-Euler algebra is available for R6. Its earlier midpoint toy is not the production chemical-stage method and is excluded from this unit's supporting derivation. The required math below uses elementary matrix scaling, a Taylor expansion with explicit conditions, and the scalar backward-Euler map, so no unverified literature lemma is needed.

## R3 — definitions, assumptions and observable map

Let `y=(x_HII,x_HeII,x_HeIII,w)` be one accepted chemical-stage iterate in units `(1,1,1,eV/H)`. Let `y_old` be that stage's old gas state, `R=R(y)` the unnormalized four-vector and `J=dR/dy` or an explicitly labeled finite-difference approximation evaluated at exactly the same iterate and prepared-absorption context. The point, stage duration, input identity, Jacobian construction and added evaluation cost must be retained. The production solver accepts `||R||_N <= 1e-11` before forming a Jacobian; therefore an accepted-iterate J is not already stored, may require new charged evaluations, and cannot be substituted by the last iteration's J. A packet lacking R/J or binding them to different states/contexts yields HOLD for actual-stage analysis.

Freeze positive diagonal scales at the supplied iterate:

`S_R = diag(1,1,1,max(|w_old|,|w|,1e-6))`,

`S_y = diag(max(|x_HII|,1e-5),max(|x_HeII|,1e-5),max(|x_HeIII|,1e-5),max(|w|,1e-6))`.

Define `b=S_R^-1 R`, `A=S_R^-1 J S_y`, solve `A z=-b`, and set `delta=S_y z`. These scales are evaluated once; A is not the derivative of the state-dependent normalized residual. The diagnostic residual is `||b||_infinity`, the linearized correction in adaptive chemical coordinates is `||z||_infinity`, and its ratio to the unchanged 1e-5 target is reported descriptively. This ratio does not authorize rejection, a new tolerance or a physical error bound.

For nonsingular A, report `kappa_infinity(A)=||A||_infinity ||A^-1||_infinity` and the computed linear-system normwise backward error `eta=||A z+b||_infinity/(||A||_infinity ||z||_infinity+||b||_infinity)`, with eta=0 when all numerator/denominator terms vanish. A singular matrix has no unique correction and returns typed HOLD; nonfinite input/arithmetic also returns HOLD rather than Infinity or NaN. Finite ill-conditioning is reported, with no arbitrary condition-number acceptance threshold. A computed inverse and backward error are binary64 diagnostics, not certified interval bounds.

For thermal projection let `f=f_He=nHe/nH`, `D=1+f+x_HII+f(x_HeII+2x_HeIII)` and `k=k_B` in eV/K. Then `T(y)=2w/(3kD)`. The linear correction is `deltaT_linear = T*(delta_w/w - delta_D/D)`, where `delta_D=delta_xHII+f*(delta_xHeII+2delta_xHeIII)`. If the corrected fractions satisfy `0<=x_HII<=1`, nonnegative HeII/HeIII with sum<=1, and corrected w>0, also report `T(y+delta)-T(y)` using the exact EOS map; otherwise return a null exact thermal projection with an explicit corrected-state-domain reason. No clipping or state commit occurs. This map evaluates a Newton correction at the chemical stage before the final geometry map; propagation through the split step, photons or subsequent evolution requires separate information.

The actual-stage claim is conditional on the supplied packet. The planned mathematical fixtures are explicitly synthetic; they do not identify which residual component caused the source007 temperature pattern. The original production acceptance inequalities remain distinct: Newton uses `<=1e-11`, while adaptive acceptance uses `<local_target` and `<2e-4`.
