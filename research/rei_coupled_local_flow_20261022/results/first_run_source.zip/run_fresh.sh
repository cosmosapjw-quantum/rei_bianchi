#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export MPLCONFIGDIR="${TMPDIR:-/tmp}/rei_coupled_local_flow_mpl"
ulimit -t 120
ulimit -v 1048576
timeout --signal=TERM 180s python3 code/run_diagnostic.py "$@"
