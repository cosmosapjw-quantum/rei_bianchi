from pathlib import Path
import subprocess,sys,tarfile,json,hashlib,shutil,os
H=Path.home();sys.path.insert(0,str(H))
from r118c4a_theory_driver import repos,scopes,record,git
R=repos['REI'];D=R/scopes['REI'];S=H/'r118c4a_rei_shadow'
assert S.is_dir() and not S.is_symlink()
assert json.loads((D/'REPAIR_EXECUTION.json').read_text())['analyze_exit']==0
idn=json.loads((D/'BUILD_ID.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
crate=S/'rust/rei_microphysics';binary=crate/'target/release/examples/c4a_probe'
assert sha(binary)==idn['binary_sha256']
assert sha(crate/'src/axbi_covariant_driver.rs')==idn['driver_patch_sha256']
assert sha(crate/'examples/c4a_probe.rs')==idn['probe_sha256']==sha(D/'probe.rs')
ar=subprocess.check_output(['git','-C',str(R),'archive',idn['base'],*idn['paths']]);assert hashlib.sha256(ar).hexdigest()==idn['archive_sha256']
# Only cycle-owned shadow files; preserve exact archive, patched driver, probe binary and lock.
items=[p for p in S.rglob('*') if p.is_file() and not p.is_symlink()]
assert all(not p.is_symlink() for p in S.rglob('*'))
target=crate/'target'
keep=[p for p in items if target not in p.parents or p==binary]
a=D/'NATIVE_SHADOW.tar.gz';assert not a.exists()
manifest=[]
with tarfile.open(a,'w:gz') as t:
 for p in sorted(keep):
  rel=str(p.relative_to(S));t.add(p,arcname=rel,recursive=False)
  manifest.append(dict(name=rel,bytes=p.stat().st_size,sha256=sha(p)))
with tarfile.open(a,'r:gz') as t:
 assert set(t.getnames())=={x['name'] for x in manifest}
 for x in manifest:assert hashlib.sha256(t.extractfile(x['name']).read()).hexdigest()==x['sha256']
report={'root':str(S),'archive':a.name,'archive_sha256':sha(a),'archive_bytes':a.stat().st_size,'preserved_files':len(keep),'preserved_bytes':sum(p.stat().st_size for p in keep),'original_shadow_files':len(items),'original_shadow_logical_bytes':sum(p.stat().st_size for p in items),'skipped_regenerable_target_files':len(items)-len(keep),'members':manifest,'pinned_git_archive_verified':True}
(D/'SHADOW_ARCHIVE.json').write_text(json.dumps(report,indent=2)+'\n')
record('REI','C10-shadow-archive','Exact successful native shadow source tree and binary archive; byte-level member and pinned Git archive verification before cleanup. Build cache excluded.',[a.name,'SHADOW_ARCHIVE.json'])
head=git(R,'rev-parse','HEAD');br=git(R,'branch','--show-current');assert git(R,'ls-remote','origin',f'refs/heads/{br}').split()[0]==head
blob=subprocess.check_output(['git','-C',str(R),'show',head+':'+scopes['REI']+'/'+a.name]);assert hashlib.sha256(blob).hexdigest()==report['archive_sha256']
# Ensure no active process is using the generated directory.
busy=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  if proc.resolve().name==str(os.getpid()):continue
  cwd=os.readlink(proc/'cwd');exe=os.readlink(proc/'exe')
  if cwd==str(S) or cwd.startswith(str(S)+'/') or exe.startswith(str(S)+'/'):busy.append(proc.name)
 except (OSError,PermissionError):pass
assert not busy,busy
shutil.rmtree(S);assert not S.exists()
summary={k:v for k,v in report.items() if k!='members'};summary['removed_after_remote_verified']=True;summary['archive_commit']=head
(D/'SHADOW_CLEANUP.json').write_text(json.dumps(summary,indent=2)+'\n')
record('REI','C10-shadow-cleanup','Removed only this cycle-created native shadow after verified remote archive; all original repositories and unrelated worktrees preserved.',['SHADOW_CLEANUP.json'])
print(json.dumps(summary,indent=2),flush=True)
