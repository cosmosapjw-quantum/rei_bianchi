from pathlib import Path
import sys,subprocess,json,hashlib,shutil,os
H=Path.home();sys.path.insert(0,str(H));from r118c4a_theory_driver import repos,scopes,push,record
D=repos['REI']/scopes['REI'];crate=H/'r118c4a_rei_shadow/rust/rei_microphysics';p=D/'probe.rs';s=p.read_text();old='map(d.c4a_rebase_initial(&init))?;';new=old+'\n   let init_before=q(&init)?;';assert s.count(old)==1;s=s.replace(old,new);old='assert_eq!(q(&init)?,x);';assert s.count(old)==1;s=s.replace(old,'assert_eq!(q(&init)?,init_before);');p.write_text(s);shutil.copy2(p,crate/'examples/c4a_probe.rs')
for name in ['native.log','STEP.csv','POINT.csv','BUILD_ID.json','build.log']:
 q=D/name;shutil.copy2(q,D/('failed_initial_'+name))
record('REI','C6-repair-invariant','The first native run failed an exact equality between requested eV input and round-tripped cgs state, with 1 ulp conversion discrepancy. Check bitwise pre/post stored state instead; no physics or tolerance change. Preserve first failure and partial outputs.', ['probe.rs','failed_initial_native.log','failed_initial_STEP.csv','failed_initial_POINT.csv','failed_initial_BUILD_ID.json','failed_initial_build.log'])
with (D/'repair_build.log').open('w') as f:r=subprocess.run(['cargo','build','--release','--offline','--example','c4a_probe'],cwd=crate,stdout=f,stderr=subprocess.STDOUT,timeout=180)
assert r.returncode==0
b=crate/'target/release/examples/c4a_probe';ident=json.loads((D/'BUILD_ID.json').read_text());ident['probe_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();ident['binary_sha256']=hashlib.sha256(b.read_bytes()).hexdigest();ident['binary_bytes']=b.stat().st_size;(D/'BUILD_ID.json').write_text(json.dumps(ident,indent=2)+'\n')
with (D/'repair_native.log').open('w') as f:r=subprocess.run([str(b),str(D/'CONFIG.cfg'),str(D/'ACTUAL_HISTORY.csv'),str(D/'POINT.csv'),str(D/'STEP.csv')],stdout=f,stderr=subprocess.STDOUT,timeout=200)
row={'tag':'repair_native','exit':r.returncode};(D/'REPAIR_EXECUTION.json').write_text(json.dumps(row,indent=2)+'\n');fs=['repair_native.log','repair_build.log','BUILD_ID.json','POINT.csv','STEP.csv','REPAIR_EXECUTION.json'];print(row,flush=True)
if r.returncode==0:
 with (D/'repair_analyze.log').open('w') as f:r=subprocess.run([sys.executable,'-u',str(D/'rei.py'),'analyze'],cwd=repos['REI'],stdout=f,stderr=subprocess.STDOUT,timeout=100)
 row['analyze_exit']=r.returncode;fs+=['repair_analyze.log'];
 if (D/'CHEMISTRY.json').exists():fs+=['CHEMISTRY.json']
 (D/'REPAIR_EXECUTION.json').write_text(json.dumps(row,indent=2)+'\n')
record('REI','C6-repair-execution','Actual repair outcomes '+json.dumps(row),fs)
if row['exit']==0 and row.get('analyze_exit')==0:
 dag=json.loads((D/'DAG.json').read_text());dag['repair_execution']=row;dag['status']='SCOPED_EXECUTED';(D/'DAG.json').write_text(json.dumps(dag,indent=2)+'\n');record('REI','C10-repair-closeout','Native point and accepted-step derivative complete for fixed geometry scalar FF2; see CHEMISTRY.json. The full DG3 owner and Einstein coupling remain open.',['DAG.json'])
print(row,flush=True)
