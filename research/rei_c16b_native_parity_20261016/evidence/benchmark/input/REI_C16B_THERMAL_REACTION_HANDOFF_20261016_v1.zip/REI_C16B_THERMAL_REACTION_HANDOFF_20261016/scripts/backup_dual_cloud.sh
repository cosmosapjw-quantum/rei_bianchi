#!/usr/bin/env bash
# Run only on the owner's Ubuntu with configured rclone remotes.
# Create-only semantics: do not overwrite prior different archives.
set -euo pipefail
if [ "$#" -ne 1 ]; then echo "usage: $0 <absolute-path-to-zip>" >&2;exit 2;fi
SRC="$(realpath "$1")"
test -s "$SRC"
NAME="$(basename "$SRC")"
EXPECTED="$(sha256sum "$SRC" | awk '{print $1}')"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
for spec in "dbx:bianchi/rei_bianchi/research/REI_C16_CASEA_SOURCE_BACKUPS" "gdrv:rei_bianchi_research_backups";do
  target="$spec/$NAME"
  echo "UPLOAD_BEGIN $target"
  rclone copyto --ignore-existing "$SRC" "$target"
  rclone copyto "$target" "$WORK/${spec%%:*}-$NAME"
  GOT="$(sha256sum "$WORK/${spec%%:*}-$NAME" | awk '{print $1}')"
  [ "$EXPECTED" = "$GOT" ] || { echo "CLOUD_MISMATCH $target $GOT";exit 3; }
  unzip -tqq "$WORK/${spec%%:*}-$NAME"
  echo "BYTE_RESTORE_VERIFIED $target $GOT"
done
echo 'DUAL_CLOUD_BYTES_VERIFIED' "$EXPECTED"
