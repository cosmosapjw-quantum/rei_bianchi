use rei_microphysics::{
    axbi_covariant_transport::{attenuation_factors, CovariantTransport, PhotonAttenuation},
    axbi_driver::{
        Driver, DriverConfig, DriverState, NativeClockMode, SourceClockConfig, SourcePlacement,
    },
    axbi_sources::AxbiSource,
    igm_state::IgmGasState,
    Absorber, AtomicProvider, AxisymmetricPoint, HHeModel,
};

fn initial(escape: f64) -> (Driver, DriverState) {
    let mut c = DriverConfig::baseline();
    c.transport_cells = 8;
    c.background_panels = 128;
    c.transport_threads = 1;
    c.escape_fraction = escape;
    let (d, mut s) = Driver::new(c).unwrap();
    s.gas = IgmGasState::from_temperature(
        [0.075, 0.12, 0.03],
        d.n_h0_cm3 / s.a.powi(3),
        d.n_he0_cm3 / s.a.powi(3),
        15000.,
    )
    .unwrap();
    (d, s)
}
fn selected() -> SourceClockConfig {
    SourceClockConfig {
        microphysics: NativeClockMode::AllMid,
        opacity_midpoint: true,
        attenuation: PhotonAttenuation::Exponential,
        source: SourcePlacement::SymmetricHalves,
        nonlinear_tolerance: 1e-13,
    }
}

#[test]
fn exponential_average_is_positive_and_count_consistent_from_zero_to_stiff() {
    for tau in [0.0, 1e-15, 1e-8, 0.2, 2., 80., 1000.] {
        let (survive, mean) = attenuation_factors(tau, PhotonAttenuation::Exponential).unwrap();
        assert!((0.0..=1.).contains(&survive) && (0.0..=1.).contains(&mean));
        assert!((tau * mean + survive - 1.).abs() < 4e-16, "tau={tau}");
        if tau == 0. {
            assert_eq!((survive, mean), (1., 1.));
        }
    }
    assert!(attenuation_factors(-1., PhotonAttenuation::Exponential).is_err());
    assert!(attenuation_factors(f64::NAN, PhotonAttenuation::Exponential).is_err());
    assert!(attenuation_factors(f64::INFINITY, PhotonAttenuation::Exponential).is_err());
}
#[test]
fn actual_verner_delta_exponential_loss_shares_species_binding_heat_owner() {
    let geo = AxisymmetricPoint::new(0.05, 0., 1e-16, 0.)
        .unwrap()
        .snapshot()
        .unwrap();
    let src = AxbiSource::new(1.898198450714027e-7, 0.2, 16, 8).unwrap();
    let core = CovariantTransport::new(&src, geo, 128, 13.6, 512.).unwrap();
    let mut ph = core.empty_state();
    core.add_delta(&mut ph, 2, 60., 0.7).unwrap();
    let gas = [1e-4, 1e-5, 3e-6];
    let nh = 1e-3;
    let dt = 1e10;
    let prep = core.prepare(&ph, &geo).unwrap();
    let out = prep
        .evaluate_with_rule(gas, nh, dt, PhotonAttenuation::Exponential)
        .unwrap();
    let c = HHeModel::controlled_fixture();
    let ap = AtomicProvider::reference();
    let sig =
        [Absorber::HI, Absorber::HeI, Absorber::HeII].map(|a| ap.cross_section(a, 60.).unwrap());
    let tau = dt * c.c_cm_s * (0..3).map(|i| gas[i] * sig[i]).sum::<f64>();
    let (n, u) = core.inventory(&out.state, &geo).unwrap();
    assert!((n - 0.7 * (-tau).exp()).abs() < 3e-15);
    assert!((0.7 - n - out.absorbed_per_h.iter().sum::<f64>()).abs() < 2e-15);
    assert!((42. - u - out.binding_ev_per_h - out.heat_ev_per_h).abs() < 1e-13);
    for j in 0..3 {
        assert!((dt * gas[j] / nh * out.photo.gamma_s[j] - out.absorbed_per_h[j]).abs() < 1e-15);
    }
    assert_eq!(
        prep.evaluate(gas, nh, dt).unwrap().state,
        prep.evaluate_with_rule(gas, nh, dt, PhotonAttenuation::BackwardEuler)
            .unwrap()
            .state
    );
}
#[test]
fn source_on_native_step_is_conservative_and_photo_events_are_real() {
    for source in [SourcePlacement::Before, SourcePlacement::SymmetricHalves] {
        let (mut d, mut s) = initial(0.2);
        let mut opt = selected();
        opt.source = source;
        d.set_source_clocks(&s, opt).unwrap();
        let initial = s.clone();
        for _ in 0..4 {
            d.fixed_step(&mut s, 1e-5 / 4.).unwrap();
        }
        let rhs = d.last_clock_rhs().unwrap().unwrap();
        assert!(s.ledgers.source_n > 0. && s.ledgers.absorbed_n > 0.);
        assert!(s.ledgers.photo_events.iter().all(|&x| x >= 0.));
        assert!(rhs.photo_input_erg_cm3_s > 0.);
        let (n, e) = d.residuals(&s).unwrap();
        assert!(
            n.abs() < 1e-16 && e.abs() < 1e-10,
            "{source:?}: {n:e} {e:e}"
        );
        assert!(
            (s.gas.fractions[0]
                - initial.gas.fractions[0]
                - s.ledgers.photo_events[0]
                - s.ledgers.ci_events[0]
                + s.ledgers.rr_events[0])
                .abs()
                < 1e-11
        );
        assert!(s.max_newton_residual <= 1e-13);
    }
}
#[test]
fn no_source_limit_matches_v12_full_midpoint_without_new_physics() {
    let (mut old, mut a) = initial(0.2);
    let (mut new, mut b) = initial(0.2);
    old.set_source_free_clock(&a, NativeClockMode::AllMid)
        .unwrap();
    let mut opt = selected();
    opt.nonlinear_tolerance = 1e-11;
    opt.source = SourcePlacement::Disabled;
    new.set_source_clocks(&b, opt).unwrap();
    for _ in 0..16 {
        old.fixed_step(&mut a, 1e-5 / 16.).unwrap();
        new.fixed_step(&mut b, 1e-5 / 16.).unwrap();
    }
    assert_eq!(a.gas.fractions, b.gas.fractions);
    assert_eq!(a.gas.w_erg_per_h, b.gas.w_erg_per_h);
    assert_eq!(a.photons, b.photons);
    assert_eq!(b.ledgers.source_n, 0.);
}
#[test]
fn source_clocks_reject_mode_conflict_and_bad_tolerance() {
    let (mut d, s) = initial(0.2);
    let mut o = selected();
    o.nonlinear_tolerance = 0.;
    assert!(d.set_source_clocks(&s, o).is_err());
    d.set_source_free_clock(&s, NativeClockMode::AllMid)
        .unwrap();
    assert!(d.set_source_clocks(&s, selected()).is_err());
    let (mut d, s) = initial(0.2);
    d.set_source_clocks(&s, selected()).unwrap();
    assert!(d
        .set_source_free_clock(&s, NativeClockMode::AllMid)
        .is_err());
}

#[test]
fn failed_trial_never_commits_newborn_photons_or_gas() {
    let (mut d, mut s) = initial(0.2);
    d.config.max_rhs = 1;
    d.set_source_clocks(&s, selected()).unwrap();
    let before = s.clone();
    assert!(d.fixed_step(&mut s, 1e-5).is_err());
    assert_eq!(s.photons, before.photons);
    assert_eq!(s.photon_energy_ref, before.photon_energy_ref);
    assert_eq!(s.gas.fractions, before.gas.fractions);
    assert_eq!(s.gas.w_erg_per_h, before.gas.w_erg_per_h);
    assert_eq!(s.ledgers.source_n, before.ledgers.source_n);
    assert_eq!(s.ledgers.source_u, before.ledgers.source_u);
    assert_eq!(s.accepted, before.accepted);
    assert!(s.attempts > before.attempts); // attempted work is still charged
}

#[test]
fn source_halves_preserve_total_birth_number_and_energy_at_common_geometry() {
    let mut result = Vec::new();
    for source in [SourcePlacement::Before, SourcePlacement::SymmetricHalves] {
        let (mut d, mut s) = initial(0.2);
        let mut opt = selected();
        opt.source = source;
        d.set_source_clocks(&s, opt).unwrap();
        d.fixed_step(&mut s, 1e-5 / 8.).unwrap();
        result.push(s.ledgers);
    }
    let a = &result[0];
    let b = &result[1];
    assert!((a.source_n - b.source_n).abs() < 1e-14 * a.source_n);
    assert!((a.source_u - b.source_u).abs() < 1e-14 * a.source_u);
    assert!(a.absorbed_n > b.absorbed_n); // before-birth photons have a longer exposure
}
