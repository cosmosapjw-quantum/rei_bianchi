# Native VigilODE Radau bounded implementation handoff

## Status

Actual pinned VigilODE Radau IIA3 is linked by local path dependency to the unchanged 477-file source closure. The coupled native reconstructed-moment/gas adapter, common-stage event integration, transactional updates and physical GL2 wrapper are implemented. The first fixed-geometry native N=4 gate passed. No expanded refinement matrix has been run by this agent.

Root corrected the invalid originally requested angular resolution n_mu=2 to the existing native minimum n_mu=8. Native source permits [8,16,32]. The four initialization failures are retained in receipts/focused_v2 and classify as API_DOMAIN_CONFIGURATION, with zero native RHS calls.

## Source boundaries

- New native child module: ../../v15_work/native_owner/rust/rei_microphysics/src/axbi_native_rhs.rs.
- Existing axbi_covariant_transport.rs only appends its child-module hook and reexport.
- All 152 preexisting files, including the transport prefix, match BASE_NATIVE_MANIFEST.json. See receipts/NATIVE_PRESERVATION.json.
- Standalone crate: Cargo.toml, Cargo.lock, src/lib.rs, src/main.rs, tests/focused.rs.
- Capturing runner: run_captured.py.
- No Git writes, remote writes, source replacement, clone or worktree by this agent.

Native derivative sums accumulate dN, dUref and the lower-energy-offset derivative directly at actual prepared quadrature nodes. Photo gamma/heat are supplied to unchanged AxbiProvider.point. Gas/rates/EOS and photon support checks remain native. No fake Jacobian, tolerance relaxation, clipping or auto-subcycling is present.

The Jacobian uses centered differences of the real scaled coupled native RHS, with one-sided fallback only when a perturbation fails domain checks. Every attempted callback is charged, including finite differences and stage replay. Case budget is 200000 calls and 30s; the gate additionally had a captured 40s external process timeout.

## First native gate

See receipts/gate_fixed_n4/{inputs.json,outcome.json,stdout.txt,stderr.txt,raw.json,summary.json}.

- n_mu=8; transport_cells=8; threads=1; background_panels=128; unchanged source energy_subdivisions=16.
- Fractions [.075,.12,.03], T=15000K, original MD14 packet seed dt=1e16s.
- Fixed geometry, T=1/k_ref20; k_ref20=1.0778812197739478e-10 s^-1.
- Newton scaled atol=1e-13, rtol=0.
- Four accepted chemical steps, dimension84 (full real 3n=252 Newton system), twelve replayed stages,640 nodes per stage.
- Calls772 =4*(21 library RHS +169 finite-difference calls +3 replay calls). No one-sided fallback occurred.
- Native case wall0.174847489s; captured subprocess wall0.215315879s; exit0.
- Max library WRMS0.0010857553584; maximum independent component stage residual/atol0.0072164496601; maximum endpoint closure/atol0.0013660947373.

Six affine components are ordered: photon number, HII/H, HeII/H, HeIII/H, electrons/H, total physical energy eV/H. Reports retain independently computed stage residual, endpoint closure L*rho, and native point-identity contribution. Max absolute remaining affine identity mismatch by component was [3.27e-18,3.31e-18,5.29e-20,1.06e-23,3.42e-18,8.38e-17]. These checks establish consistency for this case; they do not admit an accuracy order, universal positivity/stiffness, or an NCP claim.

## Focused tests

receipts/formatted_focused records the final formatted source and successful six-test command, exit0. The tests cover:

1. Actual native source-node photo/event/energy identities.
2. Affine roundtrip for empty, point and extended support.
3. Failed native candidate transaction with a real first RHS followed by resource-cap failure.
4. Actual returned-stage reconstruction and common positive b-weight event integration.
5. Public GL2 clock algebra.
6. Actual tiny source-on GL2 birth, injection and segment-clock parity against the existing native SSPRK wrapper.

Final test native call telemetry: Radau stage replay184; Radau GL2 parity374; SSPRK GL2 parity21; transactional test1. Direct-node test evaluates native derivative once and provider point once outside the Budget wrapper. Test execution wall0.11s, excluding build. Earlier successful focused_six repeats are retained; no failed/truncated scientific case is counted complete.

## Remaining owner decisions

The root scientific owner reviews this first gate before authorizing the stated finite refinement matrix. The current binary/source has subsequent readability/test and structured SSPRK JSON reporting changes relative to the captured N4 gate binary; numerical Radau implementation and accepted gate inputs are unchanged. Every receipt binds its own exact input source/binary hashes. No expanded scientific run has been performed.

The SSPRK runner now writes structured integrated events and birth/segment records. This reporting change builds successfully but has not been exercised as an expanded SSPRK scientific case. Native SSPRK itself was exercised by the focused GL2 parity test.
