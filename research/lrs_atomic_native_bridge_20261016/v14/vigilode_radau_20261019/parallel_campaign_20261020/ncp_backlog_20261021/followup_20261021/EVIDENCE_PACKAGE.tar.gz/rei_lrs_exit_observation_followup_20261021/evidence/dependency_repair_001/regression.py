import sys,pathlib,hashlib,json,time,unittest.mock as mock
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[2]))
import campaign as c
p=pathlib.Path(__file__).parent
historical=pathlib.Path('/tmp/rei_lrs_backlog_execution_20261021/focused')
protected=[historical/n for n in ['MANIFEST.json','CAMPAIGN_RECEIPT.json']]
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
before={str(f):sha(f)for f in protected}
identity=p/'A_identity.txt';identity.write_text('original')
jobs=[]
for i,n in enumerate(['A','B','C']):
 jobs.append({'id':n,'kind':'native','argv':[sys.executable,'-c','import pathlib,sys;pathlib.Path(sys.argv[1]).write_text("raw")','{attempt}/raw.txt'],'deps':[]if i==0 else[['A','B','C'][i-1]],'timeout_s':5,'budget_groups':['g'],'identity_files':[str(identity)]if n=='A'else[],'outputs':[{'path':'raw.txt'}]})
m={'accounting_policy':c.EXIT_ACCOUNTING_V1,'aggregate_caps_s':{'g':5},'jobs':jobs};out=p/'run';start=time.monotonic();first=c.run(m,out,2,None,1,.01)
assert first['overall_exit_code']==0
old={str(f):sha(f)for f in (out/'jobs').rglob('*')if f.is_file()}
identity.write_text('changed')
real=c.subprocess.Popen;calls=[]
def count(*a,**kw):calls.append(a);return real(*a,**kw)
with mock.patch.object(c.subprocess,'Popen',count):second=c.run(m,out,2,None,1,.01)
assert calls==[],calls
assert second['states']['A']['status']=='FAILED_IDENTITY_MISMATCH'
assert second['states']['B']['status']=='BLOCKED_DEPENDENCY_IDENTITY'
assert second['states']['C']['status']=='BLOCKED_DEPENDENCY_IDENTITY'
assert all(sha(pathlib.Path(f))==h for f,h in old.items())
assert len(list((out/'jobs').glob('*/attempt_*')))==3
assert before=={str(f):sha(f)for f in protected}
assert first['aggregate_charged_process_wall_s']==second['aggregate_charged_process_wall_s']
r={'status':'PASS','new_children_on_resume':0,'resume_states':{k:v['status']for k,v in second['states'].items()},'prior_attempt_files_preserved':old,'protected_historical_sha256':before,'prior_debit':first['aggregate_charged_process_wall_s'],'resume_debit':second['aggregate_charged_process_wall_s'],'wall_s':time.monotonic()-start}
(p/'REGRESSION_RESULT.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
