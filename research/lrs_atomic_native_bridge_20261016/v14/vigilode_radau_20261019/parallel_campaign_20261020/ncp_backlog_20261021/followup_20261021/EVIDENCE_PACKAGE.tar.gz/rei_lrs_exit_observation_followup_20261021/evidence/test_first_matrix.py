import campaign as c
import pathlib,sys,json,time,os,unittest.mock as mock,hashlib
ROOT=pathlib.Path(__file__).parent/'evidence'
START=time.monotonic()
def job(name,code='pass',groups=None,deps=None,timeout=2,outputs=None):
 return {'id':name,'kind':'native','argv':[sys.executable,'-c',code], 'deps':deps or [],'timeout_s':timeout,'budget_groups':groups or [],'outputs':outputs or []}
def manifest(jobs,cap=None):return {'accounting_policy':c.EXIT_ACCOUNTING_V1,'jobs':jobs,'aggregate_caps_s':cap or {}}
def run(row,m,hook=None,poll=.02):
 out=ROOT/row; t=time.monotonic()
 result=c.run(m,out,2,None,1,poll)
 assert time.monotonic()-t<5,(row,'row_timeout')
 return result
rows=[]
def record(n,fn):
 t=time.monotonic();v=fn();r={'row':n,'status':'PASS','wall_s':time.monotonic()-t,'detail':v};rows.append(r);(ROOT/'TEST_MATRIX.json').write_text(json.dumps(rows,indent=2));assert time.monotonic()-START<60

def one():
 original=c.file_outputs;calls=[]
 def delay(j,a):
  calls.append(j['id'])
  if j['id']=='a':time.sleep(.2)
  return original(j,a)
 with mock.patch.object(c,'file_outputs',delay):r=run('row1',manifest([job('a'),job('b')]),poll=.08)
 a=r['states']['a']['outcome'];b=r['states']['b']['outcome'];assert b['timing']['exit_observed']<=a['timing']['persistence_start'];assert b['process_wall_s']<.2;return {'charges':[a['process_wall_s'],b['process_wall_s']]}
def two():
 original=c.binding
 def delay(j):
  if j['id']=='b':time.sleep(.15)
  return original(j)
 with mock.patch.object(c,'binding',delay):r=run('row2',manifest([job('a','import time;time.sleep(1)',['g']),job('b','pass',['g'])],{'g':.08}))
 assert r['states']['b']['status']=='NOT_RUN_AGGREGATE_CAP';assert r['states']['a']['outcome']['reason']=='AGGREGATE_CAP';assert not list((ROOT/'row2/jobs/b').glob('*/outcome.json'));return r['aggregate_charged_process_wall_s']
def three():
 r=run('row3',manifest([job('a','import time;time.sleep(1)',['g']),job('b','pass',['g'],['a'])],{'g':.06}));assert r['states']['a']['outcome']['reason']=='AGGREGATE_CAP';assert r['states']['a']['outcome']['process_wall_s']>=.06;assert r['states']['b']['status']in ['BLOCKED_DEPENDENCY','NOT_RUN_AGGREGATE_CAP'];return r['aggregate_charged_process_wall_s']
def four():
 r=run('row4',manifest([job('exit7','import sys;sys.exit(7)'),job('bad','pass',outputs=[{'path':'missing'}]),job('good'),job('dep',deps=['exit7','bad'])]));assert r['states']['exit7']['outcome']['failure_kind']=='EXIT_FAILURE';assert r['states']['bad']['outcome']['failure_kind']=='OUTPUT_VALIDATION_FAILURE';assert r['states']['dep']['status']=='BLOCKED_DEPENDENCY';assert r['states']['good']['status']=='COMPLETED';return {k:v['status']for k,v in r['states'].items()}
def five():
 pidfile=ROOT/'row5_grandchild.pid'
 code=f'import subprocess,time,pathlib; p=subprocess.Popen(["sleep","3"]);pathlib.Path({str(pidfile)!r}).write_text(str(p.pid));time.sleep(3)'
 r=run('row5',manifest([job('a',code,timeout=.2)]));a=r['states']['a']['outcome'];assert a['reason']=='JOB_TIMEOUT';pid=int(pidfile.read_text());stat=pathlib.Path(f'/proc/{pid}/stat');assert not stat.exists()or stat.read_text().split()[2]=='Z';return {'reason':a['reason'],'grandchild_pid':pid}
def six():
 orig=c.write;trigger=[False]
 def fail(path,value):
  if pathlib.Path(path).name=='outcome.json'and not trigger[0]:trigger[0]=True;raise OSError('injected persistence failure')
  return orig(path,value)
 with mock.patch.object(c,'write',fail):r=run('row6_persistence',manifest([job('a'),job('b','import time;time.sleep(1)'),job('later',deps=['a'])]))
 assert r['states']['a']['status']=='FAILED_PERSISTENCE';assert r['states']['later']['status']=='NOT_RUN_SUPERVISOR_STOP';assert r['states']['b']['outcome']['process_wall_s']>0
 sleep=time.sleep;once=[False]
 def interrupt(t):
  if not once[0]:once[0]=True;raise KeyboardInterrupt('synthetic interruption')
  sleep(t)
 with mock.patch.object(c.time,'sleep',interrupt):q=run('row6_interrupt',manifest([job('a','import time;time.sleep(1)',['g'])],{'g':3}))
 assert q['states']['a']['outcome']['reason']=='SUPERVISOR_INTERRUPTION';assert q['aggregate_charged_process_wall_s']['g']>0;return {'persistence':'retained partial','interruption_charge':q['aggregate_charged_process_wall_s']}
def seven():
 m=manifest([job('good',groups=['g']),job('failed','import sys;sys.exit(7)',['g'])],{'g':3});r=run('row7',m);out=ROOT/'row7';old={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in out.glob('jobs/*/attempt_0001/*')if p.is_file()};previous=r['aggregate_charged_process_wall_s']['g']
 q=c.run(m,out,2,None,1,.02);assert q['states']['good']['status']=='REUSED_COMPLETED';assert q['aggregate_charged_process_wall_s']['g']>=previous;assert all(hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()==h for p,h in old.items())
 bad=out/'jobs/good/attempt_0001/stdout.txt';bad.write_text('changed');z=c.run(m,out,2,None,1,.02);assert z['states']['good']['status']=='FAILED_IDENTITY_MISMATCH';assert bad.read_text()=='changed';return {'reuse':'validated completed only','identity':'fails closed','previous_charge':previous,'resume_charge':q['aggregate_charged_process_wall_s']['g']}
try:
 for i,fn in enumerate([one,two,three,four,five,six,seven],1):record(i,fn)
 print(json.dumps({'status':'PASS','rows':rows,'whole_wall_s':time.monotonic()-START},indent=2))
except BaseException as exc:
 (ROOT/'FIRST_FAILURE.json').write_text(json.dumps({'error':repr(exc),'row':len(rows)+1,'completed':rows},indent=2));raise
