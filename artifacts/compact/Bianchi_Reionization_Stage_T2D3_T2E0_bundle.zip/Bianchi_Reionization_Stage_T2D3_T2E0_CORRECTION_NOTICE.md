# Stage T2-D3/T2-E0 correction notice

This notice supersedes two implementation details from the earlier T2-C/T2-D2 ledgers.

## 1. A photon-number-only log-energy remap is insufficient

The old fixed-grid test evolved the photon-number-adapted variable

\[
G=e^{3y}F,\qquad y=\ln(E/E_\star),
\]

and required only column-sum conservation. That closes the photon-number ledger but not the electron-rest-frame energy ledger. In the finite-tilt combined test it produced

\[
\frac{|u_e\cdot Q_\gamma|}{|\boldsymbol Q_{\gamma,e}|}\simeq0.554.
\]

The production remap must preserve both

\[
\sum_i G_i
\quad\text{and}\quad
\sum_i e^{y_i}G_i.
\]

For a shifted packet with target energy \(E'=e^{y_i+\delta}\), deposit it between adjacent target energy nodes \(E_j\le E'\le E_{j+1}\):

\[
w_{j+1}=\frac{E'-E_j}{E_{j+1}-E_j},\qquad w_j=1-w_{j+1}.
\]

This map is positive and preserves discrete photon number and energy exactly.

## 2. Do not use the transpose as the physical reverse remap

For the old periodic first-order unit test, the shift matrix was doubly stochastic and \(R^T\) could serve as a conservative adjoint. The physical nonperiodic number-and-energy remap is column-stochastic but not generally row-stochastic. Therefore \(R^T\) does not preserve photon number on pullback.

Construct a separate positive reverse remap with shift \(-\delta\). Guard cells and explicit low/high escape ledgers remain required at production boundaries.

## 3. Production six-moment route

The preferred route is now:

1. transform each transport-grid coherency tensor with the corrected spin convention \(Q+iU\leftrightarrow s=+2\);
2. remap in energy with the positive two-moment map;
3. integrate the six electron-frame symmetric-tensor moments directly on the transport quadrature;
4. apply exact local out-scattering \(-\mathcal D G\);
5. reconstruct only the in-scattering term from the six moments;
6. apply the separately constructed reverse energy remap.

This direct moment map is a positive weighted sum of PSD coherency tensors. Fully polarized impulse scans produced no negative moment eigenvalue beyond roundoff, so the trace-preserving PSD projection is normally inactive and remains a fail-safe only.
