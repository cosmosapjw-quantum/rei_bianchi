(* ::Package:: *)

(*
  Bianchi reionization Stage T2-C

  Scope:
    1. Fixed-grid conservative log-energy remapping.
    2. Photon-number adapted variable G = Exp[3 y] F.
    3. Direction-dependent finite-tilt Thomson implicit solve.
    4. Standard and conservation-deflated rank-6 Woodbury solvers.

  Conventions:
    metric signature (-,+,+,+)
    c = 1 in this verification script
    classical elastic Thomson scattering
    real symmetric 2x2 linear-polarization coherency; Stokes V omitted

  Important:
    Periodic remaps below are algebraic unit tests. The nonperiodic overlap
    remap includes explicit left/right truncation ledgers. A production grid
    still needs guard cells and a higher-order monotone reconstruction.
*)

ClearAll["Global`*"];
$MaxExtraPrecision = 2000;
workPrec = 80;
maxAbs[x_] := Max[Abs[Flatten[x]]];

(* ---------------------------------------------------------------------- *)
(* Angular quadrature and Thomson low-rank factors                         *)
(* ---------------------------------------------------------------------- *)

lebedev14[prec_:80] := Module[{axes, cubes, dirs, weights},
  axes = {{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
  cubes = Flatten[
    Table[{sx,sy,sz}/Sqrt[3], {sx,{-1,1}}, {sy,{-1,1}}, {sz,{-1,1}}],
    2
  ];
  dirs = N[Join[axes,cubes],prec];
  weights = N[Join[ConstantArray[1/15,6],ConstantArray[3/40,8]],prec];
  {dirs,weights}
];

referenceVector[k_] := If[Abs[k[[3]]] < 9/10, {0,0,1}, {1,0,0}];
screenBasis1[k_] := Normalize[Cross[referenceVector[k],k]];
screenBasis2[k_] := Cross[k,screenBasis1[k]];
screenProjector3[k_] := IdentityMatrix[3] - Outer[Times,k,k];

symPack[m_] := {m[[1,1]],m[[2,2]],m[[3,3]],m[[1,2]],m[[1,3]],m[[2,3]]};
symUnpack[z_] := {
  {z[[1]],z[[4]],z[[5]]},
  {z[[4]],z[[2]],z[[6]]},
  {z[[5]],z[[6]],z[[3]]}
};

buildThomsonData[dirs_, weights_] := Module[
  {nAng,e1,e2,embed,extract,embedMatrices,vt,outMaps,u,tOp,traceRow,iso},
  nAng = Length[dirs];
  e1 = screenBasis1 /@ dirs;
  e2 = screenBasis2 /@ dirs;

  embed[p_,x_] :=
      x[[1]] Outer[Times,e1[[p]],e1[[p]]]
    + x[[2]] Outer[Times,e2[[p]],e2[[p]]]
    + x[[3]] (Outer[Times,e1[[p]],e2[[p]]] + Outer[Times,e2[[p]],e1[[p]]]);

  extract[p_,m_] := {
    e1[[p]].m.e1[[p]],
    e2[[p]].m.e2[[p]],
    e1[[p]].m.e2[[p]]
  };

  embedMatrices = Table[
    Transpose[symPack[embed[p,#]] & /@ IdentityMatrix[3]],
    {p,nAng}
  ];

  vt = ArrayFlatten[{
    Table[weights[[p]] embedMatrices[[p]], {p,nAng}]
  }];

  outMaps = Table[
    Transpose@Table[
      extract[
        p,
        (3/2) screenProjector3[dirs[[p]]]
          .symUnpack[IdentityMatrix[6][[j]]]
          .screenProjector3[dirs[[p]]]
      ],
      {j,6}
    ],
    {p,nAng}
  ];

  u = ArrayFlatten[Table[{outMaps[[p]]},{p,nAng}]];
  tOp = -IdentityMatrix[3 nAng] + u.vt;
  traceRow = Flatten@Table[weights[[p]] {1,1,0},{p,nAng}];
  iso = Flatten@Table[{1/2,1/2,0},{nAng}];

  <|"U"->u,"VT"->vt,"Operator"->tOp,"TraceRow"->traceRow,"Iso"->iso|>
];

{electronDirs, angularWeights} = lebedev14[workPrec];
thomson = buildThomsonData[electronDirs,angularWeights];
u = thomson["U"];
vt = thomson["VT"];
tOp = thomson["Operator"];
traceRow = thomson["TraceRow"];
isotropicVector = thomson["Iso"];

(* Exact six-dimensional moment action K = V^T U. *)
z = Array[zz,6];
m = symUnpack[z];
kAction = FullSimplify[(7/10) m + (Tr[m]/10) IdentityMatrix[3]];
kMatrix = Transpose@Table[
  Coefficient[symPack[kAction],z[[j]]],
  {j,6}
];

(* ---------------------------------------------------------------------- *)
(* Conservative first-order remaps                                        *)
(* ---------------------------------------------------------------------- *)

shiftMatrix[n_Integer,m_Integer] := Module[{s=ConstantArray[0,{n,n}]},
  Do[s[[Mod[j-1+m,n]+1,j]]=1,{j,n}];
  s
];

(* Do NOT use FractionalPart[s] here: in Wolfram Language it is negative
   for negative s. The floor-based alpha is always in [0,1). *)
periodicRemap[n_Integer,s_] := Module[{m=Floor[s],alpha},
  alpha = s-m;
  (1-alpha) shiftMatrix[n,m] + alpha shiftMatrix[n,m+1]
];

(* Nonperiodic piecewise-constant overlap remap with truncation ledgers. *)
overlapRemap[n_Integer,s_?NumericQ,prec_:80] := Module[
  {target,left,right,lo,hi,ov},
  target = ConstantArray[SetPrecision[0,prec],{n,n}];
  left = ConstantArray[SetPrecision[0,prec],n];
  right = ConstantArray[SetPrecision[0,prec],n];
  Do[
    lo = SetPrecision[j-1+s,prec];
    hi = lo+1;
    Do[
      ov = Max[0,Min[SetPrecision[i,prec],hi]-Max[SetPrecision[i-1,prec],lo]];
      target[[i,j]] = ov,
      {i,n}
    ];
    left[[j]] = Max[0,Min[hi,0]-lo];
    right[[j]] = Max[0,hi-Max[lo,n]],
    {j,n}
  ];
  <|
    "Target"->target,
    "LeftEscape"->left,
    "RightEscape"->right,
    "Augmented"->Join[target,{left},{right}]
  |>
];

(* Symbolic periodic round-trip identity. *)
nSymbolic = 6;
alpha = aa;
sR = shiftMatrix[nSymbolic,1];
sL = Transpose[sR];
rPlus = (1-alpha) IdentityMatrix[nSymbolic] + alpha sR;
rMinus = (1-alpha) IdentityMatrix[nSymbolic] + alpha sL;
roundTripDiffusionResidual = FullSimplify[
  rMinus.rPlus - IdentityMatrix[nSymbolic]
  - alpha(1-alpha)(sR+sL-2 IdentityMatrix[nSymbolic])
];

(* ---------------------------------------------------------------------- *)
(* Fixed-grid G = Exp[3 y] F gate                                         *)
(* ---------------------------------------------------------------------- *)

v = N[11/20,workPrec];
gamma = 1/Sqrt[1-v^2];
doppler = 1/(gamma(1+v electronDirs[[All,3]]));

ny = 12;
dy = N[1/5,workPrec];
energyRemaps = Table[
  periodicRemap[ny,Log[doppler[[p]]]/dy],
  {p,Length[electronDirs]}
];

SeedRandom[8831];
normalG = Table[
  Module[{h=RandomInteger[{-2,2},{2,2}],mm},
    mm = Transpose[h].h;
    N[{mm[[1,1]],mm[[2,2]],mm[[1,2]]},workPrec]
  ],
  {p,Length[electronDirs]},{i,ny}
];

electronG = Table[
  doppler[[p]]^3
    Transpose@Table[energyRemaps[[p]].normalG[[p,All,c]],{c,3}],
  {p,Length[electronDirs]}
];

electronCollision = ConstantArray[0,{Length[electronDirs],ny,3}];
Do[
  electronCollision[[All,i,All]] =
    Partition[tOp.Flatten[electronG[[All,i,All]]],3],
  {i,ny}
];

(* Conservative adjoint collision pullback for G. *)
normalCollision = Table[
  doppler[[p]]^-2
    Transpose@Table[Transpose[energyRemaps[[p]]].electronCollision[[p,All,c]],{c,3}],
  {p,Length[electronDirs]}
];

normalAngularWeights = angularWeights doppler^2;
normalPhotonNumber = Sum[
  normalAngularWeights[[p]]
    Sum[normalG[[p,i,1]]+normalG[[p,i,2]],{i,ny}],
  {p,Length[electronDirs]}
];

electronRepresentationPhotonNumber = Sum[
  (angularWeights[[p]]/doppler[[p]])
    Sum[electronG[[p,i,1]]+electronG[[p,i,2]],{i,ny}],
  {p,Length[electronDirs]}
];

collisionPhotonNumberSource = Sum[
  normalAngularWeights[[p]]
    Sum[normalCollision[[p,i,1]]+normalCollision[[p,i,2]],{i,ny}],
  {p,Length[electronDirs]}
];

normalBoostedEquilibrium = Table[
  doppler[[p]]^-3 {1/2,1/2,0},
  {p,Length[electronDirs]},{i,ny}
];

electronEquilibrium = Table[
  doppler[[p]]^3
    Transpose@Table[
      energyRemaps[[p]].normalBoostedEquilibrium[[p,All,c]],
      {c,3}
    ],
  {p,Length[electronDirs]}
];

equilibriumCollision = Table[
  Partition[tOp.Flatten[electronEquilibrium[[All,i,All]]],3],
  {i,ny}
];

(* ---------------------------------------------------------------------- *)
(* Directional-rate implicit collision and deflated Woodbury solve        *)
(* ---------------------------------------------------------------------- *)

dVector = Flatten@Table[ConstantArray[doppler[[p]],3],{p,Length[electronDirs]}];
dMatrix = DiagonalMatrix[dVector];
normalTimeCollisionOperator = dMatrix.tOp;
normalNumberLeftNull = traceRow.DiagonalMatrix[1/dVector];

standardWoodburySolve[lambda_,rhs_] := Module[{a0Inv,uC,small},
  a0Inv = DiagonalMatrix[1/(1+lambda dVector)];
  uC = lambda dMatrix.u;
  small = IdentityMatrix[6]-vt.a0Inv.uC;
  a0Inv.rhs + a0Inv.uC.LinearSolve[small,vt.a0Inv.rhs]
];

(* Conservation-deflated solve. The 7x6 system must be solved by pivoted QR
   or SVD, not normal equations. *)
deflatedWoodburySolve[lambda_,rhs_] := Module[
  {amp,rhsPerp,a0Inv,uC,small,g,cRow,dScalar,y},
  amp = (normalNumberLeftNull.rhs)/(normalNumberLeftNull.isotropicVector);
  rhsPerp = rhs-amp isotropicVector;
  a0Inv = DiagonalMatrix[1/(1+lambda dVector)];
  uC = lambda dMatrix.u;
  small = IdentityMatrix[6]-vt.a0Inv.uC;
  g = vt.a0Inv.rhsPerp;
  cRow = normalNumberLeftNull.a0Inv.uC;
  dScalar = normalNumberLeftNull.a0Inv.rhsPerp;
  y = LeastSquares[Join[small,{cRow}],Join[g,{-dScalar}]];
  amp isotropicVector + a0Inv.rhsPerp + a0Inv.uC.y
];

SeedRandom[1234];
implicitRHS = N[Flatten@Table[
  Module[{h=RandomInteger[{-3,3},{2,2}],mm},
    mm=Transpose[h].h;
    {mm[[1,1]],mm[[2,2]],mm[[1,2]]}
  ],
  {Length[electronDirs]}
],workPrec];

implicitTests = Table[
  Module[{xStandard,xDeflated,a0Inv,uC,small,aug,svSmall,svAug},
    xStandard = standardWoodburySolve[lambda,implicitRHS];
    xDeflated = deflatedWoodburySolve[lambda,implicitRHS];
    a0Inv = DiagonalMatrix[1/(1+lambda dVector)];
    uC = lambda dMatrix.u;
    small = IdentityMatrix[6]-vt.a0Inv.uC;
    aug = Join[
      small,
      {normalNumberLeftNull.a0Inv.uC}
    ];
    svSmall = SingularValueList[small];
    svAug = SingularValueList[aug];
    <|
      "Lambda"->lambda,
      "StandardMomentResidual"->Abs[normalNumberLeftNull.xStandard-normalNumberLeftNull.implicitRHS],
      "DeflatedMomentResidual"->Abs[normalNumberLeftNull.xDeflated-normalNumberLeftNull.implicitRHS],
      "Small6x6Condition"->Max[svSmall]/Min[svSmall],
      "Augmented7x6Condition"->Max[svAug]/Min[svAug]
    |>
  ],
  {lambda,N[{10^2,10^6,10^12},workPrec]}
];

results = <|
  "MomentOperator"-><|
    "KMatrix"->kMatrix,
    "Eigenvalues"->Eigenvalues[kMatrix],
    "CharacteristicPolynomial"->Factor[CharacteristicPolynomial[kMatrix,x]]
  |>,
  "Remap"-><|
    "FractionalPartNegativeExample"->FractionalPart[-3.091906567872317],
    "FloorBasedFractionExample"->-3.091906567872317-Floor[-3.091906567872317],
    "PeriodicRoundTripDiffusionResidual"->roundTripDiffusionResidual,
    "PeriodicRowSumResidual"->Max@Table[
      maxAbs[energyRemaps[[p]].ConstantArray[1,ny]-ConstantArray[1,ny]],
      {p,Length[electronDirs]}
    ],
    "PeriodicColumnSumResidual"->Max@Table[
      maxAbs[Total[energyRemaps[[p]],{1}]-ConstantArray[1,ny]],
      {p,Length[electronDirs]}
    ],
    "MinimumEntry"->Min[Flatten[energyRemaps]]
  |>,
  "FixedGridG"-><|
    "NormalVsElectronNumberResidual"->electronRepresentationPhotonNumber-normalPhotonNumber,
    "CollisionPhotonNumberResidual"->collisionPhotonNumberSource,
    "BoostedEquilibriumNullResidual"->maxAbs[equilibriumCollision]
  |>,
  "Implicit"-><|
    "RightNullResidual"->maxAbs[normalTimeCollisionOperator.isotropicVector],
    "LeftNullResidual"->maxAbs[normalNumberLeftNull.normalTimeCollisionOperator],
    "Tests"->implicitTests
  |>
|>;

results
