# Bianchi reionization — Stage T2-D3/T2-E0 verification ledger

## Status

\[
\boxed{\text{PASS WITH PRODUCTION-PATH REVISION}}
\]

The corrected spin convention remains canonical:

\[
Q+iU\leftrightarrow s=+2,\qquad Q-iU\leftrightarrow s=-2,
\]

\[
{}_sY^{\rm patch}=e^{-is\alpha_{\rm patch}}{}_sY^{\rm std},
\qquad
\Phi_s=e^{+is\psi}.
\]

The main result of this stage is that the production collision interface should not construct a low-resolution electron-frame angular state unless it is needed for diagnostics. The robust path is direct six-moment extraction from the transport grid, exact local out-scattering, and six-moment in-scattering reconstruction.

---

## 1. Combined operator

For the closed-grid algebraic test with \(N_T=26\), \(N_y=4\), and three local Stokes variables, the normal-frame state dimension is

\[
3N_TN_y=312,
\]

and the electron-frame symmetric moment dimension is

\[
6N_y=24.
\]

The direct forward moment map is

\[
M_j=\sum_{p,i}w_p\,\mathcal D_p\,R^{(+)}_{p,ji}\,
\mathcal E_p\mathcal R_p G_{p i},
\]

where \(\mathcal E_p\) embeds local \((I,Q,U)\) into a symmetric \(3\times3\) electron-frame tensor and \(\mathcal R_p\) is the corrected spin-screen rotation.

The exact local loss is

\[
C_{\rm out}G=-D_TG.
\]

The raw finite-quadrature in-scattering reconstruction missed the spectral invariants by

\[
0.3331963779260482.
\]

A rank-\(N_y\) intensity correction enforcing

\[
C_{\rm inv}U=T_{\rm tr}
\]

reduced the residual to zero at roughly 57 displayed digits. The full update retained rank

\[
6N_y=24.
\]

---

## 2. Realizability and PSD projection

The direct moment map uses positive angular weights, positive energy-remap weights, and exact local screen rotations. Therefore it is a positive sum of PSD coherency tensors.

A scan over every Lebedev-26 direction and 16 fully polarized angles gave

\[
\lambda_{\min}^{\rm worst}=-3.19\times10^{-58},
\]

with zero values below the \(10^{-35}\) negativity threshold. A random physical PSD field gave

\[
\lambda_{\min}=4.5417147179.
\]

The trace-preserving projection

\[
\lambda_i\mapsto
\operatorname{tr}M\,
\frac{\max(\lambda_i,0)}{\sum_j\max(\lambda_j,0)}
\]

was inactive on all physical test bins; its maximum change was about \(1.37\times10^{-45}\). It remains a fail-safe for roundoff or an upstream cone violation, not part of the normal linear operator.

---

## 3. Energy remap correction

The old number-only fixed log-grid remap failed the finite-tilt four-force gate:

\[
\frac{|u_e\cdot Q_\gamma|}{|\boldsymbol Q_{\gamma,e}|}
=0.5538920104.
\]

The corrected map deposits a shifted packet between adjacent physical-energy nodes and preserves both number and energy. A separately constructed reverse map with shift \(-\ln\mathcal D\) replaces the old transpose pullback.

For the compact-support guard-cell test:

- forward number residual: zero at about 68 digits;
- forward energy residual: zero at about 68 digits;
- reverse number residual: zero at about 68 digits;
- reverse energy residual: zero at about 68 digits;
- minimum remap coefficient: \(0\);
- active escape: \(0\).

The corrected collision source satisfied

\[
\Delta N_\gamma=0,
\]

\[
u_e\cdot Q_\gamma=0
\]

at about 63 displayed digits.

The nontrivial four-forces were

\[
Q_\gamma^{\mu}\big|_n=
(3.6438718288,
3.4276171249,
-2.6445468108,
4.8768541994),
\]

\[
Q_\gamma^{\mu}\big|_e=
(0,
2.8100441090,
-2.2062691867,
4.0600640817).
\]

The baryon ledger uses

\[
Q_b^\mu=-Q_\gamma^\mu,
\]

so \(Q_\gamma+Q_b=0\) exactly.

---

## 4. Generalized conservation-deflated Woodbury solve

The global closed-grid test had

\[
N_{\rm state}=234,\quad N_{\rm moment}=18,
\quad \dim\ker L=3,
\]

matching the three discrete spectral invariants. Right-null and biorthogonality residuals vanished at more than 90 displayed digits.

The standard small Woodbury matrix becomes ill-conditioned as \(\lambda\) grows, whereas the invariant-augmented system remains well conditioned:

| \(\lambda\) | standard rel. error | deflated rel. error | standard invariant error | deflated invariant error | \(\kappa(S)\) | \(\kappa(S_{\rm aug})\) |
|---:|---:|---:|---:|---:|---:|---:|
| \(10^2\) | \(1.22\times10^{-15}\) | \(1.67\times10^{-16}\) | \(2.15\times10^{-16}\) | \(6.94\times10^{-18}\) | 67.49 | 8.39 |
| \(10^6\) | \(2.55\times10^{-11}\) | \(1.67\times10^{-16}\) | \(3.98\times10^{-12}\) | \(1.39\times10^{-17}\) | \(6.64\times10^5\) | 8.85 |
| \(10^{12}\) | \(2.96\times10^{-5}\) | \(1.94\times10^{-16}\) | \(4.59\times10^{-6}\) | \(6.94\times10^{-18}\) | \(6.64\times10^{11}\) | 8.85 |

The large machine-precision equation residual at \(10^{12}\) is cancellation-limited because the matrix entries are \(O(10^{12})\); the forward solution error relative to the 100-digit reference remains at machine precision.

This stiff gate used a closed periodic algebraic energy grid. Integrating nonperiodic guard/escape ledgers into the global implicit solve remains open.

---

## 5. Full-state versus six-moment interface

For the combined energy-angle maps,

\[
C_{\rm full}=P(-I+UV)B,
\]

\[
C_6=-D+PUVB,
\]

so

\[
\boxed{C_6-C_{\rm full}=-D+PB}.
\]

The matrix residual of this identity was zero at about 16 displayed digits. With \(N_y=3\), the six-moment update rank was exactly

\[
18=6N_y.
\]

The intermediate state sizes were

\[
126\quad\text{(full collision-grid state)},
\]

versus

\[
18\quad\text{(six moments)}.
\]

A random test state gave a relative full/six difference of \(0.9215\), confirming that the full-state route's projected out-scattering is not a harmless implementation detail. The six-moment route keeps the exact local loss and is the production default.

---

## 6. Energy convergence

The electron-frame spatial four-force was compared with the \(\Delta y=0.125\) result:

| \(\Delta y\) | \(\boldsymbol Q_{\gamma,e}\) | relative error |
|---:|---|---:|
| 0.5 | \((0.66993160,-0.51408782,0.95377357)\) | \(1.32784\times10^{-2}\) |
| 0.25 | \((0.66095668,-0.50720070,0.94099609)\) | \(2.96237\times10^{-4}\) |
| 0.125 | \((0.66115254,-0.50735100,0.94127493)\) | reference |

Number and \(u_e\cdot Q_\gamma\) residuals were zero at the working precision in every run.

---

## 7. Angular convergence

At \(\Delta y=0.25\), the Gauss-Legendre \(8\times16\) product grid was used as the current reference:

| angular grid | nodes | relative four-force error |
|---|---:|---:|
| Lebedev-14 | 14 | \(7.81346\times10^{-2}\) |
| Lebedev-26 | 26 | \(9.67378\times10^{-3}\) |
| GL(6)\(\times\phi_{12}\) | 72 | \(2.94549\times10^{-4}\) |
| GL(8)\(\times\phi_{16}\) | 128 | reference |

The 128-node reference gave

\[
\boldsymbol Q_{\gamma,e}
=(0.65210808,-0.50393070,0.94866353).
\]

This shows that Lebedev-26 is adequate for algebraic gates but not a converged production transport grid at \(|v|\simeq0.559\).

---

## 8. Remaining work

1. add explicit low/high escape ledgers to the nonperiodic implicit solve;
2. replace the first-order two-node energy deposition with a higher-order monotone number-and-energy remap;
3. repeat angular convergence with production Lebedev orders above 26;
4. couple the verified collision block to the nonlinear Bianchi geometry and IMEX timestepper.
