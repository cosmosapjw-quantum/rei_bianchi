Bianchi reionization Stage T2-D3/T2-E0 bundle

Primary files:
- Bianchi_Reionization_Stage_T2D3_T2E0.wl
- Bianchi_Reionization_Stage_T2D3_T2E0_results.md
- Bianchi_Reionization_Stage_T2D3_T2E0_results.json
- Bianchi_Reionization_Stage_T2D3_T2E0_CORRECTION_NOTICE.md

Included prior-stage dependencies/reference implementations:
- Bianchi_Reionization_Stage_T2C.wl
- Bianchi_Reionization_Stage_T2D2.wl
- Bianchi_Reionization_Stage_T2D2_CORRECTION_NOTICE.md

Important:
The main symbolic/numerical blocks were executed individually through the Wolfram evaluator. The standalone .wl file consolidates those verified blocks and the revised production interface. A local monolithic WolframKernel run was not available in the container.
