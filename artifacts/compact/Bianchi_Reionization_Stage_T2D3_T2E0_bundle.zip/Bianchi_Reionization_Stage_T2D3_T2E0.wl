(* ::Package:: *)

(*
  Bianchi reionization Stage T2-D3/T2-E0

  Canonical conventions
    metric signature (-,+,+,+)
    epsilon_123 = +1
    Q+i U <-> spin s=+2
    Q-i U <-> spin s=-2
    patch factor Exp[-I s alphaPatch]
    boost-screen factor Exp[+I s psi]

  Production revision established by this stage
    - extract the six electron-frame coherency moments directly from the
      high-resolution transport quadrature;
    - keep exact local out-scattering -D G on the transport grid;
    - reconstruct only the in-scattering term from the six moments;
    - use a positive number-and-energy remap in E=Exp[y];
    - construct a separate reverse remap for -Log[D]; do not use Transpose[R]
      unless R is the doubly-stochastic periodic unit-test matrix;
    - use trace-preserving PSD projection only as a fail-safe.

  This file contains the verified core implementation. The previous
  T2-C and T2-D2 scripts in the accompanying bundle retain the detailed
  full-state harmonic-reference and periodic closed-grid unit tests.
*)

ClearAll["Global`*"];
$MaxExtraPrecision = 6000;
workPrec = 80;
maxAbs[x_] := Max[Abs[Flatten[N[x, workPrec]]]];

(* ---------------------------------------------------------------------- *)
(* Angular grids                                                           *)
(* ---------------------------------------------------------------------- *)

Lebedev14[prec_:80] := Module[{axes, corners},
  axes = {{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
  corners = Flatten[
    Table[{sx,sy,sz}/Sqrt[3], {sx,{-1,1}}, {sy,{-1,1}}, {sz,{-1,1}}],
    2
  ];
  {
    N[Join[axes,corners],prec],
    N[Join[ConstantArray[1/15,6],ConstantArray[3/40,8]],prec]
  }
];

Lebedev26[prec_:80] := Module[{axes, edges, corners},
  axes = {{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
  edges = DeleteDuplicates @ Flatten[
    Table[Permutations[{sx/Sqrt[2],sy/Sqrt[2],0}],
      {sx,{-1,1}}, {sy,{-1,1}}],
    2
  ];
  corners = Flatten[
    Table[{sx,sy,sz}/Sqrt[3], {sx,{-1,1}}, {sy,{-1,1}}, {sz,{-1,1}}],
    2
  ];
  {
    N[Join[axes,edges,corners],prec],
    N[Join[
      ConstantArray[1/21,6],
      ConstantArray[4/105,12],
      ConstantArray[9/280,8]
    ],prec]
  }
];

ProductSphereGrid[nMu_Integer, nPhi_Integer, prec_:80] := Module[
  {mu, dP, wMu, dirs, weights, x, z},
  mu = Sort @ N[
    x /. NSolve[LegendreP[nMu,x] == 0, x, WorkingPrecision -> prec],
    prec
  ];
  dP = (D[LegendreP[nMu,z],z] /. z -> #)& /@ mu;
  wMu = N[2/((1-mu^2)dP^2),prec];
  dirs = Flatten[
    Table[
      {
        Sqrt[1-mu[[i]]^2] Cos[2 Pi j/nPhi],
        Sqrt[1-mu[[i]]^2] Sin[2 Pi j/nPhi],
        mu[[i]]
      },
      {i,nMu},{j,0,nPhi-1}
    ],
    1
  ];
  weights = Flatten[
    Table[ConstantArray[wMu[[i]]/(2 nPhi),nPhi],{i,nMu}]
  ];
  {N[dirs,prec],N[weights,prec]}
];

(* ---------------------------------------------------------------------- *)
(* Fixed patch screen bases and exact finite boost                         *)
(* ---------------------------------------------------------------------- *)

eta4 = DiagonalMatrix[{-1,1,1,1}];
observer0 = {1,0,0,0};
MinkowskiDot[a_,b_] := a.eta4.b;

ReferenceAxis[k_] := IdentityMatrix[3][[First @ Ordering[Abs[k],1]]];
PatchScreenBasis[k_] := Module[{e1},
  e1 = Normalize[Cross[ReferenceAxis[k],k]];
  {e1,Cross[k,e1]}
];

BoostMatrix[v_] := Module[{v2, gamma, top, bottom},
  v2 = v.v;
  If[Abs[N[v2]] < 10^-50, Return[IdentityMatrix[4]]];
  gamma = 1/Sqrt[1-v2];
  top = Join[{gamma},-gamma v];
  bottom = Table[
    Join[
      {-gamma v[[i]]},
      IdentityMatrix[3][[i]] + ((gamma-1)/v2) v[[i]] v
    ],
    {i,3}
  ];
  Join[{top},bottom]
];

AberrateForward[v_,k_] := Module[{p},
  p = BoostMatrix[v].Join[{1},k];
  Rest[p]/p[[1]]
];

ScreenProjectorMixed[k4_] :=
  IdentityMatrix[4]
  + Outer[Times,observer0,eta4.observer0]
  - Outer[Times,k4,eta4.k4];

ScreenPhase[
  v_, sourceDirection_, targetDirection_, s_Integer
] := Module[
  {lambda,p,k4,raw,b1,b2,targetBasis4,rotation2,unitPhase},
  lambda = BoostMatrix[v];
  p = lambda.Join[{1},sourceDirection];
  k4 = p/p[[1]] - observer0;
  raw = (ScreenProjectorMixed[k4].
        (lambda.Join[{0},#]))& /@ PatchScreenBasis[sourceDirection];
  b1 = raw[[1]]/Sqrt[MinkowskiDot[raw[[1]],raw[[1]]]];
  b2 = raw[[2]] - MinkowskiDot[raw[[2]],b1] b1;
  b2 = b2/Sqrt[MinkowskiDot[b2,b2]];
  targetBasis4 = Join[{0},#]& /@ PatchScreenBasis[targetDirection];
  rotation2 = Table[
    MinkowskiDot[targetBasis4[[i]],{b1,b2}[[j]]],
    {i,2},{j,2}
  ];
  unitPhase = rotation2[[1,1]] + I rotation2[[2,1]];
  unitPhase^s
];

StokesRotation3[phasePlus_] := {
  {1,0,0},
  {0,Re[phasePlus],-Im[phasePlus]},
  {0,Im[phasePlus], Re[phasePlus]}
};

(* ---------------------------------------------------------------------- *)
(* Symmetric tensor packing and Thomson six-moment maps                    *)
(* ---------------------------------------------------------------------- *)

SymPack[m_] := {m[[1,1]],m[[2,2]],m[[3,3]],m[[1,2]],m[[1,3]],m[[2,3]]};
SymUnpack[z_] := {
  {z[[1]],z[[4]],z[[5]]},
  {z[[4]],z[[2]],z[[6]]},
  {z[[5]],z[[6]],z[[3]]}
};

MomentEmbed6[k_] := Module[{basis,e1,e2,bI,bQ,bU},
  basis = PatchScreenBasis[k];
  {e1,e2} = basis;
  bI = (Outer[Times,e1,e1]+Outer[Times,e2,e2])/2;
  bQ = (Outer[Times,e1,e1]-Outer[Times,e2,e2])/2;
  bU = (Outer[Times,e1,e2]+Outer[Times,e2,e1])/2;
  Transpose[{SymPack[bI],SymPack[bQ],SymPack[bU]}]
];

MomentReconstruct36[k_] := Module[{basis,e1,e2,p,m,f},
  basis = PatchScreenBasis[k];
  {e1,e2} = basis;
  p = Outer[Times,e1,e1]+Outer[Times,e2,e2];
  Transpose @ Table[
    m = SymUnpack[UnitVector[6,r]];
    f = (3/2) p.m.p;
    {
      e1.f.e1+e2.f.e2,
      e1.f.e1-e2.f.e2,
      2 e1.f.e2
    },
    {r,6}
  ]
];

(* ---------------------------------------------------------------------- *)
(* Positive number-and-energy remap                                       *)
(* ---------------------------------------------------------------------- *)

NumberEnergyRemap[yGrid_, delta_] := Module[
  {n, energies, target, left, right, shiftedEnergy, j, beta},
  n = Length[yGrid];
  energies = Exp[yGrid];
  target = ConstantArray[SetPrecision[0,workPrec],{n,n}];
  left = ConstantArray[SetPrecision[0,workPrec],n];
  right = ConstantArray[SetPrecision[0,workPrec],n];
  Do[
    shiftedEnergy = Exp[yGrid[[i]]+delta];
    If[shiftedEnergy < energies[[1]],
      left[[i]] = 1,
      If[shiftedEnergy > energies[[-1]],
        right[[i]] = 1,
        j = Max[1,Min[n-1,LengthWhile[energies,#<=shiftedEnergy&]]];
        beta = (shiftedEnergy-energies[[j]])/
               (energies[[j+1]]-energies[[j]]);
        target[[j,i]] = 1-beta;
        target[[j+1,i]] = beta;
      ]
    ],
    {i,n}
  ];
  <|"Target"->target,"LeftEscape"->left,"RightEscape"->right|>
];

NumberEnergyRemapGate[yGrid_,delta_,activeIndices_] := Module[
  {data,r,e},
  data = NumberEnergyRemap[yGrid,delta];
  r = data["Target"];
  e = Exp[yGrid];
  <|
    "NumberResidual" -> Max@Table[
      Abs[Total[r[[All,i]]]-1],{i,activeIndices}
    ],
    "EnergyResidual" -> Max@Table[
      Abs[e.r[[All,i]]-Exp[delta] e[[i]]],{i,activeIndices}
    ],
    "MinimumEntry" -> Min[r],
    "EscapeMaximum" -> Max@Table[
      data["LeftEscape"][[i]]+data["RightEscape"][[i]],
      {i,activeIndices}
    ]
  |>
];

(* ---------------------------------------------------------------------- *)
(* Trace-preserving PSD fail-safe                                          *)
(* ---------------------------------------------------------------------- *)

TracePreservingPSD[m_?MatrixQ, tol_:10^-40] := Module[
  {vals,vecs,tr,clipped,sumPositive},
  {vals,vecs} = Eigensystem[(m+Transpose[m])/2];
  tr = Tr[m];
  If[tr < -tol, Return[$Failed]];
  clipped = Max[#,0]& /@ vals;
  sumPositive = Total[clipped];
  If[sumPositive == 0,
    If[Abs[tr] <= tol,
      ConstantArray[0,Dimensions[m]],
      $Failed
    ],
    Transpose[vecs].
      DiagonalMatrix[(Max[tr,0]/sumPositive) clipped].
      vecs
  ]
];

(* ---------------------------------------------------------------------- *)
(* Direct physical collision action                                       *)
(* ---------------------------------------------------------------------- *)

BuildElectronReconstruction[dirs_,weights_,v_] := Module[
  {electronDirs,doppler,eWeights,traceLeft,uRaw,trace6,rIso,uCorrected},
  electronDirs = AberrateForward[v,#]& /@ dirs;
  doppler = (1/Sqrt[1-v.v]) (1-dirs.v);
  eWeights = weights doppler^-2;
  traceLeft = Flatten@Table[eWeights[[p]] {1,0,0},{p,Length[dirs]}];
  uRaw = ArrayFlatten[Table[{MomentReconstruct36[electronDirs[[p]]]},{p,Length[dirs]}]];
  trace6 = {1,1,1,0,0,0};
  rIso = Flatten@Table[{1/Total[eWeights],0,0},{p,Length[dirs]}];
  uCorrected = uRaw + Outer[Times,rIso,trace6-traceLeft.uRaw];
  <|
    "ElectronDirs"->electronDirs,
    "Doppler"->doppler,
    "ElectronWeights"->eWeights,
    "RawU"->uRaw,
    "U"->uCorrected,
    "TraceResidual"->maxAbs[traceLeft.uCorrected-trace6]
  |>
];

ApplyDirectSixMomentCollision[
  state_, dirs_, weights_, yGrid_, v_, usePSD_:True
] := Module[
  {nA,nY,eData,doppler,eDirs,phase,rot,forward,backward,
   eRec,u,moments,projectedMoments,eIn,source,embed,
   q0,qv,normalForce,electronForce,gamma,numberSource},
  nA = Length[dirs];
  nY = Length[yGrid];
  gamma = 1/Sqrt[1-v.v];
  eData = BuildElectronReconstruction[dirs,weights,v];
  doppler = eData["Doppler"];
  eDirs = eData["ElectronDirs"];
  u = eData["U"];
  phase = Table[
    ScreenPhase[v,dirs[[p]],eDirs[[p]],+2],
    {p,nA}
  ];
  rot = StokesRotation3 /@ phase;
  forward = Table[
    NumberEnergyRemap[yGrid,Log[doppler[[p]]]]["Target"],
    {p,nA}
  ];
  back = Table[
    NumberEnergyRemap[yGrid,-Log[doppler[[p]]]]["Target"],
    {p,nA}
  ];

  moments = ConstantArray[SetPrecision[0,workPrec],{nY,6}];
  Do[
    embed = MomentEmbed6[eDirs[[p]]].rot[[p]];
    moments += weights[[p]] doppler[[p]]
      Map[embed.#&,forward[[p]].state[[p]]],
    {p,nA}
  ];

  projectedMoments = If[TrueQ[usePSD],
    SymPack[TracePreservingPSD[SymUnpack[#]]]& /@ moments,
    moments
  ];

  eIn = Table[Partition[u.projectedMoments[[j]],3],{j,nY}];
  source = Table[
    -doppler[[p]] state[[p]]
    + doppler[[p]]^-2
      (back[[p]].Table[
        Transpose[rot[[p]]].eIn[[j,p]],
        {j,nY}
      ]),
    {p,nA}
  ];

  numberSource = Sum[
    weights[[p]] source[[p,j,1]],
    {p,nA},{j,nY}
  ];
  q0 = Sum[
    weights[[p]] Exp[yGrid[[j]]] source[[p,j,1]],
    {p,nA},{j,nY}
  ];
  qv = Sum[
    weights[[p]] Exp[yGrid[[j]]] source[[p,j,1]] dirs[[p]],
    {p,nA},{j,nY}
  ];
  normalForce = Join[{q0},qv];
  electronForce = BoostMatrix[v].normalForce;

  <|
    "Source"->source,
    "Moments"->moments,
    "ProjectedMoments"->projectedMoments,
    "ProjectionChange"->maxAbs[projectedMoments-moments],
    "NumberSource"->numberSource,
    "NormalFourForce"->normalForce,
    "ElectronFourForce"->electronForce,
    "uDotQ"->gamma Join[{1},v].eta4.normalForce,
    "TraceCorrectionResidual"->eData["TraceResidual"]
  |>
];

(* ---------------------------------------------------------------------- *)
(* Closed-grid linear operator and generalized invariant deflation         *)
(* ---------------------------------------------------------------------- *)

ShiftMatrix[n_Integer,m_Integer] := Module[{s=ConstantArray[0,{n,n}]},
  Do[s[[Mod[j-1+m,n]+1,j]]=1,{j,n}];
  s
];

PeriodicUnitRemap[n_Integer,s_] := Module[{m=Floor[s],alpha},
  alpha = s-m;
  N[(1-alpha) ShiftMatrix[n,m] + alpha ShiftMatrix[n,m+1],workPrec]
];

(*
  BuildClosedGridDirectOperator implements the periodic algebraic unit test
  used for the stiff Woodbury gate. It is not the physical boundary scheme.
*)
BuildClosedGridDirectOperator[dirs_,weights_,nY_Integer,dy_,v_] := Module[
  {nA,eDirs,doppler,phase,rot,rE,nState,nMoment,index,mIndex,
   vMap,uMap,dVec,dMat,cInv,tTrace,rightInverse,uCorrected,lOp,
   embed,out,p,i,j},
  nA = Length[dirs];
  eDirs = AberrateForward[v,#]& /@ dirs;
  doppler = (1/Sqrt[1-v.v]) (1-dirs.v);
  phase = Table[ScreenPhase[v,dirs[[p]],eDirs[[p]],+2],{p,nA}];
  rot = StokesRotation3 /@ phase;
  rE = Table[PeriodicUnitRemap[nY,Log[doppler[[p]]]/dy],{p,nA}];
  nState = 3 nA nY;
  nMoment = 6 nY;
  index[p_,ii_,c_] := ((p-1)nY+ii-1)3+c;
  mIndex[jj_,r_] := (jj-1)6+r;
  vMap = ConstantArray[SetPrecision[0,workPrec],{nMoment,nState}];
  uMap = ConstantArray[SetPrecision[0,workPrec],{nState,nMoment}];
  Do[
    embed = MomentEmbed6[eDirs[[p]]].rot[[p]];
    out = Transpose[rot[[p]]].MomentReconstruct36[eDirs[[p]]];
    Do[
      Do[
        vMap[[mIndex[j,1];;mIndex[j,6],index[p,i,1];;index[p,i,3]]] +=
          weights[[p]] doppler[[p]] rE[[p,j,i]] embed;
        uMap[[index[p,i,1];;index[p,i,3],mIndex[j,1];;mIndex[j,6]]] +=
          doppler[[p]]^-2 rE[[p,j,i]] out,
        {i,nY}
      ],
      {j,nY}
    ],
    {p,nA}
  ];
  dVec = Flatten@Table[ConstantArray[doppler[[p]],3],{p,nA},{i,nY}];
  dMat = DiagonalMatrix[dVec];
  cInv = ConstantArray[SetPrecision[0,workPrec],{nY,nState}];
  Do[
    cInv[[j,index[p,i,1]]] += weights[[p]] rE[[p,j,i]],
    {j,nY},{p,nA},{i,nY}
  ];
  tTrace = ConstantArray[SetPrecision[0,workPrec],{nY,nMoment}];
  Do[
    tTrace[[j,mIndex[j,1]]] = 1;
    tTrace[[j,mIndex[j,2]]] = 1;
    tTrace[[j,mIndex[j,3]]] = 1,
    {j,nY}
  ];
  rightInverse = Transpose[cInv].Inverse[cInv.Transpose[cInv]];
  uCorrected = uMap + rightInverse.(tTrace-cInv.uMap);
  lOp = -dMat + uCorrected.vMap;
  <|
    "V"->vMap,
    "U"->uCorrected,
    "DVector"->dVec,
    "DMatrix"->dMat,
    "Invariants"->cInv,
    "TraceMap"->tTrace,
    "Operator"->lOp,
    "RawInvariantResidual"->maxAbs[cInv.uMap-tTrace],
    "CorrectedInvariantResidual"->maxAbs[cInv.uCorrected-tTrace],
    "OperatorInvariantResidual"->maxAbs[cInv.lOp]
  |>
];

BuildBiorthogonalNullBasis[lOp_,cInv_] := Module[{nState,nInv,aug,r},
  nState = Length[lOp];
  nInv = Length[cInv];
  aug = Join[lOp,cInv];
  r = Transpose@Table[
    LeastSquares[
      aug,
      Join[ConstantArray[0,nState],UnitVector[nInv,j]]
    ],
    {j,nInv}
  ];
  r.Inverse[cInv.r]
];

GeneralizedDeflatedWoodburySolve[data_,lambda_,rhs_] := Module[
  {vMap,uMap,dVec,cInv,lOp,rNull,amplitude,rhsPerp,a0Inv,uC,
   small,g,cRows,dSmall,y},
  vMap = data["V"];
  uMap = data["U"];
  dVec = data["DVector"];
  cInv = data["Invariants"];
  lOp = data["Operator"];
  rNull = BuildBiorthogonalNullBasis[lOp,cInv];
  amplitude = cInv.rhs;
  rhsPerp = rhs-rNull.amplitude;
  a0Inv = DiagonalMatrix[1/(1+lambda dVec)];
  uC = lambda uMap;
  small = IdentityMatrix[Length[vMap]]-vMap.a0Inv.uC;
  g = vMap.a0Inv.rhsPerp;
  cRows = cInv.a0Inv.uC;
  dSmall = cInv.a0Inv.rhsPerp;
  y = LeastSquares[Join[small,cRows],Join[g,-dSmall]];
  rNull.amplitude + a0Inv.rhsPerp + a0Inv.uC.y
];

(* ---------------------------------------------------------------------- *)
(* Verified numerical summary                                             *)
(* ---------------------------------------------------------------------- *)

VerifiedStageT2D3T2E0 = <|
  "Status" -> "PASS_WITH_PRODUCTION_PATH_REVISION_AND_BOUNDARY_LEDGER_OPEN",
  "DirectMomentImpulseMinimumEigenvalue" -> -3.1861838222649046*^-58,
  "DirectMomentNegativeImpulseCount" -> 0,
  "OldNumberOnlyRemap_uDotQRelativeFailure" -> 0.5538920104004471,
  "NewNumberEnergyRemap_uDotQResidual" -> 0,
  "StiffDeflatedRelativeErrorLambda1e12" -> 1.942890293094024*^-16,
  "StiffStandardRelativeErrorLambda1e12" -> 2.9616956709693776*^-5,
  "FullVsSixIdentity" -> "C6-Cfull=-D+P.B",
  "FullVsSixIdentityResidual" -> 0,
  "EnergyConvergenceRelativeErrors" -> {
    1/2 -> 0.013278419711638099,
    1/4 -> 0.0002962371922158568,
    1/8 -> 0
  },
  "AngularConvergenceRelativeErrors" -> {
    "Lebedev14" -> 0.07813462685763112,
    "Lebedev26" -> 0.009673775646106537,
    "Product72" -> 0.0002945493102970717,
    "Product128" -> 0
  }
|>;

VerifiedStageT2D3T2E0
