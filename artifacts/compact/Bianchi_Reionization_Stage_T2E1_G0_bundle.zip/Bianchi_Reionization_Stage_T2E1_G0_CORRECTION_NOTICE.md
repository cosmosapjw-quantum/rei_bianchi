# Stage T2-E1/G0 correction and scope notice

This notice supersedes three overly strong interpretations that could be inferred from earlier stages.

1. **A four-scalar low/high ledger is an accounting closure, not a physical escaped-radiation state.** It preserves total photon number and energy and can be included in invariant deflation. It does not retain escaped angular direction or polarization, so it cannot by itself participate in Thomson scattering. Non-negligible escape requires ghost spectral coherency bins.

2. **The exact Bianchi-I exponential is exact only when the expansion tensor `K=H I+sigma` is constant over the substep.** A nonlinear background requires a time-ordered exponential, preferably a commutator-free Magnus integrator.

3. **The combined G0 IMEX run was scalar in the Liouville block.** The corrected spin convention and polarized direct-six-moment collision block remain valid, but exact collisionless screen-tensor transport through Bianchi-I geometry remains open.

The earlier T2-C correction remains in force: physical frame remaps must preserve both photon number and energy, and reverse remaps must be generated explicitly rather than replaced by a plain transpose.
