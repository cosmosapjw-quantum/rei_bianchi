(* ::Title:: *)
(* Bianchi Reionization Stage T2-E1/G0 *)

(* This file consolidates the Wolfram blocks that were evaluated separately in the
   ChatGPT Wolfram runtime. It has not been monolithically re-run with Get[] in the
   local container, because no standalone WolframKernel is installed there. *)

ClearAll[MaxAbs];
MaxAbs[x_] := Max[Abs[Flatten[N[x, 50]]]];

(* ------------------------------------------------------------------------- *)
(* 1. Number-and-energy preserving remaps with low/high escape ledgers        *)
(* ------------------------------------------------------------------------- *)

ClearAll[BuildAugmentedRemaps];
BuildAugmentedRemaps[n_Integer, ymin_, ymax_, delta_] := Module[
  {y, e, fac, low, high, loN, loU, hiN, hiU, target, j, alpha,
   stencil, ys, w0, c, rhs, wh, augLow, augHigh, leftN, leftU},
  y = N[Subdivide[ymin, ymax, n - 1], 70];
  e = Exp[y]; fac = Exp[N[delta, 70]];
  low = ConstantArray[0`70, {n, n}];
  loN = ConstantArray[0`70, n]; loU = ConstantArray[0`70, n];
  hiN = ConstantArray[0`70, n]; hiU = ConstantArray[0`70, n];

  Do[
    target = fac e[[i]];
    Which[
      target < e[[1]], loN[[i]] = 1; loU[[i]] = target,
      target > e[[-1]], hiN[[i]] = 1; hiU[[i]] = target,
      True,
      j = Max[1, Min[n - 1, LengthWhile[e, # <= target &]]];
      alpha = (target - e[[j]])/(e[[j + 1]] - e[[j]]);
      low[[j, i]] = 1 - alpha;
      low[[j + 1, i]] = alpha
    ],
    {i, n}
  ];

  high = low;
  Do[
    target = fac e[[i]];
    If[e[[1]] <= target <= e[[-1]],
      j = Max[1, Min[n - 1, LengthWhile[e, # <= target &]]];
      If[2 <= j <= n - 2,
        stencil = {j - 1, j, j + 1, j + 2};
        ys = y[[stencil]];
        w0 = Table[
          Product[(Log[target] - ys[[k]])/(ys[[r]] - ys[[k]]),
            {k, DeleteCases[Range[4], r]}],
          {r, 4}
        ];
        c = {ConstantArray[1`70, 4], e[[stencil]]};
        rhs = {1`70, target};
        wh = w0 + Transpose[c].LinearSolve[c.Transpose[c], rhs - c.w0];
        high[[All, i]] = 0;
        high[[stencil, i]] = wh
      ]
    ],
    {i, n}
  ];

  augLow = Join[low, {loN, loU, hiN, hiU}];
  augHigh = Join[high, {loN, loU, hiN, hiU}];
  leftN = Join[ConstantArray[1`70, n], {1`70, 0`70, 1`70, 0`70}];
  leftU = Join[e, {0`70, 1`70, 0`70, 1`70}];

  <|"y" -> y, "energy" -> e, "factor" -> fac,
    "Low" -> augLow, "High" -> augHigh,
    "LeftN" -> leftN, "LeftU" -> leftU|>
];

ClearAll[ProjectPositiveTwoMoments];
ProjectPositiveTwoMoments[h_List, e_List, targetN_, targetU_, tol_: 10^-45] := Module[
  {free = Range[Length[h]], z, a, rhs, lambda, zfree, bad, kill, iterations = 0},
  While[True,
    iterations++;
    If[Length[free] < 2,
      Return[<|"Success" -> False, "State" -> ConstantArray[0, Length[h]]|>]
    ];
    a = {ConstantArray[1`70, Length[free]], e[[free]]};
    rhs = {targetN, targetU} - a.h[[free]];
    lambda = LinearSolve[a.Transpose[a], rhs];
    zfree = h[[free]] + Transpose[a].lambda;
    bad = Flatten@Position[zfree, q_ /; q < -tol];
    If[bad === {},
      z = ConstantArray[0`70, Length[h]];
      z[[free]] = Map[If[# < 0, 0, #] &, zfree];
      Return[<|"Success" -> True, "State" -> z,
        "Iterations" -> iterations,
        "NumberResidual" -> Total[z] - targetN,
        "EnergyResidual" -> e.z - targetU|>]
    ];
    kill = free[[First@Ordering[zfree, 1]]];
    free = DeleteCases[free, kill]
  ]
];

(* ------------------------------------------------------------------------- *)
(* 2. Exact constant-K Bianchi-I characteristic                              *)
(* ------------------------------------------------------------------------- *)

ClearAll[Lebedev26, TangentBasis, BianchiIGeodesicData];
Lebedev26[] := Module[{axis, edge, corner, points, weights},
  axis = Join[IdentityMatrix[3], -IdentityMatrix[3]];
  edge = DeleteDuplicates@Flatten[
    Table[ReplacePart[{0, 0, 0}, {i -> a/Sqrt[2], j -> b/Sqrt[2]}],
      {i, 1, 3}, {j, i + 1, 3}, {a, {-1, 1}}, {b, {-1, 1}}], 3];
  corner = Tuples[{-1, 1}, 3]/Sqrt[3];
  points = Join[axis, edge, corner];
  weights = Join[ConstantArray[1/21, 6],
    ConstantArray[4/105, 12], ConstantArray[9/280, 8]];
  {N[points, 70], N[weights, 70]}
];

TangentBasis[k_] := Module[{r, e1},
  r = UnitVector[3, First@Ordering[Abs[k], 1]];
  e1 = Normalize[r - (r.k) k];
  {e1, Cross[k, e1]}
];

BianchiIGeodesicData[k_, K_, dt_] := Module[
  {m, q, d, kp, jac, t1, t2, df1, df2},
  m = MatrixExp[-dt K];
  q = m.k; d = Norm[q]; kp = q/d;
  jac = Det[m]/d^3;
  {t1, t2} = TangentBasis[k];
  df1 = (IdentityMatrix[3] - Outer[Times, kp, kp]).m.t1/d;
  df2 = (IdentityMatrix[3] - Outer[Times, kp, kp]).m.t2/d;
  <|"EnergyFactor" -> d, "Direction" -> kp,
    "AngularJacobian" -> jac,
    "TangentAreaJacobian" -> Norm[Cross[df1, df2]]|>
];

ClearAll[MomentFitMovingWeights];
MomentFitMovingWeights[newPoints_, rawWeights_, oldWeights_] := Module[
  {c, target, corrected, amplitude},
  c = Transpose[{ConstantArray[1, Length[newPoints]],
    newPoints[[All, 1]], newPoints[[All, 2]], newPoints[[All, 3]],
    newPoints[[All, 1]]^2, newPoints[[All, 2]]^2,
    newPoints[[All, 1]] newPoints[[All, 2]],
    newPoints[[All, 1]] newPoints[[All, 3]],
    newPoints[[All, 2]] newPoints[[All, 3]]}];
  target = {1, 0, 0, 0, 1/3, 1/3, 0, 0, 0};
  corrected = rawWeights + c.LinearSolve[Transpose[c].c,
      target - Transpose[c].rawWeights];
  amplitude = oldWeights/corrected;
  <|"Weights" -> corrected, "Amplitude" -> amplitude,
    "MomentResidual" -> MaxAbs[Transpose[c].corrected - target]|>
];

(* ------------------------------------------------------------------------- *)
(* 3. Positive low-order characteristic remap used in the scalar IMEX gate   *)
(* ------------------------------------------------------------------------- *)

ClearAll[RemapNumberEnergy];
RemapNumberEnergy[y_, factor_, x_] := Module[
  {n = Length[y], e = Exp[y], out, loN = 0`60, loU = 0`60,
   hiN = 0`60, hiU = 0`60, target, j, alpha},
  out = ConstantArray[0`60, n];
  Do[
    target = factor e[[i]];
    Which[
      target < e[[1]], loN += x[[i]]; loU += target x[[i]],
      target > e[[-1]], hiN += x[[i]]; hiU += target x[[i]],
      True,
      j = Max[1, Min[n - 1, LengthWhile[e, # <= target &]]];
      alpha = (target - e[[j]])/(e[[j + 1]] - e[[j]]);
      out[[j]] += (1 - alpha) x[[i]];
      out[[j + 1]] += alpha x[[i]]
    ],
    {i, n}
  ];
  <|"Active" -> out, "Ledger" -> {loN, loU, hiN, hiU}|>
];

ClearAll[GeometryStep];
GeometryStep[state_, points_, weights_, y_, K_, dt_] := Module[
  {m, newPoints, factors, rawWeights, fit, amp, out, ledger, remapped},
  m = MatrixExp[-dt K];
  newPoints = Normalize /@ ((m.#) & /@ points);
  factors = Norm /@ ((m.#) & /@ points);
  rawWeights = weights Det[m]/factors^3;
  fit = MomentFitMovingWeights[newPoints, rawWeights, weights];
  amp = fit["Amplitude"];
  out = Table[
    remapped = RemapNumberEnergy[y, factors[[p]], state[[p]]];
    amp[[p]] remapped["Active"],
    {p, Length[points]}
  ];
  ledger = Sum[
    fit["Weights"][[p]] amp[[p]]
      RemapNumberEnergy[y, factors[[p]], state[[p]]]["Ledger"],
    {p, Length[points]}
  ];
  <|"State" -> out, "Points" -> newPoints,
    "Weights" -> fit["Weights"], "Ledger" -> ledger,
    "MomentResidual" -> fit["MomentResidual"]|>
];

ClearAll[ImplicitScalarThomson];
ImplicitScalarThomson[state_, weights_, lambda_] := Module[{mean},
  mean = Table[weights.state[[All, i]], {i, Length[state[[1]]]}];
  Table[mean + (state[[p]] - mean)/(1 + lambda),
    {p, Length[state]}]
];

(* ------------------------------------------------------------------------- *)
(* 4. General invariant-deflated low-rank solve                               *)
(* ------------------------------------------------------------------------- *)

ClearAll[InvariantDeflatedWoodburySolve];
InvariantDeflatedWoodburySolve[Dmat_, U_, V_, rightNull_, leftInvariant_,
   lambda_, rhs_] := Module[
  {n, r, a0, a0inv, uLambda, small, amplitudes, rhsPerp,
   g, h, y, x},
  n = Length[rhs]; r = Dimensions[V][[1]];
  a0 = IdentityMatrix[n] + lambda Dmat;
  a0inv = Inverse[a0];
  uLambda = lambda U;
  small = IdentityMatrix[r] - V.a0inv.uLambda;
  amplitudes = leftInvariant.rhs;
  rhsPerp = rhs - rightNull.amplitudes;
  g = V.a0inv.rhsPerp;
  h = -leftInvariant.a0inv.rhsPerp;
  y = LeastSquares[
    Join[small, leftInvariant.a0inv.uLambda],
    Join[g, h]
  ];
  x = rightNull.amplitudes + a0inv.rhsPerp + a0inv.uLambda.y;
  x
];

Print["Stage T2-E1/G0 definitions loaded."];
