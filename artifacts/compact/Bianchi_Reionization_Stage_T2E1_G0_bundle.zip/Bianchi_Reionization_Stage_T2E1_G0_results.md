# Bianchi Reionization — Stage T2-E1/G0 Verification Ledger

## Scope

This stage combines four previously separated blocks:

1. a nonperiodic low/high photon-number and energy escape ledger;
2. a higher-order monotone number-and-energy remap on a log-energy grid;
3. the direct six-moment Thomson production operator with exact local out-scattering and invariant-deflated implicit integration;
4. an exact constant-expansion-tensor Bianchi-I null-characteristic/Liouville step, followed by a scalar stiff IMEX coupling gate.

Conventions retained from the preceding stages:

- metric signature `(-,+,+,+)`;
- `Q+iU` carries spin `s=+2`, `Q-iU` carries spin `s=-2`;
- normal-time Thomson loss is direction dependent through `D_p = Gamma_e (1-v_e.k_p)`;
- the production collision architecture is direct six-moment in-scattering plus exact local out-scattering.

## Overall verdict

`PARTIAL PASS — architecture locked, two production gates remain open.`

Passed:

- higher-order remap accuracy, positivity, number conservation, energy conservation;
- low/high escape accounting at the remap level;
- escape-augmented invariant-deflated implicit algebra through optical-depth parameter `lambda=10^12`;
- exact constant-K Bianchi-I direction, energy, and angular-Jacobian characteristic map;
- radiation 1+3 energy equation and FLRW/Minkowski limits;
- scalar half-characteristic / implicit-collision / half-characteristic IMEX conservation and stiff positivity.

Still open:

- a physical nonzero-escape *collision* closure needs ghost spectral states carrying angular/polarization information; four scalar ledgers alone are an accounting device, not enough to collide escaped radiation;
- the G0 geometry-coupling test transported scalar intensity. Exact Bianchi-I parallel transport of the polarization screen tensor remains a separate gate.

---

## 1. Higher-order monotone number-and-energy remap

### Construction

The low-order map deposits a source spectral mass into the two target energy nodes bracketing

`E' = exp(delta) E`,

with nonnegative weights chosen to satisfy exactly

- column sum = 1;
- target energy-weighted column sum = `E'`.

The high-order candidate uses a four-node cubic Lagrange stencil in `y=log E`, followed by a minimum-norm two-constraint correction that restores exact number and energy moments. It is signed.

A single global convex blending parameter was tested and rejected: arbitrarily small negative high-order tails can force the global parameter to zero. The accepted limiter is an active-set Euclidean projection of the high-order output onto

`z_i >= 0`, `sum_i z_i = N_target`, `sum_i E_i z_i = U_target`.

The low/high escape ledgers are held fixed at their positive low-order values during this projection.

### Wolfram results

Smooth-spectrum relative L1 errors:

| N | dy | low order | signed high order | projected high order | active-set iterations |
|---:|---:|---:|---:|---:|---:|
| 32 | 0.4516129032 | 2.4484153e-2 | 2.8195692e-3 | 2.8195468e-3 | 9 |
| 64 | 0.2222222222 | 8.5113389e-3 | 2.8903353e-4 | 2.8903353e-4 | 2 |
| 128 | 0.1102362205 | 2.1367960e-3 | 1.8618883e-5 | 1.8618883e-5 | 4 |
| 256 | 0.0549019608 | 4.5015481e-4 | 9.4853365e-7 | 9.4853365e-7 | 7 |

Observed refinement orders for the projected high-order map:

- 3.2862;
- 3.9564;
- 4.2949.

Thus the limiter retained approximately fourth-order behavior on the smooth test.

Sharp-spectrum adversarial test:

- raw high-order minimum: `-1.3859408571e-4`;
- low-order minimum: `0`;
- projected minimum: `0`;
- projection iterations: `3`;
- number residual: `1.11e-16`;
- energy residual: `0`;
- relative projection correction: `6.4375457e-4`.

### Verdict

`PASS as a nonlinear high-order prototype.`

It is not yet the final production remapper: the active-set solve is global within each angular ray and should later be replaced or compared with a local flux-corrected/PPM implementation.

---

## 2. Escape-augmented invariant-deflated implicit solve

### State

The algebraic gate used:

- 14 angular directions;
- 2 active log-energy bins;
- three local coherency components `(I,Q,U)`;
- 84 active degrees of freedom;
- four scalar ledger degrees of freedom `(N_low,U_low,N_high,U_high)`;
- 12 six-moment degrees of freedom;
- a rank-16 update: `12` collision moments plus `4` ledger rows.

The finite-tilt test velocity was

`v_e = (0.31,-0.22,0.41)`, `|v_e| = 0.5591064299`.

### Ledger constraints

The augmented rows were constructed so that

`C_N^tot L_aug = 0`, `C_U^tot L_aug = 0`,

where the total rows include active spectral moments and the low/high ledgers.

Wolfram results:

- number closure residual: `0`;
- energy closure residual: `0`;
- augmented nullity: `4`;
- null biorthogonalization residual: `6.33e-18`.

### Stiff solve

| lambda | relative error vs 60-digit direct solve | null-invariant residual | absolute linear residual | minimum coherency eigenvalue |
|---:|---:|---:|---:|---:|
| 1e2 | 4.48e-15 | 2.22e-15 | 4.40e-13 | 6.0009e-4 |
| 1e6 | 1.63e-15 | 1.78e-15 | 1.80e-9 | 6.0465e-8 |
| 1e12 | 9.58e-16 | 9.99e-16 | 6.25e-4 | 6.0452e-14 |

The large unscaled residual at `lambda=1e12` comes from cancellation in an `O(10^12)` matrix evaluated at machine precision; the solution itself agrees with the high-precision direct solve at `9.6e-16`, and all deflated invariants remain at machine precision.

At `lambda=1e12`, the accumulated ledger was

`(0.6017909491, 0.1131015048, 0.6057886728, 2.6849942284)`.

### Important limitation

The implicit test proves the algebra of an augmented ledger/null system. In the nonzero-escape collision problem, four scalar ledgers do not retain the angular direction or polarization of escaped radiation. Consequently:

- they close number/energy accounting;
- they do not provide enough information to Thomson-scatter the escaped part.

Production choices are therefore:

1. choose guard bands so forward/reverse collision-frame escape is below tolerance; or
2. promote boundary reservoirs to ghost spectral states carrying the full angular coherency distribution.

### Verdict

`PASS for invariant-deflated accounting; PARTIAL for physical nonzero-escape collision closure.`

---

## 3. Exact constant-K Bianchi-I characteristic

Let

`K = H I + sigma`, `tr sigma = 0`,

and assume `K` is constant over a numerical substep. The exact physical-momentum map is

`q' = M q`, `M = exp(-Delta t K)`.

For a unit direction `k`, define

`d(k) = |M k|`, `k' = M k / d(k)`.

Then

`E' = d E`,

and the angular Jacobian is

`dOmega'/dOmega = det(M)/d^3`.

For a comoving spectral coherency density, the characteristic amplitude is

`A(k) = d^3/det(M)`.

### Wolfram geometry results

For an off-diagonal trace-free shear and `Delta t=0.37`:

- unit-direction residual: below displayed precision (`~1e-79` after high-precision rerun);
- local tangent-area Jacobian residual: below displayed precision (`~1e-75`);
- semigroup/composition residual: `2.22e-16` in the first numerical run;
- FLRW direction residual: `1.11e-16`;
- FLRW angular-Jacobian residual: `4.44e-16`;
- FLRW common energy-factor residual: `1.11e-16`.

Directional energy-factor range in the test:

`0.9601411065 <= d(k) <= 0.9795179758`.

### Moving-quadrature correction

Raw transformed Lebedev-26 weights produced a finite-cubature moment residual of order `1.40e-6`. A minimum-norm correction enforced the real `l<=2` moment conditions exactly:

- corrected angular moment residual: below `1e-75`;
- minimum corrected weight: `0.03150037777 > 0`;
- relative weight correction: `6.04e-6`;
- phase-space weight/amplitude identity residual: below `1e-75`.

### Photon number and energy

Using a positive spectral state with explicit low/high escape rows:

- comoving photon-number residual: `-4.44e-16`;
- comoving energy residual relative to the exact directional redshifted value: `0`;
- mapped minimum: `2.3248e-3`;
- nonzero low-energy escape number: `2.58098e-2`;
- low-energy escape energy: `4.58967e-4`.

### Radiation 1+3 energy equation

The discrete exact-map derivative satisfies

`dot(mu) + 4 H mu + sigma_ij pi_ij = 0`.

The high-precision algebraic residual was below `1e-79`.

### Verdict

`PASS for constant K over a substep.`

For a nonlinear time-dependent Bianchi-I background, `K(t1)` and `K(t2)` need not commute. A commutator-free Magnus or adaptive midpoint exponential is required next.

---

## 4. Scalar Bianchi-I IMEX gate

The executed split was

1. exact half-characteristic Bianchi-I step;
2. invariant-exact backward-Euler scalar Thomson isotropization;
3. exact half-characteristic Bianchi-I step.

The energy domain used 64 log bins on `[-8,8]`, with explicit low/high ledgers. The stiff parameter was

`lambda = 10^12`.

Results:

- initial-to-half photon-number residual: `8.88e-16`;
- full IMEX photon-number residual: `0`;
- half-step angular-moment-fit residual: `2.78e-16`;
- final angular-moment-fit residual: `2.22e-16`;
- minimum angular weight: `0.03144824520`;
- collision energy residual: `1.14e-13`;
- electron-rest-frame `u_e.Q_gamma` residual: `2.84e-13`;
- `Q_gamma + Q_b` residual: `0`;
- minimum final spectral state: `1.9155e-3`;
- stiff isotropization relative error: `6.45e-14`;
- accumulated ledger `(N_low,U_low,N_high,U_high)`:
  `(0.04078783575, 1.3465888e-5, 0, 0)`;
- FLRW direction residual: `1.11e-16`;
- Minkowski state residual: `7.22e-16`;
- Minkowski direction residual: `1.11e-16`.

### Scope warning

This combined G0 IMEX gate transported scalar intensity. The corrected spin convention and direct six-moment polarized Thomson operator were retained from T2-D2/T2-E0, but exact collisionless parallel transport of the polarization screen through Bianchi-I geometry was not implemented in this combined step.

### Verdict

`PASS as a scalar stiff-stability/conservation gate.`

It is not yet a complete polarized Bianchi-I IMEX solver.

---

## 5. Architecture locked by this stage

### Explicit/semi-Lagrangian geometry block

- exact characteristic matrix exponential for constant `K`;
- moving angular nodes;
- positive moment-fitted angular weights;
- high-order signed spectral remap followed by two-moment active-set positivity projection;
- explicit low/high number-energy ledger.

### Implicit collision block

- corrected spin convention;
- direct six-moment in-scattering;
- exact local out-scattering;
- PSD moment projection as a fail-safe only;
- generalized invariant-deflated Woodbury/QR solve.

### Required production safeguards

- guard-band tolerance for collision-frame escape;
- ghost-state promotion if escape is not negligible;
- cone limiter for full coherency states;
- time-ordered exponential for evolving `K(t)`;
- exact polarization-screen transport in the Liouville block.

---

## 6. Recommended next stage

`Stage G1/P0`:

1. replace constant-K steps by a commutator-free fourth-order Magnus propagator and verify noncommuting time-dependent shear;
2. derive and implement exact Bianchi-I screen-tensor/Jones-vector parallel transport;
3. couple the polarized Liouville map to the direct six-moment implicit collision operator;
4. promote low/high ledgers to optional ghost coherency bins and verify full four-momentum accounting when escape is non-negligible;
5. compare first-order active-set remap fallback, fourth-order projected remap, and a local PPM/FCT implementation;
6. close global temporal convergence with an L-stable second-order IMEX scheme.
