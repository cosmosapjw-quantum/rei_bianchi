"""
Bianchi reionization R0-C/R1-A trajectory auditor.

This script documents the Python-backed multi-ray validation used in the
stage result. It is intentionally separated from the Wolfram chemistry and
moment derivations. The durable JSON file contains the executed numerical
outputs.

Conventions
-----------
metric (-,+,+,+), epsilon_123=+1
Q+iU <-> spin +2
"""

from __future__ import annotations

import numpy as np
from scipy.integrate import solve_ivp

EPS = np.zeros((3, 3, 3))
EPS[0, 1, 2] = EPS[1, 2, 0] = EPS[2, 0, 1] = 1.0
EPS[1, 0, 2] = EPS[2, 1, 0] = EPS[0, 2, 1] = -1.0


def background(kind: str, t: float):
    H = 0.08 + 0.015 * np.sin(2 * np.pi * t)
    s11 = 0.05 * np.cos(1.1 * t)
    s22 = -0.03 * np.cos(0.9 * t)
    s33 = -s11 - s22
    sigma = np.array([
        [s11, 0.018*np.sin(1.3*t), 0.012*np.cos(0.7*t)],
        [0.018*np.sin(1.3*t), s22, 0.015*np.sin(0.8*t)],
        [0.012*np.cos(0.7*t), 0.015*np.sin(0.8*t), s33],
    ])
    a = np.zeros(3)
    n = np.zeros((3, 3))
    if kind == "V":
        a[0] = 0.04 * (1 + 0.2*np.sin(1.5*t))
    elif kind == "II":
        n[0, 0] = 0.06 * (1 + 0.15*np.cos(1.2*t))
    return H, sigma, a, n


def direction_rhs(k, sigma, a, n):
    return -sigma @ k + (k @ sigma @ k)*k + np.cross(n @ k, k) - a + (a @ k)*k


def energy_log_rhs(k, H, sigma):
    return -H - k @ sigma @ k


def spatial_connection_contraction(k, a, n):
    A = np.zeros((3, 3))
    for ell in range(3):
        for b in range(3):
            for i in range(3):
                gamma = 0.0
                for d in range(3):
                    gamma += 0.5 * (
                        EPS[i, b, d] * n[d, ell]
                        - EPS[b, ell, d] * n[d, i]
                        + EPS[ell, i, d] * n[d, b]
                    )
                gamma += -a[b] * (i == ell) + a[ell] * (i == b)
                A[ell, b] += k[i] * gamma
    return A


def rhs(kind, t, y):
    k = y[:3]
    S = y[3:9].reshape(3, 2)
    H, sigma, a, n = background(kind, t)
    kd = direction_rhs(k, sigma, a, n)
    A = spatial_connection_contraction(k, a, n)
    Sd = -A @ S
    for q in range(2):
        Sd[:, q] += k * (k @ A @ S[:, q] - kd @ S[:, q])
    return np.concatenate([kd, Sd.ravel(), [energy_log_rhs(k, H, sigma)]])


def reference_basis(k):
    axis = np.eye(3)[np.argmin(np.abs(k))]
    e1 = np.cross(axis, k)
    e1 /= np.linalg.norm(e1)
    return np.column_stack([e1, np.cross(k, e1)])


def integrate_ray(kind, k0):
    k0 = np.asarray(k0, dtype=float)
    k0 /= np.linalg.norm(k0)
    S0 = reference_basis(k0)
    y0 = np.concatenate([k0, S0.ravel(), [0.0]])
    sol = solve_ivp(
        lambda t, y: rhs(kind, t, y),
        (0.0, 1.0),
        y0,
        rtol=1e-11,
        atol=1e-13,
        method="DOP853",
    )
    return sol.y[:, -1]


if __name__ == "__main__":
    k0 = np.array([1.0, 0.3, 0.2])
    for kind in ("I", "V", "II"):
        y = integrate_ray(kind, k0)
        print(kind, y[:3], np.exp(y[-1]))
