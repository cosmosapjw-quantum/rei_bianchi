# Stage R0-C/R1-A source lock

## Primary literature

- Mellema, Iliev, Alvarez & Shapiro, C2-Ray:
  arXiv:astro-ph/0508416.
  Photon conservation and analytical ionization relaxation.

- Friedrich, Mellema, Iliev & Shapiro:
  arXiv:1201.0602; MNRAS 421 (2012) 2232.
  Full coupled H/He on-the-spot treatment, multifrequency ionization and
  heating, secondary ionization, and timestep tests.

- Verner, Ferland, Korista & Yakovlev:
  arXiv:astro-ph/9601009; ApJ 465 (1996) 487.
  Ground-state photoionization cross-section fits and parameter tables.

- Choudhury & Chakraborty:
  arXiv:2504.03384.
  SCRIPT sink closure linking emissivity, clumping, mean free path,
  photoionization rate and density.

- Cain & D'Aloisio:
  arXiv:2409.04521.
  FlexRT and flexible/generalized opacity treatment.

- Chardin, Kulkarni & Haehnelt:
  arXiv:1707.06993.
  Self-shielding during reionization and density-dependent ionization.

- Stebbins:
  arXiv:astro-ph/0703541.
  Lorentz-invariant central temperature moments for nonperturbative
  intensity and polarization spectral distortions.

- Dahmen, Gruber & Mula:
  arXiv:1810.07035.
  Certified adaptive source iteration and a-posteriori transport errors.

## Durable auditor

Bianchi_Reionization_Stage_G1_P1_bundle.zip
SHA-256:
662c57fcde5ff59dcf9088cc9692837c827ab742d3afcc14623f3f0ffc45709e

## Calibration firewall

The following are physically generated validation fixtures, not copied
published calibration tables:

1. The Verner heating table uses N_E proportional to E^-1.5 and the
   explicitly recorded H I / He I / He II column fixture.
2. The sink table uses a lognormal conditional density PDF, the
   self-shielding scaling, and an explicitly recorded mean-free-path
   normalization and cap.
3. The full-OTS rate fixture uses representative positive rate
   coefficients to verify the channel algebra, Picard iteration,
   positivity and conservation.

They must not be interpreted as cosmological best-fit predictions.
