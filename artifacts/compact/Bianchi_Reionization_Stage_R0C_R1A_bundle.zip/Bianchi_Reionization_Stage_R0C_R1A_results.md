# Bianchi Reionization — Stage R0-C/R1-A

## Verdict

\[
\boxed{\text{Stage R0-C/R1-A}=\text{CONDITIONAL PASS}}
\]

Four pieces have passed independently:

1. conservative full-OTS H/He channel algebra and a homogeneous
   baryon-proper-time matrix-relaxation interface;
2. source-spectrum-specific Verner multifrequency ionization/heating tables;
3. a physics-generated tabulated SCRIPT/FlexRT sink interface;
4. Stebbins central moments, corrected spin transformation, and adaptive
   scattering-order audits on time-dependent Bianchi I/V/II kinematic
   trajectories.

Two qualifications remain:

- the OTS rates and sink conditional-density model still require physical
  calibration;
- the full-frequency auditor and the time-dependent I/V/II trajectory
  audit have not yet been executed as one monolithic joint calculation.
  The trajectory audit is grey T/E/B/four-force, while the exact spectral
  comparison is a separate Stebbins-mixture benchmark.

## 1. Full coupled OTS channel system

State ordering:

\[
X=(x_{\rm HI},x_{\rm HII},x_{\rm HeI},x_{\rm HeII},x_{\rm HeIII})^T.
\]

The Friedrich constants used by the OTS channel algebra are

\[
p=0.96,\qquad l=1.425,\qquad m=0.737,
\]

\[
w=(l-m)+my,
\]

\[
A_H=vw+(1-v)fz,
\]

\[
A_{\rm HeI}=vm(1-y)+(1-v)f(1-z).
\]

The event vectors are

\[
\nu_{\rm HII,B}=(1,-1,0,0,0),
\]

\[
\nu_{\rm HeII,1}=(-y,y,y,-y,0),
\]

\[
\nu_{\rm HeII,exc}=(-p,p,1,-1,0),
\]

\[
\nu_{\rm HeIII,1}
=(-(1-y_{2a}-y_{2b}),1-y_{2a}-y_{2b},
-y_{2b},1+y_{2b}-y_{2a},-1+y_{2a}),
\]

\[
\nu_{\rm HeIII,n2}=(-1,1,0,1,-1),
\]

\[
\nu_{\rm HeIII,cas}
=(-A_H,A_H,-A_{\rm HeI},1+A_{\rm HeI},-1).
\]

For every channel,

\[
(1,1,0,0,0)\cdot\nu_r=0,
\]

\[
(0,0,1,1,1)\cdot\nu_r=0
\]

was reduced to zero by Wolfram.

The ground-state opacity fractions are computed from local proper
densities and photoionization cross sections at the relevant recombination
photon energies. The functions \(v(T)\) and \(f(x_{\rm HI})\) remain
tabulated interfaces.

A representative Picard/matrix-exponential fixture retained positive
populations and H/He normalization to \(10^{-16}\). At dimensionless
\(\Delta t=0.2\), the full-OTS and U-OTS final states differed by

\[
3.06\times10^{-4}
\]

in relative norm. This is an algorithmic validation fixture, not a
cosmological prediction.

## 2. Multifrequency ionization and heating tables

For group \(g\), species \(s\), source photon-number spectrum
\(\dot N_E\), and total optical depth \(\tau_E\),

\[
{\cal I}_{sg}(\tau)
=
\int_{E_g^-}^{E_g^+}
dE\,\dot N_E
[1-e^{-\tau_E}]
\frac{n_s\sigma_s(E)}
{\sum_r n_r\sigma_r(E)},
\]

\[
{\cal H}_{sg}(\tau)
=
\int_{E_g^-}^{E_g^+}
dE\,\dot N_E
[1-e^{-\tau_E}]
\frac{n_s\sigma_s(E)}
{\sum_r n_r\sigma_r(E)}
(E-E_{{\rm th},s}).
\]

The table uses the Verner fits, the explicitly recorded spectrum
\(\dot N_E\propto E^{-1.5}\), three ionization-threshold groups, and ten
optical-depth nodes.

Threshold cross sections reproduced by the implementation were

\[
\sigma_{\rm HI}(13.6{\rm eV})
=6.3463\times10^{-18}{\rm cm^2},
\]

\[
\sigma_{\rm HeI}(24.59{\rm eV})
=7.4347\times10^{-18}{\rm cm^2},
\]

\[
\sigma_{\rm HeII}(54.42{\rm eV})
=1.5873\times10^{-18}{\rm cm^2}.
\]

All ionization and heating entries were nonnegative. The largest energy
ledger residual was

\[
1.78\times10^{-15}.
\]

## 3. Tabulated sink interface

The tabulation axes are

\[
z=(5,6,7,8,10),
\]

\[
\Delta_{\rm cell}=(0.3,1,3,10),
\]

\[
T=(5000,10000,20000){\rm K},
\]

\[
\Gamma_{\rm HI}=(10^{-14},10^{-13},10^{-12}){\rm s^{-1}}.
\]

A lognormal conditional density PDF and self-shielding threshold generate

\[
C_{\rm eff}
=\frac{M_2M_0}{M_1^2},
\]

a neutral volume fraction, and

\[
\lambda_{\rm mfp}
=\lambda_0 f_{\rm neutral}^{-2/3}.
\]

Log-space multilinear interpolation had node residual

\[
3.55\times10^{-14}.
\]

The validation table ranges were

\[
C_{\rm eff}\ge1.1033,
\]

\[
0.0463\le\lambda_{\rm mfp}/{\rm pMpc}\le60,
\]

\[
0.0167\le\kappa/{\rm pMpc^{-1}}\le21.59.
\]

The fixed-point relation between emissivity, mean free path and
photoionization rate converged to

\[
\Gamma_{\rm HI}=1.8\times10^{-13}{\rm s^{-1}}
\]

with logarithmic residual

\[
5.36\times10^{-13}.
\]

The conditional PDF and mean-free-path normalization remain calibration
parameters.

## 4. Stebbins central moments

Let \(x_m\) be raw log-temperature moments, \(x_0=1\), and define

\[
u_p=\sum_{m=0}^p {p\choose m}(-x_1)^{p-m}x_m.
\]

Wolfram verified:

\[
u_2=x_2-x_1^2,
\]

\[
u_3=x_3-3x_1x_2+2x_1^3,
\]

\[
u_4=x_4-4x_1x_3+6x_1^2x_2-3x_1^4.
\]

All \(u_{p\ge2}\) were invariant under a common log-temperature shift.
For raw collision moments \(c_m\),

\[
\boxed{
\dot u_p=c_p^{\rm central}-p\,u_{p-1}c_1
}
\]

was verified for \(p=2,\ldots,7\). All explicit geometry/redshift
translation terms cancel. This is the triangular closure that makes the
moment hierarchy useful in large-shear backgrounds.

For the test blackbody mixture,

\[
u_2=0.01590634,
\qquad
y=\frac{u_2}{2}=0.00795317.
\]

Truncation at \(M=4\) gave relative errors

\[
7.91\times10^{-8}
\]

for intensity and

\[
2.05\times10^{-6}
\]

for polarization. At \(M=6\) these became

\[
1.13\times10^{-9},
\qquad
7.19\times10^{-9}.
\]

For the corrected convention

\[
P_+=Q+iU,\qquad s=+2,
\]

the rotation test

\[
P_+'\!=e^{2i\psi}P_+
\]

had residual

\[
1.39\times10^{-17}.
\]

## 5. Time-dependent Bianchi I/V/II trajectories

A common time-dependent \(H(t)\) and full off-diagonal \(\sigma(t)\) were
used. The vertical slices were

\[
{\rm I}: a_B=0,\ n_B=0,
\]

\[
{\rm V}: a_B\ne0,\ n_B=0,
\]

\[
{\rm II}: a_B=0,\ n_{11}\ne0.
\]

Bianchi I retains the linear momentum structure underlying the CF4
characteristic. The \(a_B,n_B\) direction terms in V and II are nonlinear,
so they were integrated with the exact tetrad direction/screen ODE rather
than represented as a pure \(3\times3\) CF4 momentum exponential.

Representative Wolfram rays had

\[
|k^2-1|\lesssim1.3\times10^{-16},
\]

\[
\|S^TS-I\|\lesssim4.8\times10^{-17},
\]

\[
\|k^TS\|\lesssim1.2\times10^{-17}.
\]

A Python multi-ray auditor then combined these trajectories with
time-dependent tilt, positive Thomson scattering and adaptive
scattering-order recursion at total optical depth \(\tau=0.06\).

At order \(N=2\), all three type slices had state, T/E/B and four-force
relative errors below \(10^{-4}\). Representative values were

\[
\epsilon_{\rm state}\simeq3.53\times10^{-5},
\]

\[
\epsilon_T\simeq5.2\times10^{-5},
\]

\[
\epsilon_E\simeq(0.5-0.9)\times10^{-5},
\]

\[
\epsilon_B\simeq(1.25-1.51)\times10^{-5},
\]

\[
\epsilon_Q\simeq1.43\times10^{-5}.
\]

The next-term a-posteriori ratios at \(N=2\) were approximately

\[
3.48\times10^{-5}
\]

for the state and

\[
1.42\times10^{-5}
\]

for the four-force.

This does not justify a universal fixed \(N=2\). The earlier random
static R0-B auditor required \(N=4\) for a \(10^{-4}\) four-force target.
The production rule remains adaptive per protected observable.

## 6. Final status

Passed:

- full-OTS stoichiometric conservation;
- positive Picard/matrix relaxation;
- Verner multifrequency heating ledger;
- tabulated self-shielding/sink interface;
- exact Stebbins central-moment algebra;
- corrected spin convention;
- time-dependent I/V/II grey T/E/B/four-force source iteration.

Open:

1. calibrating OTS rate tables and sink PDF/MFP normalization;
2. one monolithic time-dependent full-frequency G1/P1 vs Stebbins moment
   comparison;
3. self-consistent Einstein backgrounds rather than kinematic vertical
   slices;
4. all eleven Bianchi types.
