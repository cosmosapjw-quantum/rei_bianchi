(* ::Package:: *)

(*
  Bianchi Reionization Stage R0-C/R1-A
  Conventions:
    metric (-,+,+,+), epsilon_123=+1
    Q+iU <-> spin +2, Q-iU <-> spin -2
*)

ClearAll["Global`*"];

(* ---------------- Full OTS stoichiometric channels ---------------- *)

pOTS = 24/25;
lOTS = 57/40;
mOTS = 737/1000;

FullOTSChannels[y_, z_, y2a_, y2b_, v_, f_] := Module[
  {w, aH, aHeI},
  w = (lOTS - mOTS) + mOTS y;
  aH = v w + (1-v) f z;
  aHeI = v mOTS (1-y) + (1-v) f (1-z);
  <|
    "HII_caseB"     -> {1,-1,0,0,0},
    "HeII_ground"   -> {-y,y,y,-y,0},
    "HeII_excited"  -> {-pOTS,pOTS,1,-1,0},
    "HeIII_ground"  -> {-(1-y2a-y2b),1-y2a-y2b,-y2b,1+y2b-y2a,-1+y2a},
    "HeIII_n2"      -> {-1,1,0,1,-1},
    "HeIII_cascade" -> {-aH,aH,-aHeI,1+aHeI,-1}
  |>
];

NuclearConservation[channel_] := {
  {1,1,0,0,0}.channel,
  {0,0,1,1,1}.channel
};

(* ---------------- Exact frozen-rate step and time average ------------ *)

ExactStepAverage[A_?MatrixQ, z0_?VectorQ, dt_] := Module[
  {n, aug, result},
  n = Length[z0];
  aug = ArrayFlatten[{
    {A, ConstantArray[0,{n,n}]},
    {IdentityMatrix[n], ConstantArray[0,{n,n}]}
  }];
  result = MatrixExp[dt aug].Join[z0,ConstantArray[0,n]];
  {result[[1;;n]], result[[n+1;;2n]]/dt}
];

(* ---------------- Verner cross sections ------------------------------ *)

VernerParameters = <|
 "HI"   -> {13.60, 0.4298, 5.475*^4, 32.88, 2.963, 0., 0., 0.},
 "HeI"  -> {24.59, 13.61, 949.2, 1.469, 3.188, 2.039, 0.4434, 2.136},
 "HeII" -> {54.42, 1.720, 1.369*^4, 32.88, 2.963, 0., 0., 0.}
|>;

VernerSigma[name_, energy_?NumericQ] := Module[
  {q, eth, e0, sigma0, ya, pp, yw, y0, y1, x, yy},
  q = VernerParameters[name];
  {eth,e0,sigma0,ya,pp,yw,y0,y1}=q;
  If[energy < eth, 0.,
    x = energy/e0-y0;
    yy = Sqrt[x^2+y1^2];
    10^-18 sigma0 ((x-1)^2+yw^2)
      yy^(pp/2-11/2)/(1+Sqrt[yy/ya])^pp
  ]
];

(* Ionization/heating integrals:
   I_sg = Integral N_E [1-exp(-tau_E)] kappa_s/kappa_tot dE
   H_sg = Integral ... (E-E_th,s) dE
*)

(* ---------------- Stebbins central moments --------------------------- *)

RawToCentral[raw_List, p_Integer] :=
  Expand @ Sum[
    Binomial[p,m] (-raw[[2]])^(p-m) raw[[m+1]],
    {m,0,p}
  ];

CentralCollision[coll_List, raw1_, p_Integer] :=
  Expand @ Sum[
    Binomial[p,m] (-raw1)^(p-m) coll[[m+1]],
    {m,0,p}
  ];

(* Exact triangular law:
   du_p/deta = c_p^central - p u_(p-1) c_1
   Geometry/log-temperature translations cancel from all u_p, p>=2.
*)

(* Corrected spin convention:
   Pplus = Q+iU has spin +2 and transforms as exp(+2 i psi) Pplus.
*)

(* ---------------- Exact tetrad direction equation ------------------- *)

BianchiDirectionRHS[k_, sigma_, aB_, nB_] :=
  -sigma.k + (k.sigma.k) k + Cross[nB.k,k] - aB + (aB.k) k;

BianchiEnergyLogRHS[k_, H_, sigma_] :=
  -H - k.sigma.k;

Print["R0-C/R1-A definitions loaded."];
