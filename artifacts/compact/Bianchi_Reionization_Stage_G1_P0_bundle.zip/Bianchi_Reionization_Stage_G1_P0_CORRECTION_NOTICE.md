# Stage G1/P0 correction notice

This stage supersedes one architectural assumption from the preceding
T2-E1/G0 plan.

## Superseded assumption

A standard L-stable second-order SSP2(2,2,2) IMEX collision update was
expected to provide the production stiff solver after adding a coherency
cone repair.

## Corrected result

The scheme is second order and L-stable, but it is not coherency-cone
preserving. On the Lebedev-14 polarized Thomson operator, fully polarized
impulses first fail near

\[
\lambda\Delta t=3.116636869,
\]

and the worst eigenvalue at \(\lambda\Delta t=4+3\sqrt2\) is
\(-0.14792269\). The required PSD repair can be order-unity and therefore
cannot be treated as a harmless numerical limiter.

## New production default

Use a second-order CF4–exponential Strang composition:

\[
G_{h/2}^{\rm CF4}
\exp(hL_{\rm Thomson})
G_{h/2}^{\rm CF4}.
\]

Backward Euler remains a cone-positive first-order fallback and
invariant-deflated diagnostic solver. SSP2(2,2,2) remains usable only
under a verified cone-CFL restriction or as a comparison implementation.
