# Bianchi Reionization — Stage G1/P0

## Verdict

\[
\boxed{\text{G1/P0}=\text{PARTIAL PASS WITH PRODUCTION REVISION}}
\]

The requested SSP2(2,2,2) L-stable second-order IMEX pair is genuinely
second order and L-stable, but it is **not** an invariant-domain method for
the polarized Thomson coherency cone. The production recommendation is
therefore revised to

\[
\boxed{
\text{CF4 Bianchi-I geometry}
+\text{exact screen/Jones transport}
+\text{full coherency ghost cells}
+\text{exact/exponential Thomson collision in a Strang composition}
}.
\]

## 1. Noncommuting time-dependent Bianchi-I characteristic

For

\[
\dot{\boldsymbol q}=-cK(t)\boldsymbol q,\qquad K=HI+\sigma,
\]

the accepted fourth-order commutator-free Magnus step is

\[
M_{\rm CF4}
=
e^{-ch(a_1K_1+a_2K_2)}
e^{-ch(a_2K_1+a_1K_2)},
\]

\[
c_{1,2}=\frac12\mp\frac{\sqrt3}{6},\qquad
a_{1,2}=\frac{3\mp2\sqrt3}{12}.
\]

The displayed product order matters. Reversing the two exponentials gave
only second-order convergence in the executed noncommuting test.

Observed CF4 orders:

```text
4.0148403, 4.0036800, 4.0009182, 4.0002294, 4.0000573
```

The RK4 reference self-check was \(2.30\times10^{-22}\).

For constant \(K\), the characteristic was exact to \(2.49\times10^{-16}\).

## 2. Exact screen/Jones equation

With

\[
\dot k=-c(I-kk^{\mathsf T})Kk,
\]

define

\[
\Omega=\dot k\,k^{\mathsf T}-k\,\dot k^{\mathsf T}.
\]

Then

\[
\dot S=\Omega S
\]

is the exact screen-parallel transport equation. For every screen vector
\(s\),

\[
\dot s=c(s^{\mathsf T}Kk)k.
\]

Wolfram reduced all of the following to zero:

\[
\Omega^{\mathsf T}+\Omega,\quad
\Omega k-\dot k,\quad
\Omega s-(s^{\mathsf T}Kk)k,
\]

\[
\frac{d}{dt}(k^2),\quad
\frac{d}{dt}(s^2),\quad
\frac{d}{dt}(s\cdot k).
\]

The CF4 Lie step for the screen showed fourth-order convergence:

```text
4.0114412, 4.0001202, 3.9986949, 3.9990094
```

Jones/coherency eigenvalues and trace were preserved to
\(2.22\times10^{-16}\).

A projector/polar retraction

\[
\widetilde S=(I-kk^{\mathsf T})S_{\rm raw},\qquad
S=\widetilde S(\widetilde S^{\mathsf T}\widetilde S)^{-1/2}
\]

restored orthonormality, transversality and orientation to
\(7.0\times10^{-16}\), \(7.9\times10^{-17}\), and
\(2.2\times10^{-16}\), respectively.

## 3. Low/high ghost coherency cells

Full \(2\times2\) coherency matrices were stored in three low and three
high ghost cells around eight active log-energy cells. A nonnegative
two-moment deposition remap preserved

\[
\sum_i J_i,\qquad \sum_iE_iJ_i
\]

and therefore photon number, spectral energy and the PSD cone.

Executed residuals:

```text
forward number  = 0
forward energy  = 0
backward number = 0
backward energy = 0
minimum remap coefficient = 0
```

The low-order forward/backward state error was \(0.3586\), so this is a
safe baseline rather than the production high-order remap.

## 4. L-stable SSP2(2,2,2) IMEX

The implicit tableau uses

\[
\gamma=1-\frac1{\sqrt2},\qquad
A_I=
\begin{pmatrix}
\gamma&0\\
1-2\gamma&\gamma
\end{pmatrix},
\qquad
b_I=\left(\frac12,\frac12\right).
\]

Its stability function is

\[
R_I(z)
=
\frac{4(1-z+\sqrt2 z)}
{(2-2z+\sqrt2 z)^2},
\qquad
\lim_{z\to-\infty}R_I(z)=0.
\]

The noncommuting CF4–IMEX composition converged at order two:

```text
2.0179246, 2.0091897, 2.0046539, 2.0023421, 2.0011749
```

### Cone failure

The minimum of \(R_I(-x)\) is

\[
-\frac{\sqrt2-1}{2}
\]

at

\[
x=4+3\sqrt2=8.242640687\ldots.
\]

On the Lebedev-14 polarized Thomson operator:

\[
\operatorname{rank}L=41,\qquad \dim\ker L=1.
\]

A scan of all 14 directions and 16 polarization angles found

\[
\lambda\Delta t_{\rm cone}
\simeq3.116636869.
\]

At \(4+3\sqrt2\), all 224 fully polarized impulses violated the coherency
cone; the worst eigenvalue was

\[
-0.1479226939.
\]

A conservative PSD repair closed photon energy and stress-energy exchange,
but required a \(56.0\%\) relative correction in the worst case. It is
therefore a fail-safe, not a production integrator.

## 5. Exponential collision replacement

For the same Lebedev-14 Thomson generator, both

\[
e^{\lambda L}
\]

and backward Euler remained cone-positive in the impulse scan. The exact
exponential had worst local coherency eigenvalues

```text
lambda=1        0.00331170
lambda=3        0.01468412
lambda=4        0.01925240
lambda=8.24264  0.02932047
lambda=10       0.03096317
lambda=100      0.03333333
```

The CF4–exponential Strang composition was second order:

```text
1.9963446, 1.9990827, 1.9997705, 1.9999426, 1.9999857
```

and reached the stiff equilibrium projector with zero displayed residual.

For a nontrivial polarized impulse at \(\lambda=4+3\sqrt2\):

\[
\Delta N_\gamma=0,\qquad
u_e\cdot Q_\gamma=1.90\times10^{-19},
\qquad
Q_\gamma+Q_b=0.
\]

## 6. Required production revision

The production path should be

\[
\boxed{
G_{h/2}^{\rm CF4}
\exp(hL_{\rm Thomson})
G_{h/2}^{\rm CF4}
}
\]

rather than the standard SSP2 IMEX collision update.

The remaining problem is computational, not conceptual: apply the
finite-tilt, energy-coupled operator exponential without forming the full
matrix. The next stage should implement an invariant-preserving low-rank
Krylov/Leja or six-moment exponential action.

## Open gates

1. Matrix-valued high-order PSD-preserving remap on active and ghost cells.
2. Efficient exponential action for the finite-tilt energy-coupled
   direct-six-moment operator.
3. Monolithic convergence after screen retraction at every CF4 substep.
4. Full high-resolution angular convergence with time-dependent Bianchi-I
   polarization.
