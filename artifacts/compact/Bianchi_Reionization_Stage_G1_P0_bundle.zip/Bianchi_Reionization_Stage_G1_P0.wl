(* ::Package:: *)

(*
  Bianchi Reionization Stage G1/P0
  Conventions:
    metric signature (-,+,+,+)
    epsilon_123 = +1
    Q + i U <-> spin s=+2
    Q - i U <-> spin s=-2

  This file consolidates the Wolfram blocks individually executed during
  Stage G1/P0. The production recommendation at the end is:
    CF4 Bianchi-I characteristic
    + exact screen/Jones parallel transport
    + full coherency ghost cells
    + exact/exponential Thomson collision in a second-order Strang composition.

  The formally L-stable SSP2(2,2,2) IMEX pair is retained as a diagnostic
  moderate-stiffness integrator only, because it fails the coherency-cone gate.
*)

ClearAll["Global`*"];

(* ---------- G1-A: fourth-order commutator-free Magnus characteristic ---------- *)

$WorkingPrecision = 50;

c1 = 1/2 - Sqrt[3]/6;
c2 = 1/2 + Sqrt[3]/6;
a1 = (3 - 2 Sqrt[3])/12;
a2 = (3 + 2 Sqrt[3])/12;

CF4Characteristic[K_, t0_, h_, c_:1] := Module[
  {K1, K2, B1, B2},
  K1 = K[t0 + c1 h];
  K2 = K[t0 + c2 h];
  B1 = -c h (a1 K1 + a2 K2);
  B2 = -c h (a2 K1 + a1 K2);
  (* This ordering is fourth order. Reversing it gave only second order. *)
  MatrixExp[B1].MatrixExp[B2]
];

(* q' = M q, E' = |M k| E, k' = M k / |M k| *)
CharacteristicData[M_, k_] := Module[{d, kp, jac, amp},
  d = Norm[M.k];
  kp = (M.k)/d;
  jac = Det[M]/d^3;
  amp = d^3/Det[M];
  <|"Direction" -> kp, "EnergyFactor" -> d,
    "AngularJacobian" -> jac, "ComovingAmplitude" -> amp|>
];

(* ---------- P0-A: exact screen/Jones differential transport ---------- *)

KDirectionDot[K_, k_, c_:1] :=
  -c (IdentityMatrix[3] - Outer[Times, k, k]).K.k;

ScreenGenerator[K_, k_, c_:1] := Module[{kd},
  kd = KDirectionDot[K, k, c];
  Outer[Times, kd, k] - Outer[Times, k, kd]
];

(*
  Exact equations:
    dk/dt = -(I-k k^T) c K k
    dS/dt = Omega S
    Omega = kdot k^T - k kdot^T
  For each screen vector s:
    ds/dt = c (s.K.k) k
*)

ScreenRetraction[q_, Sraw_] := Module[{k, P, T, G, R},
  k = Normalize[q];
  P = IdentityMatrix[3] - Outer[Times, k, k];
  T = P.Sraw;
  G = Transpose[T].T;
  R = T.MatrixPower[G, -1/2];
  If[Det[Transpose[{R[[All, 1]], R[[All, 2]], k}]] < 0,
    R[[All, 2]] = -R[[All, 2]]
  ];
  R
];

CF4ScreenStep[K_, t0_, h_, q_, S_, c_:1] := Module[
  {M1, M2, q1, q2, Om1, Om2, Mend, Rend, qend, Sraw},
  M1 = CF4Characteristic[K, t0, c1 h, c];
  M2 = CF4Characteristic[K, t0, c2 h, c];
  q1 = M1.q;
  q2 = M2.q;
  Om1 = ScreenGenerator[K[t0 + c1 h], Normalize[q1], c];
  Om2 = ScreenGenerator[K[t0 + c2 h], Normalize[q2], c];
  Mend = CF4Characteristic[K, t0, h, c];
  Rend =
    MatrixExp[h (a1 Om1 + a2 Om2)].
    MatrixExp[h (a2 Om1 + a1 Om2)];
  qend = Mend.q;
  Sraw = Rend.S;
  {qend, ScreenRetraction[qend, Sraw]}
];

(* Jones/coherency components are constant in the transported screen basis. *)
SpatialCoherency[S_, J_] := S.J.ConjugateTranspose[S];

(* ---------- G1-B: full coherency ghost-energy cells ---------- *)

PositiveNumberEnergyRemap[energy_List, factor_?NumericQ] := Module[
  {n = Length[energy], R, target, j, alpha},
  R = ConstantArray[0, {n, n}];
  Do[
    target = factor energy[[i]];
    Which[
      target <= First[energy],
        R[[1, i]] = 1,
      target >= Last[energy],
        R[[-1, i]] = 1,
      True,
        j = Max[1, Min[n - 1, LengthWhile[energy, # < target &]]];
        alpha = (target - energy[[j]])/(energy[[j + 1]] - energy[[j]]);
        R[[j, i]] = 1 - alpha;
        R[[j + 1, i]] = alpha
    ],
    {i, 1, n}
  ];
  R
];

ApplyMatrixRemap[R_, state_] := Module[
  {nAngle = Length[state], nE = Dimensions[state][[2]]},
  Table[
    Sum[R[[j, i]] state[[p, i]], {i, 1, nE}],
    {p, 1, nAngle}, {j, 1, nE}
  ]
];

(*
  Ghost-cell rule:
    store full 2x2 coherency per angle and energy cell;
    choose Nghost so no physical shift reaches the outer boundary;
    if an outer ghost occupancy exceeds tolerance, expand/fail closed.
*)

(* ---------- G1-C: formally L-stable SSP2(2,2,2) IMEX diagnostic ---------- *)

gamma = 1 - 1/Sqrt[2];

SSP2IMEXStep[y_, h_, A_, B_] := Module[{id, y1, y2},
  id = IdentityMatrix[Length[y]];
  y1 = LinearSolve[id - h gamma B, y];
  y2 = LinearSolve[
    id - h gamma B,
    y + h A.y1 + h (1 - 2 gamma) B.y1
  ];
  y + h/2 (A.y1 + A.y2 + B.y1 + B.y2)
];

SSP2ImplicitStability[z_] :=
  4 (1 - z + Sqrt[2] z)/(2 - 2 z + Sqrt[2] z)^2;

(*
  L-stable: Limit[SSP2ImplicitStability[z], z -> -Infinity] == 0.
  But it is not coherency-cone preserving.
  Lebedev-14 fully polarized impulse scan gave a cone CFL of
      lambda Delta t <= 3.1166368689...
  and at lambda Delta t = 4 + 3 Sqrt[2] the worst eigenvalue was -0.14792269.
*)

(* ---------- G1-D: production replacement ---------- *)

(*
  Use the exact/exponential collision map at fixed medium:
      C_h = MatrixExp[h L_Thomson]
  in a second-order composition
      G_{h/2}^{CF4} C_h G_{h/2}^{CF4}.
  This passed second-order convergence, cone positivity, photon-number
  conservation, u_e.Q_gamma=0 and Q_gamma+Q_b=0 in the executed gates.

  For the full finite-tilt energy-coupled operator, MatrixExp must be replaced
  by an invariant-preserving low-rank exponential action (Krylov/Leja or a
  dedicated six-moment exponential reduction).
*)

CF4ExponentialStrangStep[Ghalf1_, collisionExp_, Ghalf2_, state_] :=
  Ghalf2.collisionExp.Ghalf1.state;

Print["Stage G1/P0 consolidated definitions loaded."];
