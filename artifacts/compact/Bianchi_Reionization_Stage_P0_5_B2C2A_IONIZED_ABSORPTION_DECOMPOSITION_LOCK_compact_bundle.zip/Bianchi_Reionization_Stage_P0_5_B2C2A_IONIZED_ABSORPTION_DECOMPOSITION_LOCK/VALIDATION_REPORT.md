# Validation report

## Overall assessment: Needs revision before B2C2B

The B2C2A numerical accounting is reproducible and internally closed, but the
physical component interpretation is not ready for unresolved-sink
subtraction. The absolute central-Gamma P0.4 opacity produces two materially
negative signed residuals.

## Methodology review

- The differential hazard definition has consistent comoving units.
- Effective/explicit H I double counting is prevented by an explicit energy
  firewall.
- Group totals reconcile with the B2C1C causal ledger at
  `6.183e-11`.
- The signed residual closes declared components to the inherited total, but
  it is not a nonnegative physical component.
- FlexRT finite-cell deposition is used only as a refinement auditor and
  converges at first order to the differential operator.

## High-severity issue

Two material negative rows occur at the first interval:

|   z_mid | group   |   average_absorption_rate_s-1_cMpc-3 |   signed_rate_relative_to_inherited |   time_average_kappa_cMpc_inv |
|--------:|:--------|-------------------------------------:|------------------------------------:|------------------------------:|
|    5.95 | G1      |                         -6.08562e+49 |                           -0.139795 |                   -0.00566148 |
|    5.95 | G2a     |                         -3.39225e+49 |                           -0.330047 |                   -0.00657226 |

Impact: interpreting this signed residual as an unresolved absorber would
produce a negative sink. B2C2B must remain blocked.

## Calculation spot checks

- Component-sum identity: verified to
  `1.083e-15`.
- P0.4 domain extrapolation: 0 rows.
- H I double-counting: 0 rows.
- Primary G3/external-HeII absorption: exact zero.
- Smallest-cell FlexRT relative difference: maximum
  `2.194e-04`.
- High-precision 2F1 rational-moment audit: relative difference
  `3.531e-16` against direct quadrature.

## Required revision

1. Apply a provenance-locked current-Gamma response ratio to the public
   central-Gamma anchor without free normalization.
2. Separate direct-energy group integration from the inherited discrete-node
   group closure.
3. Keep the resulting group-shape residual numerical, not astrophysical.
4. Re-evolve B2C1C if the canonical group operator changes.
5. Authorize B2C2B only after all physical absorption components are
   nonnegative.

## Required caveat

The gamma-conditioned raw auditor removes the negative sign but still leaves a
positive G1/G2a mismatch of approximately 7--20%; it is not yet a production
opacity closure.
