# Web and literature source lock

## FlexRT

Christopher Cain and Anson D'Aloisio, *FlexRT: A fast and flexible radiative
transfer code for cosmological reionization simulations*, arXiv:2409.04521,
published in JCAP 12 (2024) 025.

Use in B2C2A:
- adaptive ray-tracing/cell-deposition architecture;
- opacity prescriptions remain replaceable components;
- finite-cell deposition is an auditor of the differential one-zone hazard.

## C2-Ray

Garrelt Mellema et al., *C2-Ray: A new method for photon-conserving transport
of ionizing radiation*, arXiv:astro-ph/0508416.

Use in B2C2A:
- photons removed by bound-free opacity must match photoionization deposition;
- component/species allocation must be nonnegative and sum to the group total.

## SCRIPT sink closure

Tirthankar Roy Choudhury and Abinash Chakraborty,
*Capturing Small-Scale Reionization Physics: A Sub-Grid Model for Photon
Sinks with SCRIPT*, arXiv:2504.03384.

Use in B2C2A:
- emissivity, clumping, MFP, density, and photoionization rate are coupled;
- opacity components are not independent free normalizations.

## Mean-free-path emulator

Tohfa et al., arXiv:2602.03923.

Use in B2C2A:
- P0.4 effective H I opacity depends on wavelength, density, local
  reionization history, and Gamma_HI;
- PUBLIC_REPO_EXACT is retained as the absolute central-Gamma anchor;
- current-Gamma conditioning is an auditor until the direct group closure is
  reconciled with the inherited B2C1C operator.
