# Stage P0.5-B2C2A — Ionized absorption decomposition lock

## Verdict

\[
\boxed{
\text{B2C2A}=
\texttt{FAIL\_CLOSED\_NEGATIVE\_UNATTRIBUTED\_EFFECTIVE\_RESIDUAL}
}
\]

The requested differential absorption decomposition, unit conversion,
component firewall, FLRW background receipts, exact primary G3/HeII zero,
FlexRT cell-deposition refinement, Wolfram gates, and high-precision analytic
auditor all ran successfully.

The stage does not pass its physical component gate. The locked absolute
`PUBLIC_REPO_EXACT` central-Gamma opacity exceeds the inherited B2C1C group
hazard in two material rows at the first interval. No component was rescaled,
clipped, or reassigned to species.

## Strong numerical results

\[
\max \epsilon_{\rm group\to causal}
=
6.183e-11,
\]

\[
\max \epsilon_{\rm declared+signed\ residual}
=
6.315e-16,
\]

\[
\max \epsilon_{\rm FlexRT,smallest\ cell}
=
2.194e-04.
\]

The cell-deposition convergence order is

\[
0.985867
\le p\le
1.000000.
\]

## Material blocker

|   z_mid | group   |   average_absorption_rate_s-1_cMpc-3 |   time_average_kappa_cMpc_inv |   signed_rate_relative_to_inherited |   P0_4_public_central_gamma12 |   state_Gamma12_min |   state_Gamma12_max |
|--------:|:--------|-------------------------------------:|------------------------------:|------------------------------------:|------------------------------:|--------------------:|--------------------:|
|    5.95 | G1      |                         -6.08562e+49 |                   -0.00566148 |                           -0.139795 |                      0.146773 |            0.152699 |            0.235515 |
|    5.95 | G2a     |                         -3.39225e+49 |                   -0.00657226 |                           -0.330047 |                      0.146773 |            0.152699 |            0.235515 |

The worst signed residual is

\[
-33.005\%
\]

of the inherited group absorption rate, with

\[
\kappa_{\rm residual,min}^c
=
-1.428918e-02
\ \mathrm{cMpc}^{-1}.
\]

Because an unresolved sink must be nonnegative, this signed mismatch cannot
be promoted to B2C2B physics.

## Diagnosis

The public absolute table is tied to a central Gamma history, while the
B2C1C trajectory spans a different instantaneous Gamma range. A raw
current-Gamma auditor removes the negative sign, but still leaves a positive
G1/G2a mismatch of roughly 7--20%. That remaining mismatch tracks the use of
direct spectral group integration versus the inherited sparse/discrete group
closure.

Thus two effects must be separated:

1. current-Gamma response of the effective opacity;
2. group-shape/discretization closure.

## Exact firewalls

- Effective and explicit H I never coexist in 13.6--39.5 eV.
- P0.4 interpolation never extrapolates outside the six-node domain.
- Primary G3 photon absorption and external He II absorption are exactly zero.
- Neutral islands are `EXCLUDED_NOT_ZERO`.
- The signed residual is not exponentiated in the FlexRT cell auditor.
- Recombination remains an unloaded external dependency.
- Geometry remains `FLRW_CONTROL` with immutable snapshot receipts.

## Decision

\[
\boxed{\text{B2C2B unresolved-sink closure is NOT AUTHORIZED.}}
\]

The next stage is

```text
P0.5-B2C2A-R1-GAMMA-CONDITIONED-DIRECT-OPACITY-RECONCILIATION
```

and must re-run the inherited absorption history before any unresolved-sink
subtraction.
