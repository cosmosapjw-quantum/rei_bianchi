from pathlib import Path
import json
import numpy as np
import pandas as pd

root = Path(__file__).resolve().parents[1]
data = root / 'data'

results = json.loads((root / 'results.json').read_text())
assert results['verdict'] == 'FAIL_CLOSED_NEGATIVE_UNATTRIBUTED_EFFECTIVE_RESIDUAL'
assert results['numerical_core_pass'] is True
assert results['gates']['group_sum_vs_B2C1C_causal_ledger_relative_residual_max'] < 1e-10
assert results['gates']['declared_component_sum_vs_inherited_relative_residual_max'] < 1e-12
assert results['gates']['component_sum_identity_relative_residual_max'] < 1e-12
assert results['gates']['cell_smallest_relative_difference_max'] < 0.01
lo, hi = results['gates']['cell_observed_order_range']
assert 0.8 < lo < 1.2 and 0.8 < hi < 1.2
assert results['gates']['primary_G3_and_external_HeII_absorption_exact_zero'] is True
assert results['gates']['P0_4_domain_extrapolation_count'] == 0
assert results['gates']['HI_double_count_count'] == 0

material = pd.read_csv(data / 'material_negative_residuals.csv')
assert len(material) == 2
assert (material['signed_rate_relative_to_inherited'] < -1e-8).all()

firewall = pd.read_csv(data / 'opacity_firewall_audit.csv')
assert not firewall['effective_and_explicit_HI_double_count'].any()
assert not firewall['P0_4_domain_extrapolated'].any()
assert not firewall['neutral_island_included'].any()
assert firewall['primary_G3_source_exact_zero'].all()
assert firewall['primary_external_HeII_absorption_exact_zero'].all()

species = pd.read_csv(data / 'species_component_absorption.csv')
assert not species['renormalized_to_species'].any()
primary_heii = species[(species.group == 'G3') & (species.species == 'HeII')]
assert (primary_heii['absorption_rate_s-1_cMpc-3'] == 0.0).all()

cell = pd.read_csv(data / 'cell_deposition_refinement.csv')
assert cell['signed_residual_excluded'].all()
assert cell['monotone_refinement_expected'].all()

snapshots = [json.loads(line) for line in (root / 'background_snapshot_receipts.jsonl').read_text().splitlines() if line.strip()]
assert len(snapshots) == 5
assert all(x['background_model'] == 'FLRW_CONTROL' for x in snapshots)
assert all(not x['geometry_feedback_enabled'] for x in snapshots)
assert all(not x['primitive_geometry_transplanted'] for x in snapshots)

recomb = json.loads((root / 'RECOMBINATION_EXTERNAL_DEPENDENCY_RECEIPT.json').read_text())
assert recomb['dependency_status'] == 'EXTERNAL_NOT_LOADED'
assert recomb['contains_astrophysical_reionization'] is False
assert recomb['forbidden_double_count'] is True

neutral = json.loads((root / 'neutral_island_exclusion_ledger.json').read_text())
assert neutral['status'] == 'EXCLUDED_NOT_ZERO'
assert neutral['included_in_ionized_absorption'] is False

wolfram = json.loads((root / 'wolfram_validation_results.json').read_text())
assert wolfram['status'] == 'PASS'
assert wolfram['ComponentSumResidual'] == 0
assert wolfram['ProperComovingResidual'] == 0
assert wolfram['ThresholdBelowExactZero'] == 0
assert wolfram['PrimaryG3Absorption'] == 0
assert wolfram['PrimaryExternalHeIIAbsorption'] == 0
assert wolfram['NoDoubleCountCounterexample'] is False
assert wolfram['AllocationSum'] == 1

special = json.loads((data / 'special_function_powerlaw_rational_audit.json').read_text())
assert special['relative_difference'] < 1e-12
assert special['production_operator'] == 'DIRECT_NUMERICAL_QUADRATURE'

state = json.loads((root / 'STAGE_STATE.json').read_text())
assert state['status'] == 'FAIL_CLOSED_NEGATIVE_UNATTRIBUTED_EFFECTIVE_RESIDUAL'
assert state['B2C2B_authorized'] is False

assert (root / 'BLOCKER_ANALYSIS.md').exists()
assert (root / 'NEXT_STAGE_PROMPT.md').exists()

print('P0.5-B2C2A verification: NUMERICAL_CORE_PASS; PHYSICAL_COMPONENT_GATE_FAIL_CLOSED; B2C2B_NOT_AUTHORIZED')
