# B2C2A state ledger

## Provenance

- New post-interruption durable stage.
- Primordial recombination remains an unloaded external dependency.
- Background is `FLRW_CONTROL`; primitive Bianchi code informs only the
  receipt contract.

## Numerical core

- Group absorption sum versus B2C1C causal ledger:
  6.183e-11 maximum.
- Declared components plus signed residual versus inherited hazard:
  6.315e-16 maximum.
- FlexRT smallest-cell differential-limit error:
  2.194e-04 maximum.
- Observed refinement order:
  0.985867--1.000000.

## Fail-closed physical gate

`PUBLIC_REPO_EXACT` is an absolute central-Gamma table. Used without a
current-Gamma response, it exceeds the inherited B2C1C hazard in two material
rows at z_mid=5.95:

|   z_mid | group   |   average_absorption_rate_s-1_cMpc-3 |   time_average_kappa_cMpc_inv |   signed_rate_relative_to_inherited |   P0_4_public_central_gamma12 |   state_Gamma12_min |   state_Gamma12_max |
|--------:|:--------|-------------------------------------:|------------------------------:|------------------------------------:|------------------------------:|--------------------:|--------------------:|
|    5.95 | G1      |                         -6.08562e+49 |                   -0.00566148 |                           -0.139795 |                      0.146773 |            0.152699 |            0.235515 |
|    5.95 | G2a     |                         -3.39225e+49 |                   -0.00657226 |                           -0.330047 |                      0.146773 |            0.152699 |            0.235515 |

The signed residual is preserved and is never assigned to H/He species.
B2C2B is not authorized.

## Authoritative files

- `results.json`
- `data/group_total_absorption.csv`
- `data/component_hazard_table.csv`
- `data/species_component_absorption.csv`
- `data/gamma_conditioned_opacity_audit.csv`
- `data/material_negative_residuals.csv`
- `data/cell_deposition_refinement.csv`
- `background_snapshot_receipts.jsonl`
- `wolfram_validation_results.json`

## Scope exclusions

No unresolved-sink subtraction, front construction, source/fesc calibration,
recombination implementation, primitive geometry transplant, or Bianchi
feedback occurred.
