@Web+Wolfram Stage P0.5-B2C2A-R1-GAMMA-CONDITIONED-DIRECT-OPACITY-RECONCILIATION를 실행해줘.

B2C2A의 exact-zero primary G3 state, FLRW BackgroundSnapshot receipts,
component registry, differential-hazard definition, signed-residual firewall,
FlexRT refinement auditor와 recombination external-dependency receipt를
정본으로 유지한다. B2C2A의 FAIL_CLOSED 판정을 성공으로 상속하지 마.

1. 새 durable R1 stage를 계산 전에 만들고 B2C2A bundle/hash 및 모든
   upstream canonical bundle을 input lock에 고정해줘.

2. P0.4 PUBLIC_REPO_EXACT six-node table은 central-Gamma absolute anchor로
   유지한다. underlying P0.4 raw table에서 동일 z,E node의 response ratio

   R_Gamma(E,z,Gamma)
     = kappa_raw(E,z,Gamma) / kappa_raw(E,z,Gamma_central(z))

   를 계산하고

   kappa_eff(E,z,Gamma)
     = kappa_PUBLIC(E,z) R_Gamma(E,z,Gamma)

   로 current-Gamma-conditioned lane을 구성해줘. 자유 normalization이나
   inherited absorption에 대한 fitting은 금지한다.

3. density, local z_re, eta/global averaging convention은 P0.4 정본과
   동일하게 유지해줘. PUBLIC anchor와 raw response의 energy/z/Gamma domain
   밖 extrapolation은 fail closed해줘.

4. 다음 두 group operators를 병렬로 계산해줘.

   A. DIRECT_ENERGY_GROUP:
      within-group phi(E) direct quadrature.

   B. LEGACY_DISCRETE_NODE_GROUP:
      B2C1C inherited sparse-node/group closure를 byte/formula-level로
      재현한 auditor.

   두 operator의 차이는
   GROUP_SHAPE_DISCRETIZATION_RESIDUAL로 따로 저장하고 물리적 unresolved
   sink로 해석하지 마.

5. current-Gamma-conditioned effective HI, explicit HeI 및 high-energy
   explicit atomic lanes로 B2C1C absorption history를 다시 계산해줘.
   material negative component가 하나라도 남으면 fail closed해줘.

6. reconciliation 선택은 다음 순서로 해줘.
   - Gamma response가 central-Gamma mismatch를 제거하는지 판정.
   - direct/discrete group closure가 B2C1C photon history에 주는 영향을
     분리.
   - canonical group operator를 바꾸어야 한다면 B2C1C history를 다시
     진화시키고 기존 history와 섞지 마.

7. signed residual을 species에 재정규화하거나 max(0,...)로 자르지 마.
   physical components와 numerical closure residual을 별도 registry에
   유지해줘.

8. FlexRT finite-cell auditor와 Wolfram telescoping/unit/differential-limit
   gates를 다시 실행해줘. Precise Special Functions는 닫힌 analytic
   limit의 independent oracle로만 사용해줘.

9. 이번 R1에서도 unresolved-sink subtraction, front allocation,
   source/f_esc calibration, recombination implementation, primitive geometry
   transplant와 Bianchi feedback은 시작하지 마.

R1에서 모든 physical component가 nonnegative하고 inherited/canonical
history가 일관되게 재잠긴 뒤에만 B2C2B를 승인해줘.
