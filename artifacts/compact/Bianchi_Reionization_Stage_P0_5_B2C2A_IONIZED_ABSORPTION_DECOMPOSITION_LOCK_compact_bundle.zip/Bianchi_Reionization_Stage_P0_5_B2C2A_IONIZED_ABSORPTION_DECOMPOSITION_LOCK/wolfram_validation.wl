ClearAll["Global`*"];

groupResiduals = {
 dn1 + phi0 - phi1 - em1 + abs1,
 dn2 + phi1 - phi2 - em2 + abs2,
 dn3 + phi2 - phi3 - em3 + abs3,
 dn4 + phi3 - phi4 - em4 + abs4
};
totalGroupResidual = Expand[Total[groupResiduals]];

componentResidual = FullSimplify[(kEff + kHI + kHeI + kHeII) +
    (kInherited - kEff - kHI - kHeI - kHeII) - kInherited];

properComovingResidual = FullSimplify[
  (cc/aa/mpc) (aa np sigma mpc) - cc np sigma,
  Assumptions -> {aa > 0, mpc > 0}
];

finiteCell = (vv/dd) nn (1 - Exp[-kTot dd]) kComp/kTot;
finiteCellLimit = FullSimplify[
  Limit[finiteCell, dd -> 0, Direction -> "FromAbove"],
  Assumptions -> {vv >= 0, nn >= 0, kTot > 0, kComp >= 0}
];
finiteCellSeries = Normal@Series[finiteCell, {dd, 0, 2}];

sigmaThreshold[e_, eth_] := Piecewise[{{0, e < eth}}, sigmaAbove[e]];
thresholdBelow = FullSimplify[
  sigmaThreshold[eth - eps, eth],
  Assumptions -> {eps > 0, eth > 0}
];

primaryG3Rate = FullSimplify[vv nG3 kG3 /. nG3 -> 0];
primaryHeIIAbsorption = FullSimplify[vv nG3 kHeII /. nG3 -> 0];
selectorProducts = Table[s (1 - s), {s, {0, 1}}];
selectorCounterexample = Reduce[
  Element[s, Integers] && 0 <= s <= 1 && s (1 - s) != 0,
  s, Reals
];
allocationSum = FullSimplify[(k1 + k2 + k3)/(k1 + k2 + k3),
  Assumptions -> {k1 >= 0, k2 >= 0, k3 >= 0, k1 + k2 + k3 > 0}];

<|
 "TotalGroupResidual" -> totalGroupResidual,
 "TelescopingBoundaryPart" -> phi0 - phi4,
 "ComponentSumResidual" -> componentResidual,
 "ProperComovingResidual" -> properComovingResidual,
 "FiniteCellDifferentialLimit" -> finiteCellLimit,
 "FiniteCellSeries" -> finiteCellSeries,
 "ThresholdBelowExactZero" -> thresholdBelow,
 "PrimaryG3Absorption" -> primaryG3Rate,
 "PrimaryExternalHeIIAbsorption" -> primaryHeIIAbsorption,
 "NoDoubleCountSelectorProducts" -> selectorProducts,
 "NoDoubleCountCounterexample" -> selectorCounterexample,
 "AllocationSum" -> allocationSum
|>
