# B2C2A blocker analysis

## Blocker

The numerical accounting core passes, but the absolute `PUBLIC_REPO_EXACT`
central-Gamma opacity is not a nonnegative component decomposition of the
inherited B2C1C group hazard over the complete history.

At the first interval, two signed residuals are materially negative:

```text
 z_mid group  average_absorption_rate_s-1_cMpc-3  time_average_kappa_cMpc_inv  signed_rate_relative_to_inherited  P0_4_public_central_gamma12  state_Gamma12_min  state_Gamma12_max
  5.95    G1                       -6.085624e+49                    -0.005661                          -0.139795                     0.146773           0.152699           0.235515
  5.95   G2a                       -3.392246e+49                    -0.006572                          -0.330047                     0.146773           0.152699           0.235515
```

The worst signed rate is -0.330047 of the
inherited group rate, and the minimum signed residual opacity is
-1.428918e-02 cMpc^-1.

This is not repaired by species rescaling. The current-Gamma raw P0.4 auditor
removes the negative sign but leaves an 8--20% positive group mismatch in G1
and G2a. That remaining discrepancy is consistent with the difference between
(a) direct energy integration and (b) the inherited sparse/discrete group
closure. It is not yet a physical unresolved absorber.

## Decision

`B2C2B-UNRESOLVED-SINK-CLOSURE` is **not authorized**.

The next stage must reconcile both:

1. current-Gamma response of the P0.4 opacity; and
2. direct-energy versus inherited discrete-node group closure.

Neither correction may be fitted to force nonnegative residuals.
