# B2C2A absorption-decomposition specification

## Scope

This stage decomposes ionized-medium absorption evidence. It does **not**
subtract diffuse maintenance, infer unresolved sinks, define fronts by a
ledger residual, implement primordial recombination, or activate Bianchi
geometry feedback.

## Units and loss operator

All opacity components use comoving inverse length:

\[
\kappa_{s,\rm atom}^{c}(E,t)
= a(t)n_s^{p}(t)\sigma_s(E){\rm Mpc}_{\rm cm}.
\]

The cosmic-time loss coefficient is

\[
\frac{c}{a\,{\rm Mpc}_{\rm cm}}\kappa^c.
\]

## Opacity firewall

- 13.6--39.5 eV: `EFFECTIVE_HI_SUBGRID` is the only H I component.
- Explicit He I starts at 24.59 eV.
- Above 39.5 eV: explicit atomic H I and He I are used.
- Above 54.42 eV: explicit He II exists as an operator, but primary G3 photon
  number and external He II absorption are exactly zero.
- `NEUTRAL_ISLAND_TRANSFER` is excluded-not-zero.
- The signed residual is never rescaled or allocated to species.

## Primary differential decomposition

\[
\bar\kappa_{c,g}^{c}
=\int_{G_g}\phi_g(E)\kappa_c^c(E)\,dE,
\]

\[
\dot N_{{\rm abs},c,g}^{c}
=\frac{c}{a\,{\rm Mpc}_{\rm cm}}
N_{\gamma,g}^{c}\bar\kappa_{c,g}^{c}.
\]

The inherited group hazard is closed by

\[
\kappa_{\rm inherited,g}
=\sum_{c\in\rm declared}\kappa_{c,g}
+\kappa_{\rm unattributed,g}^{\rm signed}.
\]

The signed residual is diagnostic only. A materially negative residual blocks
B2C2B because it cannot be interpreted as a nonnegative unresolved sink.

## FlexRT finite-cell auditor

\[
D_{c,g}(\Delta\chi)
=\frac{c}{a\,\Delta\chi\,{\rm Mpc}_{\rm cm}}
N_{\gamma,g}^{c}
\int\phi_g(E)[1-e^{-\kappa_{\rm tot}^c(E)\Delta\chi}]
\frac{\kappa_c^c(E)}{\kappa_{\rm tot}^c(E)}\,dE.
\]

Only nonnegative physical components enter the exponential. The signed
unattributed residual is explicitly excluded. The differential limit is the
primary operator.
