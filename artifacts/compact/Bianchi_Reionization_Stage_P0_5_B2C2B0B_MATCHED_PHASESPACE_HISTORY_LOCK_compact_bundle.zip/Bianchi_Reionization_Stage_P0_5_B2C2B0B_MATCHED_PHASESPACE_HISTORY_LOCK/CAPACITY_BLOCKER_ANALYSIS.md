# Absorption–chemistry capacity blocker

## Necessary boundedness condition

For a comoving hydrogen parcel inventory \(N_H^c\), let the interval-averaged
photoionization event rate be \(J_H\), the full-OTS recombination cycling rate
be \(M_H\), and let all additional collisional ionization terms be
nonnegative. The most permissive interval update is

\[
X_1
=
X_0
+
\frac{\Delta t}{N_H^c}
\left(J_H-M_H+C_H\right).
\]

A bounded state \(X_1\le1\) can exist only if

\[
J_H
\le
M_H
+
\frac{N_H^c(1-X_0)}{\Delta t}
-C_H.
\]

Dropping \(C_H\ge0\) yields the weaker necessary condition used by this
stage. Therefore a positive deficit

\[
\mathcal D_H
=
J_H-M_H-
\frac{N_H^c(1-X_0)}{\Delta t}>0
\]

already proves that no bounded diffuse-only history exists.

## Durable findings

- Primary deterministic closure: all five intervals fail.
- Three absorber-shape lanes: identical global capacity result.
- Maximum locked sensitivity envelope: four of five intervals fail.
- No matched history was accepted or fabricated.
- No absorption component was clipped or redistributed.

## Interpretation boundary

The excess is not automatically called an unresolved sink. The gate proves
only that the effective-opacity absorption contains a channel outside the
current diffuse parcel chemistry state space. A physical sink interpretation
requires a dynamic reservoir with its own nuclei, thermal state, opacity and
lifetime/relaxation equations.
