"""P0.5-B2C2B0B matched phase-space history evolution.

The implementation is a photon-conserving, fixed-parcel, post-reionization
homogeneous-background closure.  The global ionizing photon reservoir is
advanced with the R1 current-Gamma opacity.  Every absorbed photon is then
assigned group -> macro environment -> micro parcel -> species, and exactly
the same event count enters the node chemistry and photoheating.

The fixed B2C2B0A quadrature weights are converted at z=6 into immutable
Lagrangian nuclei loads.  The transported density coordinates affect local
rates and parcel volumes, but never create or destroy nuclei.

No unresolved-sink subtraction, new front inference, Q_M evolution,
primordial recombination, Bianchi geometry, or source calibration occurs.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd
from scipy.interpolate import PchipInterpolator

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))

import hierarchical_two_scale_closure as HIER
import phase_space_kernel_b2c0 as B2C0
import hi_transmission_kernel_b2c1a as B2C1A
import multigroup_hhe_transmission as B2C1B
from b2b_physical_model import (
    C_LIGHT, KB_ERG, MPC_CM, NH0, YHE,
    allocate_front_sink, hubble, make_spectrum_lanes,
)
from monolithic_model_b2a import EV_ERG, beta_hi, beta_hei, beta_heii, lambda_hi, lambda_heii

MYR_S=1.0e6*365.25*86400.0
PRIMARY='MFP_BASELINE_E_MINUS_2P5_1_TO_4_RYD'
SHAPE_LANES=[
    'LOCAL_NEUTRAL_HAZARD_PRIMARY',
    'RECOMBINATION_WEIGHTED_AUDITOR',
    'SCRIPT_SELF_SHIELDING_AUDITOR',
]
SENSITIVITY_LANES=[
    'MACRO_DENSITY_VARIANCE',
    'EARLY_REIONIZED_COOLER',
    'EARLY_REIONIZED_HOTTER',
    'PATCHY_BETA_DIRICHLET',
]
GROUP_ORDER=['G1','G2a','G2b','G3']
SPECIES=['HI','HeI','HeII']
NHC=NH0*MPC_CM**3


def find_one(root:Path,filename:str)->Path:
    matches=list(root.rglob(filename))
    if not matches: raise FileNotFoundError(f'{filename} below {root}')
    return sorted(matches,key=lambda p:(len(p.parts),str(p)))[0]


def pchip_scalar(x:np.ndarray,y:np.ndarray,value:float,logy:bool=False)->float:
    if logy:
        return float(np.exp(PchipInterpolator(x,np.log(y))(value)))
    return float(PchipInterpolator(x,y)(value))


class EffectiveKappaFits:
    def __init__(self,table:pd.DataFrame):
        self.models={}
        for z,sub in table.groupby('z'):
            sub=sub.sort_values('Gamma12')
            x=np.log(sub['Gamma12'].to_numpy())
            self.models[float(z)]={
                'domain':(float(sub.Gamma12.min()),float(sub.Gamma12.max())),
                'G1':PchipInterpolator(x,np.log(sub.fit_G1_cMpc_inv.to_numpy()),extrapolate=False),
                'G2a':PchipInterpolator(x,np.log(sub.fit_G2a_cMpc_inv.to_numpy()),extrapolate=False),
            }
    def evaluate(self,zmid:float,gamma12:float)->tuple[float,float]:
        model=self.models[float(zmid)]
        lo,hi=model['domain']
        if not (lo<=gamma12<=hi):
            raise RuntimeError(f'Gamma12={gamma12} outside [{lo},{hi}] at z={zmid}')
        x=np.log(gamma12)
        return float(np.exp(model['G1'](x))),float(np.exp(model['G2a'](x)))


@dataclass
class Interval:
    index:int
    z_start:float
    z_mid:float
    z_end:float
    duration_s:float
    emission:float
    front_group:np.ndarray
    red_coeff:np.ndarray
    source_fraction:np.ndarray
    macro_raw_group:dict[str,np.ndarray]
    delta_start:np.ndarray
    delta_end:np.ndarray
    dln_delta_dt:np.ndarray
    Hubble:float


@dataclass
class ParcelState:
    N:np.ndarray
    xH:np.ndarray
    x2:np.ndarray
    x3:np.ndarray
    e:np.ndarray

    def copy(self)->'ParcelState':
        return ParcelState(self.N.copy(),self.xH.copy(),self.x2.copy(),self.x3.copy(),self.e.copy())


def state_temperature(state:ParcelState)->np.ndarray:
    electrons=state.xH+YHE*(state.x2+2.0*state.x3)
    particles=1.0+YHE+electrons
    return 2.0*state.e/(3.0*KB_ERG*particles)


def helium_fractions(state:ParcelState)->tuple[np.ndarray,np.ndarray,np.ndarray]:
    x1=1.0-state.x2-state.x3
    return x1,state.x2,state.x3


def interpolate_control_state(history:pd.DataFrame,z:float)->dict[str,float]:
    ordered=history.sort_values('z')
    x=ordered.z.to_numpy()
    out={}
    for col in ['N1','N2','N3','xHII','xHeII','xHeIII','T_K','Gamma_HI']:
        y=ordered[col].to_numpy()
        out[col]=pchip_scalar(x,y,z,logy=col in {'N1','N2','N3','T_K','Gamma_HI'})
    out['xHeI']=max(1.0-out['xHeII']-out['xHeIII'],0.0)
    return out


def load_fixed_micro(path:Path)->HIER.FixedMicroTemplate:
    d=np.load(path)
    return HIER.FixedMicroTemplate(
        n_delta=int(d['n_delta']),n_t=int(d['n_t']),
        w_delta=d['w_delta'],w_temperature=d['w_temperature'],
        u_delta=d['u_delta'],u_temperature=d['u_temperature'],
        weight_lock_redshift=float(d['weight_lock_redshift']),
    )


def initial_hierarchy(
    history:pd.DataFrame,fixed_macro:pd.DataFrame,fixed_micro:HIER.FixedMicroTemplate,
    mapping:pd.DataFrame,variant:str,
)->tuple[ParcelState,np.ndarray,np.ndarray,np.ndarray,np.ndarray,pd.DataFrame]:
    values=interpolate_control_state(history,6.0)
    hstate=B2C0.HistoryState(
        z=6.0,x_hii=values['xHII'],x_heii=values['xHeII'],x_heiii=values['xHeIII'],
        temperature=values['T_K'],gamma_hi=values['Gamma_HI'],
    )
    macro=HIER.macro_measure(6.0,mapping,fixed_macro)
    closure_variant='BASELINE'
    if variant=='MACRO_DENSITY_VARIANCE': closure_variant='MACRO_DENSITY_VARIANCE'
    if variant in {'EARLY_REIONIZED_COOLER','EARLY_REIONIZED_HOTTER'}: closure_variant=variant
    nodes,_,_=HIER.construct_hierarchy(hstate,macro,fixed_micro,closure_variant=closure_variant)
    W=nodes.W_node.to_numpy()
    delta0=nodes.delta_total.to_numpy()
    mu=W*delta0
    mu/=mu.sum()
    xH=nodes.xHII.to_numpy()
    x2=nodes.xHeII.to_numpy(); x3=nodes.xHeIII.to_numpy()
    T=nodes.T_K.to_numpy()
    electrons=xH+YHE*(x2+2*x3)
    e=1.5*KB_ERG*T*(1.0+YHE+electrons)
    state=ParcelState(
        N=np.array([values['N1'],values['N2'],values['N3']],dtype=float),
        xH=xH,x2=x2,x3=x3,e=e,
    )
    macro_index=nodes.macro_index.to_numpy(dtype=int)
    micro_index=nodes.micro_index.to_numpy(dtype=int)
    zre=nodes.z_re.to_numpy()
    return state,mu,macro_index,micro_index,zre,nodes


def rate_delta_endpoint(
    z:float,control_history:pd.DataFrame,fixed_macro:pd.DataFrame,
    fixed_micro:HIER.FixedMicroTemplate,mapping:pd.DataFrame,mu:np.ndarray,
    macro_index:np.ndarray,variant:str,
)->np.ndarray:
    values=interpolate_control_state(control_history,z)
    hstate=B2C0.HistoryState(
        z=z,x_hii=values['xHII'],x_heii=values['xHeII'],x_heiii=values['xHeIII'],
        temperature=values['T_K'],gamma_hi=values['Gamma_HI'],
    )
    macro=HIER.macro_measure(z,mapping,fixed_macro)
    micro_variant='MACRO_DENSITY_VARIANCE' if variant=='MACRO_DENSITY_VARIANCE' else 'BASELINE'
    grid,_=HIER.transported_micro_grid(hstate,fixed_micro,micro_variant)
    delta_sub=grid['delta'].reshape(-1)
    raw=macro.D_L_mass.to_numpy()[macro_index]*delta_sub[np.arange(len(mu))%len(delta_sub)]
    # Lagrangian volume normalization: v_i=mu_i/delta_i and sum_i v_i=1.
    scale=float(np.sum(mu/raw))
    delta=scale*raw
    return delta


def macro_raw_group_shapes(
    zmid:float,gamma12:float,macro:pd.DataFrame,raw_model:HIER.RawMacroOpacity,
)->dict[str,np.ndarray]:
    result={}
    for group in ['G1','G2a']:
        energy,weights=HIER.normalized_group_quadrature(group,32)
        vals=[]
        for row in macro.itertuples():
            evaluator,_=raw_model.energy_evaluator(
                zmid,row.z_re,float(row.density_sigma),gamma12
            )
            vals.append(float(np.sum(weights*evaluator(energy))))
        result[group]=np.asarray(vals)
    return result


def build_intervals(
    control_history:pd.DataFrame,ledger:pd.DataFrame,allocation:pd.DataFrame,
    fit_control:pd.DataFrame,fixed_macro:pd.DataFrame,fixed_micro:HIER.FixedMicroTemplate,
    mapping:pd.DataFrame,raw_model:HIER.RawMacroOpacity,mu:np.ndarray,
    macro_index:np.ndarray,variant:str,lane:Any,
)->list[Interval]:
    alloc=allocation[allocation.lane=='INSIDE_OUT_SELF_SHIELD_PRIMARY'].set_index('z_mid')
    intervals=[]
    endpoints=sorted(set(ledger.z_start).union(set(ledger.z_end)),reverse=True)
    delta_cache={z:rate_delta_endpoint(z,control_history,fixed_macro,fixed_micro,mapping,mu,macro_index,variant) for z in endpoints}
    for rec in ledger.sort_values('interval_index').itertuples():
        ar=alloc.loc[rec.z_mid]
        front,_=allocate_front_sink(
            float(ar.front_HII_rate),float(ar.front_HeII_rate),
            float(ar.front_HeIII_electron_weighted_rate),lane,
        )
        control_gamma=math.sqrt(float(rec.Gamma12_min)*float(rec.Gamma12_max))
        macro=HIER.macro_measure(float(rec.z_mid),mapping,fixed_macro)
        raw_shapes=macro_raw_group_shapes(float(rec.z_mid),control_gamma,macro,raw_model)
        d0=delta_cache[float(rec.z_start)]; d1=delta_cache[float(rec.z_end)]
        intervals.append(Interval(
            index=int(rec.interval_index),z_start=float(rec.z_start),z_mid=float(rec.z_mid),
            z_end=float(rec.z_end),duration_s=float(rec.dt_Myr)*MYR_S,
            emission=float(rec.emission_rate),front_group=np.asarray(front[:3]),
            red_coeff=np.asarray(lane.redshift_coeff[:3]),
            source_fraction=np.asarray(lane.source_fraction[:3]),
            macro_raw_group=raw_shapes,delta_start=d0,delta_end=d1,
            dln_delta_dt=(np.log(d1)-np.log(d0))/(float(rec.dt_Myr)*MYR_S),
            Hubble=hubble(float(rec.z_mid)),
        ))
    return intervals


def cooling_terms(
    T:np.ndarray,nH:np.ndarray,xH:np.ndarray,x2:np.ndarray,x3:np.ndarray,
)->tuple[np.ndarray,dict[str,np.ndarray]]:
    x1=np.maximum(1.0-x2-x3,0.0)
    nHe=YHE*nH
    ne=nH*xH+nHe*(x2+2*x3)
    nHI=nH*(1-xH); nHII=nH*xH
    nHeI=nHe*x1; nHeII=nHe*x2; nHeIII=nHe*x3
    llH=315614.0/T; llHeI=570670.0/T; llHeII=lambda_heii(T)
    recH=3.435e-30*T*llH**1.970/(1+(llH/2.250)**0.376)**3.720
    recHeII=KB_ERG*T*(1.26e-14*llHeI**0.750)
    recHeIII=8.0*3.435e-30*T*llHeII**1.970/(1+(llHeII/2.250)**0.376)**3.720
    excH=7.5e-19*np.exp(-118348.0/T)/(1+np.sqrt(T/1e5))
    excHeII=5.54e-17*T**-0.397*np.exp(-473638.0/T)/(1+np.sqrt(T/1e5))
    ff=1.42e-27*np.sqrt(T)*(1.1+0.34*np.exp(-(5.5-np.log10(T))**2/3.0))
    cool_rec=ne*nHII*recH+ne*nHeII*recHeII+ne*nHeIII*recHeIII
    cool_exc=ne*nHI*excH+ne*nHeII*excHeII
    cool_ion=EV_ERG*(ne*nHI*13.598*beta_hi(T)+ne*nHeI*24.587*beta_hei(T)+ne*nHeII*54.416*beta_heii(T))
    cool_ff=ne*(nHII+nHeII+4*nHeIII)*ff
    total=cool_rec+cool_exc+cool_ion+cool_ff
    return total,{
        'recombination_cooling':cool_rec,'excitation_cooling':cool_exc,
        'collisional_ionization_cooling':cool_ion,'free_free_cooling':cool_ff,
    }


def full_ots_source(
    z:float,delta:np.ndarray,T:np.ndarray,xH:np.ndarray,x2:np.ndarray,x3:np.ndarray,
    patchy:bool,
)->np.ndarray:
    x1=np.maximum(1.0-x2-x3,0.0)
    means={'xHII':xH,'xHeI':x1,'xHeII':x2,'xHeIII':x3}
    closure='PATCHY_BETA_DIRICHLET' if patchy else 'DETERMINISTIC'
    moments=B2C0.conditional_moments(means,closure)
    dummy=B2C0.HistoryState(z=z,x_hii=float(np.mean(xH)),x_heii=float(np.mean(x2)),x_heiii=float(np.mean(x3)),temperature=float(np.mean(T)),gamma_hi=0.0)
    grid={'delta':delta,'temperature':T,'weight':np.ones_like(T)}
    return B2C0.full_ots_kernel(dummy,grid,moments)['source']


def solve_helium_be(
    p1:np.ndarray,p2:np.ndarray,p3:np.ndarray,
    r12:np.ndarray,r21:np.ndarray,r23:np.ndarray,r32:np.ndarray,dt:float,
)->tuple[np.ndarray,np.ndarray,np.ndarray]:
    a1=1+dt*r12; c1=-dt*r21
    a2=-dt*r12; b2=1+dt*(r21+r23); c2=-dt*r32
    b3=-dt*r23; c3=1+dt*r32
    cp1=c1/a1; dp1=p1/a1
    den2=b2-a2*cp1; cp2=c2/den2; dp2=(p2-a2*dp1)/den2
    den3=c3-b3*cp2; p3n=(p3-b3*dp2)/den3
    p2n=dp2-cp2*p3n; p1n=dp1-cp1*p2n
    return p1n,p2n,p3n


def macro_micro_effective_q(
    shape_lane:str,delta:np.ndarray,volume:np.ndarray,T:np.ndarray,
    xH:np.ndarray,x2:np.ndarray,x3:np.ndarray,macro_index:np.ndarray,
    macro_raw:np.ndarray,z:float,gamma_hi:float,sigma_hi:float,
)->np.ndarray:
    nH=NH0*(1+z)**3*delta
    nHe=YHE*nH; x1=np.maximum(1-x2-x3,0)
    nHI=nH*(1-xH)
    nmacro=int(macro_index.max())+1
    vmacro=np.bincount(macro_index,weights=volume,minlength=nmacro)
    qmacro=vmacro*macro_raw
    qmacro/=qmacro.sum()
    gray=B2C1A.gray_sigma_hi()[0]
    if shape_lane=='LOCAL_NEUTRAL_HAZARD_PRIMARY':
        chi=B2C1A.calibrate_chi_jeans(z,gamma_hi,gray)['chi_J']
        L=chi*B2C1A.jeans_length_cm(nH,T,xH,x2,x3)
        shape=nHI*sigma_hi*np.exp(-0.5*nHI*sigma_hi*L)+1e-300
    elif shape_lane=='RECOMBINATION_WEIGHTED_AUDITOR':
        ne=nH*xH+nHe*(x2+2*x3)
        shape=B2C0.alpha_b_hii(T)*ne*nH*xH+1e-300
    elif shape_lane=='SCRIPT_SELF_SHIELDING_AUDITOR':
        nss=B2C1A.self_shielding_density_cm3(T,gamma_hi,gray)
        attenuation=1.0-B2C1A.rahmati_gamma_ratio(nH,nss)
        shape=nHI*np.maximum(attenuation,1e-12)+1e-300
    else: raise ValueError(shape_lane)
    weighted=volume*shape
    denom=np.bincount(macro_index,weights=weighted,minlength=nmacro)
    q=qmacro[macro_index]*weighted/denom[macro_index]
    q/=q.sum()
    return q


def explicit_component_q(
    mu:np.ndarray,species_fraction:np.ndarray,
)->np.ndarray:
    q=mu*np.maximum(species_fraction,0.0)
    total=q.sum()
    return q/total if total>0 else np.zeros_like(q)


def step_radiation(
    Nold:np.ndarray,dt:float,emission:float,source_fraction:np.ndarray,
    front:np.ndarray,abs_coeff:np.ndarray,red_coeff:np.ndarray,H:float,
)->tuple[np.ndarray,dict[str,float]]:
    red=H*red_coeff
    source=emission*source_fraction-front
    if np.any(source<0):
        raise RuntimeError('Negative net photon source in implicit step')
    N=np.zeros(3)
    N[2]=(Nold[2]+dt*source[2])/(1+dt*(abs_coeff[2]+red[2]))
    N[1]=(Nold[1]+dt*(source[1]+red[2]*N[2]))/(1+dt*(abs_coeff[1]+red[1]))
    N[0]=(Nold[0]+dt*(source[0]+red[1]*N[1]))/(1+dt*(abs_coeff[0]+red[0]))
    if np.any(N<0): raise RuntimeError('Negative photon reservoir')
    storage=float((N.sum()-Nold.sum())/dt)
    absorption=float(np.dot(abs_coeff,N))
    redloss=float(red[0]*N[0])
    residual=float(emission-front.sum()-storage-absorption-redloss)
    return N,{
        'storage_rate':storage,'absorption_rate':absorption,'redshift_loss_rate':redloss,
        'front_rate':float(front.sum()),'emission_rate':emission,
        'relative_residual':residual/max(abs(emission),1.0),
    }


def evolve_step(
    state:ParcelState,dt:float,z:float,delta:np.ndarray,dln_delta_dt:np.ndarray,
    mu:np.ndarray,macro_index:np.ndarray,interval:Interval,kappa_fit:EffectiveKappaFits,
    lane:Any,shape_lane:str,patchy:bool,
)->tuple[ParcelState,dict[str,float],dict[str,np.ndarray]]:
    x1,x2,x3=helium_fractions(state)
    T=state_temperature(state)
    volume=mu/delta
    volume/=volume.sum()
    gamma_hi=C_LIGHT*(1+z)**3/MPC_CM**3*float(np.dot(lane.sigma_HI[:3],state.N))
    k1eff,k2aeff=kappa_fit.evaluate(interval.z_mid,gamma_hi/1e-12)
    # Explicit global differential opacities; v*delta=mu in the Lagrangian closure.
    a=1/(1+z); nHbar=NH0*(1+z)**3
    mean_hi=float(np.sum(mu*(1-state.xH)))
    mean_hei=float(np.sum(mu*x1))
    kHeI2a=a*nHbar*YHE*mean_hei*lane.sigma_HeI[1]*MPC_CM
    kHI2b=a*nHbar*mean_hi*lane.sigma_HI[2]*MPC_CM
    kHeI2b=a*nHbar*YHE*mean_hei*lane.sigma_HeI[2]*MPC_CM
    kappa=np.array([k1eff,k2aeff+kHeI2a,kHI2b+kHeI2b])
    abs_coeff=C_LIGHT*(1+z)/MPC_CM*kappa
    Nnew,photon_ledger=step_radiation(
        state.N,dt,interval.emission,interval.source_fraction,interval.front_group,
        abs_coeff,interval.red_coeff,interval.Hubble,
    )
    group_abs=abs_coeff*Nnew
    # Photon-event allocation.
    events_H=np.zeros_like(state.xH); events_HeI=np.zeros_like(state.xH)
    heat_rate=np.zeros_like(state.xH)
    qeff1=macro_micro_effective_q(
        shape_lane,delta,volume,T,state.xH,state.x2,state.x3,macro_index,
        interval.macro_raw_group['G1'],z,gamma_hi,lane.sigma_HI[0],
    )
    events_H+=group_abs[0]*qeff1
    heat_rate+=group_abs[0]*qeff1*lane.excess_HI[0]*EV_ERG
    qeff2=macro_micro_effective_q(
        shape_lane,delta,volume,T,state.xH,state.x2,state.x3,macro_index,
        interval.macro_raw_group['G2a'],z,gamma_hi,lane.sigma_HI[1],
    )
    if kappa[1]>0:
        frac_eff=k2aeff/kappa[1]; frac_hei=kHeI2a/kappa[1]
    else: frac_eff=frac_hei=0.0
    events_H+=group_abs[1]*frac_eff*qeff2
    heat_rate+=group_abs[1]*frac_eff*qeff2*lane.excess_HI[1]*EV_ERG
    qhei=explicit_component_q(mu,x1)
    events_HeI+=group_abs[1]*frac_hei*qhei
    heat_rate+=group_abs[1]*frac_hei*qhei*lane.excess_HeI[1]*EV_ERG
    if kappa[2]>0:
        frac_hi=kHI2b/kappa[2]; frac_hei2=kHeI2b/kappa[2]
    else: frac_hi=frac_hei2=0.0
    qhi=explicit_component_q(mu,1-state.xH)
    events_H+=group_abs[2]*frac_hi*qhi
    heat_rate+=group_abs[2]*frac_hi*qhi*lane.excess_HI[2]*EV_ERG
    events_HeI+=group_abs[2]*frac_hei2*qhei
    heat_rate+=group_abs[2]*frac_hei2*qhei*lane.excess_HeI[2]*EV_ERG
    Hcount=mu*NHC; Hecount=YHE*Hcount
    photo_rate_H=events_H/Hcount
    photo_rate_HeI=events_HeI/Hecount
    # Picard solve with photon events as constant conservative source terms.
    # The same atom may recombine and be reionized within one implicit step,
    # so the integrated event count is not limited by the initial neutral count.
    xHc=state.xH.copy(); p1c=x1.copy(); p2c=state.x2.copy(); p3c=state.x3.copy(); ec=state.e.copy()
    theta=3*interval.Hubble-dln_delta_dt
    max_picard=100; picard_res=math.inf; damping=0.15
    source_final=None; thermal_used=None
    for iteration in range(max_picard):
        Tc=2*ec/(3*KB_ERG*(1+YHE+xHc+YHE*(p2c+2*p3c)))
        nH=nHbar*delta; nHe=YHE*nH
        ne=nH*xHc+nHe*(p2c+2*p3c)
        source=full_ots_source(z,delta,Tc,xHc,p2c,p3c,patchy)
        dH_ots=source[:,1]/nH
        d1_ots=source[:,2]/nHe; d2_ots=source[:,3]/nHe; d3_ots=source[:,4]/nHe
        collH=ne*beta_hi(Tc)
        coll12=ne*beta_hei(Tc); coll23=ne*beta_heii(Tc)
        upH=collH+np.maximum(dH_ots,0)/np.maximum(1-xHc,1e-30)
        downH=np.maximum(-dH_ots,0)/np.maximum(xHc,1e-30)
        xHn=(state.xH+dt*(photo_rate_H+upH))/(1+dt*(upH+downH))
        flux12=-d1_ots; flux23=d3_ots
        r12=coll12+np.maximum(flux12,0)/np.maximum(p1c,1e-30)
        r21=np.maximum(-flux12,0)/np.maximum(p2c,1e-30)
        r23=coll23+np.maximum(flux23,0)/np.maximum(p2c,1e-30)
        r32=np.maximum(-flux23,0)/np.maximum(p3c,1e-30)
        p1_rhs=x1-dt*photo_rate_HeI
        p2_rhs=state.x2+dt*photo_rate_HeI
        p3_rhs=state.x3
        p1n,p2n,p3n=solve_helium_be(p1_rhs,p2_rhs,p3_rhs,r12,r21,r23,r32,dt)
        cool,components=cooling_terms(Tc,nH,xHn,p2n,p3n)
        heat_spec=heat_rate/Hcount
        cool_spec=cool/nH
        denom=1+dt*(2/3)*theta
        en=(state.e+dt*(heat_spec-cool_spec))/denom
        if np.min(en)<=0 or np.min(p1n)<-1e-12 or np.min(p2n)<-1e-12 or np.min(p3n)<-1e-12:
            raise RuntimeError('Implicit chemistry/thermal step violates positivity')
        res=max(
            float(np.max(np.abs(xHn-xHc))),float(np.max(np.abs(p2n-p2c))),
            float(np.max(np.abs(p3n-p3c))),float(np.max(np.abs(en-ec)/np.maximum(np.abs(en),1e-30))),
        )
        xHc=(1-damping)*xHc+damping*xHn
        p1c=(1-damping)*p1c+damping*p1n
        p2c=(1-damping)*p2c+damping*p2n
        p3c=(1-damping)*p3c+damping*p3n
        ec=(1-damping)*ec+damping*en
        source_final=source; thermal_used=(heat_spec,cool_spec,theta,components)
        picard_res=res
        if res<3e-11:
            xHc,p1c,p2c,p3c,ec=xHn,p1n,p2n,p3n,en
            break
    if picard_res>=3e-8:
        raise RuntimeError(f'Picard failed: residual {picard_res}')
    # Discrete storage identities.
    storage_H=float(np.sum(Hcount*(xHc-state.xH))/dt)
    storage_HeI=float(np.sum(Hecount*(p1c-x1))/dt)
    storage_HeII=float(np.sum(Hecount*(p2c-state.x2))/dt)
    storage_HeIII=float(np.sum(Hecount*(p3c-state.x3))/dt)
    photo_H=float(events_H.sum()); photo_HeI=float(events_HeI.sum())
    nonphoto_H=storage_H-photo_H
    nonphoto_HeI=storage_HeI+photo_HeI
    nonphoto_HeII=storage_HeII-photo_HeI
    nonphoto_HeIII=storage_HeIII
    species_identity=max(
        abs(storage_H-(photo_H+nonphoto_H)),
        abs(storage_HeI-(-photo_HeI+nonphoto_HeI)),
        abs(storage_HeII-(photo_HeI+nonphoto_HeII)),
        abs(storage_HeIII-nonphoto_HeIII),
    )/max(abs(photo_H)+abs(photo_HeI)+abs(nonphoto_H)+abs(nonphoto_HeI)+1.0,1.0)
    heat_spec,cool_spec,theta_used,_=thermal_used
    thermal_lhs=float(np.sum(mu*(ec-state.e))/dt)
    thermal_rhs=float(np.sum(mu*(heat_spec-cool_spec-(2/3)*theta_used*ec)))
    thermal_res=abs(thermal_lhs-thermal_rhs)/max(abs(thermal_lhs),abs(thermal_rhs),1e-300)
    out=ParcelState(Nnew,xHc,p2c,p3c,ec)
    diag={
        **photon_ledger,'species_storage_relative_residual':species_identity,
        'thermal_storage_relative_residual':thermal_res,'picard_residual':picard_res,
        'min_xH':float(xHc.min()),'max_xH':float(xHc.max()),
        'min_xHeI':float(p1c.min()),'min_xHeII':float(p2c.min()),'min_xHeIII':float(p3c.min()),
        'helium_simplex_error':float(np.max(np.abs(p1c+p2c+p3c-1))),
        'gamma_HI':gamma_hi,'kappa_G1':kappa[0],'kappa_G2a':kappa[1],'kappa_G2b':kappa[2],
        'photo_H_rate':photo_H,'photo_HeI_rate':photo_HeI,
        'nonphoto_H_rate':nonphoto_H,'nonphoto_HeI_rate':nonphoto_HeI,
        'nonphoto_HeII_rate':nonphoto_HeII,'nonphoto_HeIII_rate':nonphoto_HeIII,
    }
    arrays={'events_H':events_H,'events_HeI':events_HeI,'delta':delta,'volume':volume}
    return out,diag,arrays


def global_summary(state:ParcelState,mu:np.ndarray,z:float,lane:Any)->dict[str,float]:
    x1,x2,x3=helium_fractions(state); T=state_temperature(state)
    gamma=C_LIGHT*(1+z)**3/MPC_CM**3*float(np.dot(lane.sigma_HI[:3],state.N))
    return {
        'z':z,'N1':state.N[0],'N2':state.N[1],'N3':state.N[2],'N4_exact':0.0,
        'xHII':float(np.sum(mu*state.xH)),'xHeI':float(np.sum(mu*x1)),
        'xHeII':float(np.sum(mu*x2)),'xHeIII':float(np.sum(mu*x3)),
        'T_mass_K':float(np.sum(mu*T)),'Gamma_HI':gamma,'Gamma_HeII_exact':0.0,
        'thermal_energy_per_H_erg':float(np.sum(mu*state.e)),
    }


def run_lane(
    name:str,shape_lane:str,variant:str,patchy:bool,dt_target_myr:float,
    control_history:pd.DataFrame,ledger:pd.DataFrame,allocation:pd.DataFrame,
    fixed_macro:pd.DataFrame,fixed_micro:HIER.FixedMicroTemplate,mapping:pd.DataFrame,
    raw_model:HIER.RawMacroOpacity,kappa_fit:EffectiveKappaFits,lane:Any,
    checkpoint:bool=False,
)->tuple[pd.DataFrame,pd.DataFrame,dict[str,np.ndarray],dict[str,Any]]:
    state,mu,macro_index,micro_index,zre,initial_nodes=initial_hierarchy(
        control_history,fixed_macro,fixed_micro,mapping,variant
    )
    intervals=build_intervals(
        control_history,ledger,allocation,ledger,fixed_macro,fixed_micro,mapping,
        raw_model,mu,macro_index,variant,lane,
    )
    history_rows=[{'lane':name,**global_summary(state,mu,6.0,lane)}]
    ledger_rows=[]; checkpoints={'z_6p0_xH':state.xH.copy(),'z_6p0_x2':state.x2.copy(),'z_6p0_x3':state.x3.copy(),'z_6p0_e':state.e.copy()}
    max_diag={k:0.0 for k in ['photon','species','thermal','simplex','picard']}
    total_steps=0
    for inter in intervals:
        nsteps=max(1,int(math.ceil(inter.duration_s/(dt_target_myr*MYR_S))))
        dt=inter.duration_s/nsteps
        for step in range(nsteps):
            fmid=(step+0.5)/nsteps
            logd=(1-fmid)*np.log(inter.delta_start)+fmid*np.log(inter.delta_end)
            delta=np.exp(logd)
            # Re-enforce the exact Lagrangian volume normalization at each midpoint.
            delta*=float(np.sum(mu/delta))
            state,diag,_=evolve_step(
                state,dt,inter.z_mid,delta,inter.dln_delta_dt,mu,macro_index,
                inter,kappa_fit,lane,shape_lane,patchy,
            )
            total_steps+=1
            max_diag['photon']=max(max_diag['photon'],abs(diag['relative_residual']))
            max_diag['species']=max(max_diag['species'],diag['species_storage_relative_residual'])
            max_diag['thermal']=max(max_diag['thermal'],diag['thermal_storage_relative_residual'])
            max_diag['simplex']=max(max_diag['simplex'],diag['helium_simplex_error'])
            max_diag['picard']=max(max_diag['picard'],diag['picard_residual'])
            if step==nsteps-1:
                ledger_rows.append({'lane':name,'interval_index':inter.index,'z_mid':inter.z_mid,'z_end':inter.z_end,'dt_step_Myr':dt/MYR_S,'nsteps':nsteps,**diag})
        history_rows.append({'lane':name,**global_summary(state,mu,inter.z_end,lane)})
        if checkpoint:
            tag=str(inter.z_end).replace('.','p')
            checkpoints[f'z_{tag}_xH']=state.xH.copy(); checkpoints[f'z_{tag}_x2']=state.x2.copy(); checkpoints[f'z_{tag}_x3']=state.x3.copy(); checkpoints[f'z_{tag}_e']=state.e.copy()
    meta={'lane':name,'shape_lane':shape_lane,'variant':variant,'patchy':patchy,'dt_target_Myr':dt_target_myr,'total_steps':total_steps,'max_residuals':max_diag,'mu_sum':float(mu.sum()),'node_count':len(mu)}
    return pd.DataFrame(history_rows),pd.DataFrame(ledger_rows),checkpoints,meta


def temporal_convergence(histories:dict[float,pd.DataFrame],lane_name:str)->pd.DataFrame:
    rows=[]
    keys=sorted(histories,reverse=True)
    cols=['N1','N2','N3','xHII','xHeII','xHeIII','T_mass_K','Gamma_HI']
    endpoints={dt:histories[dt].iloc[-1] for dt in keys}
    for dt in keys:
        row={'lane':lane_name,'dt_target_Myr':dt}
        for col in cols: row[col]=endpoints[dt][col]
        rows.append(row)
    frame=pd.DataFrame(rows).sort_values('dt_target_Myr',ascending=False)
    if len(frame)>=3:
        a,b,c=[frame.iloc[i] for i in range(3)]
        scale=np.array([max(abs(c[col]),1e-30) for col in cols])
        e1=np.linalg.norm((np.array([a[col] for col in cols])-np.array([b[col] for col in cols]))/scale)
        e2=np.linalg.norm((np.array([b[col] for col in cols])-np.array([c[col] for col in cols]))/scale)
        order=math.log(e1/e2,2) if e1>0 and e2>0 else math.nan
        frame['coarse_medium_scaled_difference']=e1
        frame['medium_fine_scaled_difference']=e2
        frame['observed_order']=order
    return frame


def flexrt_audit(history:pd.DataFrame,ledger:pd.DataFrame)->pd.DataFrame:
    rows=[]
    cells=[1.0/2**i for i in range(10)]
    for rec in ledger.itertuples():
        h=history[np.isclose(history.z,rec.z_end)].iloc[0]
        N=np.array([h.N1,h.N2,h.N3])
        kappa=np.array([rec.kappa_G1,rec.kappa_G2a,rec.kappa_G2b])
        vchi=C_LIGHT*(1+rec.z_mid)/MPC_CM
        ref=vchi*N*kappa
        prev=None
        for level,dchi in enumerate(cells):
            finite=vchi/dchi*N*(-np.expm1(-kappa*dchi))
            rel=np.max(np.abs(finite-ref)/np.maximum(np.abs(ref),1.0))
            order=math.log(prev/rel,2) if prev is not None and rel>0 and prev>0 else math.nan
            rows.append({'lane':rec.lane,'interval_index':rec.interval_index,'z_mid':rec.z_mid,'level':level,'delta_chi_cMpc':dchi,'relative_difference_max':rel,'observed_order':order})
            prev=rel
    return pd.DataFrame(rows)


def execute(b0a_root:Path,r1_root:Path,b2b_root:Path,p04_root:Path,output:Path,checkpoint_dir:Path)->dict[str,Any]:
    output.mkdir(parents=True,exist_ok=True); checkpoint_dir.mkdir(parents=True,exist_ok=True)
    control_history=pd.read_csv(r1_root/'data/canonical_direct_history.csv')
    ledger=pd.read_csv(r1_root/'data/canonical_direct_photon_ledger.csv')
    allocation=pd.read_csv(find_one(r1_root,'photon_allocation_all_lanes.csv'))
    fit_table=pd.read_csv(r1_root/'data/gamma_conditioned_group_fit_tables.csv')
    mapping=pd.read_csv(p04_root/'data/density_mapping_colossus_1_3_10_port.csv')
    raw=pd.read_csv(p04_root/'data/checkpoint_raw_cellwise.csv.gz')
    raw_model=HIER.RawMacroOpacity(raw)
    fixed_macro=pd.read_csv(b0a_root/'data/fixed_macro_parcel_template_z6.csv')
    fixed_micro=load_fixed_micro(b0a_root/'data/fixed_micro_parcel_template_z6.npz')
    kappa_fit=EffectiveKappaFits(fit_table)
    lane=make_spectrum_lanes()[PRIMARY]

    production=[]; ledger_frames=[]; metas=[]; checkpoint_payload={}
    for shape in SHAPE_LANES:
        name=shape
        hist,led,ck,meta=run_lane(
            name,shape,'BASELINE',False,0.10,control_history,ledger,allocation,
            fixed_macro,fixed_micro,mapping,raw_model,kappa_fit,lane,
            checkpoint=(shape=='LOCAL_NEUTRAL_HAZARD_PRIMARY'),
        )
        production.append(hist); ledger_frames.append(led); metas.append(meta)
        if ck: checkpoint_payload.update({f'{name}_{k}':v for k,v in ck.items()})

    # Sensitivity histories use a coarser but still implicit matched solve.
    sensitivity_map={
        'MACRO_DENSITY_VARIANCE':('LOCAL_NEUTRAL_HAZARD_PRIMARY','MACRO_DENSITY_VARIANCE',False),
        'EARLY_REIONIZED_COOLER':('LOCAL_NEUTRAL_HAZARD_PRIMARY','EARLY_REIONIZED_COOLER',False),
        'EARLY_REIONIZED_HOTTER':('LOCAL_NEUTRAL_HAZARD_PRIMARY','EARLY_REIONIZED_HOTTER',False),
        'PATCHY_BETA_DIRICHLET':('LOCAL_NEUTRAL_HAZARD_PRIMARY','BASELINE',True),
    }
    for name,(shape,variant,patchy) in sensitivity_map.items():
        hist,led,_,meta=run_lane(
            name,shape,variant,patchy,0.20,control_history,ledger,allocation,
            fixed_macro,fixed_micro,mapping,raw_model,kappa_fit,lane,False,
        )
        production.append(hist); ledger_frames.append(led); metas.append(meta)

    history_all=pd.concat(production,ignore_index=True)
    ledger_all=pd.concat(ledger_frames,ignore_index=True)
    history_all.to_csv(output/'matched_phase_space_history.csv',index=False)
    ledger_all.to_csv(output/'matched_interval_ledgers.csv',index=False)
    np.savez_compressed(checkpoint_dir/'primary_node_history_checkpoints.npz',**checkpoint_payload)
    (output.parent/'lane_metadata.json').write_text(json.dumps(metas,indent=2),encoding='utf-8')

    # Temporal convergence for primary shape.
    conv_hist={0.4:run_lane('CONV_0P4','LOCAL_NEUTRAL_HAZARD_PRIMARY','BASELINE',False,0.4,control_history,ledger,allocation,fixed_macro,fixed_micro,mapping,raw_model,kappa_fit,lane,False)[0],
               0.2:run_lane('CONV_0P2','LOCAL_NEUTRAL_HAZARD_PRIMARY','BASELINE',False,0.2,control_history,ledger,allocation,fixed_macro,fixed_micro,mapping,raw_model,kappa_fit,lane,False)[0],
               0.1:history_all[history_all.lane=='LOCAL_NEUTRAL_HAZARD_PRIMARY'].copy()}
    conv=temporal_convergence(conv_hist,'LOCAL_NEUTRAL_HAZARD_PRIMARY')
    conv.to_csv(output/'temporal_convergence.csv',index=False)

    # R1 homogeneous auditor comparison at endpoint grid.
    comparisons=[]
    for lane_name,sub in history_all.groupby('lane'):
        for rec in sub.itertuples():
            ref=control_history[np.isclose(control_history.z,rec.z)]
            if ref.empty: continue
            r=ref.iloc[0]
            comparisons.append({'lane':lane_name,'z':rec.z,
                'N1_relative':rec.N1/r.N1-1,'N2_relative':rec.N2/r.N2-1,'N3_relative':rec.N3/r.N3-1,
                'xHII_difference':rec.xHII-r.xHII,'xHeII_difference':rec.xHeII-r.xHeII,
                'xHeIII_difference':rec.xHeIII-r.xHeIII,'T_relative':rec.T_mass_K/r.T_K-1,
                'Gamma_HI_relative':rec.Gamma_HI/r.Gamma_HI-1})
    pd.DataFrame(comparisons).to_csv(output/'r1_homogeneous_history_comparison.csv',index=False)

    flex=flexrt_audit(history_all,ledger_all)
    flex.to_csv(output/'flexrt_finite_cell_refinement.csv',index=False)

    max_photon=float(ledger_all.relative_residual.abs().max())
    max_species=float(ledger_all.species_storage_relative_residual.max())
    max_thermal=float(ledger_all.thermal_storage_relative_residual.max())
    max_simplex=float(ledger_all.helium_simplex_error.max())
    min_fraction=float(min(ledger_all.min_xH.min(),ledger_all.min_xHeI.min(),ledger_all.min_xHeII.min(),ledger_all.min_xHeIII.min()))
    production_lanes=set(SHAPE_LANES)
    shape_pass=all(
        ledger_all[ledger_all.lane==name].relative_residual.abs().max()<1e-8
        and ledger_all[ledger_all.lane==name].species_storage_relative_residual.max()<1e-8
        and ledger_all[ledger_all.lane==name].thermal_storage_relative_residual.max()<1e-8
        for name in production_lanes
    )
    smallest=flex.sort_values('delta_chi_cMpc').groupby(['lane','interval_index']).first().reset_index()
    flex_error=float(smallest.relative_difference_max.max())
    orders=flex[np.isfinite(flex.observed_order)]
    order_range=[float(orders.observed_order.min()),float(orders.observed_order.max())]
    observed_order=float(conv.observed_order.iloc[0]) if 'observed_order' in conv else math.nan
    exact_g3=bool((history_all.N4_exact==0).all() and (history_all.Gamma_HeII_exact==0).all())
    passed=bool(shape_pass and max_photon<1e-8 and max_species<1e-8 and max_thermal<1e-8 and max_simplex<1e-12 and min_fraction>=-1e-12 and exact_g3 and flex_error<0.01 and np.isfinite(observed_order))
    result={
        'stage':'P0.5-B2C2B0B-MATCHED-PHASESPACE-HISTORY-LOCK',
        'verdict':'PASS_B2C2B_AUTHORIZED_WITH_CAVEATS' if passed else 'FAIL_CLOSED_MATCHED_HISTORY',
        'gates':{
            'photon_ledger_relative_residual_max':max_photon,
            'species_storage_relative_residual_max':max_species,
            'thermal_storage_relative_residual_max':max_thermal,
            'helium_simplex_error_max':max_simplex,
            'minimum_species_fraction':min_fraction,
            'primary_G3_external_HeII_exact_zero':exact_g3,
            'three_shape_lanes_pass':shape_pass,
            'temporal_observed_order':observed_order,
            'FlexRT_smallest_cell_relative_error_max':flex_error,
            'FlexRT_observed_order_range':order_range,
            'raw_macro_shape_nearest_gamma_fill_count':int(raw_model.gamma_nearest_fill_count),
        },
        'measure_policy':{'fixed_mass_parcel_loads':True,'dot_W_J':0.0,'dot_w_I_given_J':0.0,'density_coordinate_role':'local rate and parcel volume only'},
        'lanes':sorted(history_all.lane.unique()),
        'B2C2B_authorization':{'authorized':passed,'conditions':['unresolved subtraction must use matched lane-specific histories','three absorber-shape lanes remain an envelope','no sink clipping or cross-species redistribution'] if passed else []},
        'forbidden_work_confirmed':['unresolved-sink subtraction','new front allocation','Q_M growth','source/f_esc calibration','primordial recombination implementation','primitive geometry transplant','Bianchi feedback'],
        'next_stage':'P0.5-B2C2B-UNRESOLVED-SINK-CLOSURE-LOCK' if passed else 'BLOCKED',
    }
    (output.parent/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--b0a-root',type=Path,required=True); p.add_argument('--r1-root',type=Path,required=True)
    p.add_argument('--b2b-root',type=Path,required=True); p.add_argument('--p04-root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True); p.add_argument('--checkpoints',type=Path,required=True)
    a=p.parse_args()
    print(json.dumps(execute(a.b0a_root,a.r1_root,a.b2b_root,a.p04_root,a.output,a.checkpoints),indent=2))
