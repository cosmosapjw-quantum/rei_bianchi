from pathlib import Path
import json
import math
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
D = ROOT / 'data'

results = json.loads((ROOT / 'results.json').read_text())
assert results['verdict'] == 'FAIL_CLOSED_ABSORPTION_CHEMISTRY_CAPACITY_MISMATCH'
assert results['accepted_matched_history_created'] is False
assert results['B2C2B_authorization']['authorized'] is False
assert results['next_stage'].endswith('JOINT-CHEMISTRY-SINK-RESERVOIR-HISTORY-LOCK')

hard = results['hard_gate']
assert hard['primary_all_intervals_fail'] is True
assert hard['maximum_sensitivity_envelope_failed_interval_count'] == 4
assert hard['interval_count'] == 5
assert hard['shape_lane_global_capacity_difference_max'] == 0.0
assert 0.45 < hard['primary_minimum_nonchemistry_fraction_bound_range'][0] < 0.46
assert 0.53 < hard['primary_minimum_nonchemistry_fraction_bound_range'][1] < 0.54
assert 0.13 < hard['maximum_envelope_nonchemistry_fraction_bound_max'] < 0.14

frame = pd.read_csv(D / 'matched_history_capacity_gate.csv')
assert set(frame.shape_lane.unique()) == {
    'LOCAL_NEUTRAL_HAZARD_PRIMARY',
    'RECOMBINATION_WEIGHTED_AUDITOR',
    'SCRIPT_SELF_SHIELDING_AUDITOR',
}
assert set(frame.chemistry_lane.unique()) == {
    'PRIMARY_DETERMINISTIC',
    'MACRO_DENSITY_VARIANCE',
    'EARLY_REIONIZED_COOLER',
    'EARLY_REIONIZED_HOTTER',
    'PATCHY_BETA_DIRICHLET',
}
assert len(frame) == 75
assert np.isfinite(frame['H_absorption_s-1_cMpc-3']).all()
assert (frame['H_absorption_s-1_cMpc-3'] > 0).all()

primary = pd.read_csv(D / 'primary_capacity_blocker.csv')
assert len(primary) == 5
assert (primary['H_capacity_deficit_s-1_cMpc-3'] > 0).all()
assert (~primary['H_feasible_without_separate_sink_reservoir']).all()
recomputed = (
    primary['H_absorption_s-1_cMpc-3']
    - primary['H_full_OTS_maintenance_s-1_cMpc-3']
    - primary['H_maximum_storage_rate_s-1_cMpc-3']
)
assert (
    np.abs(recomputed - primary['H_capacity_deficit_s-1_cMpc-3'])
    / np.maximum(np.abs(recomputed), 1.0)
).max() < 1e-12
fraction = 1.0 - (
    primary['H_full_OTS_maintenance_s-1_cMpc-3']
    + primary['H_maximum_storage_rate_s-1_cMpc-3']
) / primary['H_absorption_s-1_cMpc-3']
assert np.abs(
    fraction - primary['H_minimum_nonchemistry_fraction_bound']
).max() < 1e-12

maxenv = pd.read_csv(D / 'maximum_sensitivity_envelope_capacity.csv')
assert len(maxenv) == 5
assert (maxenv['H_capacity_deficit_s-1_cMpc-3'] > 0).sum() == 4
assert set(maxenv['max_envelope_chemistry_lane']) == {'MACRO_DENSITY_VARIANCE'}

# Shape lanes redistribute the same total and cannot change capacity.
spread = (
    frame.groupby(['chemistry_lane', 'z_mid'])[
        'H_capacity_deficit_s-1_cMpc-3'
    ]
    .agg(lambda x: x.max() - x.min())
    .max()
)
assert spread == 0.0

symbolic = json.loads((ROOT / 'symbolic_capacity_gate_results.json').read_text())
assert symbolic['status'] == 'PASS_EXACT_CAPACITY_NO_SOLUTION_GATE'
assert symbolic['factor_identity_residual'] == '0'
assert symbolic['full_OTS_stoichiometric_residual'] == ['0'] * 5
assert symbolic['primary_G3_absorption'] == 0
assert symbolic['primary_external_HeII_photoionization'] == 0

precision = json.loads((D / 'high_precision_capacity_audit.json').read_text())
assert precision['status'] == 'PASS_HIGH_PRECISION_CAPACITY_AUDIT'
assert float(precision['maximum_relative_difference_to_durable_csv']) < 1e-12
assert precision['maximum_sensitivity_failed_interval_count_recomputed'] == 4

wolfram = json.loads((ROOT / 'WOLFRAM_EXECUTION_STATUS.json').read_text())
assert wolfram['native_execution_performed'] is False
assert wolfram['fallback_status'] == 'PASS_EXACT_CAPACITY_NO_SOLUTION_GATE'

special = json.loads((ROOT / 'PRECISE_SPECIAL_FUNCTIONS_EXECUTION_STATUS.json').read_text())
assert special['plugin_namespace_available'] is False
assert special['status'] == 'PASS_HIGH_PRECISION_CAPACITY_AUDIT'
assert special['production_operator_replaced'] is False

state = json.loads((ROOT / 'STAGE_STATE.json').read_text())
assert state['status'] == 'DURABLE_FAIL_CLOSED_B2C2B_DENIED'
assert state['accepted_matched_history_created'] is False
assert state['B2C2B_authorized'] is False

for attempt in [
    'ATTEMPT_1_EXPLICIT_PHOTO_BOUNDARY_VIOLATION',
    'ATTEMPT_2_CONSTANT_SOURCE_IMPLICIT_NONLINEAR_FAILURE',
]:
    status = json.loads((ROOT / 'state' / attempt / 'ATTEMPT_STATUS.json').read_text())
    assert status['scientific_outputs_authoritative'] is False

# The hard gate forbids fabricating downstream matched-history products.
for forbidden in [
    'matched_phase_space_history.csv',
    'matched_thermal_history.csv',
    'unresolved_sink.csv',
    'front_allocation.csv',
]:
    assert not (D / forbidden).exists()

recomb = json.loads((ROOT / 'RECOMBINATION_EXTERNAL_DEPENDENCY_RECEIPT.json').read_text())
assert recomb['dependency_status'] == 'EXTERNAL_NOT_LOADED'
assert recomb['contains_astrophysical_reionization'] is False
neutral = json.loads((ROOT / 'neutral_island_exclusion_ledger.json').read_text())
assert neutral['included_in_ionized_absorption'] is False

print(
    'P0.5-B2C2B0B verification: DURABLE FAIL-CLOSED; '
    'B2C2B DENIED; joint dynamic chemistry/sink reservoir required'
)
