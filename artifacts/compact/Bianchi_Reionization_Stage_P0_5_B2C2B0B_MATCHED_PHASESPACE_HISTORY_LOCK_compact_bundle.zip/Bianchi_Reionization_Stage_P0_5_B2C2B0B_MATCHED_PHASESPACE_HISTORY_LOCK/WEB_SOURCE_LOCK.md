# Web source lock

1. **Mellema et al., C2-Ray, arXiv:astro-ph/0508416**
   - Bound-free photon depletion must equal the photoionizations caused by
     those photons.
   - Used to justify a one-event/one-ledger coupling between transport and
     chemistry.

2. **Friedrich et al., H/He C2-Ray, arXiv:1201.0602**
   - Helium, multifrequency heating and the full coupled OTS approximation are
     solved as one non-equilibrium transport/chemistry system.

3. **Choudhury & Chakraborty, SCRIPT sink model, arXiv:2504.03384**
   - Emissivity, clumping, mean free path, photoionization rate and density
     require a self-consistent sink closure rather than independent tuning.

4. **Tohfa et al., MFP emulator, arXiv:2602.03923**
   - The emulator provides an effective subgrid opacity as a function of
     wavelength, redshift, local reionization redshift, Gamma and box-scale
     density.

5. **Cain & D'Aloisio, FlexRT I, arXiv:2409.04521**
   - Flexible opacity prescriptions and adaptive photon transport motivate a
     modular opacity backend, while event accounting must remain conservative.

No literature number was fitted to the capacity bound.
