@Web+Wolfram Stage P0.5-B2C2B0C-JOINT-CHEMISTRY-SINK-RESERVOIR-HISTORY-LOCK를 실행해줘.

B2C2B0B의 capacity fail-closed result, B2C2B0A fixed-weight hierarchical
parcel templates, R1 current-Gamma direct opacity, exact-zero primary G3,
full-OTS node chemistry, FLRW receipts, neutral-island exclusion과
recombination external-dependency receipt를 정본으로 유지한다.

이번 단계는 post-hoc

Ndot_unresolved = Ndot_abs - Ndot_maint

subtraction을 수행하는 단계가 아니다. Total effective absorption을
transport/chemistry 진화 안에서 diffuse chemistry channel과 별도의 dynamic
sink reservoir channel로 동시에 분해해 bounded joint history를 구성하는
B2C2B0C다.

1. 계산 전에 새 durable B2C2B0C directory, input lock, stage state,
   receipts, manifest와 SHA256SUMS를 생성해줘.

2. 기존 B2C2B0B prototype histories는 전부 auditor/quarantine으로 유지하고,
   z=6 state에서 새 joint history를 처음부터 진화해줘. 중간 splice는 금지한다.

3. R1 total H I effective opacity를 매 step 다음 비음수 competing hazards로
   분해해줘.

   kappa_HI,total^eff
     = kappa_HI,diffuse
       + kappa_HI,sink,

   kappa_HI,diffuse >= 0,
   kappa_HI,sink >= 0.

   합은 R1 current-Gamma opacity를 exact하게 재현해야 한다. Total opacity를
   새 history에 맞춰 자유 normalization하지 마.

4. Absorbed H I photons는 동일 hazard fractions로 동시에 분배해줘.

   j_H,total = j_H,diffuse + j_H,sink,

   j_H,diffuse
     = (kappa_diffuse/kappa_total) j_H,total,

   j_H,sink
     = (kappa_sink/kappa_total) j_H,total.

   이 partition을 history 종료 후 residual subtraction으로 만들지 마.

5. Diffuse channel은 B2C2B0A fixed macro/micro parcels와 full-OTS chemistry를
   사용해줘. 각 step에서 diffuse capacity cone

   j_H,diffuse
     <= m_H,diffuse
        + available neutral-storage rate

   를 hard constraint로 유지하고 clipping하지 마.

6. Sink channel에는 명시적 dynamic state를 도입해줘. 최소한 macro/group별
   다음을 포함해줘.

   - N_HI,sink^c,
   - N_HII,sink^c,
   - u_sink 또는 T_sink,
   - kappa_HI,sink,g,
   - recombination/relaxation 또는 evaporation transfer rates.

   Sink H nuclei normalization과 positivity를 algebraically 또는 constrained
   variables로 보장해줘.

7. Sink opacity는 arbitrary algebraic bucket으로 두지 마. Sink neutral column,
   geometry/scale and ionization state에서 opacity를 계산하고,

   kappa_diffuse + kappa_sink = kappa_R1

   residual을 monolithic constraint로 닫아줘. 해가 없으면 fail closed해줘.

8. Sink-to-diffuse mass transfer가 있으면 nuclei, thermal energy와 opacity
   transfer ledger를 모두 저장해줘. Neutral-island transfer와 sink reservoir를
   동일시하지 마.

9. 세 micro absorber-shape lane을 모두 진화해줘.

   A. LOCAL_NEUTRAL_HAZARD_PRIMARY
   B. RECOMBINATION_WEIGHTED_AUDITOR
   C. SCRIPT_SELF_SHIELDING_AUDITOR

   Raw local-Gamma asset limitation을 유지하고 lane envelope를 fitting하지 마.

10. 다음 joint ledgers를 닫아줘.

    - total photon number,
    - diffuse H/He species storage,
    - sink H nuclei storage,
    - diffuse and sink thermal energy,
    - total effective opacity,
    - exact-zero primary G3/external HeII.

    hard relative residual <1e-8,
    target <1e-10.

11. B2C2B0B capacity table을 regression target이 아닌 necessary-condition
    auditor로 재실행해줘. 새 joint history에서는 every step/interval에서
    diffuse capacity deficit <= 0이어야 하고, 초과 absorption은 sink state로
    동역학적으로 흘러야 한다.

12. dt-halving 또는 embedded reference로 temporal convergence를 확인해줘.
    Positivity projection이나 max(0,...) clipping으로 order를 만들지 마.

13. FlexRT finite-cell deposition을 diffuse/sink competing hazards로 다시
    검사하고 smallest-cell error <1%, first-order differential-limit
    convergence를 요구해줘.

14. Wolfram native runtime이 있으면 capacity complementarity, photon
    partition, nuclei/energy/opacity identities를 실행해줘. 없으면 native
    pending 상태와 exact symbolic fallback을 보존해줘. Precise Special
    Functions는 닫힌 moments의 독립 oracle로만 사용해줘.

15. 이번 B2C2B0C에서는 post-hoc unresolved-sink subtraction, 새 front
    allocation, Q_M growth, source/f_esc calibration, primordial recombination
    implementation, primitive geometry transplant와 Bianchi feedback을 시작하지
    마.

세 shape lane 모두에서 bounded joint chemistry-sink history와 모든 ledgers가
닫힌 뒤에만 P0.5-B2C2B-UNRESOLVED-SINK-CLOSURE-LOCK를 다시 승인해줘.
