ClearAll["Global`*"];

x1 = x0 + dt (jH - mH + cH)/nH;
deficit = jH - mH - nH (1 - x0)/dt;

boundaryIdentity = FullSimplify[
 x1 - 1 - dt (deficit + cH)/nH
];

noBoundedSolution = Reduce[
 nH > 0 && dt > 0 && 0 <= x0 <= 1 && cH >= 0 &&
 deficit > 0 && x1 <= 1,
 {jH, mH, nH, dt, x0, cH}, Reals
];

shapeAllocation = FullSimplify[
 Sum[q[i], {i, 1, n}] jH,
 Assumptions -> Sum[q[i], {i, 1, n}] == 1
];

photonPartition = FullSimplify[
 jDiffuse + jSink - jTotal,
 Assumptions -> jDiffuse + jSink == jTotal
];

B = {{-1, 0, 0}, {1, 0, 0}, {0, -1, 0},
     {0, 1, -1}, {0, 0, 1}};
mExt = {sHI, sHeI, -sHeIII};
sRec = {sHI, -sHI, sHeI, -sHeI - sHeIII, sHeIII};
stoichResidual = FullSimplify[B.mExt + sRec];

<|
 "BoundaryIdentityResidual" -> boundaryIdentity,
 "NoBoundedSolution" -> noBoundedSolution,
 "ShapeAllocationTotal" -> shapeAllocation,
 "PhotonPartitionResidual" -> photonPartition,
 "FullOTSStoichiometricResidual" -> stoichResidual,
 "PrimaryG3Absorption" -> 0,
 "PrimaryExternalHeIIPhotoionization" -> 0
|>
