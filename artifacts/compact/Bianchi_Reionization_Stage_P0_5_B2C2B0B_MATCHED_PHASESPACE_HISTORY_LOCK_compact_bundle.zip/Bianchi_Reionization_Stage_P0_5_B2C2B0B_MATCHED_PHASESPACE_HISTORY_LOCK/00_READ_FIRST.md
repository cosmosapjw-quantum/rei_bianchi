# Stage P0.5-B2C2B0B — Matched phase-space history lock

## Verdict

\[
\boxed{
\text{P0.5-B2C2B0B}
=
\texttt{DURABLE\_FAIL\_CLOSED}
}
\]

\[
\boxed{
\text{B2C2B unresolved-sink subtraction}
=
\texttt{NOT\ AUTHORIZED}
}
\]

No accepted matched history was created. Before temporal integration, the
necessary diffuse-chemistry capacity condition fails:

\[
\boxed{
J_H
\le
M_H
+
\frac{N_H^c(1-X_{\rm HII,start})}{\Delta t}
}
\]

where \(J_H\) is the R1 ionized-phase H I absorption event rate and \(M_H\)
is the full-OTS maintenance/cycling rate on the locked hierarchical parcels.

For the primary deterministic closure every interval violates this condition.
The minimum fraction of H I absorption that cannot be represented by diffuse
photoionization plus full-OTS cycling is bounded below by

\[
0.453035
\le
f_{\rm nonchem}^{\rm min}
\le
0.538174.
\]

The remaining neutral storage would saturate after only

\[
0.044245\text{--}0.155900\ {
m Myr},
\]

whereas the locked intervals last roughly 20--23 Myr.

## Representative values

At the first interval,

\[
J_H=5.016761e+50,
\qquad
M_H=2.532577e+50
\quad
[{
m s^{-1}\,cMpc^{-3}}].
\]

At the final interval,

\[
J_H=4.584139e+50,
\qquad
M_H=2.112410e+50.
\]

Changing only the micro absorber-shape lane cannot repair the global gate,
because all three lanes preserve the same macro absorption exactly.

The strongest locked chemistry sensitivity, `MACRO_DENSITY_VARIANCE`, still
fails four of five intervals. Its largest required non-chemistry fraction is

\[
0.130661.
\]

This is a necessary lower bound on a distinct absorption channel, not an
accepted post-hoc unresolved-sink measurement.

## Consequence

Assigning all R1 effective H I absorption to the diffuse node chemistry would
force \(X_{\rm HII}>1\). Positivity projection, clipping, source redistribution
or a smaller timestep cannot change the interval-integrated capacity
inequality.

The correct next operation is to introduce a dynamically evolved sink
reservoir inside the transport/chemistry history itself. The total R1 opacity
must be partitioned at every step into competing diffuse and sink hazards,
with separate nuclei, thermal and opacity ledgers. Only after that joint
history closes may a physical unresolved-sink claim be made.

## Work stopped by the hard gate

The following requested downstream tests were not promoted because no bounded
matched diffuse history exists:

- node thermal-history convergence;
- temporal-order acceptance;
- matched-history FlexRT refinement;
- comparison of a nonexistent accepted history to R1;
- B2C2B unresolved-sink subtraction.

The B2C2B0A fixed-weight closure, R1 opacity operator, exact-zero primary G3,
FLRW receipts, neutral-island exclusion and external recombination boundary
remain intact.
