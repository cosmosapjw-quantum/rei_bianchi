# B2C2B0B state ledger

## Canonical input state

- B2C2B0A fixed z=6 macro/micro parcel weights and quantile labels;
- R1 current-Gamma direct opacity and exact-zero primary G3;
- B2C0 full-OTS event algebra;
- inherited FLRW/background/front control receipts;
- neutral-island transfer excluded but not set to zero;
- primordial recombination external and unloaded.

## Attempt 1

An explicit node source prototype allocated all effective absorption to local
chemistry. It exhausted local neutral inventories and violated the bounded
species cone. No history was accepted.

## Attempt 2

Implicit and relaxed prototypes reduced local stiffness but retained the same
interval-integrated capacity mismatch. Convergence required hidden positivity
handling or impractically small steps. No history was accepted.

## Accepted operation

`matched_history_feasibility_gate.py` evaluates a solver-independent necessary
condition before history integration. It is the authoritative B2C2B0B result.

## Current authority

Authoritative:

- `results.json`;
- `data/matched_history_capacity_gate.csv`;
- `data/primary_capacity_blocker.csv`;
- `data/maximum_sensitivity_envelope_capacity.csv`;
- `symbolic_capacity_gate_results.json`;
- `data/high_precision_capacity_audit.json`.

Non-authoritative prototypes are quarantined under `state/`.
