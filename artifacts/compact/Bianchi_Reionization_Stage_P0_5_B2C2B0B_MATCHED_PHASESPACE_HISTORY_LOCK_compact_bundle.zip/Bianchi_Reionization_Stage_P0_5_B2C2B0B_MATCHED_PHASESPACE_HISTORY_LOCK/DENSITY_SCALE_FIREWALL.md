# Density-scale firewall

The P0.4 emulator's density input remains the original box-scale coordinate
\(D_{L,\rm emulator}\). Local atomic and recombination rates instead use

\[
D_{L,\rm mass}
=
D_{L,\rm emulator}/
\langle D_{L,\rm emulator}\rangle_{W_{\rm fixed}}.
\]

The required mass adapter lies in

\[
1.022616455
\le
C_D
\le
1.031433838.
\]

The adapter is not supplied to the emulator. It only enforces

\[
\sum_{J,I}W_Jw_{I|J}D_{L,\rm mass}\Delta_{\rm sub}=1.
\]

Measured maximum residual:

\[
0.000e+00.
\]

Flat identification of P0.4 box density with B2C0 local gas overdensity is
forbidden.
