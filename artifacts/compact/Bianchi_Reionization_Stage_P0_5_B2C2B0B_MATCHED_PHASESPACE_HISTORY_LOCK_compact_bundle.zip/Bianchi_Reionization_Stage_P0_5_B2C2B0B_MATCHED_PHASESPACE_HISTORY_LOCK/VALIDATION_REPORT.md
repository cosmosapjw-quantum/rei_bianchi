# Validation report

## Overall decision

**Durable fail-closed. B2C2B is not authorized.**

A solver-independent necessary boundedness condition fails before a matched
history can be integrated. The result is reproduced by a fresh canonical run
and a comprehensive validator.

## Hard-gate summary

| Check | Result |
|---|---:|
| Primary intervals failing | 5/5 |
| Maximum sensitivity envelope intervals failing | 4/5 |
| Shape-lane global-capacity spread | 0.000e+00 |
| Primary lower-bound non-chemistry fraction | 0.453035--0.538174 |
| Primary boundary saturation time | 0.044245--0.155900 Myr |
| Accepted matched history | no |

The necessary condition is

\[
J_H\le M_H+N_H^c(1-X_{\rm HII,start})/\Delta t.
\]

A positive deficit proves that any diffuse-only update would leave the bounded
species cone. This conclusion is independent of the local absorber-shape
redistribution because all three shape lanes preserve the same global
absorption.

## Scope of non-execution

Thermal-history, temporal-order and matched-history FlexRT tests are not marked
failed; they are **not executed after the earlier hard gate**. Running them
would require either a hidden sink channel, positivity clipping or an
unphysical species state.

## Independent checks

- exact symbolic factorization of the capacity inequality: pass;
- full-OTS stoichiometry: pass;
- 80-dps recomputation of durable capacity rows: pass;
- fresh feasibility executable: exit 0;
- comprehensive validator: exit 0.

## Tool limitation

Native Wolfram and Precise Special Functions runtimes were not available in
this environment. Reproducible Wolfram Language input is supplied, and exact
SymPy plus 80-dps mpmath fallbacks pass. No native execution is claimed.
