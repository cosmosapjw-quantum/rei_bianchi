# Measure-evolution policy

Primary policy:

```text
FIXED_WEIGHT_LAGRANGIAN_MACRO_MICRO_PARCELS
```

\[
\dot W_J=0,\qquad \dot w_{I|J}=0.
\]

The fixed weight hashes are identical at all five midpoint checks.

\[
\max_z\|\Delta W_J\|_\infty
=
0.000e+00,
\]

\[
\max_z\|\Delta w_{I|J}\|_\infty
=
0.000e+00.
\]

The coordinates \(\Delta_{\rm sub}\) and \(T\) move through fixed quantile
labels. This is coordinate transport, not probability creation or removal.

A future Eulerian PDF implementation must provide conservative weight-flux
ledgers. Rebuilding a redshift-dependent PDF while omitting the
\(\dot W\,n\) storage term is fail-closed.
