from pathlib import Path
import json
import numpy as np
import pandas as pd
root=Path(__file__).resolve().parents[1]
r=json.loads((root/'results.json').read_text())
assert r['verdict']=='DURABLE_PASS' and r['all_hard_gates_pass']
h=pd.read_csv(root/'data/primary_exact_zero_G3_history.csv')
assert (h.N4_exact==0).all() and (h.Gamma_HeII_exact==0).all()
assert np.max(np.abs(h.xHeI+h.xHeII+h.xHeIII-1))<1e-12
assert h[['xHeI','xHeII','xHeIII']].to_numpy().min()>=0
he=pd.read_csv(root/'data/primary_heiii_dynamic_ledger.csv')
assert he.global_decay.all()
assert he.relative_dynamic_identity_residual.abs().max()<1e-10
assert he.pointwise_identity_residual_max.max()<1e-10
ph=pd.read_csv(root/'data/primary_photon_ledger.csv')
th=pd.read_csv(root/'data/primary_thermal_energy_ledger.csv')
assert ph.relative_residual.abs().max()<1e-10
assert th.relative_residual.abs().max()<1e-10
assert (th.integrated_threshold_HeII==0).all()
ps=pd.read_csv(root/'data/phase_space_rate_sign_summary.csv')
det=ps[ps.closure=='DETERMINISTIC']
assert det['net_HeIII_rate_s-1_cMpc-3'].lt(0).all()
assert ps.unsupported_identity_relative_error_max.max()<1e-12
tc=pd.read_csv(root/'data/timestep_convergence.csv')
orders=tc.observed_order.dropna(); assert orders.between(.8,1.2).all()
mean=json.loads((root/'data/mean_and_hard_auditor_results.json').read_text())
assert mean['mean_global_decay_all'] and mean['hard_G3_support_positive'] and mean['hard_support_cone_closed']
assert 300<mean['mean_tRec_Myr_range'][0]<600 and 300<mean['mean_tRec_Myr_range'][1]<600
sf=json.loads((root/'data/special_function_benchmarks.json').read_text()); assert sf['plugin']=='Precise Special Functions'
wf=json.loads((root/'wolfram_validation_results.json').read_text()); assert wf['status']=='PASS' and wf['PrimitiveResidual']==0 and wf['StoichiometricResidual']==[0,0,0,0,0]
plugins=json.loads((root/'PLUGIN_USAGE_LEDGER.json').read_text()); assert plugins['Precise_Special_Functions']['status']=='PASS' and plugins['Wolfram']['status']=='PASS'
assert (root/'RUNTIME_INTERRUPTION_RECOVERY_ADDENDUM.md').exists()
print('P0.5-B2C1C durable gates: PASS')
