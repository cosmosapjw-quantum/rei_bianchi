# B2C1C state ledger

Authoritative: `results.json`, cumulative primary ledgers, phase-space signs,
timestep convergence, special-function benchmarks, and Wolfram results.

Interrupted pre-stage output was not inherited. A post-processing quadrature
ledger is auditor-only; the strict cumulative-ODE ledger is authoritative.
