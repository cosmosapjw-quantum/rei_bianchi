# Stage P0.5-B2C1C — Primary He III decay lock

## Verdict

\[
\boxed{\text{P0.5-B2C1C}=\texttt{DURABLE\_PASS}}
\]

The primary MFP-consistent stellar lane enforces

\[
N_{\gamma,G3}^{\rm source}=0,
\qquad
\Gamma_{\rm HeII}^{\rm ext}=0
\]

algebraically, without a numerical photon floor. He III is evolved as a
coupled recombination/decay variable inside the full-OTS H/He/thermal system.

## Primary result

\[
x_{\rm HeIII}: 0.002842000\rightarrow 0.002214519911,
\qquad
x_{\rm HeIII}(5.5)/x_{\rm HeIII}(6)=0.779211791312.
\]

Every macro step has negative global He III evolution. The exact-zero run
agrees with the durable B2B primary history to 2.506e-11 relative in
\(x_{\rm HeIII}\).

## Full-OTS decay equation

\[
\dot x_{\rm HeIII}
=n_eC_{\rm HeII}(T)x_{\rm HeII}
-n_e\alpha_{\rm HeIII}^{\rm OTS,eff}x_{\rm HeIII},
\]

\[
\alpha_{\rm HeIII}^{\rm OTS,eff}
=\alpha_B+(1-y_{2a})(\alpha_A-\alpha_B).
\]

The B2C1B unsupported static HeII-to-HeIII demand is the positive full-OTS
He III recombination loss, not an external G3 source.

## Conservation and energy gates

| Gate | Maximum residual |
|---|---:|
| Photon number | 2.480e-11 |
| Thermal energy | 3.245e-12 |
| Integrated He III dynamic identity | 1.499e-12 |
| Pointwise He III identity | 4.995e-16 |
| Helium normalization | 1.110e-16 |

All occupied photon groups and species remain positive. The primary He II
threshold-energy input is exactly zero. H/He threshold energy, photoheating,
recombination/collisional/free-free cooling, and expansion work are stored
interval by interval.

## Mean-history and phase-space signs

\[
t_{\rm rec,HeIII}^{\rm OTS}=372.884\text{--}505.485\ {\rm Myr}.
\]

Mean-history collisional/recombination ratio:

\[
1.609e-15\text{--}2.562e-13.
\]

The full phase-space integral remains globally decaying. Hot bins above
50296.4 K can have positive collisional production; they occupy at most
4.800e-05 of the volume and 2.016e-03 of the mass. No binwise sign is clipped.

## Temporal convergence

\[
1.000201\le p_{\rm obs}\le 1.001009.
\]

## Precise Special Functions and Wolfram

Precise Special Functions supplied 80-digit values of \({}_2F_1\),
\(\Gamma(3),\Gamma(4)\), and \(\zeta(3),\zeta(4)\). The analytic LCDM
power-law-rate auditor gives survival 0.776532214573, differing from the direct
locked-history survival by 4.366e-04. No atomic coefficient was fitted to an
endpoint.

Wolfram verifies the hypergeometric primitive, exact primary
\(\Gamma_{\rm HeII}=0\), full-OTS stoichiometry, and first-order backward
Euler error.

## Final decision

The primary external diffuse-maintenance vector for B2C2 is

\[
\boxed{(\dot N_{\rm HI\to HII},\dot N_{\rm HeI\to HeII},0)}.
\]

He III recombination remains in species evolution, internal OTS
cross-ionization, and thermal ledgers. The next authorized stage is
`P0.5-B2C2-UNRESOLVED-SINK-FRONT-ALLOCATION`. Bianchi propagation remains
unauthorized.
