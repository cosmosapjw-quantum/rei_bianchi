ClearAll["Global`*"];
A = Rationalize[2.445064876420066*^-20, 0];
r = Rationalize[4.194911127295288, 0];
H0 = Rationalize[67.4*10^5/3.085677581491367*^24, 0];
Om = Rationalize[0.315, 0]; Ol = Rationalize[0.685, 0]; q = Om/Ol;
primitive[y_] := y^r/r Hypergeometric2F1[1/2, r/3, 1+r/3, -q y^3];
opticalDepth = N[A/(H0 Sqrt[Ol]) (primitive[7]-primitive[13/2]), 40];
survival = N[Exp[-opticalDepth], 40];

Clear[rr,qq,yy];
primitiveGeneral[yy_] := yy^rr/rr Hypergeometric2F1[1/2,rr/3,1+rr/3,-qq yy^3];
primitiveResidual = FullSimplify[D[primitiveGeneral[yy],yy]-yy^(rr-1)/Sqrt[1+qq yy^3],Assumptions->{yy>0,rr>0,qq>0}];

Clear[aA,aB,y2a,ne,CHeII,xHeII,xHeIII];
aEff = aB+(1-y2a)(aA-aB);
rate = ne CHeII xHeII-ne aEff xHeIII;
B={{-1,0,0},{1,0,0},{0,-1,0},{0,1,-1},{0,0,1}};
source={sHI,-sHI,sHeI,-sHeI-sHeIII,sHeIII};
mext={sHI,sHeI,-sHeIII};
stoich=FullSimplify[B.mext+source];
be=Normal@Series[-t/h Log[1-h lambda]-lambda t,{h,0,2}];
coefficient=N[Gamma[4]Zeta[4]/(Gamma[3]Zeta[3]),60];
<|"AlphaEffOTS"->aEff,"HeIIIRate"->rate,"ExactPrimaryGammaHeII"->0,"PrimitiveResidual"->primitiveResidual,"OpticalDepth"->opticalDepth,"Survival"->survival,"StoichiometricResidual"->stoich,"BackwardEulerGlobalErrorSeries"->be,"BlackbodyMeanPhotonCoefficient"->coefficient|>
