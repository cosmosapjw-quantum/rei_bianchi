# D0 completion and PR roadmap

| PR | Scope | State |
|---|---|---|
| 1 | B2C1C primary He III decay | COMPLETE |
| 2 | B2C2 unresolved sink and front allocation | NEXT |
| 3 | B2D source ensemble and Q/Gamma closure | PLANNED |
| 4 | B2E homogeneous FLRW/FlexRT end-to-end | PLANNED |
| 5 | C0 Bianchi I/V/II UV coupling | PLANNED |
| 6 | C1A finite tilt/electron-frame coupling | PLANNED |
| 7 | C1B all-11 Bianchi types and exceptional branches | PLANNED |
| 8 | C2 CMB Thomson/Stebbins/full-kinetic coupling | PLANNED |
| 9 | C3 anisotropic line-of-sight and CAMB-level output | PLANNED |
| 10 | D0 all-type regressions and benchmark suite | PLANNED |
| 11 | D1 equation compendium, claim gates, docs/release | PLANNED |

A twelfth PR is reserved for cross-cutting integration hardening.
