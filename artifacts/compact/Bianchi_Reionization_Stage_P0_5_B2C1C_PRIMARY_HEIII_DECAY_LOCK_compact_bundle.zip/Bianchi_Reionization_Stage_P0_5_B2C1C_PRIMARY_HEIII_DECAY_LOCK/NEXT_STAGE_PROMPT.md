@Web+Wolfram Stage P0.5-B2C2-UNRESOLVED-SINK-FRONT-ALLOCATION를 실행해줘.

B2C1C exact primary G3=0, Gamma_HeII^ext=0, dynamic HeIII decay,
B2C1B multigroup H/He transmission/allocation, B2C1A Q firewall와 B2C0
phase-space maintenance를 정본으로 유지한다.

1. 새 durable directory, input lock, state, receipts, manifest, SHA256SUMS를
   계산 전에 생성해줘.
2. Primary external diffuse-maintenance vector는 정확히
   (m_HI->HII, m_HeI->HeII, 0)으로 둬.
3. group/species ionized absorption을 causal ledger와 direct finite-tau
   transmission/allocation에서 계산해줘.
4. Ndot_abs,ion=Ndot_maint,diffuse+Ndot_unresolved로 정의하고 음수
   unresolved component는 clipping 없이 fail closed해줘.
5. species-resolved front costs와 Q_M evolution을 연결하되 primary HeIII
   external front cost는 source support가 없으면 exact zero로 유지해줘.
6. storage, redshift, maintenance, unresolved, front, source의 full ledger를
   residual <1e-8, positivity, 0<=f_front<=1로 검증해줘.
7. topology/transmission alternatives는 systematic envelope로 유지해줘.
8. source/f_esc calibration과 Bianchi geometry는 아직 시작하지 마.
