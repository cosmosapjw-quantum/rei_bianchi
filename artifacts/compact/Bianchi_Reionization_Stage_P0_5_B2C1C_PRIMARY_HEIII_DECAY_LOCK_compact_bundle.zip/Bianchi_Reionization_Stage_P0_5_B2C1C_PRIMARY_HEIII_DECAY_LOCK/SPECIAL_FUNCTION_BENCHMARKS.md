# Special-function benchmark ledger

Plugin: **Precise Special Functions**.

\[
k(z)=A(1+z)^r,
\quad A=2.445064876420e-20\ {m s}^{-1},
\quad r=4.194911127295.
\]

\[
\intrac{y^{r-1}}{\sqrt{1+qy^3}}dy
=rac{y^r}{r}\,{}_2F_1\left(rac12,rac r3;1+rac r3;-qy^3ight).
\]

The 80-digit plugin values are stored in
`data/special_function_benchmarks.json`. Analytic-fit optical depth:
0.252917150360649; survival: 0.776532214572650; direct locked-history survival: 0.776193318131972.

\[
\langle Eangle/(k_BT)=\Gamma(4)\zeta(4)/[\Gamma(3)\zeta(3)]
=2.701178032919064.
\]

At 80,000 K this is 18.621561048 eV. This untruncated Planck value is an audit,
not the finite-band production source moment.
