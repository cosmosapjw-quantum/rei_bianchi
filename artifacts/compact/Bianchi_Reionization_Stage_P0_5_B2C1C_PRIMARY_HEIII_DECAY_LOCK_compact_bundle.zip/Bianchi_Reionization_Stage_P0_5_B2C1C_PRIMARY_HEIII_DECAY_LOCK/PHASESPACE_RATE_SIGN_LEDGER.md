# Phase-space He III rate-sign ledger

Global deterministic and Beta/Dirichlet integrals remain negative at every
history node. Positive collisional-production bins are retained.

- maximum positive-bin volume fraction: 4.79962753e-05
- maximum positive-bin mass fraction: 2.01584931e-03
- minimum positive-net temperature: 50296.405405 K
- maximum unsupported-demand identity residual: 4.126e-16
- deterministic global collisional/recombination range: 2.162674e-02--1.130192e-01
