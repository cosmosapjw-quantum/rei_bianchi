from __future__ import annotations
import argparse,importlib.util,json,sys,math
from pathlib import Path
import numpy as np,pandas as pd
from monolithic_model_b2a import beta_heii
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b2c0',HERE/'phase_space_kernel_b2c0.py'); m=importlib.util.module_from_spec(spec); sys.modules[spec.name]=m; spec.loader.exec_module(m)
MPC=m.MPC_CM
def run(history,out):
 h=pd.read_csv(history); rows=[]; grids=[]
 for r in h.itertuples():
  state=m.HistoryState(float(r.z),float(r.xHII),float(r.xHeII),float(r.xHeIII),float(r.T_K),float(r.Gamma_HI)); c0=m.calibrate_mhr_c0(state.z); cg=m.build_grid(state,256,32,c0); offsets=m.calibrate_fraction_offsets(state,cg)
  for closure in ['DETERMINISTIC','PATCHY_BETA_DIRICHLET']:
   grid=m.build_grid(state,192,32,c0); means=m.conditional_means(state,grid,offsets); moments=m.conditional_moments(means,closure); ker=m.full_ots_kernel(state,grid,moments)
   coll=ker['pair_heii']*beta_heii(grid['temperature']); rec=ker['m_ext'][...,2]; net=coll-rec; w=grid['weight']; d=grid['delta']; conv=MPC**3/(1+state.z)**3; pos=net>0
   ct=float(np.sum(w*coll)*conv); rt=float(np.sum(w*rec)*conv); nt=float(np.sum(w*net)*conv); vpos=float(np.sum(w*pos)); mpos=float(np.sum(w*d*pos)/np.sum(w*d)); minT=float(np.min(grid['temperature'][pos])) if np.any(pos) else math.nan
   aeff=m.alpha_b_heiii(grid['temperature'])+(1-ker['y2a'])*(m.alpha_a_heiii(grid['temperature'])-m.alpha_b_heiii(grid['temperature'])); direct=ker['pair_heiii']*aeff; ident=float(np.max(np.abs(direct-rec)/np.maximum(np.abs(rec),1e-300)))
   rows.append({'z':state.z,'closure':closure,'collisional_HeII_rate_s-1_cMpc-3':ct,'unsupported_HeIII_recombination_s-1_cMpc-3':rt,'net_HeIII_rate_s-1_cMpc-3':nt,'collisional_over_recombination':ct/max(rt,1),'positive_net_volume_fraction':vpos,'positive_net_mass_fraction':mpos,'positive_bin_collisional_fraction':float(np.sum(w*coll*pos)*conv/max(ct,1)),'positive_net_contribution_s-1_cMpc-3':float(np.sum(w*net*pos)*conv),'minimum_positive_net_temperature_K':minT,'unsupported_identity_relative_error_max':ident})
   if abs(state.z-5.5)<1e-9:
    for i in range(0,grid['delta'].shape[0],3):
     for j in range(0,grid['delta'].shape[1],2):
      grids.append({'closure':closure,'delta':grid['delta'][i,j],'T_K':grid['temperature'][i,j],'weight':w[i,j],'xHeII':means['xHeII'][i,j],'xHeIII':means['xHeIII'][i,j],'collisional_cm-3_s-1':coll[i,j],'unsupported_recombination_cm-3_s-1':rec[i,j],'net_cm-3_s-1':net[i,j],'net_sign':'POSITIVE_COLLISIONAL' if net[i,j]>0 else 'NEGATIVE_DECAY','y2a':ker['y2a'][i,j]})
 f=pd.DataFrame(rows); g=pd.DataFrame(grids); f.to_csv(out/'phase_space_rate_sign_summary.csv',index=False); g.to_csv(out/'phase_space_rate_grid_z5p5.csv.gz',index=False,compression='gzip')
 det=f[f.closure=='DETERMINISTIC']; res={'substage':'PHASESPACE_RATE_SIGN','verdict':'PASS' if det['net_HeIII_rate_s-1_cMpc-3'].lt(0).all() and f.unsupported_identity_relative_error_max.max()<1e-12 else 'FAIL','global_decay_all':bool(det['net_HeIII_rate_s-1_cMpc-3'].lt(0).all()),'positive_bin_volume_fraction_max':float(f.positive_net_volume_fraction.max()),'positive_bin_mass_fraction_max':float(f.positive_net_mass_fraction.max()),'minimum_positive_temperature_K':float(f.minimum_positive_net_temperature_K.min()),'unsupported_identity_relative_error_max':float(f.unsupported_identity_relative_error_max.max()),'collisional_over_recombination_global_range':[float(det.collisional_over_recombination.min()),float(det.collisional_over_recombination.max())]}; (out/'phase_space_rate_sign_results.json').write_text(json.dumps(res,indent=2)); print(json.dumps(res,indent=2))
if __name__=='__main__':
 ap=argparse.ArgumentParser(); ap.add_argument('--history',type=Path,required=True); ap.add_argument('--output',type=Path,required=True); a=ap.parse_args(); run(a.history,a.output)
