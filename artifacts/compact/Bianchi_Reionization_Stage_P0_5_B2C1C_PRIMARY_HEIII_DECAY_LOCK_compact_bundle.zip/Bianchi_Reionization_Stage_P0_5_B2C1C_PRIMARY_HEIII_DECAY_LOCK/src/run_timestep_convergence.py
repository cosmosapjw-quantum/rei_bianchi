from __future__ import annotations
import argparse,json,math,sys
from pathlib import Path
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as jnp
import numpy as np,pandas as pd
from scipy.integrate import solve_ivp
from scipy.optimize import root
HERE=Path(__file__).resolve().parent; sys.path.insert(0,str(HERE))
from b2b_physical_model import KB_ERG,NH0,YHE,allocate_front_sink,build_opacity_fit,make_params,make_spectrum_lanes
from primary_exact_zero_model import z7_from_state,z7_rhs,physical_state
MYR_S=1e6*365.25*86400.; PRIMARY='MFP_BASELINE_E_MINUS_2P5_1_TO_4_RYD'
def find(root,name):
 m=sorted(root.rglob(name),key=lambda p:(len(p.parts),str(p)))
 if not m: raise FileNotFoundError(name)
 return m[0]
def vec(z,p):
 s=physical_state(z,p); return np.r_[s['N'][:3],s['xHII'],s['xHeII'],s['xHeIII'],s['u'],s['GammaHI'],s['T']]
def run(stage,b2b,out):
 hist=pd.read_csv(stage/'data'/'primary_exact_zero_G3_history.csv'); start=hist[np.isclose(hist.z,5.6)].iloc[0]
 ledger=pd.read_csv(b2b/'data'/'forward_history_photon_ledger.csv'); rec=ledger[(ledger.lane==PRIMARY)&np.isclose(ledger.z_mid,5.55)].iloc[0]
 alloc=pd.read_csv(find(b2b,'photon_allocation_all_lanes.csv')); ar=alloc[(alloc.lane=='INSIDE_OUT_SELF_SHIELD_PRIMARY')&np.isclose(alloc.z_mid,5.55)].iloc[0]
 raw=find(b2b,'environment_mfp_energies.txt'); density=find(b2b,'density_mapping_colossus_1_3_10_port.csv'); lane=make_spectrum_lanes()[PRIMARY]; knots,coeff,_=build_opacity_fit(raw,density,5.55,lane); front,_=allocate_front_sink(ar.front_HII_rate,ar.front_HeII_rate,ar.front_HeIII_electron_weighted_rate,lane)
 nH=NH0*(1+5.55)**3; nHe=YHE*nH; ne=nH*start.xHII+nHe*(start.xHeII+2*start.xHeIII); u=1.5*(nH+nHe+ne)*KB_ERG*start.T_K; z0=z7_from_state(np.array([start.N1,start.N2,start.N3]),start.xHII,start.xHeII,start.xHeIII,u)
 p=make_params(z_cos=5.55,dt_seconds=1.,lane=lane,log_kappa_knots=knots,log_kappa_coeffs=coeff,n_prev=np.array([start.N1,start.N2,start.N3,0.]),x_prev=np.array([start.xHII,start.xHeII,start.xHeIII]),u_prev=u,front_sink_group=front,scale_n=np.array([start.N1,start.N2,start.N3,1e-300]),scale_u=u,scale_gamma=max(start.Gamma_HI,1e-30)); emiss=float(rec.total_emission); rhs=jax.jit(z7_rhs); duration=.05*MYR_S
 ref=solve_ivp(lambda t,y:np.asarray(rhs(jnp.asarray(y),jnp.array(emiss),p),float),(0,duration),z0,method='BDF',rtol=2e-12,atol=2e-14,max_step=duration/400)
 if not ref.success: raise RuntimeError(ref.message)
 zref=ref.y[:,-1]; vref=vec(zref,p); scales=np.maximum(np.abs(vref),np.array([1,1,1,1e-6,1e-6,1e-6,1e-30,1e-16,1.]))
 rows=[]
 for hmyr in [.05,.025,.0125,.00625,.003125]:
  nsteps=round(.05/hmyr); h=hmyr*MYR_S; z=z0.copy(); maxres=0
  for _ in range(nsteps):
   old=jnp.asarray(z)
   def R(new): return new-old-h*rhs(new,jnp.array(emiss),p)
   J=jax.jit(jax.jacfwd(R)); sol=root(lambda q:np.asarray(R(jnp.asarray(q)),float),z,jac=lambda q:np.asarray(J(jnp.asarray(q)),float),method='hybr',options={'xtol':1e-11,'maxfev':500})
   if not sol.success: raise RuntimeError(sol.message)
   z=np.asarray(sol.x,float); maxres=max(maxres,float(np.max(np.abs(R(jnp.asarray(z))))))
  v=vec(z,p); err=float(np.linalg.norm((v-vref)/scales)); rows.append({'step_Myr':hmyr,'n_steps':nsteps,'scaled_state_error':err,'nonlinear_residual_max':maxres,'xHeIII':v[5],'T_K':v[-1],'GammaHI_s-1':v[-2]})
 f=pd.DataFrame(rows); orders=[math.nan]+[math.log(f.scaled_state_error.iloc[i-1]/f.scaled_state_error.iloc[i],2) for i in range(1,len(f))]; f['observed_order']=orders; f.to_csv(out/'timestep_convergence.csv',index=False); valid=f.observed_order.dropna(); res={'substage':'TIMESTEP_CONVERGENCE','verdict':'PASS' if valid.between(.8,1.2).all() and f.nonlinear_residual_max.max()<1e-10 else 'FAIL','observed_order_range':[float(valid.min()),float(valid.max())],'nonlinear_residual_max':float(f.nonlinear_residual_max.max()),'reference_xHeIII':float(vref[5])}; (out/'timestep_convergence_results.json').write_text(json.dumps(res,indent=2)); print(json.dumps(res,indent=2))
if __name__=='__main__':
 ap=argparse.ArgumentParser(); ap.add_argument('--stage',type=Path,required=True); ap.add_argument('--b2b',type=Path,required=True); ap.add_argument('--output',type=Path,required=True); a=ap.parse_args(); run(a.stage,a.b2b,a.output)
