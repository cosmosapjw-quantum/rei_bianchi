from __future__ import annotations
import argparse,json,sys
from pathlib import Path
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as jnp
import numpy as np,pandas as pd
from scipy.integrate import solve_ivp
HERE=Path(__file__).resolve().parent; sys.path.insert(0,str(HERE))
from b2b_physical_model import C_LIGHT,KB_ERG,MPC_CM,NH0,YHE,allocate_front_sink,build_opacity_fit,make_params,make_spectrum_lanes
from monolithic_model_b2a import chemistry_rates,opacity_cMpc_inv
from primary_exact_zero_model import state_from_z7,z7_from_state,z7_rhs,physical_state,heiii_rates,thermal_components
MYR_S=1e6*365.25*86400.; PRIMARY='MFP_BASELINE_E_MINUS_2P5_1_TO_4_RYD'; TH_KEYS=['photoheat','recombination_cooling','excitation_cooling','collisional_ionization_cooling','free_free_cooling','cooling_total','expansion_work','thermal_rhs']; E_KEYS=['threshold_H','threshold_HeI','threshold_HeII']
def find(root,name):
 m=sorted(root.rglob(name),key=lambda p:(len(p.parts),str(p))); 
 if not m: raise FileNotFoundError(name)
 return m[0]
def diagnostics(z7,p):
 s=state_from_z7(z7,p); k=opacity_cMpc_inv(s,p); abscoef=C_LIGHT*(1+p['z_cos'])/MPC_CM*k; red=p['Hubble']*p['redshift_coeff']; th=thermal_components(s,p); he=heiii_rates(s,p); return jnp.concatenate([jnp.array([jnp.sum(abscoef*s['N']),red[0]*s['N'][0]]),jnp.array([th[k] for k in TH_KEYS]),jnp.array([th[k] for k in E_KEYS]),jnp.array([he['collisional_density_cm-3_s-1'],he['unsupported_density_cm-3_s-1']])])
def augmented_rhs(y,em,p): return jnp.concatenate([z7_rhs(y[:7],em,p),diagnostics(y[:7],p)])
def run(b2b,out,checkpoints):
 out.mkdir(parents=True,exist_ok=True); checkpoints.mkdir(parents=True,exist_ok=True)
 hist=pd.read_csv(b2b/'data'/'physical_forward_history.csv'); base=hist[hist.lane==PRIMARY].sort_values('z',ascending=False); ledger=pd.read_csv(b2b/'data'/'forward_history_photon_ledger.csv'); intervals=ledger[ledger.lane==PRIMARY].sort_values('z_mid',ascending=False); alloc=pd.read_csv(find(b2b,'photon_allocation_all_lanes.csv')); alloc=alloc[alloc.lane=='INSIDE_OUT_SELF_SHIELD_PRIMARY'].set_index('z_mid'); raw=find(b2b,'environment_mfp_energies.txt'); density=find(b2b,'density_mapping_colossus_1_3_10_port.csv'); lane=make_spectrum_lanes()[PRIMARY]
 init=base[np.isclose(base.z,6.0)].iloc[0]; n123=np.array([init.N1,init.N2,init.N3]); nH=NH0*7**3; nHe=YHE*nH; ne=nH*init.xHII+nHe*(init.xHeII+2*init.xHeIII); u=1.5*(nH+nHe+ne)*KB_ERG*init.T_K; z7=z7_from_state(n123,init.xHII,init.xHeII,init.xHeIII,u)
 knots0,coeff0,_=build_opacity_fit(raw,density,6.0,lane); p0=make_params(z_cos=6.0,dt_seconds=1,lane=lane,log_kappa_knots=knots0,log_kappa_coeffs=coeff0,n_prev=np.r_[n123,0.],x_prev=np.array([init.xHII,init.xHeII,init.xHeIII]),u_prev=u,front_sink_group=np.zeros(4),scale_n=np.r_[n123,1e-300],scale_u=u,scale_gamma=max(init.Gamma_HI,1e-30))
 s0=physical_state(z7,p0); history=[{'z':6.0,'N1':s0['N'][0],'N2':s0['N'][1],'N3':s0['N'][2],'N4_exact':s0['N'][3],'xHII':s0['xHII'],'xHeI':s0['xHeI'],'xHeII':s0['xHeII'],'xHeIII':s0['xHeIII'],'T_K':s0['T'],'Gamma_HI':s0['GammaHI'],'Gamma_HeI':s0['GammaHeI'],'Gamma_HeII_exact':s0['GammaHeII']}]; photons=[]; thermal=[]; heled=[]
 aug=jax.jit(augmented_rhs)
 for idx,rec in enumerate(intervals.itertuples()):
  zmid=float(rec.z_mid); znext=round(float(rec.z_next),2); duration=float(rec.dt_Myr)*MYR_S; emission=float(rec.total_emission); knots,coeff,_=build_opacity_fit(raw,density,zmid,lane); current=physical_state(z7,p0 if idx==0 else p); ar=alloc.loc[zmid]; front,_=allocate_front_sink(float(ar.front_HII_rate),float(ar.front_HeII_rate),float(ar.front_HeIII_electron_weighted_rate),lane); assert front[3]==0
  p=make_params(z_cos=zmid,dt_seconds=duration,lane=lane,log_kappa_knots=knots,log_kappa_coeffs=coeff,n_prev=current['N'],x_prev=np.array([current['xHII'],current['xHeII'],current['xHeIII']]),u_prev=current['u'],front_sink_group=front,scale_n=np.r_[current['N'][:3],1e-300],scale_u=current['u'],scale_gamma=max(current['GammaHI'],1e-30)); start=physical_state(z7,p); y0=np.r_[z7,np.zeros(15)]; atol=np.r_[np.full(7,5e-14),np.full(2,1e34),np.full(11,1e-31),np.full(2,1e-23)]
  sol=solve_ivp(lambda t,y:np.asarray(aug(jnp.asarray(y),jnp.array(emission),p),float),(0,duration),y0,method='BDF',rtol=5e-13,atol=atol,dense_output=True,max_step=duration/240)
  if not sol.success: raise RuntimeError(sol.message)
  yf=sol.y[:,-1]; z7=yf[:7]; cum=yf[7:]; end=physical_state(z7,p); assert end['N'][3]==0 and end['GammaHeII']==0
  absint,redint=cum[:2]; thint=cum[2:10]; eint=cum[10:13]; heint=cum[13:15]
  storage=(end['N'][:3].sum()-start['N'][:3].sum())/duration; absrate=absint/duration; redrate=redint/duration; frontrate=front[:3].sum(); pres=emission-storage-absrate-redrate-frontrate; du=end['u']-start['u']; tres=du-thint[-1]; nHe_mid=YHE*NH0*(1+zmid)**3; dxden=nHe_mid*(end['xHeIII']-start['xHeIII']); hres=dxden-(heint[0]-heint[1])
  point=0
  for t in np.linspace(0,duration,21):
   zz=jnp.asarray(sol.sol(float(t))[:7]); s=state_from_z7(zz,p); dx3=float(chemistry_rates(s,p)[2]); net=float(heiii_rates(s,p)['net_fraction_s-1']); point=max(point,abs(dx3-net)/max(abs(dx3),abs(net),1e-40))
  photons.append({'z_mid':zmid,'z_next':znext,'emission_rate':emission,'storage_rate':storage,'absorption_rate':absrate,'redshift_loss_rate':redrate,'front_rate':frontrate,'relative_residual':pres/max(abs(emission),1),'N4_exact':end['N'][3]}); thermal.append({'z_mid':zmid,'z_next':znext,'delta_u':du,**{f'integrated_{k}':thint[i] for i,k in enumerate(TH_KEYS)},**{f'integrated_{k}':eint[i] for i,k in enumerate(E_KEYS)},'relative_residual':tres/max(abs(du),abs(thint[-1]),1e-300)}); heled.append({'z_mid':zmid,'z_next':znext,'N4_exact':end['N'][3],'Gamma_HeII_exact':end['GammaHeII'],'collisional_integral_cm-3':heint[0],'unsupported_recombination_integral_cm-3':heint[1],'delta_HeIII_density_cm-3':dxden,'relative_dynamic_identity_residual':hres/max(abs(dxden),abs(heint[0]-heint[1]),1e-300),'pointwise_identity_residual_max':point,'xHeIII_start':start['xHeIII'],'xHeIII_end':end['xHeIII'],'global_decay':end['xHeIII']<start['xHeIII']}); history.append({'z':znext,'N1':end['N'][0],'N2':end['N'][1],'N3':end['N'][2],'N4_exact':end['N'][3],'xHII':end['xHII'],'xHeI':end['xHeI'],'xHeII':end['xHeII'],'xHeIII':end['xHeIII'],'T_K':end['T'],'Gamma_HI':end['GammaHI'],'Gamma_HeI':end['GammaHeI'],'Gamma_HeII_exact':end['GammaHeII']})
  p0=p
 H=pd.DataFrame(history); P=pd.DataFrame(photons); T=pd.DataFrame(thermal); HE=pd.DataFrame(heled); H.to_csv(out/'primary_exact_zero_G3_history.csv',index=False); P.to_csv(out/'primary_photon_ledger.csv',index=False); T.to_csv(out/'primary_thermal_energy_ledger.csv',index=False); HE.to_csv(out/'primary_heiii_dynamic_ledger.csv',index=False)
 res={'substage':'PRIMARY_FORWARD_CUMULATIVE','verdict':'PASS' if ((H.N4_exact==0).all() and (H.Gamma_HeII_exact==0).all() and HE.global_decay.all() and P.relative_residual.abs().max()<1e-10 and T.relative_residual.abs().max()<1e-10 and HE.relative_dynamic_identity_residual.abs().max()<1e-10 and HE.pointwise_identity_residual_max.max()<1e-10) else 'FAIL','xHeIII_z6':float(H.iloc[0].xHeIII),'xHeIII_z5p5':float(H.iloc[-1].xHeIII),'survival_fraction':float(H.iloc[-1].xHeIII/H.iloc[0].xHeIII),'photon_residual_max':float(P.relative_residual.abs().max()),'thermal_residual_max':float(T.relative_residual.abs().max()),'dynamic_identity_max':float(HE.relative_dynamic_identity_residual.abs().max()),'pointwise_identity_max':float(HE.pointwise_identity_residual_max.max())}; (out/'primary_forward_results.json').write_text(json.dumps(res,indent=2)); (checkpoints/'primary_final_state.json').write_text(json.dumps(history[-1],indent=2)); print(json.dumps(res,indent=2))
if __name__=='__main__':
 ap=argparse.ArgumentParser(); ap.add_argument('--b2b',type=Path,required=True); ap.add_argument('--output',type=Path,required=True); ap.add_argument('--checkpoints',type=Path,required=True); a=ap.parse_args(); run(a.b2b,a.output,a.checkpoints)
