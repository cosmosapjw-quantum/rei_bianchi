from __future__ import annotations
import argparse,json,math,sys
from pathlib import Path
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as jnp
import numpy as np,pandas as pd
from numpy.polynomial.legendre import leggauss
from scipy.integrate import solve_ivp
HERE=Path(__file__).resolve().parent; sys.path.insert(0,str(HERE))
from b2b_physical_model import C_LIGHT,KB_ERG,MPC_CM,NH0,YHE,allocate_front_sink,build_opacity_fit,make_params,make_spectrum_lanes
from monolithic_model_b2a import chemistry_rates,opacity_cMpc_inv
from primary_exact_zero_model import state_from_z7,z7_from_state,z7_rhs,physical_state,heiii_rates,thermal_components
MYR_S=1e6*365.25*86400.; PRIMARY='MFP_BASELINE_E_MINUS_2P5_1_TO_4_RYD'
def find(root,name):
 m=sorted(root.rglob(name),key=lambda p:(len(p.parts),str(p)))
 if not m: raise FileNotFoundError(name)
 return m[0]
def gl_integrate(solution,duration,fn,n=192):
 x,w=leggauss(n); t=.5*duration*(x+1); vals=np.array([fn(float(tt)) for tt in t],float); return .5*duration*np.tensordot(w,vals,axes=(0,0))
def run(b2b,output,checkpoints):
 output.mkdir(parents=True,exist_ok=True); checkpoints.mkdir(parents=True,exist_ok=True)
 hist=pd.read_csv(b2b/'data'/'physical_forward_history.csv'); base=hist[hist.lane==PRIMARY].sort_values('z',ascending=False)
 ledger=pd.read_csv(b2b/'data'/'forward_history_photon_ledger.csv'); intervals=ledger[ledger.lane==PRIMARY].sort_values('z_mid',ascending=False)
 allocation=pd.read_csv(find(b2b,'photon_allocation_all_lanes.csv')); allocation=allocation[allocation.lane=='INSIDE_OUT_SELF_SHIELD_PRIMARY'].set_index('z_mid')
 raw=find(b2b,'environment_mfp_energies.txt'); density=find(b2b,'density_mapping_colossus_1_3_10_port.csv'); lane=make_spectrum_lanes()[PRIMARY]
 if lane.source_fraction[3]!=0: raise RuntimeError('primary G3 source not exact zero')
 init=base[np.isclose(base.z,6.0)].iloc[0]; n123=np.array([init.N1,init.N2,init.N3]); nH=NH0*7**3; nHe=YHE*nH; ne=nH*init.xHII+nHe*(init.xHeII+2*init.xHeIII); u=1.5*(nH+nHe+ne)*KB_ERG*init.T_K
 z7=z7_from_state(n123,init.xHII,init.xHeII,init.xHeIII,u); rhs=jax.jit(z7_rhs)
 knots0,coeff0,_=build_opacity_fit(raw,density,6.0,lane)
 p0=make_params(z_cos=6.0,dt_seconds=1.0,lane=lane,log_kappa_knots=knots0,log_kappa_coeffs=coeff0,n_prev=np.r_[n123,0.],x_prev=np.array([init.xHII,init.xHeII,init.xHeIII]),u_prev=u,front_sink_group=np.zeros(4),scale_n=np.r_[n123,1e-300],scale_u=u,scale_gamma=max(init.Gamma_HI,1e-30))
 history=[]; photons=[]; thermal=[]; heled=[]; interval_solutions=[]
 for idx,rec in enumerate(intervals.itertuples()):
  zmid=float(rec.z_mid); znext=round(float(rec.z_next),2); duration=float(rec.dt_Myr)*MYR_S; emission=float(rec.total_emission)
  knots,coeff,_=build_opacity_fit(raw,density,zmid,lane)
  if idx==0:
   s0=physical_state(z7,p0); history.append({'z':6.0,'N1':s0['N'][0],'N2':s0['N'][1],'N3':s0['N'][2],'N4_exact':s0['N'][3],'xHII':s0['xHII'],'xHeI':s0['xHeI'],'xHeII':s0['xHeII'],'xHeIII':s0['xHeIII'],'T_K':s0['T'],'Gamma_HI':s0['GammaHI'],'Gamma_HeI':s0['GammaHeI'],'Gamma_HeII_exact':s0['GammaHeII']})
  current=physical_state(z7,p0 if idx==0 else p)
  ar=allocation.loc[zmid]
  front,_=allocate_front_sink(float(ar.front_HII_rate),float(ar.front_HeII_rate),float(ar.front_HeIII_electron_weighted_rate),lane)
  if front[3]!=0: raise RuntimeError('front G3 nonzero')
  p=make_params(z_cos=zmid,dt_seconds=duration,lane=lane,log_kappa_knots=knots,log_kappa_coeffs=coeff,n_prev=current['N'],x_prev=np.array([current['xHII'],current['xHeII'],current['xHeIII']]),u_prev=current['u'],front_sink_group=front,scale_n=np.r_[current['N'][:3],1e-300],scale_u=current['u'],scale_gamma=max(current['GammaHI'],1e-30))
  zstart=z7.copy(); sstart=physical_state(zstart,p)
  sol=solve_ivp(lambda t,y:np.asarray(rhs(jnp.asarray(y),jnp.array(emission),p),float),(0,duration),zstart,method='BDF',rtol=1e-10,atol=2e-12,dense_output=True,max_step=duration/100)
  if not sol.success: raise RuntimeError(sol.message)
  z7=sol.y[:,-1]; send=physical_state(z7,p)
  if send['N'][3]!=0 or send['GammaHeII']!=0: raise RuntimeError('exact-zero constraint drift')
  def diag(t):
   s=state_from_z7(jnp.asarray(sol.sol(t)),p); k=opacity_cMpc_inv(s,p); abscoef=C_LIGHT*(1+p['z_cos'])/MPC_CM*k; red=p['Hubble']*p['redshift_coeff']; th=thermal_components(s,p); he=heiii_rates(s,p); dx3=chemistry_rates(s,p)[2]
   return {'abs':float(jnp.sum(abscoef*s['N'])),'red':float(red[0]*s['N'][0]),'thermal':np.array([float(th[k]) for k in ['photoheat','recombination_cooling','excitation_cooling','collisional_ionization_cooling','free_free_cooling','cooling_total','expansion_work','thermal_rhs']]),'threshold':np.array([float(th[k]) for k in ['threshold_H','threshold_HeI','threshold_HeII']]),'he':np.array([float(he[k]) for k in ['collisional_density_cm-3_s-1','unsupported_density_cm-3_s-1']]),'dx3':float(dx3),'net':float(he['net_fraction_s-1'])}
  absint=float(gl_integrate(sol,duration,lambda t:diag(t)['abs'])); redint=float(gl_integrate(sol,duration,lambda t:diag(t)['red'])); thint=gl_integrate(sol,duration,lambda t:diag(t)['thermal']); eint=gl_integrate(sol,duration,lambda t:diag(t)['threshold']); heint=gl_integrate(sol,duration,lambda t:diag(t)['he'])
  point=max(abs(diag(float(t))['dx3']-diag(float(t))['net'])/max(abs(diag(float(t))['dx3']),abs(diag(float(t))['net']),1e-40) for t in np.linspace(0,duration,21))
  storage=(send['N'][:3].sum()-sstart['N'][:3].sum())/duration; absrate=absint/duration; redrate=redint/duration; frontrate=float(front[:3].sum()); pres=emission-storage-absrate-redrate-frontrate
  du=send['u']-sstart['u']; tres=du-thint[-1]
  nHe_mid=YHE*NH0*(1+zmid)**3; dxden=nHe_mid*(send['xHeIII']-sstart['xHeIII']); hres=dxden-(heint[0]-heint[1])
  photons.append({'z_mid':zmid,'z_next':znext,'emission_rate':emission,'storage_rate':storage,'absorption_rate':absrate,'redshift_loss_rate':redrate,'front_rate':frontrate,'relative_residual':pres/max(abs(emission),1),'N4_exact':send['N'][3]})
  thermal.append({'z_mid':zmid,'z_next':znext,'delta_u':du,'integrated_photoheat':thint[0],'integrated_recombination_cooling':thint[1],'integrated_excitation_cooling':thint[2],'integrated_collisional_ionization_cooling':thint[3],'integrated_free_free_cooling':thint[4],'integrated_cooling_total':thint[5],'integrated_expansion_work':thint[6],'integrated_thermal_rhs':thint[7],'integrated_threshold_H':eint[0],'integrated_threshold_HeI':eint[1],'integrated_threshold_HeII':eint[2],'relative_residual':tres/max(abs(du),abs(thint[-1]),1e-300)})
  heled.append({'z_mid':zmid,'z_next':znext,'N4_exact':send['N'][3],'Gamma_HeII_exact':send['GammaHeII'],'collisional_integral_cm-3':heint[0],'unsupported_recombination_integral_cm-3':heint[1],'delta_HeIII_density_cm-3':dxden,'relative_dynamic_identity_residual':hres/max(abs(dxden),abs(heint[0]-heint[1]),1e-300),'pointwise_identity_residual_max':point,'xHeIII_start':sstart['xHeIII'],'xHeIII_end':send['xHeIII'],'global_decay':send['xHeIII']<sstart['xHeIII']})
  history.append({'z':znext,'N1':send['N'][0],'N2':send['N'][1],'N3':send['N'][2],'N4_exact':send['N'][3],'xHII':send['xHII'],'xHeI':send['xHeI'],'xHeII':send['xHeII'],'xHeIII':send['xHeIII'],'T_K':send['T'],'Gamma_HI':send['GammaHI'],'Gamma_HeI':send['GammaHeI'],'Gamma_HeII_exact':send['GammaHeII']})
  interval_solutions.append({'zmid':zmid,'duration':duration,'emission':emission,'p':p,'solution':sol})
 pd.DataFrame(history).to_csv(output/'primary_exact_zero_G3_history.csv',index=False); pd.DataFrame(photons).to_csv(output/'primary_photon_ledger.csv',index=False); pd.DataFrame(thermal).to_csv(output/'primary_thermal_energy_ledger.csv',index=False); pd.DataFrame(heled).to_csv(output/'primary_heiii_dynamic_ledger.csv',index=False)
 h=pd.DataFrame(history); ph=pd.DataFrame(photons); th=pd.DataFrame(thermal); he=pd.DataFrame(heled)
 result={'substage':'PRIMARY_FORWARD','verdict':'PASS' if ((h.N4_exact==0).all() and (h.Gamma_HeII_exact==0).all() and he.global_decay.all() and ph.relative_residual.abs().max()<1e-7 and th.relative_residual.abs().max()<1e-7 and he.relative_dynamic_identity_residual.abs().max()<1e-8 and he.pointwise_identity_residual_max.max()<1e-10) else 'FAIL','xHeIII_z6':float(h.iloc[0].xHeIII),'xHeIII_z5p5':float(h.iloc[-1].xHeIII),'survival_fraction':float(h.iloc[-1].xHeIII/h.iloc[0].xHeIII),'photon_residual_max':float(ph.relative_residual.abs().max()),'thermal_residual_max':float(th.relative_residual.abs().max()),'dynamic_identity_max':float(he.relative_dynamic_identity_residual.abs().max()),'pointwise_identity_max':float(he.pointwise_identity_residual_max.max())}
 (output/'primary_forward_results.json').write_text(json.dumps(result,indent=2)); (checkpoints/'primary_final_state.json').write_text(json.dumps(history[-1],indent=2)); print(json.dumps(result,indent=2))
if __name__=='__main__':
 ap=argparse.ArgumentParser(); ap.add_argument('--b2b',type=Path,required=True); ap.add_argument('--output',type=Path,required=True); ap.add_argument('--checkpoints',type=Path,required=True); a=ap.parse_args(); run(a.b2b,a.output,a.checkpoints)
