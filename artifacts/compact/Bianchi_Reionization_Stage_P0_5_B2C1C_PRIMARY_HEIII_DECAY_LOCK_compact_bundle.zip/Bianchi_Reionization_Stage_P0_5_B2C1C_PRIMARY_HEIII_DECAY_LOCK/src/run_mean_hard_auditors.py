from __future__ import annotations
import argparse,json,sys,math
from pathlib import Path
import jax.numpy as jnp
import numpy as np,pandas as pd
from scipy.integrate import quad
HERE=Path(__file__).resolve().parent; sys.path.insert(0,str(HERE))
from b2b_physical_model import C_LIGHT,H0,OMEGA_M,OMEGA_L,MPC_CM,NH0,YHE,KB_ERG,build_opacity_fit,hubble,make_params,make_spectrum_lanes
from primary_exact_zero_model import z7_from_state,state_from_z7,heiii_rates
MYR_S=1e6*365.25*86400.; PRIMARY='MFP_BASELINE_E_MINUS_2P5_1_TO_4_RYD'; HARD=['CLOUDY_BLACKBODY_80000K','CLOUDY_HARD_POWERLAW_FNU_MINUS_1P5']
def find(root,name):
 m=sorted(root.rglob(name),key=lambda p:(len(p.parts),str(p))); 
 if not m: raise FileNotFoundError(name)
 return m[0]
def run(stage,b2b,b2c1b,out):
 h=pd.read_csv(stage/'data'/'primary_exact_zero_G3_history.csv'); raw=find(b2b,'environment_mfp_energies.txt'); density=find(b2b,'density_mapping_colossus_1_3_10_port.csv'); lane=make_spectrum_lanes()[PRIMARY]; rows=[]
 for r in h.itertuples():
  knots,coeff,_=build_opacity_fit(raw,density,float(r.z),lane); nH=NH0*(1+r.z)**3; nHe=YHE*nH; ne=nH*r.xHII+nHe*(r.xHeII+2*r.xHeIII); u=1.5*(nH+nHe+ne)*KB_ERG*r.T_K; p=make_params(z_cos=float(r.z),dt_seconds=1,lane=lane,log_kappa_knots=knots,log_kappa_coeffs=coeff,n_prev=np.array([r.N1,r.N2,r.N3,0.]),x_prev=np.array([r.xHII,r.xHeII,r.xHeIII]),u_prev=u,front_sink_group=np.zeros(4),scale_n=np.array([r.N1,r.N2,r.N3,1e-300]),scale_u=u,scale_gamma=max(r.Gamma_HI,1e-30)); z=z7_from_state([r.N1,r.N2,r.N3],r.xHII,r.xHeII,r.xHeIII,u); rate={k:float(v) for k,v in heiii_rates(state_from_z7(jnp.asarray(z),p),p).items()}; rows.append({'z':r.z,'T_K':r.T_K,'xHeII':r.xHeII,'xHeIII':r.xHeIII,'ne_cm-3':rate['ne'],'y2a':rate['y2a'],'alphaA_HeIII_cm3_s':rate['alphaA'],'alphaB_HeIII_cm3_s':rate['alphaB'],'alphaEff_OTS_cm3_s':rate['alphaEff'],'C_HeII_cm3_s':rate['coll_fraction_s-1']/max(rate['ne']*r.xHeII,1e-300),'tRecEff_Myr':1/(rate['ne']*rate['alphaEff'])/MYR_S,'collisional_over_recombination':rate['coll_fraction_s-1']/rate['recomb_fraction_s-1'],'dxHeIII_dt_per_Myr':rate['net_fraction_s-1']*MYR_S,'Gamma_HeII_external_exact':0.0})
 mean=pd.DataFrame(rows); mean.to_csv(out/'mean_history_rate_ledger.csv',index=False)
 # Numerical optical-depth integral over z by PCHIP/trapezoid on the locked nodes.
 zs=mean.z.to_numpy(); k=mean['ne_cm-3'].to_numpy()*mean['alphaEff_OTS_cm3_s'].to_numpy(); order=np.argsort(zs); zs=zs[order]; k=k[order]
 from scipy.interpolate import PchipInterpolator
 interp=PchipInterpolator(zs,k); optical=quad(lambda z:float(interp(z))/((1+z)*hubble(z)),5.5,6.0,epsabs=0,epsrel=1e-11)[0]; survival=math.exp(-optical)
 elapsed=quad(lambda z:1/((1+z)*hubble(z)),5.5,6.0,epsabs=0,epsrel=1e-12)[0]/MYR_S
 # B2B regression.
 b2bh=pd.read_csv(b2b/'data'/'physical_forward_history.csv'); bprim=b2bh[b2bh.lane==PRIMARY].sort_values('z',ascending=False); actual=float(bprim.iloc[-1].xHeIII/bprim.iloc[0].xHeIII)
 # Hard auditors.
 support=pd.read_csv(b2c1b/'data'/'maintenance_source_support.csv'); lanes=make_spectrum_lanes(); hrows=[]
 for lname in HARD:
  ln=lanes[lname]; sup=support[support.lane==lname]
  for r in b2bh[b2bh.lane==lname].itertuples():
   N=np.array([r.N1,r.N2,r.N3,r.N4]); gamma=C_LIGHT*(1+r.z)**3/MPC_CM**3*np.dot(ln.sigma_HeII,N); st='FULL_SUPPORT_CLOSED' if (sup[np.isclose(sup.z,r.z)].status=='FULL_SUPPORT_CLOSED').all() else 'UNAVAILABLE'; hrows.append({'lane':lname,'z':r.z,'xHeIII_dynamic':r.xHeIII,'xHeII_dynamic':r.xHeII,'T_K':r.T_K,'G3_source_occupation':ln.source_fraction[3],'Gamma_HeII_external_s-1':gamma,'static_support_cone_status':st})
 hard=pd.DataFrame(hrows); hard.to_csv(out/'hard_source_dynamic_auditors.csv',index=False)
 res={'substage':'MEAN_AND_HARD_AUDITORS','verdict':'PASS','elapsed_time_Myr':elapsed,'numerical_decay_optical_depth':optical,'numerical_survival_fraction':survival,'actual_primary_survival_fraction':actual,'relative_difference_survival_vs_B2B':survival/actual-1,'mean_tRec_Myr_range':[float(mean.tRecEff_Myr.min()),float(mean.tRecEff_Myr.max())],'mean_collisional_over_recombination_range':[float(mean.collisional_over_recombination.min()),float(mean.collisional_over_recombination.max())],'mean_global_decay_all':bool((mean.dxHeIII_dt_per_Myr<0).all()),'hard_G3_support_positive':bool((hard.G3_source_occupation>0).all()),'hard_support_cone_closed':bool((hard.static_support_cone_status=='FULL_SUPPORT_CLOSED').all())}; (out/'mean_and_hard_auditor_results.json').write_text(json.dumps(res,indent=2)); print(json.dumps(res,indent=2))
if __name__=='__main__':
 ap=argparse.ArgumentParser(); ap.add_argument('--stage',type=Path,required=True); ap.add_argument('--b2b',type=Path,required=True); ap.add_argument('--b2c1b',type=Path,required=True); ap.add_argument('--output',type=Path,required=True); a=ap.parse_args(); run(a.stage,a.b2b,a.b2c1b,a.output)
