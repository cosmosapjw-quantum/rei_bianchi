# Web source lock

- Friedrich et al. 2012, arXiv:1201.0602: coupled H/He C2-Ray, full OTS
  recombination-photon coupling, rate tables, and the zero-external-HeII
  coupled evolution limit.
- SCRIPT He II reionization, arXiv:2402.03794: hard/quasar He II source lane as
  a separate auditor from the primary stellar lane.

Numerical results are local artifact results, not web replacements.
