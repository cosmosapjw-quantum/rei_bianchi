# Exact support and He III decay specification

Primary support is 1--4 Ryd. The evolved primary photon state contains only
G1, G2a, and G2b variables; G3 is inserted algebraically as exact zero.

\[
N_{\gamma,G3}^{\rm source}=0,
\qquad
\Gamma_{\rm HeII}^{\rm ext}=0.
\]

\[
\dot x_{\rm HeIII}=n_eC_{\rm HeII}x_{\rm HeII}
-n_e[\alpha_B+(1-y_{2a})(\alpha_A-\alpha_B)]x_{\rm HeIII}.
\]

The dynamic identity is

\[
\frac{dN_{\rm HeIII}^{c}}{dt}
=\dot N_{\rm coll,HeII}^{c}-\dot N_{\rm unsupported,HeII}^{c}.
\]

Internal full-OTS recombination photons are never reinserted as external G3
source photons. Hard-source auditors retain nonzero G3 and are separate lanes.
