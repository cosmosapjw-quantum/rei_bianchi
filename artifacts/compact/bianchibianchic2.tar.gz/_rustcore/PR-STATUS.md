
---

## v3.0 진행 5차 (2026-07-29) — C1 일반유형 조석 codegen

### 완료 — C1
`scripts/codegen_riemann_rust.py` 로 검증된 sympy pickle(144 비영성분, 24 인자)에서
`_rustcore/src/rays/riemann_gen.rs` 를 **자동생성** (333줄, CSE 임시 141개).
손유도 대신 codegen 을 택한 이유: 대각 I 은 Gauss-Codazzi 로 손유도했지만(R4) 일반유형은
항이 많아 손유도가 위험하다.  **검증된 소스에서 기계적으로 뽑으면 구성상 정확**.

| 검증 | 잔차 |
|---|---|
| 일반유형 Riemann R^a_bcd (N,A,R≠0, 30 상태) | 3.6e-15 |
| 일반유형 조석 T_AB (임의 스크린, E_A⁰≠0 포함) | 4.5e-13 |
| **Ricci 집속 오라클** tr T = -R_mn k^m k^n (D16) | 5.7e-14 |
| 대각 극한에서 R4 손유도 닫힌형과 일치 | 4.4e-16 |

**성능**: 조석 2000회 — Python(JAX vmap, warm) 1729 ms → Rust 4.2 ms (**413×**).

**의의**: 이제 Rust 고속 경로가 **VII_h 등 일반유형까지 커버**한다.  이전에는 대각
Bianchi I 만 가능해 12,000× 가속의 과학적 쓸모가 type I 에 갇혀 있었다 (Planck 의
Bianchi 탐색 대상이 VII_h 이므로 이것이 병목이었다).

### 구현 노트
- sympy `RustCodePrinter` 는 정수 리터럴(`2*x`)을 내보내 Rust f64 와 곱셈 불가 →
  `sp.nfloat(e, n=17)` 로 전부 f64 리터럴화 (`2.0*x`).

### 상태
```
pytest 290 passed (fast; C1 신규 5)   cargo test 7 passed
```
### 다음
A3 (r_s 물리 개선) → B1/B2/B3 (Rust 열역학 커널·다준위 재결합·스캔) → D (견고성) → E (GPU)

---

## v3.0 진행 7차 (2026-07-29) — B1 Rust 열역학 커널 + B3 자기일관 동결

### 완료 — B1 (Rust 가 실제로 푸는 병목)
| 커널 | 구현 | 패리티 | 성능 |
|---|---|---|---|
| 중성미자 FD (ρ,p,w) | Gauss-Legendre 2구간 ×64 | scipy.quad 대비 **7e-14** | **266×** |
| g_*(T), g_*s(T) | codegen 표 + 로그선형 보간 | **비트-정확 (0.0)** | — |

**핵심 수치 — DAG 분석에서 예측한 병목이 실측으로 확인·제거되었다:**
```
ODE RHS 안에서 매 스텝 FD 호출 (1e4 스텝):
    Python(scipy.quad)  7.6 초/궤적   →   Rust(GL+Rayon)  28.6 ms/궤적
```
(계획 §0 에서 "궤적당 ~8초, 스캔 1e4 개면 22시간" 이라 추정한 그 항목.)

**설계 결정 2건:**
- 합성 심프슨(N=4000)은 h⁴ 오차라 ~3e-9 에 그쳐 해석 적분값(7π⁴/120, 1.5ζ(3)) 검증에
  실패했다 → **Gauss-Legendre**(총 128 평가)로 교체해 ~1e-15 달성.  평가횟수는 30배
  줄면서 정확도는 6자리 올랐다.
- g_* 표는 Rust 에 손으로 베끼지 않고 **`scripts/codegen_thermo_tables.py` 로 생성**
  (Python 이 단일 진리원).  A1 처럼 표를 고칠 때 조용히 어긋나는 것을 구조적으로 차단 —
  차등테스트가 `==` 비트-정확을 요구한다.

### 완료 — B3 자기일관 g_* 동결 + 이방 스캔
기존 API 는 `g_star=90` 하드코딩이었다.  A1 로 표를 고친 지금 T_f 에서의 실제 g_* 를
반복해로 푼다: 100 GeV WIMP → **T_f=4.46 GeV, g_*=85.21** (5회 수렴), Ωh² 2.9% 보정.
(구표였다면 이 구간을 106.75 라 우겼을 것 — A1 이 없었으면 이 보정이 틀렸다.)
`anisotropy_scan(⟨σv⟩, boosts)`: boost 1.0→2.0 에서 Ωh² 0.0818→0.1584 단조 증가.

### 상태
```
pytest 299 passed (fast; B1 4 + B3 3 신규)   cargo test 14 passed
```
### 다음
B2 다준위 재결합 (RECFAST 3-준위 → HyRec 급) — 남은 최대 항목이자 r_s 잔여 0.15% 의 원천.
이후 C2 (나머지 차트) → D (견고성) → E (GPU).

---

## v3.0 진행 8차 (2026-07-29) — 상태 통합 복원

세션 간 tarball 분산으로 A1(g_* 표)·통합계층(backend.py 등)이 누락된 상태로 시작.
**Rust `dof_table.rs` 가 A1 표의 codegen 사본**이라는 점을 이용해 Python `dof.py` 를
역복원(36점, 비트-동일 확인 — `test_gstar_table_shared_exactly` 통과).
`bianchi/backend.py`, `bianchi/rays/_dispatch.py`, `tests/test_backend_integration.py` 재작성.

```
pytest 299 passed  (손실 이전과 동일)   cargo test 14 passed
```
★ 이후로는 **전체 저장소 스냅샷**을 전달한다 (부분 tarball 병합 시 누락 재발 방지).
