# B2C2B0A joint phase-space closure addendum

## Decision

The matched-closure preflight remains valid, but the proposed B2C2B0 stage
still combines two logically distinct tasks:

1. defining a closed subgrid phase-space operator shared by opacity and
   chemistry;
2. re-evolving the radiation/chemistry/thermal history with that operator.

These are separated into

```text
B2C2B0A — JOINT-PHASESPACE-OPACITY-CHEMISTRY-CLOSURE-LOCK
B2C2B0B — MATCHED-PHASESPACE-HISTORY-LOCK
```

B2C2B unresolved-sink subtraction remains closed until both stages pass.

## Why another split is necessary

The Lumina phase-space recombination formula reconstructs a recombination
rate from a measured or prescribed joint distribution

\[
P_V(\Delta,T,x_s),
\]

including conditional second moments such as
\(\langle x_{\rm HII}^2\rangle_{\Delta,T}\). It is an accounting identity,
not by itself an evolution equation for the conditional distribution.

The current project has two different subgrid marginals:

- B2C0: \(P_V(\Delta,T)\) and conditional H-Beta/He-Dirichlet moments;
- P0.4/R1: density, local reionization-redshift and Gamma-dependent opacity.

Before evolving a matched history, these must be represented by one common
joint measure. Otherwise absorption can be assigned to one unresolved
population while recombinations are evaluated on another.

## Immediate next stage

\[
\boxed{
\texttt{
P0.5-B2C2B0A-
JOINT-PHASESPACE-OPACITY-CHEMISTRY-CLOSURE-LOCK
}
}
\]

This stage builds and verifies the common measure and node-level operators.
It does not re-evolve the full history and does not compute an unresolved
sink.
