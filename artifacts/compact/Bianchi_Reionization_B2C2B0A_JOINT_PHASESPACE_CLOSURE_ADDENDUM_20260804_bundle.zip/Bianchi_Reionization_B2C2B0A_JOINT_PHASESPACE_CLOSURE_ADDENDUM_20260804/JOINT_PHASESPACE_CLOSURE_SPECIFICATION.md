# Joint phase-space opacity–chemistry closure specification

## 1. Common node space

Use a common quadrature index

\[
I=(i_\Delta,i_T,i_r),
\]

where \(r\) denotes local reionization-redshift/history state. The node data
are

\[
\mathcal X_I
=
(\Delta_I,T_I,z_{{\rm re},I},W_I).
\]

The weights satisfy

\[
W_I\ge0,
\qquad
\sum_IW_I=1,
\qquad
\sum_IW_I\Delta_I=1.
\]

## 2. Marginal constraints

The common measure must reproduce the locked marginals:

\[
\sum_{i_r}W_{i_\Delta i_T i_r}
=
P_{B2C0}(\Delta_{i_\Delta},T_{i_T}),
\]

\[
\sum_{i_T}W_{i_\Delta i_T i_r}
=
P_{P0.4}(\Delta_{i_\Delta},z_{{\rm re},i_r}
\mid{\rm ionized},z).
\]

If the two density grids differ, project both to a declared common grid with
a conservative positive remap.

The baseline joint coupling is the maximum-entropy conditional-independence
closure

\[
P(T,z_{\rm re}\mid\Delta)
=
P(T\mid\Delta)P(z_{\rm re}\mid\Delta).
\]

This is a modeling closure, not a calibrated physical theorem. A correlated
\(T-z_{\rm re}\) sensitivity lane must be kept separate.

If the supplied pairwise marginals are numerically inconsistent, use an
iterative proportional fitting / KL projection whose marginal correction
norm is recorded. Do not rescale physical rates to hide marginal errors.

## 3. Node-level opacity

For each node and group,

\[
\kappa_{I,g}
=
\kappa^{\rm eff}_{\rm HI}
(E,z,\Delta_I,z_{{\rm re},I},\Gamma)
+
\kappa^{\rm atom}_{\rm HeI}
+
\kappa^{\rm atom}_{\rm HI,high}
+
\kappa^{\rm atom}_{\rm HeII},
\]

with the existing R1 energy firewall.

The global opacity must be recovered from the same nodes:

\[
\bar\kappa_g
=
\sum_IW_I\kappa_{I,g}.
\]

## 4. Node-level recombination and chemistry

Each node carries conditional moments or local states

\[
y_I
=
(x_{{\rm HII},I},
 x_{{\rm HeII},I},
 x_{{\rm HeIII},I},
 u_I).
\]

Full-OTS recombination is

\[
S_{{\rm rec},I}^{\rm OTS}
=
S_{\rm rec}^{\rm OTS}(\Delta_I,T_I,y_I).
\]

The global phase-space source is

\[
S_{\rm rec}^{\rm phase}
=
\sum_IW_IS_{{\rm rec},I}^{\rm OTS}.
\]

B2C0's algebraic Beta/Dirichlet closure remains an auditor. The primary
predictive lane for the later history stage should evolve node-level species
states, rather than recalibrating second moments to a global fraction after
each step.

## 5. Photon-conserving node allocation

For group \(g\), distribute absorbed photons to nodes using their physical
hazards:

\[
q_{I,g}
=
\frac{W_I\bar\kappa_{I,g}}
{\sum_JW_J\bar\kappa_{J,g}},
\qquad
\sum_Iq_{I,g}=1.
\]

Species allocation within the node uses the B2C1B direct finite-optical-depth
operator:

\[
j^{\rm abs}_{I,s,g}
=
A_{I,s,g}\,
q_{I,g}\,
\dot N_{{\rm abs},g}.
\]

Hard identities:

\[
A_{I,s,g}\ge0,
\qquad
\sum_sA_{I,s,g}=1,
\]

\[
\sum_{I,s}j^{\rm abs}_{I,s,g}
=
\dot N_{{\rm abs},g}.
\]

Threshold-below support is exactly zero.

## 6. Evolving measure caveat

If the common measure \(W_I(t)\) changes with time, global storage obeys

\[
\frac{d}{dt}\sum_IW_In_{s,I}
=
\sum_IW_I\dot n_{s,I}
+
\sum_I\dot W_In_{s,I}.
\]

B2C2B0B must therefore use either:

1. fixed-weight Lagrangian subgrid parcels; or
2. a conservative Eulerian remap with explicit weight-flux ledgers.

Silently rebuilding the PDF at each redshift while omitting the
\(\dot W_I\) contribution is forbidden.

## 7. B2C2B0A hard gates

\[
\left|\sum_IW_I-1\right|<10^{-12},
\]

\[
\left|\sum_IW_I\Delta_I-1\right|<10^{-10},
\]

marginal relative residuals:

\[
<10^{-8},
\qquad
{\rm target}<10^{-10},
\]

\[
\frac{|\sum_IW_I\kappa_{I,g}-\bar\kappa_g^{R1}|}
{\bar\kappa_g^{R1}}
<1\%,
\]

\[
\frac{\|\sum_IW_IS_{{\rm rec},I}^{\rm OTS}
-S_{\rm rec}^{B2C0}\|}
{\|S_{\rm rec}^{B2C0}\|}
<1\%,
\]

\[
\frac{|\sum_{I,s}j^{\rm abs}_{I,s,g}
-\dot N_{{\rm abs},g}|}
{\dot N_{{\rm abs},g}}
<10^{-10}.
\]

No history re-evolution, unresolved subtraction, front allocation or source
calibration is allowed in B2C2B0A.
