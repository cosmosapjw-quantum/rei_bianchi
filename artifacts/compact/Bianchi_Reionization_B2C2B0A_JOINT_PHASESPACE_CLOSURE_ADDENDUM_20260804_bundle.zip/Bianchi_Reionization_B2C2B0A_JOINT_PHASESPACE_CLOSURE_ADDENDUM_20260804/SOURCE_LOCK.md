# Source lock

1. **Mellema et al.**, C2-Ray, arXiv:astro-ph/0508416.
   Photon depletion by bound-free opacity is explicitly required to equal the
   number of photoionizations caused by those photons.

2. **Friedrich et al.**, H/He C2-Ray, arXiv:1201.0602.
   Hydrogen, helium, multifrequency absorption, thermal evolution and the full
   coupled OTS chemistry are solved as one non-equilibrium system.

3. **Sadain et al.**, The Lumina Project: Intergalactic Clumping and
   Recombination Sinks, arXiv:2606.18382.
   The recombination budget is represented in joint density-temperature-
   ionization phase space and depends on conditional second moments. The
   phase-space integral reproduces the measured cell-summed rate, but is not
   itself a reduced dynamical closure.

4. **Choudhury & Chakraborty**, SCRIPT sink model,
   arXiv:2504.03384v2.
   Conditional density distributions, self-shielding, clumping, mean free
   path and photoionization rate are dynamically linked rather than treated
   as independent normalizations.

5. **Bianco et al.**, inhomogeneous subgrid clumping,
   arXiv:2101.01712.
   Local density-dependent and stochastic clumping prescriptions alter the
   photoionization field and reionization evolution, showing that a single
   global recombination multiplier is not an adequate replacement for the
   distribution of sinks.

6. **Cain & D'Aloisio**, FlexRT I, arXiv:2409.04521.
   Flexible opacity backends and adaptive ray tracing support a modular
   transport operator, while chemistry must remain photon-ledger consistent.
