@Web+Wolfram Stage P0.5-B2C2B0A-JOINT-PHASESPACE-OPACITY-CHEMISTRY-CLOSURE-LOCK를 실행해줘.

B2C2A-R1의 canonical direct-opacity operator와
CANONICAL_DIRECT_REEVOLVED history, B2C0 phase-space full-OTS kernel,
B2C1A/B transmission and allocation operators, P0.4 density/z_re/Gamma
response, exact-zero primary G3, FLRW receipts, neutral-island exclusion 및
recombination external-dependency receipt를 정본으로 유지한다.

이번 단계는 matched history를 재진화하는 B2C2B0B가 아니라, opacity와
chemistry가 공유할 common subgrid measure 및 node-allocation operator를
잠그는 B2C2B0A다.

1. 계산 전에 새 durable B2C2B0A directory, input lock, stage state,
   receipts, manifest와 SHA256SUMS를 생성해줘.

2. common node index

   I=(i_Delta,i_T,i_zre)

   와 nonnegative weights W_I를 구성해줘.

   Sum_I W_I = 1,
   Sum_I W_I Delta_I = 1.

3. 다음 두 locked marginals를 동시에 재현해줘.

   A. B2C0 P_V(Delta,T)
   B. P0.4 P(Delta,z_re | ionized,z)

   density grids가 다르면 positive conservative remap을 사용해줘.

4. baseline joint coupling은 maximum-entropy conditional independence

   P(T,z_re|Delta)
     = P(T|Delta) P(z_re|Delta)

   로 두고, 이것이 modeling assumption임을 명시해줘.
   T-z_re correlated sensitivity auditor를 별도 lane으로 만들어줘.

5. pairwise marginals가 discretization 때문에 불일치하면
   iterative proportional fitting/KL projection을 사용하되,
   marginal correction norm과 KL change를 저장해줘.
   physical rate를 rescale해 marginal error를 숨기지 마.

6. 각 common node에서 R1 opacity component와 B2C0 full-OTS source를
   동시에 계산해줘.

   kappa_bar_g = Sum_I W_I kappa_(I,g),

   S_rec^phase = Sum_I W_I S_rec,I^OTS.

7. R1 global group opacity 및 B2C0 phase-space maintenance를 common-node
   sum으로 각각 <1% 오차로 재현해줘.
   두 target에 맞추기 위한 free normalization은 금지한다.

8. absorbed group photons를 node hazards에 따라

   q_(I,g)
     = W_I kappa_(I,g) /
       Sum_J W_J kappa_(J,g)

   로 배분하고, B2C1B direct finite-tau species allocation A_(I,s,g)를
   결합해줘.

   j_abs_(I,s,g)
     = A_(I,s,g) q_(I,g) Ndot_abs,g.

9. 다음 identities를 검증해줘.

   q>=0,
   Sum_I q_(I,g)=1,

   A>=0,
   Sum_s A_(I,s,g)=1,

   Sum_(I,s) j_abs_(I,s,g)=Ndot_abs,g,

   threshold 아래 support exact zero,
   primary G3/external HeII exact zero.

10. closure lanes를 분리해줘.

    A. LOCAL_NODE_STATE_PRIMARY:
       B2C2B0B에서 node species/thermal states를 진화시킬 준비가 된
       closure.

    B. ALGEBRAIC_BETA_DIRICHLET_AUDITOR:
       B2C0의 현재 moment closure.

    C. HOMOGENEOUS_CHEMISTRY_AUDITOR.

11. measure evolution policy를 잠가줘.

    - fixed-weight Lagrangian parcels 또는
    - conservative Eulerian remap + explicit weight-flux ledger.

    redshift마다 PDF를 재생성하면서 dot W_I storage term을 버리는
    구현은 fail closed해줘.

12. Wolfram으로 marginal sums, opacity/source sums, allocation identities,
    nuclei stoichiometry와 exact-zero support를 검증해줘.
    Precise Special Functions는 lognormal/power-law의 닫힌 marginal
    moments를 고정밀 oracle로만 사용해줘.

13. 이번 B2C2B0A에서는 full history re-evolution,
    unresolved-sink subtraction, front allocation, Q_M growth,
    source/f_esc calibration, primordial recombination implementation,
    primitive geometry transplant와 Bianchi feedback을 시작하지 마.

common-node closure와 photon allocation이 닫힌 뒤에만
P0.5-B2C2B0B-MATCHED-PHASESPACE-HISTORY-LOCK를 승인해줘.
