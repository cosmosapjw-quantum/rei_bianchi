# Recombination externalization addendum

## Decision

Primordial recombination is an independent project and is not implemented,
refactored, approximated, or transplanted in the current Full
Bianchi–FlexRT reionization project.

The current project owns:

- post-handoff ionizing UV transport;
- H/He reionization chemistry and thermal evolution;
- ionized-IGM opacity, maintenance, unresolved sinks, and fronts;
- Bianchi background coupling, tilt, Thomson scattering, and CMB transfer;
- a stable external recombination interface and splice validator.

The external recombination project owns:

- primordial H/He recombination and multilevel-atom physics;
- Ly-alpha and recombination-radiation transfer internal to that project;
- residual electron fraction and matter temperature before reionization;
- its numerical error, provenance, and validity interval.

## Immediate consequence

B2C2A/B/C proceed without importing a recombination implementation. Their
initial state is the durable B2C1C post-recombination/reionization state.
Every stage records that the recombination dependency is external and not
loaded.

## Final-claim consequence

D0 can certify the reionization/Bianchi/FlexRT subsystem against a mock or
tabulated external provider. An end-to-end early-universe-to-late-reionization
CMB claim requires a later adapter/integration gate after the independent
recombination project is supplied.

## Next stage

Use `B2C2A_RECOMBINATION_DECOUPLED_NEXT_STAGE_PROMPT.md` as the canonical
prompt for the next execution.
