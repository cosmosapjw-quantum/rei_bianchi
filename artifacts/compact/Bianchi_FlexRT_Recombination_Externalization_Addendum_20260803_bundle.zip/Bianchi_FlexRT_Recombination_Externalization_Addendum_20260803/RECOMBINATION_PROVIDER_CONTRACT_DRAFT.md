# External Recombination Provider contract draft

## Purpose

Define a stable seam between an independently developed recombination solver
and the Full Bianchi–FlexRT/CAMB-level homogeneous reionization/CMB system.
The interface exposes physical history and uncertainty; it does not expose or
inherit the provider's internal atomic-state implementation.

## Dependency direction

```text
BackgroundHistory
       |
       v
ExternalRecombinationProvider  ---> RecombinationHistory
                                      |
ReionizationHistory -----------------+--> ElectronHistoryAssembler
                                               |
                                               v
                                      Thomson/visibility/CMB transfer
```

The current project depends on the protocol, never on a concrete HyRec,
CosmoRec, RECFAST, or future Full-Bianchi recombination implementation.

## Protocol

```python
class ExternalRecombinationProvider(Protocol):
    def solve(
        self,
        background: BackgroundHistory,
        params: RecombinationParameters,
    ) -> RecombinationHistory: ...

class RecombinationHistory(Protocol):
    def snapshot_at_t(self, t_s: float) -> RecombinationSnapshot: ...
    def snapshot_at_z(self, z: float) -> RecombinationSnapshot: ...
    def interval(self) -> tuple[float, float]: ...
    def receipt(self) -> RecombinationReceipt: ...
```

## Required snapshot fields

```text
t_s, z, a
x_HII, x_HeI, x_HeII, x_HeIII
x_e_per_H
T_m_K
n_e_proper_cm-3

dx_e_dt_s-1
dT_m_dt_K_s-1              optional but strongly preferred

validity_flag
local_error_estimate
interpolation_error_estimate
snapshot_sha256
```

Future Bianchi-capable providers may additionally return direction-dependent
radiation moments or multilevel populations, but the common interface must not
require them for an FLRW provider.

## Required receipt fields

```text
provider_id / semantic_version
source_commit_or_archive_sha256
atomic_data_manifest_sha256
background_history_receipt_sha256
metric/sign/unit convention tags
validity redshift/time interval
solver tolerances and precision
recombination_only = true
contains_astrophysical_reionization = false
contains_late_HeII_reionization = false
```

A provider that embeds tanh, phenomenological, or astrophysical reionization
must be rejected for the production splice because it would double-count the
current project's reionization solver.

## Handoff state

The splice layer requests a `RecombinationHandoff` at an accepted boundary:

```text
handoff_id / sha256
t_handoff_s, z_handoff
species fractions
x_e_per_H
T_m_K / thermal internal energy
first derivatives
provider-side covariance/error estimate
```

The reionization solver owns the state after the handoff. The recombination
provider is immutable during reionization evolution.

## Electron-history assembly

The assembled electron history is not a sum of two full histories. It is a
piecewise or blended ownership transfer:

```text
x_e(t) = recombination provider       before handoff window
       = continuity-preserving blend  inside handoff window
       = reionization solver          after handoff window
```

The blend, if used, must preserve species bounds and at least C0 continuity;
C1 continuity is required for visibility-source derivatives unless a
controlled non-smooth adapter is explicitly audited.

## Acceptance criteria

- No overlap of astrophysical reionization ownership.
- Species fractions and electron fraction remain physical.
- `n_e`, `T_m`, and optical-depth integrands are continuous to the declared
  regularity.
- No change to a provider's history outside the handoff window.
- Provider/background convention hashes match.
- Recombination implementation can be replaced without changing FlexRT,
  Bianchi geometry, or CMB source APIs.
