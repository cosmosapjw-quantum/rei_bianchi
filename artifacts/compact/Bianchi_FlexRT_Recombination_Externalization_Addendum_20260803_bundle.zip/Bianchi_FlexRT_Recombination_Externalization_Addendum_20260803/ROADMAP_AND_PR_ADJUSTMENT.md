# Roadmap and PR adjustment after recombination externalization

## What does not change

PR 2 through PR 10 continue in the adopted order:

1. PR 2 — B2C2 absorption/unresolved/front closure
2. PR 3 — B2D source ensemble and Q/Gamma closure
3. PR 4 — B2E homogeneous FLRW/FlexRT end-to-end solver and interface freeze
4. PR 5 — C0 Bianchi I/V/II geometry coupling
5. PR 6 — C1A tilt/electron-frame/multifluid exchange
6. PR 7 — C1B all 11 Bianchi types and exceptional branches
7. PR 8 — C2 CMB kinetic/Thomson coupling
8. PR 9 — C3 anisotropic line of sight and CAMB-level observables
9. PR 10 — D0 all-type verification

## New reserved integration gate

One PR slot in the adopted 10–12 PR envelope is reserved for the independent
recombination project when it is supplied:

- PR 11 — external recombination adapter, handoff/splice validation, and
  early-to-late electron-history integration.

If documentation/release packaging is kept separate:

- PR 12 — equation compendium, claim matrix, release packaging.

If the recombination project is not ready by D0, D0 may certify the current
subsystem using mock/tabulated providers, but the end-to-end primordial
recombination-to-CMB claim remains `BLOCKED_EXTERNAL_DEPENDENCY`.

## Interfaces frozen before recombination arrives

PR 2:
- record external-dependency and handoff provenance only;
- no recombination API implementation.

PR 4:
- implement and freeze `ExternalRecombinationProvider`,
  `RecombinationHistory`, `ElectronHistoryAssembler`, and `MatterSource`
  contracts;
- supply `FrozenInitialStateProvider` and `TabulatedHistoryProvider` test
  implementations only.

PR 8/9:
- consume the assembled electron history, never a concrete recombination
  code.

PR 10:
- test provider replacement, continuity, convention mismatch failures, and
  optical-depth/visibility stability.
