@Web+Wolfram Stage P0.5-B2C2A-IONIZED-ABSORPTION-DECOMPOSITION-LOCK를 실행해줘.

B2C1C의 exact-zero primary G3 support, primary HeIII decay state,
B2C1B direct finite-tau multigroup H/He operator, B2C1A global/F-selected Q
firewall, B2C0 phase-space maintenance kernel, B2B causal photon history와
primitive-code BackgroundHistory contract를 정본으로 유지한다.

중요한 scope lock:
- primordial recombination은 별도 외부 프로젝트다.
- 이번 stage에서 recombination equation, RECFAST/HyRec/CosmoRec adapter,
  multilevel atom 또는 recombination-radiation transfer를 구현하지 마.
- B2C1C의 durable z=6 initial/handoff state를 사용해 post-handoff
  reionization absorption만 계산해줘.

1. 계산 전에 새 durable B2C2A directory, input lock, stage state,
   receipts, manifest와 SHA256SUMS를 생성해줘.

2. `RECOMBINATION_EXTERNAL_DEPENDENCY_RECEIPT.json`을 먼저 생성해줘.
   최소 필드:

   dependency_status = EXTERNAL_NOT_LOADED,
   ownership = PRIMORDIAL_RECOMBINATION_ONLY,
   current_initial_state_source = B2C1C_DURABLE_HANDOFF,
   contains_astrophysical_reionization = false,
   future_provider_contract = ExternalRecombinationProvider,
   forbidden_double_count = true.

   이번 stage의 수치에는 external recombination provider를 호출하지 마.

3. background는 `FLRW_CONTROL`로 유지하되 모든 interval row에

   background_snapshot_id,
   background_snapshot_sha256,
   background_model,
   proper_time_start_s, proper_time_end_s,
   H_start_s^-1, H_end_s^-1,
   ell_start_cm, ell_end_cm,
   thermodynamics_handoff_id,
   thermodynamics_handoff_sha256,
   recombination_dependency_status

   를 기록해줘. Primitive Bianchi geometry를 이식하거나 feedback을
   켜지 마.

4. group별 ionized-phase absorption을 causal photon history에서

   Ndot_abs,ion,g^c =
     (1/Delta t) Integral c kappa_tot,g(t) N_gamma,g^c(t) dt

   로 계산해줘. Photon storage, group-boundary redshift flux,
   ionized absorption과 neutral-front absorption을 분리해줘.

5. opacity firewall:

   - 13.6--39.5 eV: P0.4 effective HI opacity가 H-I absorber 정본이다.
     explicit diffuse atomic HI opacity를 더하지 마.
   - HeI/HeII atomic opacity는 threshold가 허용되는 component로 별도 유지.
   - 39.5 eV 초과: explicit Verner HI/HeI/HeII high-energy lane.
   - primary G3 source/absorption은 exact zero.
   - neutral-island transfer는 ionized unresolved sink에 넣지 마.

6. direct finite-tau component hazard로

   A_(s,g) =
     Integral phi_g(E)[1-exp(-tau_tot)] tau_(s,g)/tau_tot dE /
     Integral phi_g(E)[1-exp(-tau_tot)] dE

   를 계산하고 64-node reference와 production quadrature를 비교해줘.

   A>=0, Sum_s A=1, threshold-zero exact,
   direct/production mismatch <1%를 gate로 사용해줘.

7. species/group absorption table

   Ndot_abs,ion,s,g^c = A_(s,g) Ndot_abs,ion,g^c

   를 생성하고 provenance를
   EFFECTIVE_HI / EXPLICIT_HI / EXPLICIT_HEI / EXPLICIT_HEII로 저장해줘.

8. causal absorption과 FlexRT-style homogeneous cell-deposition auditor를
   독립 비교하고 상대차 <1%를 engineering gate로 사용해줘.

9. 이번 B2C2A에서 금지:

   - recombination implementation 또는 provider adapter
   - Ndot_unresolved subtraction
   - front를 residual로 정의
   - source/f_esc calibration
   - primitive geometry transplant
   - Bianchi feedback

10. Wolfram gates:

   - group-boundary redshift-flux telescoping
   - component allocation sum
   - no-double-count firewall
   - proper/comoving dimensional conversion
   - primary G3 and external HeII absorption exact zero
   - handoff/electron-fraction ownership이 additive double count가 아님을
     symbolic state-ownership table로 검증

11. Precise Special Functions는 analytic power-law group moments와 실제로
    hypergeometric/Beta 형태로 닫히는 limit의 high-precision oracle로만
    사용해줘. Production finite-tau operator는 direct quadrature를 유지해줘.

B2C2A가 통과한 뒤에만 B2C2B에서

Ndot_unresolved,s,g^c =
  Ndot_abs,ion,s,g^c - Ndot_maint,diffuse,s,g^c

를 계산하고 음수 component를 fail closed해줘.
