# Source lock

- CAMB current class boundary: reionization models expose `x_e(z,tau,xe_recomb)`
  and receive the residual recombination electron fraction for a smooth handoff.
- CAMB keeps Recombination and Reionization as separate modules/dependencies.
- CLASS thermodynamics keeps recombination algorithm and reionization
  parametrization as separate configuration concepts and publishes a shared
  interpolated thermodynamics table to downstream modules.
- FlexRT provides adaptive ray tracing with a flexible IGM-opacity treatment.
- SCRIPT sink modelling couples emissivity, clumping, mean free path and
  photoionization through a common density/sink closure.

These are architecture precedents, not numerical inputs to B2C2A.
