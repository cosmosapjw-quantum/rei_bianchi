from __future__ import annotations
import json, math, sys
from pathlib import Path
import numpy as np, pandas as pd
from scipy.integrate import solve_ivp, quad
from scipy.optimize import fsolve
BASE=Path('/mnt/data/Bianchi_FlexRT_Primitive_Context_Survey_20260803')
sys.path.insert(0,str(BASE/'shim')); sys.path.insert(1,str(BASE/'repo'))
import bianchi
import jax.numpy as jnp
from bianchi.charts import class_a as ca, class_b as cb, class_b_tilted as bt
from bianchi.physical import chart as pc
OUT=BASE/'reference_run'; OUT.mkdir(exist_ok=True)
MPC_KM=3.0856775814913673e19; MYR_S=3.15576e13
H0=67.4; OM=0.315; OL=0.685; Z0=6.0; Z1=5.5
DTau=math.log((1+Z0)/(1+Z1)); Hz0=H0*math.sqrt(OM*(1+Z0)**3+OL); Hz0s=Hz0/MPC_KM
dt_lcdm=quad(lambda z: 1/((1+z)*(H0/MPC_KM)*math.sqrt(OM*(1+z)**3+OL)),Z1,Z0,epsrel=1e-12)[0]
def integ(fn,y0,args,n=241):
 ts=np.linspace(0,DTau,n); sol=solve_ivp(lambda t,y: np.asarray(fn(t,y,args),float),(0,DTau),np.asarray(y0,float),t_eval=ts,method='DOP853',rtol=2e-11,atol=2e-13)
 if not sol.success: raise RuntimeError(sol.message)
 return ts,sol.y.T,sol.nfev
def ca_run(name,state,g=1.0):
 args={'gamma':g}; fn=lambda t,v,a: ca.rhs(t,ca.StateA.from_array(jnp.asarray(v)),a).as_array(); ts,ys,nfev=integ(fn,state.as_array(),args)
 aa=[ca.aux(ca.StateA.from_array(jnp.asarray(v)),g) for v in ys]; q=np.array([float(x['q']) for x in aa]); om=np.array([float(x['Omega']) for x in aa]); s2=np.array([float(x['Sigma2']) for x in aa]); K=np.array([float(x['K']) for x in aa]); H=pc.hubble_of_tau(ts,q,H0=Hz0s); t=pc.cosmic_time_of_tau(ts,H); r=np.array([float(ca.omega_identity_residual(ca.StateA.from_array(jnp.asarray(v)),args)) for v in ys]); df=pd.DataFrame(ys,columns=ca.STATE_NAMES); df.insert(0,'tau',ts); df['z_proxy']=(1+Z0)*np.exp(-ts)-1; df['Omega']=om; df['Sigma2']=s2; df['K']=K; df['q']=q; df['H_s-1']=H; df['elapsed_Myr']=t/MYR_S; df.to_csv(OUT/f'{name}.csv',index=False); return dict(model=name,chart='class_a',nfev=nfev,Omega0=om[0],Omega1=om[-1],Sigma2_0=s2[0],Sigma2_1=s2[-1],K0=K[0],K1=K[-1],H_ratio=H[-1]/H[0],elapsed_Myr=t[-1]/MYR_S,max_constraint_or_identity=float(np.max(abs(r))))
def cb_run(name,state,k,g=1.0):
 args={'gamma':g,'kappa':k}; fn=lambda t,v,a: cb.rhs(t,cb.StateB.from_array(jnp.asarray(v)),a).as_array(); ts,ys,nfev=integ(fn,state.as_array(),args); aa=[cb.aux(cb.StateB.from_array(jnp.asarray(v)),g,k) for v in ys]; q=np.array([float(x['q']) for x in aa]); om=np.array([float(x['Omega']) for x in aa]); s2=np.array([float(x['Sigma2']) for x in aa]); K=np.array([float(x['K']) for x in aa]); H=pc.hubble_of_tau(ts,q,H0=Hz0s); t=pc.cosmic_time_of_tau(ts,H); c=np.array([float(cb.codazzi(cb.StateB.from_array(jnp.asarray(v)),k)) for v in ys]); p=np.array([float(cb.codazzi_propagation_residual(cb.StateB.from_array(jnp.asarray(v)),args)) for v in ys]); df=pd.DataFrame(ys,columns=cb.STATE_NAMES); df.insert(0,'tau',ts); df['z_proxy']=(1+Z0)*np.exp(-ts)-1; df['Omega']=om; df['Sigma2']=s2; df['K']=K; df['q']=q; df['H_s-1']=H; df['elapsed_Myr']=t/MYR_S; df.to_csv(OUT/f'{name}.csv',index=False); return dict(model=name,chart='class_b',kappa=k,nfev=nfev,Omega0=om[0],Omega1=om[-1],Sigma2_0=s2[0],Sigma2_1=s2[-1],K0=K[0],K1=K[-1],H_ratio=H[-1]/H[0],elapsed_Myr=t[-1]/MYR_S,max_constraint_or_identity=float(max(np.max(abs(c)),np.max(abs(p)))))
def tilted_ic(g=1.0):
 rng=np.random.default_rng(11)
 for _ in range(500):
  geo=rng.normal(size=8)*0.015; geo[5]=abs(geo[5])+0.01; geo[6]=rng.uniform(-.45,.45); geo[7]=abs(geo[7])+0.008
  def cons(v):
   c=bt.constraints(bt.StateBT.from_array(jnp.asarray(np.r_[geo,v])),{'gamma':g}); return [float(c[k]) for k in ('C2','C3','C4')]
  v=fsolve(cons,rng.normal(size=3)*.005,xtol=1e-12,maxfev=1000); st=bt.StateBT.from_array(jnp.asarray(np.r_[geo,v])); a=bt.aux(st,{'gamma':g}); c=bt.constraints(st,{'gamma':g})
  if float(a['Omega'])>.8 and float(a['V2'])<.1 and max(abs(float(c[k])) for k in ('C2','C3','C4'))<1e-10: return np.r_[geo,v]
 raise RuntimeError
def tilted_run():
 name='Bianchi_classB_tilted_dust'; g=1.; args={'gamma':g}; y0=tilted_ic(); fn=lambda t,v,a: bt.rhs(t,bt.StateBT.from_array(jnp.asarray(v)),a).as_array(); ts,ys,nfev=integ(fn,y0,args,n=181); aa=[bt.aux(bt.StateBT.from_array(jnp.asarray(v)),args) for v in ys]; q=np.array([float(x['q']) for x in aa]); om=np.array([float(x['Omega']) for x in aa]); s2=np.array([float(x['Sigma2']) for x in aa]); K=np.array([float(x['K']) for x in aa]); V2=np.array([float(x['V2']) for x in aa]); H=pc.hubble_of_tau(ts,q,H0=Hz0s); t=pc.cosmic_time_of_tau(ts,H); cs=np.array([[float(bt.constraints(bt.StateBT.from_array(jnp.asarray(v)),args)[k]) for k in ('C1','C2','C3','C4')] for v in ys]); df=pd.DataFrame(ys,columns=bt.STATE_NAMES); df.insert(0,'tau',ts); df['z_proxy']=(1+Z0)*np.exp(-ts)-1; df['Omega']=om; df['Sigma2']=s2; df['K']=K; df['V2']=V2; df['q']=q; df['H_s-1']=H; df['elapsed_Myr']=t/MYR_S; df.to_csv(OUT/f'{name}.csv',index=False); return dict(model=name,chart='class_b_tilted',nfev=nfev,Omega0=om[0],Omega1=om[-1],Sigma2_0=s2[0],Sigma2_1=s2[-1],K0=K[0],K1=K[-1],V0=float(np.sqrt(V2[0])),V1=float(np.sqrt(V2[-1])),H_ratio=H[-1]/H[0],elapsed_Myr=t[-1]/MYR_S,max_constraint_or_identity=float(np.max(abs(cs))))
models=[]; models.append(ca_run('Bianchi_I_dust',ca.StateA.of(1e-3,-5e-4,0,0,0))); models.append(ca_run('Bianchi_II_dust',ca.from_type('II',Sp=1e-3,Sm=-5e-4,scale=1e-2))); models.append(ca_run('Bianchi_VI0_dust',ca.from_type('VI_0',Sp=1e-3,Sm=-5e-4,scale=1e-2))); models.append(cb_run('Bianchi_V_dust',cb.type_V_state(1.25e-6,1e-4),0.)); st,_=cb.on_codazzi_surface(1e-3,1e-4,1e-4,.02,-4.); models.append(cb_run('Bianchi_VIh_kappa_minus4_dust',st,-4.)); models.append(tilted_run())
meta={'archive_sha256':'ba10a80ca7e4cec510e935d5a75032725ae822b89cb25c6dd2599d770955ef38','scope':'primitive reference; repository RHS + SciPy DOP853 via scratch Equinox compatibility shim; not production dependency reproduction','z_start':Z0,'z_end':Z1,'delta_tau':DTau,'H_z6_km_s_Mpc':Hz0,'flat_LCDM_elapsed_Myr':dt_lcdm/MYR_S,'models':models}
(OUT/'reference_run_summary.json').write_text(json.dumps(meta,indent=2),encoding='utf-8'); pd.DataFrame(models).to_csv(OUT/'reference_run_summary.csv',index=False); print(json.dumps(meta,indent=2))
