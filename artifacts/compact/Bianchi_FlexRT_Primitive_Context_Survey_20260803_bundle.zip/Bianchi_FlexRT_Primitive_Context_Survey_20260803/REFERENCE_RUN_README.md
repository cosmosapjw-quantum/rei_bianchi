# Background reference run

This run uses repository RHS functions through a scratch state-container compatibility shim and SciPy DOP853. It does not modify the uploaded source and is not a replacement for the pinned Diffrax/Rust production environment.

- `z_start=6`, `z_end=5.5`
- `Delta tau = ln(7/6.5) = 0.0741079721537`
- Planck-like reference: `H0=67.4 km/s/Mpc`, `Omega_m=0.315`, `Omega_Lambda=0.685`
- flat-LambdaCDM elapsed time: `109.0114107946 Myr`

The models use a dust-like gamma=1 and deliberately small shear/curvature. They are interface and convention tests, not inferred cosmological models.
