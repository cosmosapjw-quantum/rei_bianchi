from __future__ import annotations
import dataclasses
class Module:
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        dataclasses.dataclass(cls)
def field(*, converter=None, **kwargs):
    allowed={'default','default_factory','init','repr','hash','compare','metadata','kw_only'}
    return dataclasses.field(**{k:v for k,v in kwargs.items() if k in allowed})
def filter_jit(fn): return fn
