# Primitive Bianchi code context survey

## Decision supported
How to use `bianchibianchic2` as a reference implementation while completing the Full Bianchi–FlexRT/CAMB-level homogeneous reionization program, without prematurely coupling or transplanting unstable interfaces.

## Provenance
- Uploaded archive SHA-256: `ba10a80ca7e4cec510e935d5a75032725ae822b89cb25c6dd2599d770955ef38`.
- No Git metadata was present in the archive; PR statements are project documentation, not independently verified commit history.
- Source size: about 38,627 Python/Rust lines across 82 package modules, 62 test modules, 50 independent-audit modules and 26 Rust modules.

## Primary evidence inspected
- Project state: `README.md`, `PR-STATUS.md`, `PLAN-NEXT-v4.md`, `requirements.lock`, `bootstrap.sh`.
- Geometry/conventions: `bianchi/conventions.py`, `algebra.py`, `charts/*`.
- Physical adapters: `physical/chart.py`, `frame_transport.py`, `initial.py`.
- Tilt/matter: `charts/class_b_tilted.py`, `matter/*`.
- Characteristics/thermo/CMB: `rays/*`, `observables/*`, `thermo/*`.
- Backend: `backend.py`, `_rustcore/README.md`, `_rustcore/src/*`.

## Reproduced evidence
- The exact pinned environment was not reproduced: the runtime lacks Diffrax/Equinox and its internal package index did not contain `diffrax==0.7.2`.
- A scratch Equinox compatibility shim was used only to instantiate immutable state containers; SciPy DOP853 called the repository chart RHS directly.
- Selected tests: 57 passed (`test_flrw_limit`, `test_m8_physical`, `test_m9_recomb`, `test_k4c_type_v_tilted`). This does not reproduce the archive's documented full-suite count.
- Six background references were run over `z=6 -> 5.5`: Bianchi I, II, VI_0, V, VI_h(kappa=-4), and constrained tilted class B. Constraint/identity residuals are `O(10^-16)` to `O(10^-21)`.

## Main architecture finding
Treat the primitive archive as:
1. an immutable `GeometryBackend` and `AuditOracle`; and
2. a future performance backend after the reionization interfaces freeze.

Do not put the new UV/full-OTS/FlexRT state directly into every chart RHS. Use this boundary:

```text
GeometryBackend
  -> BackgroundHistory / BackgroundSnapshot
  -> ReionizationOperator
  -> MatterSource {Omega, q_flux, Pi, Q_energy, Q_momentum}
  -> coupled geometry step
```

`BackgroundSnapshot` must expose physical time, H, ell, Sigma/N/A/R, frame velocities, triad, dense interpolation provenance, chart/type identity and constraint receipts. `ReionizationState` remains a separate state with photon groups, H/He fractions, thermal energy, QV/QM/topology history, Jacobian and ledgers.

## Important limitations
- Primitive `thermo/recombination.py` is Saha/Peebles-level and should be an auditor only.
- `general_matter` evolves Omega and flux but prescribes Pi.
- `class_b_tilted` is a strong single-fluid geometry oracle, not the final multifluid state.
- General ray formulas are reusable; diagonal convenience integrators need background-history callbacks.
- Rust transplantation should wait for interface freeze and preserve Python differential oracles.

## Confidence
High for formula/interface compatibility: direct source inspection plus six successful background runs.
Medium for production readiness: exact dependencies and Rust extension were not rebuilt here.
