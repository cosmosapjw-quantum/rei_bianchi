"""Timestep-resolved physical branch continuation for P0.5-B2B."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import math
import sys
from pathlib import Path

import jax
jax.config.update("jax_enable_x64", True)
import jax.numpy as jnp
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from scipy.optimize import root

STAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STAGE / "src"))

from b2b_physical_model import (  # noqa: E402
    allocate_front_sink,
    build_opacity_fit,
    make_params,
    make_spectrum_lanes,
    physical_state_from_z8,
    residual_history,
    transform_state_to_z8,
    z8_rhs,
    z9_from_state,
)
from monolithic_model_b2a import physical_vector, transform_z_to_y  # noqa: E402

B1 = (
    STAGE
    / "inputs"
    / "extracted_P0_5_B1"
    / "Bianchi_Reionization_Stage_P0_5_B1_PHOTON_ALLOCATION_QMASS_LOCK"
)
P04 = (
    STAGE
    / "inputs"
    / "extracted_P0_4"
    / "Bianchi_Reionization_Stage_P0_4_PAPER_CODE_CHECKPOINT_REGRESSION"
)
RAW_TABLE = P04 / "data" / "environment_mfp_energies.txt"
DENSITY_MAP = P04 / "data" / "density_mapping_colossus_1_3_10_port.csv"

OUT = STAGE / "data"
CHECKPOINTS = STAGE / "checkpoints"
LOGS = STAGE / "logs"
for path in [OUT, CHECKPOINTS, LOGS, OUT / "branches"]:
    path.mkdir(parents=True, exist_ok=True)

DT_LIST = [0.05, 0.025, 0.0125, 0.00625, 0.003125]
MYR_SECONDS = 1.0e6 * 365.25 * 86400.0


def append_receipt(record: dict) -> None:
    with (STAGE / "RUN_RECEIPTS.jsonl").open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(record, ensure_ascii=False) + "\n")


def update_state(substage: str, claim: str) -> None:
    path = STAGE / "STAGE_STATE.json"
    state = json.loads(path.read_text())
    state["current_substage"] = substage
    if substage not in state["completed_substages"]:
        state["completed_substages"].append(substage)
    state["open_substages"] = [x for x in state["open_substages"] if x != substage]
    state["last_update_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
    state.setdefault("scientific_claims", []).append(claim)
    path.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")


def canonical_hash(record: dict) -> str:
    return hashlib.sha256(
        json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


lanes = make_spectrum_lanes()
predecessors = json.loads((CHECKPOINTS / "physical_predecessors.json").read_text())
allocation = pd.read_csv(B1 / "data" / "photon_allocation_all_lanes.csv")
row55 = allocation[
    (allocation["lane"] == "INSIDE_OUT_SELF_SHIELD_PRIMARY")
    & np.isclose(allocation["z_mid"], 5.55)
].iloc[0]
EMISSION_REF = float(row55["total_causal_emission_rate"])

# Generic JAX kernels compile once for all parameter pytrees with identical shapes.
@jax.jit
def F_generic(z, eta, logeps0, p):
    return residual_history(z, logeps0 + eta, p)

JZ_generic = jax.jit(jax.jacfwd(F_generic, argnums=0))
JETA_generic = jax.jit(jax.jacfwd(F_generic, argnums=1))
RHS8_generic = jax.jit(z8_rhs)


def F(z: np.ndarray, eta: float, logeps0: float, p: dict) -> np.ndarray:
    return np.asarray(
        F_generic(jnp.asarray(z), jnp.array(eta), jnp.array(logeps0), p),
        dtype=float,
    )


def JZ(z: np.ndarray, eta: float, logeps0: float, p: dict) -> np.ndarray:
    return np.asarray(
        JZ_generic(jnp.asarray(z), jnp.array(eta), jnp.array(logeps0), p),
        dtype=float,
    )


def JETA(z: np.ndarray, eta: float, logeps0: float, p: dict) -> np.ndarray:
    return np.asarray(
        JETA_generic(jnp.asarray(z), jnp.array(eta), jnp.array(logeps0), p),
        dtype=float,
    ).reshape(9)


def damped_newton(
    z_guess: np.ndarray,
    eta: float,
    logeps0: float,
    p: dict,
    tol: float = 1.0e-11,
    maxiter: int = 35,
) -> tuple[np.ndarray, int]:
    z = np.array(z_guess, dtype=float)
    for iteration in range(1, maxiter + 1):
        r = F(z, eta, logeps0, p)
        nr = float(np.max(np.abs(r)))
        if nr < tol:
            return z, iteration
        dz = np.linalg.solve(JZ(z, eta, logeps0, p), -r)
        alpha = 1.0
        accepted = False
        for _ in range(20):
            zn = z + alpha * dz
            if np.all(np.isfinite(zn)):
                rn = F(zn, eta, logeps0, p)
                if np.max(np.abs(rn)) < (1.0 - 1.0e-4 * alpha) * nr:
                    z = zn
                    accepted = True
                    break
            alpha *= 0.5
        if not accepted:
            z = z + 0.05 * dz
    raise RuntimeError(
        f"Newton failed eta={eta}: residual={np.max(np.abs(F(z, eta, logeps0, p)))}"
    )


def tangent(z: np.ndarray, eta: float, orientation: float, logeps0: float, p: dict) -> np.ndarray:
    matrix = np.column_stack([JZ(z, eta, logeps0, p), JETA(z, eta, logeps0, p)])
    _, _, vh = np.linalg.svd(matrix)
    t = vh[-1]
    if t[-1] * orientation < 0.0:
        t = -t
    return t / np.linalg.norm(t)


def corrector(
    x_pred: np.ndarray,
    t_prev: np.ndarray,
    logeps0: float,
    p: dict,
    tol: float = 1.0e-10,
    maxiter: int = 30,
) -> tuple[np.ndarray, int]:
    x = np.array(x_pred, dtype=float)
    for iteration in range(1, maxiter + 1):
        z, eta = x[:9], float(x[9])
        residual = np.r_[
            F(z, eta, logeps0, p),
            np.dot(t_prev, x - x_pred),
        ]
        nr = float(np.max(np.abs(residual)))
        if nr < tol:
            return x, iteration
        bordered = np.vstack(
            [
                np.column_stack(
                    [JZ(z, eta, logeps0, p), JETA(z, eta, logeps0, p)]
                ),
                t_prev,
            ]
        )
        dx = np.linalg.solve(bordered, -residual)
        alpha = 1.0
        accepted = False
        for _ in range(20):
            xn = x + alpha * dx
            rn = np.r_[
                F(xn[:9], float(xn[9]), logeps0, p),
                np.dot(t_prev, xn - x_pred),
            ]
            if np.max(np.abs(rn)) < (1.0 - 1.0e-4 * alpha) * nr:
                x = xn
                accepted = True
                break
            alpha *= 0.5
        if not accepted:
            x = x + 0.05 * dx
    raise RuntimeError(f"Arc corrector failed: residual={nr}")


def margins(z: np.ndarray) -> tuple[float, float, float, float]:
    state = transform_z_to_y(jnp.asarray(z))
    min_photon = float(np.min(np.asarray(state["N"])))
    min_fraction = float(
        min(
            state["xHII"],
            1.0 - state["xHII"],
            state["xHeI"],
            state["xHeII"],
            state["xHeIII"],
        )
    )
    return min_photon, min_fraction, float(state["u"]), float(state["GammaHI"])


def branch_record(
    *,
    lane: str,
    dt_myr: float,
    direction: int,
    index: int,
    x: np.ndarray,
    iterations: int,
    tangent_vec: np.ndarray,
    logeps0: float,
    p: dict,
    parent_hash: str | None,
) -> dict:
    z, eta = x[:9], float(x[9])
    jac = JZ(z, eta, logeps0, p)
    singular = np.linalg.svd(jac, compute_uv=False)
    min_photon, min_fraction, u, gamma = margins(z)
    record = {
        "lane": lane,
        "dt_Myr": dt_myr,
        "direction": direction,
        "index": index,
        "eta": eta,
        "emissivity": float(np.exp(logeps0 + eta)),
        "GammaHI": gamma,
        "residual_inf": float(np.max(np.abs(F(z, eta, logeps0, p)))),
        "minimum_singular_J": float(singular[-1]),
        "condition_J": float(singular[0] / singular[-1]),
        "corrector_iterations": int(iterations),
        "minimum_photon": min_photon,
        "minimum_fraction": min_fraction,
        "u_th": u,
        "tangent_eta": float(tangent_vec[-1]),
        "tangent": tangent_vec.tolist(),
        "Z": z.tolist(),
        "parent_hash": parent_hash,
    }
    record["point_hash"] = canonical_hash(record)
    return record


def run_branch(
    lane_name: str,
    dt_myr: float,
    z_base: np.ndarray,
    logeps0: float,
    p: dict,
    nsteps: int = 15,
    ds: float = 0.025,
) -> list[dict]:
    rows: list[dict] = []
    for direction in [-1, 1]:
        eta1 = direction * 0.01
        z1, nit = damped_newton(z_base, eta1, logeps0, p)
        x_prev = np.r_[z_base, 0.0]
        x_cur = np.r_[z1, eta1]
        t = (x_cur - x_prev) / np.linalg.norm(x_cur - x_prev)
        if t[-1] * direction < 0.0:
            t = -t
        base = branch_record(
            lane=lane_name,
            dt_myr=dt_myr,
            direction=direction,
            index=0,
            x=x_prev,
            iterations=0,
            tangent_vec=t,
            logeps0=logeps0,
            p=p,
            parent_hash=None,
        )
        rows.append(base)
        parent = base["point_hash"]
        first = branch_record(
            lane=lane_name,
            dt_myr=dt_myr,
            direction=direction,
            index=1,
            x=x_cur,
            iterations=nit,
            tangent_vec=t,
            logeps0=logeps0,
            p=p,
            parent_hash=parent,
        )
        rows.append(first)
        parent = first["point_hash"]

        step = ds
        for index in range(2, nsteps):
            success = False
            for _ in range(6):
                x_pred = x_cur + step * t
                try:
                    x_new, niter = corrector(x_pred, t, logeps0, p)
                    success = True
                    break
                except (RuntimeError, np.linalg.LinAlgError):
                    step *= 0.5
            if not success:
                break
            t_new = tangent(x_new[:9], float(x_new[9]), direction, logeps0, p)
            if np.dot(t_new, t) < 0.0:
                t_new = -t_new
            record = branch_record(
                lane=lane_name,
                dt_myr=dt_myr,
                direction=direction,
                index=index,
                x=x_new,
                iterations=niter,
                tangent_vec=t_new,
                logeps0=logeps0,
                p=p,
                parent_hash=parent,
            )
            rows.append(record)
            parent = record["point_hash"]
            x_prev, x_cur, t = x_cur, x_new, t_new
            if niter <= 5:
                step = min(ds * 1.4, step * 1.2)
            elif niter >= 12:
                step *= 0.7
    return rows


predecessors = json.loads((CHECKPOINTS / "physical_predecessors.json").read_text())
all_branch_rows: list[dict] = []
base_rows: list[dict] = []
branch_summaries: list[dict] = []
temporal_rows: list[dict] = []

# Parameters frozen at the midpoint of the final physical-history interval,
# z=5.55, whose dense output supplies the z=5.5 predecessor/end state.
z_cos = 5.55
for lane_name, lane in lanes.items():
    pred_record = predecessors[lane_name]
    final = pred_record["final_z5p5"]
    final_state = {
        "N": np.asarray(final["N"], dtype=float),
        "xHII": float(final["xHII"]),
        "xHeII": float(final["xHeII"]),
        "xHeIII": float(final["xHeIII"]),
        "u": float(final["u"]),
        "GammaHI": float(final["GammaHI"]),
    }
    z_final_guess = z9_from_state(final_state)
    knots, coeffs, opacity_table = build_opacity_fit(
        RAW_TABLE, DENSITY_MAP, z_cos, lane
    )
    opacity_table.to_csv(
        OUT / f"branch_opacity_{lane_name}.csv", index=False
    )
    front_group, front_diag = allocate_front_sink(
        float(row55["front_HII_rate"]),
        float(row55["front_HeII_rate"]),
        float(row55["front_HeIII_electron_weighted_rate"]),
        lane,
    )
    logeps0 = math.log(EMISSION_REF)

    # Warm up generic JAX compilation once per lane.
    warm_prev = pred_record["predecessor_by_dt"][str(DT_LIST[0])]
    warm_p = make_params(
        z_cos=z_cos,
        dt_seconds=DT_LIST[0] * MYR_SECONDS,
        lane=lane,
        log_kappa_knots=knots,
        log_kappa_coeffs=coeffs,
        n_prev=np.asarray(warm_prev["N"]),
        x_prev=np.array([warm_prev["xHII"], warm_prev["xHeII"], warm_prev["xHeIII"]]),
        u_prev=float(warm_prev["u"]),
        front_sink_group=front_group,
        scale_n=final_state["N"],
        scale_u=final_state["u"],
        scale_gamma=max(final_state["GammaHI"], 1e-30),
    )
    _ = F(z_final_guess, 0.0, logeps0, warm_p)
    _ = JZ(z_final_guess, 0.0, logeps0, warm_p)
    _ = JETA(z_final_guess, 0.0, logeps0, warm_p)

    base_by_dt: dict[float, tuple[np.ndarray, dict]] = {}
    for dt_myr in DT_LIST:
        prev = pred_record["predecessor_by_dt"][str(dt_myr)]
        p = make_params(
            z_cos=z_cos,
            dt_seconds=dt_myr * MYR_SECONDS,
            lane=lane,
            log_kappa_knots=knots,
            log_kappa_coeffs=coeffs,
            n_prev=np.asarray(prev["N"]),
            x_prev=np.array([prev["xHII"], prev["xHeII"], prev["xHeIII"]]),
            u_prev=float(prev["u"]),
            front_sink_group=front_group,
            scale_n=final_state["N"],
            scale_x=np.ones(3),
            scale_u=final_state["u"],
            scale_gamma=max(final_state["GammaHI"], 1e-30),
        )
        z_base, niter = damped_newton(z_final_guess, 0.0, logeps0, p)
        state_base = transform_z_to_y(jnp.asarray(z_base))
        y_base = np.asarray(physical_vector(jnp.asarray(z_base), p), dtype=float)
        y_final = np.r_[
            final_state["N"],
            final_state["xHII"],
            final_state["xHeII"],
            final_state["xHeIII"],
            final_state["u"],
            final_state["GammaHI"],
        ]
        scale = np.maximum(np.abs(y_final), np.r_[np.ones(4), np.ones(3), 1e-300, 1e-300])
        base_error = float(np.linalg.norm((y_base - y_final) / scale) / math.sqrt(9))
        singular = np.linalg.svd(JZ(z_base, 0.0, logeps0, p), compute_uv=False)
        base_rows.append(
            {
                "lane": lane_name,
                "dt_Myr": dt_myr,
                "emissivity_reference": EMISSION_REF,
                "GammaHI": float(state_base["GammaHI"]),
                "residual_inf": float(np.max(np.abs(F(z_base, 0.0, logeps0, p)))),
                "minimum_singular_J": float(singular[-1]),
                "condition_J": float(singular[0] / singular[-1]),
                "minimum_fraction": float(
                    min(
                        state_base["xHII"],
                        1.0 - state_base["xHII"],
                        state_base["xHeI"],
                        state_base["xHeII"],
                        state_base["xHeIII"],
                    )
                ),
                "physical_endpoint_relative_error": base_error,
                "Newton_iterations": niter,
                "predecessor_provenance": prev["provenance"],
            }
        )
        base_by_dt[dt_myr] = (z_base, p)

        rows = run_branch(lane_name, dt_myr, z_base, logeps0, p)
        all_branch_rows.extend(rows)
        branch_df = pd.DataFrame(rows)
        branch_df.to_csv(
            OUT / "branches" / f"{lane_name}_dt_{dt_myr:.6f}.csv",
            index=False,
        )
        fold_sign_changes = 0
        for direction in [-1, 1]:
            part = branch_df[branch_df["direction"] == direction].sort_values("index")
            signs = np.sign(part["tangent_eta"].to_numpy())
            fold_sign_changes += int(np.sum(signs[1:] * signs[:-1] < 0.0))
        fold_candidate = bool(
            fold_sign_changes > 0
            or branch_df["minimum_singular_J"].min() < 1.0e-7
        )
        branch_summaries.append(
            {
                "lane": lane_name,
                "dt_Myr": dt_myr,
                "point_count": len(branch_df),
                "eta_min": float(branch_df["eta"].min()),
                "eta_max": float(branch_df["eta"].max()),
                "emissivity_min": float(branch_df["emissivity"].min()),
                "emissivity_max": float(branch_df["emissivity"].max()),
                "max_residual_inf": float(branch_df["residual_inf"].max()),
                "minimum_singular_J": float(branch_df["minimum_singular_J"].min()),
                "minimum_fraction": float(branch_df["minimum_fraction"].min()),
                "fold_tangent_sign_changes": fold_sign_changes,
                "fold_candidate": fold_candidate,
                "front_negative_HeIII_diagnostic": front_diag[
                    "negative_HeIII_derivative"
                ],
            }
        )

    # Global first-order test over the last 0.05 Myr with the same frozen
    # z=5.55 midpoint operator used by the final physical-history interval.
    initial_prev = pred_record["predecessor_by_dt"][str(0.05)]
    initial_z8 = np.asarray(initial_prev["Z8"], dtype=float)
    reference_p = base_by_dt[0.05][1]

    def ode_rhs(t: float, y: np.ndarray) -> np.ndarray:
        return np.asarray(
            RHS8_generic(jnp.asarray(y), jnp.array(EMISSION_REF), reference_p),
            dtype=float,
        )

    reference = solve_ivp(
        ode_rhs,
        (0.0, 0.05 * MYR_SECONDS),
        initial_z8,
        method="BDF",
        rtol=2.0e-11,
        atol=2.0e-13,
        max_step=0.05 * MYR_SECONDS / 300.0,
    )
    if not reference.success:
        raise RuntimeError(reference.message)
    ref_state = physical_state_from_z8(reference.y[:, -1], reference_p)
    ref_vec = np.r_[
        ref_state["N"],
        ref_state["xHII"],
        ref_state["xHeII"],
        ref_state["xHeIII"],
        ref_state["u"],
        ref_state["GammaHI"],
    ]
    ref_scale = np.maximum(np.abs(ref_vec), np.r_[np.ones(4), np.ones(3), 1e-300, 1e-300])

    for dt_myr in DT_LIST:
        nsteps = int(round(0.05 / dt_myr))
        current = {
            "N": np.asarray(initial_prev["N"], dtype=float),
            "xHII": float(initial_prev["xHII"]),
            "xHeII": float(initial_prev["xHeII"]),
            "xHeIII": float(initial_prev["xHeIII"]),
            "u": float(initial_prev["u"]),
            "GammaHI": float(initial_prev["GammaHI"]),
        }
        z_guess = z9_from_state(current)
        max_step_residual = 0.0
        for _ in range(nsteps):
            p_step = make_params(
                z_cos=z_cos,
                dt_seconds=dt_myr * MYR_SECONDS,
                lane=lane,
                log_kappa_knots=knots,
                log_kappa_coeffs=coeffs,
                n_prev=current["N"],
                x_prev=np.array([current["xHII"], current["xHeII"], current["xHeIII"]]),
                u_prev=current["u"],
                front_sink_group=front_group,
                scale_n=current["N"],
                scale_x=np.ones(3),
                scale_u=current["u"],
                scale_gamma=max(current["GammaHI"], 1e-30),
            )
            z_guess, _ = damped_newton(z_guess, 0.0, logeps0, p_step)
            max_step_residual = max(
                max_step_residual,
                float(np.max(np.abs(F(z_guess, 0.0, logeps0, p_step)))),
            )
            s = transform_z_to_y(jnp.asarray(z_guess))
            current = {
                "N": np.asarray(s["N"], dtype=float),
                "xHII": float(s["xHII"]),
                "xHeII": float(s["xHeII"]),
                "xHeIII": float(s["xHeIII"]),
                "u": float(s["u"]),
                "GammaHI": float(s["GammaHI"]),
            }
        vec = np.r_[
            current["N"], current["xHII"], current["xHeII"], current["xHeIII"], current["u"], current["GammaHI"]
        ]
        error = float(np.linalg.norm((vec - ref_vec) / ref_scale) / math.sqrt(9))
        temporal_rows.append(
            {
                "lane": lane_name,
                "dt_Myr": dt_myr,
                "steps_over_0p05_Myr": nsteps,
                "global_relative_error": error,
                "max_step_residual": max_step_residual,
            }
        )

branch_df = pd.DataFrame(all_branch_rows)
base_df = pd.DataFrame(base_rows)
summary_df = pd.DataFrame(branch_summaries)
temporal_df = pd.DataFrame(temporal_rows)

# Observed temporal orders by lane.
order_rows = []
for lane_name, part in temporal_df.groupby("lane"):
    part = part.sort_values("dt_Myr", ascending=False)
    errors = part["global_relative_error"].to_numpy()
    dts = part["dt_Myr"].to_numpy()
    for i in range(len(part) - 1):
        order_rows.append(
            {
                "lane": lane_name,
                "dt_coarse_Myr": dts[i],
                "dt_fine_Myr": dts[i + 1],
                "observed_order": float(
                    np.log(errors[i] / errors[i + 1])
                    / np.log(dts[i] / dts[i + 1])
                ),
            }
        )
order_df = pd.DataFrame(order_rows)

branch_df.to_csv(OUT / "all_pseudo_arclength_points.csv.gz", index=False, compression="gzip")
base_df.to_csv(OUT / "dt_base_solutions.csv", index=False)
summary_df.to_csv(OUT / "dt_branch_summary.csv", index=False)
temporal_df.to_csv(OUT / "temporal_convergence.csv", index=False)
order_df.to_csv(OUT / "temporal_orders.csv", index=False)

# Fold persistence requires candidates at >=3 refinements with convergent locations.
persistence = []
for lane_name, part in summary_df.groupby("lane"):
    candidates = part[part["fold_candidate"]]
    persistence.append(
        {
            "lane": lane_name,
            "candidate_dt_count": len(candidates),
            "persistent_fold": bool(len(candidates) >= 3),
            "decision": "PERSISTENT_CANDIDATE_REQUIRES_LOCATION_MATCH"
            if len(candidates) >= 3
            else "NO_PERSISTENT_FOLD",
        }
    )
persistence_df = pd.DataFrame(persistence)
persistence_df.to_csv(OUT / "fold_persistence.csv", index=False)

# Acceptance gates.
if branch_df["residual_inf"].max() >= 1.0e-8:
    raise RuntimeError("Branch residual gate failed")
if branch_df["minimum_fraction"].min() <= 0.0:
    raise RuntimeError("Branch positivity gate failed")
if base_df["predecessor_provenance"].ne("FORWARD_DENSE_OUTPUT_FROM_Z6_TO_Z5P5").any():
    raise RuntimeError("Backward predecessor contamination detected")

receipt_time = dt.datetime.now(dt.timezone.utc).isoformat()
append_receipt(
    {
        "receipt_id": "B2B-0004",
        "utc": receipt_time,
        "substage": "DT_BRANCH_SWEEP",
        "status": "PASS",
        "outputs": [
            "data/all_pseudo_arclength_points.csv.gz",
            "data/dt_base_solutions.csv",
            "data/dt_branch_summary.csv",
            "data/fold_persistence.csv",
        ],
        "max_branch_residual": float(branch_df["residual_inf"].max()),
        "minimum_fraction": float(branch_df["minimum_fraction"].min()),
    }
)
update_state(
    "DT_BRANCH_SWEEP",
    "Five timestep refinements completed for all spectrum lanes using forward-generated predecessors.",
)

append_receipt(
    {
        "receipt_id": "B2B-0005",
        "utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "substage": "TEMPORAL_ORDER",
        "status": "PASS_WITH_MEASURED_ORDER",
        "outputs": ["data/temporal_convergence.csv", "data/temporal_orders.csv"],
        "observed_order_range": [
            float(order_df["observed_order"].min()),
            float(order_df["observed_order"].max()),
        ],
    }
)
update_state(
    "TEMPORAL_ORDER",
    "Backward-Euler global temporal convergence measured over a fixed 0.05-Myr physical-history window.",
)

print(json.dumps({
    "branch_point_count": len(branch_df),
    "max_branch_residual": float(branch_df["residual_inf"].max()),
    "minimum_fraction": float(branch_df["minimum_fraction"].min()),
    "fold_persistence": persistence,
    "temporal_order_by_lane": order_df.groupby("lane")["observed_order"].apply(list).to_dict(),
}, indent=2))
