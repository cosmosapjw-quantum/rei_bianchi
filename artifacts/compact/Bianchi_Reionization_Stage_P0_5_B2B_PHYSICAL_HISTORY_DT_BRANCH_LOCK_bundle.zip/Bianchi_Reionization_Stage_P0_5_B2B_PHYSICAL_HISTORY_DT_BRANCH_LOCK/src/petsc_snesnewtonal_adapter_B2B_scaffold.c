/*
 * PETSc SNESNEWTONAL scaffold for P0.5-B2B.
 *
 * Status: IMPLEMENTED_NOT_COMPILED_PETSC_UNAVAILABLE.
 *
 * This adapter intentionally contains no model-specific finite differences.
 * B2BResidualAndJacobian() and B2BEmissivityTangent() are the only callbacks
 * that must be wired to the durable residual/Jacobian implementation.
 */
#include <petscsnes.h>

typedef struct {
  PetscReal log_eps_min;
  PetscReal log_eps_max;
  void *model_ctx;
} B2BContext;

/* User-provided durable model hooks. */
PETSC_EXTERN PetscErrorCode B2BResidualAndJacobian(Vec U, PetscReal log_eps,
                                                   Vec F, Mat J, void *ctx);
PETSC_EXTERN PetscErrorCode B2BEmissivityTangent(Vec U, PetscReal log_eps,
                                                 Vec Q, void *ctx);

static PetscReal MapLoadToLogEps(PetscReal lambda, const B2BContext *ctx)
{
  return ctx->log_eps_min + lambda * (ctx->log_eps_max - ctx->log_eps_min);
}

static PetscErrorCode FormResidual(SNES snes, Vec U, Vec F, void *vctx)
{
  B2BContext *ctx = (B2BContext *)vctx;
  PetscReal lambda, log_eps;
  PetscFunctionBeginUser;
  PetscCall(SNESNewtonALGetLoadParameter(snes, &lambda));
  log_eps = MapLoadToLogEps(lambda, ctx);
  PetscCall(B2BResidualAndJacobian(U, log_eps, F, NULL, ctx->model_ctx));
  PetscFunctionReturn(PETSC_SUCCESS);
}

static PetscErrorCode FormJacobian(SNES snes, Vec U, Mat J, Mat P, void *vctx)
{
  B2BContext *ctx = (B2BContext *)vctx;
  PetscReal lambda, log_eps;
  PetscFunctionBeginUser;
  PetscCall(SNESNewtonALGetLoadParameter(snes, &lambda));
  log_eps = MapLoadToLogEps(lambda, ctx);
  PetscCall(B2BResidualAndJacobian(U, log_eps, NULL, J, ctx->model_ctx));
  if (P != J) PetscCall(MatCopy(J, P, SAME_NONZERO_PATTERN));
  PetscFunctionReturn(PETSC_SUCCESS);
}

/* PETSc defines this as the tangent load vector.  The chain factor converts
 * dF/d(log epsilon) to dF/d(lambda). */
static PetscErrorCode FormTangentLoad(SNES snes, Vec U, Vec Q, void *vctx)
{
  B2BContext *ctx = (B2BContext *)vctx;
  PetscReal lambda, log_eps, scale;
  PetscFunctionBeginUser;
  PetscCall(SNESNewtonALGetLoadParameter(snes, &lambda));
  log_eps = MapLoadToLogEps(lambda, ctx);
  scale = ctx->log_eps_max - ctx->log_eps_min;
  PetscCall(B2BEmissivityTangent(U, log_eps, Q, ctx->model_ctx));
  PetscCall(VecScale(Q, scale));
  PetscFunctionReturn(PETSC_SUCCESS);
}

PetscErrorCode ConfigureB2BSNESNEWTONAL(SNES snes, Vec r, Mat J,
                                        B2BContext *ctx)
{
  PetscFunctionBeginUser;
  PetscCall(SNESSetType(snes, SNESNEWTONAL));
  PetscCall(SNESSetFunction(snes, r, FormResidual, ctx));
  PetscCall(SNESSetJacobian(snes, J, J, FormJacobian, ctx));
  PetscCall(SNESNewtonALSetFunction(snes, FormTangentLoad, ctx));
  /* Select exact/normal correction, step size and lambda bounds through the
   * official options database, e.g.
   *   -snes_newtonal_correction_type exact
   *   -snes_newtonal_step_size 0.02
   *   -snes_newtonal_lambda_min 0
   *   -snes_newtonal_lambda_max 1
   */
  PetscCall(SNESSetFromOptions(snes));
  PetscFunctionReturn(PETSC_SUCCESS);
}
