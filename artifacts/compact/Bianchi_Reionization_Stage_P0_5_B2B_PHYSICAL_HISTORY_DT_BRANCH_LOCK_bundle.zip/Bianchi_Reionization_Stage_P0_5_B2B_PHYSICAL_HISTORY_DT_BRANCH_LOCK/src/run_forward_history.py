"""Generate spectrum-specific causal forward histories for P0.5-B2B."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import sys
from pathlib import Path

import jax
jax.config.update("jax_enable_x64", True)
import jax.numpy as jnp
import numpy as np
import pandas as pd
from scipy.integrate import quad, solve_ivp

STAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STAGE / "src"))

from b2b_physical_model import (  # noqa: E402
    KB_ERG,
    YHE,
    NH0,
    allocate_front_sink,
    build_opacity_fit,
    hubble,
    make_params,
    make_spectrum_lanes,
    physical_state_from_z8,
    project_reservoir,
    temperature,
    transform_state_to_z8,
    transform_z8_to_state,
    z8_rhs,
    C_LIGHT,
    MPC_CM,
)
from monolithic_model_b2a import opacity_cMpc_inv  # noqa: E402

B1 = (
    STAGE
    / "inputs"
    / "extracted_P0_5_B1"
    / "Bianchi_Reionization_Stage_P0_5_B1_PHOTON_ALLOCATION_QMASS_LOCK"
)
P04 = (
    STAGE
    / "inputs"
    / "extracted_P0_4"
    / "Bianchi_Reionization_Stage_P0_4_PAPER_CODE_CHECKPOINT_REGRESSION"
)
RAW_TABLE = P04 / "data" / "environment_mfp_energies.txt"
DENSITY_MAP = P04 / "data" / "density_mapping_colossus_1_3_10_port.csv"

OUT = STAGE / "data"
CHECKPOINTS = STAGE / "checkpoints"
LOGS = STAGE / "logs"
for p in [OUT, CHECKPOINTS, LOGS, OUT / "opacity_nodes"]:
    p.mkdir(parents=True, exist_ok=True)


def append_receipt(record: dict) -> None:
    with (STAGE / "RUN_RECEIPTS.jsonl").open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(record, ensure_ascii=False) + "\n")


def update_state(substage: str, claim: str) -> None:
    path = STAGE / "STAGE_STATE.json"
    state = json.loads(path.read_text())
    state["current_substage"] = substage
    if substage not in state["completed_substages"]:
        state["completed_substages"].append(substage)
    state["open_substages"] = [x for x in state["open_substages"] if x != substage]
    state["last_update_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
    state.setdefault("scientific_claims", []).append(claim)
    path.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def canonical_hash(record: dict) -> str:
    return sha256_bytes(
        json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    )


lanes = make_spectrum_lanes()

# Durable spectrum lock.
spectrum_records = []
for lane in lanes.values():
    spectrum_records.append(
        {
            "lane": lane.name,
            "role": lane.role,
            "source_max_eV": lane.source_max_eV,
            "source_fraction": lane.source_fraction.tolist(),
            "initial_positivity_floor_fraction": lane.positivity_floor_fraction,
            "sigma_HI_cm2": lane.sigma_HI.tolist(),
            "sigma_HeI_cm2": lane.sigma_HeI.tolist(),
            "sigma_HeII_cm2": lane.sigma_HeII.tolist(),
            "redshift_coeff": lane.redshift_coeff.tolist(),
            "convention": (
                "MFP baseline and hard-power-law lanes use F_nu proportional "
                "nu^-1.5, hence photon-number dN/dE proportional E^-2.5."
                if "E_MINUS_2P5" in lane.name or "HARD_POWERLAW" in lane.name
                else "See lane name and role."
            ),
        }
    )
(STAGE / "SPECTRUM_LOCK.json").write_text(
    json.dumps(spectrum_records, indent=2), encoding="utf-8"
)
pd.DataFrame(spectrum_records).to_json(
    OUT / "spectrum_lanes.json", orient="records", indent=2
)

state_now = json.loads((STAGE / "STAGE_STATE.json").read_text())
if "SPECTRUM_LOCK" not in state_now.get("completed_substages", []):
    now = dt.datetime.now(dt.timezone.utc).isoformat()
    append_receipt(
        {
            "receipt_id": "B2B-0002",
            "utc": now,
            "substage": "SPECTRUM_LOCK",
            "status": "PASS",
            "outputs": ["SPECTRUM_LOCK.json", "data/spectrum_lanes.json"],
        }
    )
    update_state(
        "SPECTRUM_LOCK",
        "Four spectrum lanes locked; photon-number E^-1.5 is explicitly forbidden as MFP baseline.",
    )

# Canonical histories.
reservoir = pd.read_csv(B1 / "data" / "photon_reservoir_nodes.csv")
allocation = pd.read_csv(B1 / "data" / "photon_allocation_all_lanes.csv")
allocation = allocation[
    allocation["lane"] == "INSIDE_OUT_SELF_SHIELD_PRIMARY"
].sort_values("z_mid", ascending=False)
dynamic = pd.read_csv(B1 / "inputs" / "p05_flrw_dynamic_history.csv")

z_start, z_end = 6.0, 5.5
initial_res = reservoir[np.isclose(reservoir["z"], z_start)].iloc[0]
initial_chem = dynamic[np.isclose(dynamic["z"], z_start)].iloc[0]

# Interval rows 5.95, ..., 5.55.
intervals = allocation[
    (allocation["z_mid"] <= 5.95 + 1e-12)
    & (allocation["z_mid"] >= 5.55 - 1e-12)
].sort_values("z_mid", ascending=False)
if list(np.round(intervals["z_mid"], 2)) != [5.95, 5.85, 5.75, 5.65, 5.55]:
    raise RuntimeError(f"Unexpected history intervals: {intervals['z_mid'].tolist()}")

rhs_jit = jax.jit(z8_rhs)


def diagnostic_quantities(z8: np.ndarray, p: dict) -> tuple[float, float]:
    state = transform_z8_to_state(jnp.asarray(z8), p)
    kappa = opacity_cMpc_inv(state, p)
    absorption = C_LIGHT * (1.0 + p["z_cos"]) / MPC_CM * kappa
    red_out = p["Hubble"] * p["redshift_coeff"]
    ionized_absorption = float(jnp.sum(absorption * state["N"]))
    threshold_redshift = float(red_out[0] * state["N"][0])
    return ionized_absorption, threshold_redshift


history_rows: list[dict] = []
ledger_rows: list[dict] = []
predecessor_records: dict[str, dict] = {}
summary_records: list[dict] = []

for lane_name, lane in lanes.items():
    total_n = float(initial_res["N_gamma_total_cMpc3"])
    n0 = project_reservoir(total_n, lane)
    xh = float(initial_chem["xHII"])
    x2 = float(initial_chem["xHeII"])
    x3 = float(initial_chem["xHeIII"])
    T0 = float(initial_chem["T_K"])
    n_h = NH0 * (1.0 + z_start) ** 3
    n_he = YHE * n_h
    ne = n_h * xh + n_he * (x2 + 2.0 * x3)
    u0 = 1.5 * (n_h + n_he + ne) * KB_ERG * T0
    z8 = transform_state_to_z8(n0, xh, x2, x3, u0)

    # Initial-state parameters at z=6 are used only to compute the projected Gamma.
    knots6, coeff6, tab6 = build_opacity_fit(RAW_TABLE, DENSITY_MAP, z_start, lane)
    tab6.to_csv(
        OUT / "opacity_nodes" / f"{lane_name}_z6p00.csv", index=False
    )
    p6 = make_params(
        z_cos=z_start,
        dt_seconds=1.0,
        lane=lane,
        log_kappa_knots=knots6,
        log_kappa_coeffs=coeff6,
        n_prev=n0,
        x_prev=np.array([xh, x2, x3]),
        u_prev=u0,
        front_sink_group=np.zeros(4),
        scale_n=n0,
        scale_u=u0,
        scale_gamma=float(initial_res["Gamma_HI_s_inv"]),
    )
    state0 = physical_state_from_z8(z8, p6)
    history_rows.append(
        {
            "lane": lane_name,
            "z": z_start,
            "N_total": float(np.sum(state0["N"])),
            "N1": state0["N"][0],
            "N2": state0["N"][1],
            "N3": state0["N"][2],
            "N4": state0["N"][3],
            "xHII": state0["xHII"],
            "xHeII": state0["xHeII"],
            "xHeIII": state0["xHeIII"],
            "T_K": state0["T"],
            "Gamma_HI": state0["GammaHI"],
            "B1_total_reservoir_auditor": total_n,
            "B1_Gamma_auditor": float(initial_res["Gamma_HI_s_inv"]),
        }
    )

    last_solution = None
    last_p = None
    last_t_end = None

    for row in intervals.itertuples():
        zmid = float(row.z_mid)
        znext = round(zmid - 0.05, 2)
        dt_seconds = float(row.dt_Myr) * 1.0e6 * 365.25 * 86400.0
        emission = float(row.total_causal_emission_rate)
        front_group, front_diag = allocate_front_sink(
            float(row.front_HII_rate),
            float(row.front_HeII_rate),
            float(row.front_HeIII_electron_weighted_rate),
            lane,
        )

        knots, coeffs, table = build_opacity_fit(
            RAW_TABLE, DENSITY_MAP, zmid, lane
        )
        table.to_csv(
            OUT / "opacity_nodes" / f"{lane_name}_z{zmid:.2f}.csv".replace(".", "p"),
            index=False,
        )
        # Use current state as harmless scale placeholders during ODE generation.
        current_stub = physical_state_from_z8(
            z8,
            make_params(
                z_cos=zmid,
                dt_seconds=dt_seconds,
                lane=lane,
                log_kappa_knots=knots,
                log_kappa_coeffs=coeffs,
                n_prev=np.ones(4),
                x_prev=np.array([0.5, 0.3, 0.2]),
                u_prev=1.0,
                front_sink_group=front_group,
            ),
        )
        p = make_params(
            z_cos=zmid,
            dt_seconds=dt_seconds,
            lane=lane,
            log_kappa_knots=knots,
            log_kappa_coeffs=coeffs,
            n_prev=np.asarray(current_stub["N"]),
            x_prev=np.array(
                [current_stub["xHII"], current_stub["xHeII"], current_stub["xHeIII"]]
            ),
            u_prev=float(current_stub["u"]),
            front_sink_group=front_group,
            scale_n=np.asarray(current_stub["N"]),
            scale_u=float(current_stub["u"]),
            scale_gamma=max(float(current_stub["GammaHI"]), 1e-30),
        )

        def scipy_rhs(t: float, y: np.ndarray) -> np.ndarray:
            return np.asarray(
                rhs_jit(jnp.asarray(y), jnp.array(emission), p), dtype=float
            )

        solution = solve_ivp(
            scipy_rhs,
            (0.0, dt_seconds),
            z8,
            method="BDF",
            rtol=2.0e-9,
            atol=2.0e-11,
            dense_output=True,
            max_step=dt_seconds / 80.0,
        )
        if not solution.success:
            raise RuntimeError(f"{lane_name} z={zmid}: {solution.message}")

        z8_start = z8.copy()
        z8 = solution.y[:, -1]
        final_state = physical_state_from_z8(z8, p)
        if min(
            np.min(final_state["N"]),
            final_state["xHII"],
            1.0 - final_state["xHII"],
            final_state["xHeI"],
            final_state["xHeII"],
            final_state["xHeIII"],
            final_state["u"],
            final_state["GammaHI"],
        ) <= 0.0:
            raise RuntimeError(f"{lane_name} z={znext}: positivity failure")

        # Evaluate the ledger independently from the state solve.  The final
        # implementation integrates the positive absorption and threshold-
        # redshift terms against the dense BDF interpolant with adaptive quad.
        p_np = {k: np.asarray(v, dtype=float) for k, v in p.items()}

        def pchip_numpy(knots, coeffs, x):
            idx = np.clip(np.searchsorted(knots, x, side="right") - 1, 0, len(knots) - 2)
            dx = x - knots[idx]
            c = coeffs[:, idx]
            return ((c[0] * dx + c[1]) * dx + c[2]) * dx + c[3]

        def diagnostics_numpy(y):
            N = np.exp(y[:4])
            xH = 1.0 / (1.0 + np.exp(-y[4]))
            he_logits = np.array([0.0, y[5], y[6]])
            he = np.exp(he_logits - he_logits.max())
            he /= he.sum()
            pref = C_LIGHT * (1.0 + zmid) ** 3 / MPC_CM**3
            gamma = pref * np.dot(p_np["sigma_HI"], N)
            logg = np.log(gamma / 1.0e-12)
            klow = np.exp([
                pchip_numpy(p_np["log_kappa_knots"], p_np["log_kappa_pchip_coeffs"][j], logg)
                for j in range(2)
            ])
            nH = float(p_np["nH_phys"]); nHe = float(p_np["nHe_phys"])
            nHI = nH * (1.0 - xH); nHeI = nHe * he[0]; nHeII = nHe * he[1]
            conv = MPC_CM / (1.0 + zmid)
            kHI = nHI * p_np["sigma_HI"] * conv
            kHeI = nHeI * p_np["sigma_HeI"] * conv
            kHeII = nHeII * p_np["sigma_HeII"] * conv
            kappa = np.array([klow[0], klow[1] + kHeI[1], kHI[2] + kHeI[2], kHI[3] + kHeI[3] + kHeII[3]])
            absorption_coeff = C_LIGHT * (1.0 + zmid) / MPC_CM * kappa
            red_out = hubble(zmid) * p_np["redshift_coeff"]
            return float(np.dot(absorption_coeff, N)), float(red_out[0] * N[0])

        # Integrate the two positive ledger terms against the dense BDF
        # interpolant. This is independent of the adaptive output-node spacing
        # and closes the post-processing ledger to the requested tolerance.
        absorption_integral = quad(
            lambda tt: diagnostics_numpy(solution.sol(tt))[0],
            0.0,
            dt_seconds,
            epsabs=0.0,
            epsrel=2.0e-11,
            limit=600,
        )[0]
        redshift_integral = quad(
            lambda tt: diagnostics_numpy(solution.sol(tt))[1],
            0.0,
            dt_seconds,
            epsabs=0.0,
            epsrel=2.0e-11,
            limit=600,
        )[0]
        absorption_rate = float(absorption_integral / dt_seconds)
        redshift_rate = float(redshift_integral / dt_seconds)
        start_state = physical_state_from_z8(z8_start, p)
        storage_rate = float(
            (np.sum(final_state["N"]) - np.sum(start_state["N"])) / dt_seconds
        )
        front_rate = float(front_group.sum())
        ledger_residual = emission - (
            storage_rate + absorption_rate + redshift_rate + front_rate
        )

        ledger_rows.append(
            {
                "lane": lane_name,
                "z_mid": zmid,
                "z_next": znext,
                "dt_Myr": float(row.dt_Myr),
                "total_emission": emission,
                "storage_rate": storage_rate,
                "ionized_absorption_rate": absorption_rate,
                "threshold_redshift_loss_rate": redshift_rate,
                "front_absorption_rate": front_rate,
                "relative_ledger_residual": ledger_residual / max(abs(emission), 1.0),
                "negative_HeIII_front_derivative": front_diag[
                    "negative_HeIII_derivative"
                ],
                "solver_nfev": solution.nfev,
                "solver_njev": solution.njev,
                "solver_nlu": solution.nlu,
            }
        )
        history_rows.append(
            {
                "lane": lane_name,
                "z": znext,
                "N_total": float(np.sum(final_state["N"])),
                "N1": final_state["N"][0],
                "N2": final_state["N"][1],
                "N3": final_state["N"][2],
                "N4": final_state["N"][3],
                "xHII": final_state["xHII"],
                "xHeII": final_state["xHeII"],
                "xHeIII": final_state["xHeIII"],
                "T_K": final_state["T"],
                "Gamma_HI": final_state["GammaHI"],
                "B1_total_reservoir_auditor": float(
                    reservoir[np.isclose(reservoir["z"], znext)][
                        "N_gamma_total_cMpc3"
                    ].iloc[0]
                ),
                "B1_Gamma_auditor": float(
                    reservoir[np.isclose(reservoir["z"], znext)][
                        "Gamma_HI_s_inv"
                    ].iloc[0]
                ),
            }
        )

        if np.isclose(zmid, 5.55):
            last_solution = solution
            last_p = p
            last_t_end = dt_seconds

    if last_solution is None or last_p is None or last_t_end is None:
        raise RuntimeError(f"No final interval solution for {lane_name}")

    dt_list_myr = [0.05, 0.025, 0.0125, 0.00625, 0.003125]
    pred = {}
    for dt_myr in dt_list_myr:
        seconds = dt_myr * 1.0e6 * 365.25 * 86400.0
        if seconds >= last_t_end:
            raise RuntimeError("Requested predecessor exceeds final history interval")
        z8_prev = last_solution.sol(last_t_end - seconds)
        prev = physical_state_from_z8(z8_prev, last_p)
        pred[str(dt_myr)] = {
            "dt_Myr": dt_myr,
            "N": prev["N"].tolist(),
            "xHII": prev["xHII"],
            "xHeII": prev["xHeII"],
            "xHeIII": prev["xHeIII"],
            "u": prev["u"],
            "T": prev["T"],
            "GammaHI": prev["GammaHI"],
            "Z8": np.asarray(z8_prev).tolist(),
            "provenance": "FORWARD_DENSE_OUTPUT_FROM_Z6_TO_Z5P5",
        }

    final = physical_state_from_z8(z8, last_p)
    predecessor_records[lane_name] = {
        "lane": lane_name,
        "role": lane.role,
        "initial_state_source": "B1_Z6_TOTAL_RESERVOIR_AND_CHEMISTRY_REPROJECTED",
        "emission_amplitude_source": "B1_PRIMARY_TOTAL_CAUSAL_EMISSION_AUDITOR",
        "final_z5p5": {
            "N": final["N"].tolist(),
            "xHII": final["xHII"],
            "xHeII": final["xHeII"],
            "xHeIII": final["xHeIII"],
            "u": final["u"],
            "T": final["T"],
            "GammaHI": final["GammaHI"],
            "Z8": z8.tolist(),
        },
        "predecessor_by_dt": pred,
    }
    summary_records.append(
        {
            "lane": lane_name,
            "role": lane.role,
            "predecessor_exists_all_dt": True,
            "initial_GammaHI": state0["GammaHI"],
            "final_GammaHI": final["GammaHI"],
            "final_xHII": final["xHII"],
            "final_xHeII": final["xHeII"],
            "final_xHeIII": final["xHeIII"],
            "final_T_K": final["T"],
            "minimum_N_final": float(np.min(final["N"])),
        }
    )

pd.DataFrame(history_rows).to_csv(OUT / "physical_forward_history.csv", index=False)
pd.DataFrame(ledger_rows).to_csv(OUT / "forward_history_photon_ledger.csv", index=False)
pd.DataFrame(summary_records).to_csv(OUT / "predecessor_summary.csv", index=False)
(CHECKPOINTS / "physical_predecessors.json").write_text(
    json.dumps(predecessor_records, indent=2), encoding="utf-8"
)

max_ledger = float(
    pd.DataFrame(ledger_rows)["relative_ledger_residual"].abs().max()
)
if max_ledger >= 1.0e-7:
    raise RuntimeError(f"Forward history ledger residual too large: {max_ledger}")

receipt_time = dt.datetime.now(dt.timezone.utc).isoformat()
append_receipt(
    {
        "receipt_id": "B2B-0003",
        "utc": receipt_time,
        "substage": "FORWARD_HISTORY",
        "status": "PASS",
        "outputs": [
            "data/physical_forward_history.csv",
            "data/forward_history_photon_ledger.csv",
            "data/predecessor_summary.csv",
            "checkpoints/physical_predecessors.json",
        ],
        "max_relative_photon_ledger_residual": max_ledger,
    }
)
update_state(
    "FORWARD_HISTORY",
    "All four spectrum lanes generated positive forward predecessors from z=6.0 to 5.5 without backward fitting.",
)

print(json.dumps({
    "spectrum_lanes": list(lanes),
    "max_relative_ledger_residual": max_ledger,
    "predecessor_summary": summary_records,
}, indent=2))
