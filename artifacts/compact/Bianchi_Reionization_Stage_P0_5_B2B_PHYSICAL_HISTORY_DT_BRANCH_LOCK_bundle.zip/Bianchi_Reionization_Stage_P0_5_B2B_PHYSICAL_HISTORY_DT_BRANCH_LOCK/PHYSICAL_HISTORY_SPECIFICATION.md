# Physical-history specification

## Conventions

- metric signature: `(-,+,+,+)`
- `epsilon_123=+1`
- photon variables: comoving group photon numbers per cMpc^3
- source and sink rates: photons s^-1 cMpc^-3
- atomic rates: s^-1 or cm^3 s^-1 as appropriate
- time variable in this homogeneous gate: FLRW cosmic time / baryon proper time

## Spectrum lanes

### Primary MFP-consistent lane

`J_nu proportional nu^-1.5` on 1--4 Ryd, hence

`dN/dE proportional E^-2.5`.

Source group fractions:

[0.6727341885901934, 0.23916139005996803, 0.08810442134983842, 0.0]

The fourth source group, above 4 Ryd, is exactly zero. Its tiny positive photon
number is a transform-domain floor, not a physical hard-photon population.

### Auditors

- Cloudy 80,000 K blackbody
- Cloudy hard power law `F_nu proportional nu^-1.5`
- B2A `E^-4` numerical regression lane

Photon-number `E^-1.5` is explicitly forbidden as the MFP physical baseline.

## History construction

The total B1 photon-reservoir and causal-emission amplitudes are auditors.
No B1 group fractions are inherited. Each lane reprojects the total amplitude
onto its own source spectrum and evolves forward from z=6.0 to 5.5.

Predecessors for dt = 0.05, 0.025, 0.0125, 0.00625, 0.003125 Myr are dense
forward outputs of the last z_mid=5.55 history interval. No backward-fitted
predecessor is used.
