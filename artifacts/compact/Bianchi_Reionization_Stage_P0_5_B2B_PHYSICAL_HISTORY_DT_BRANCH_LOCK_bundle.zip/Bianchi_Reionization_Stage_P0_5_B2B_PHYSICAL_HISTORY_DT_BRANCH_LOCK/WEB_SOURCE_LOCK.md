# Web source lock

- arXiv:2602.03923v3, lines 57--81: the MFP simulations use
  `J_nu proportional nu^-1.5` between 1 and 4 Ryd, five frequency bins, and
  tabulate MFP at six energies up to 39.5 eV.
- PETSc official `SNESNEWTONAL` documentation: Newton arc-length continuation,
  load-parameter bounds, step size, correction type, tangent-load callback,
  and diagonal variable scaling.
- arXiv:1201.0602: the inherited C2-Ray H/He extension includes coupled full
  OTS and multifrequency ionization/heating; it is contextual source lock, not
  a new B2B fit.

No web-derived numerical branch value is used. All B2B branch numbers are
regenerated durable outputs of this stage.
