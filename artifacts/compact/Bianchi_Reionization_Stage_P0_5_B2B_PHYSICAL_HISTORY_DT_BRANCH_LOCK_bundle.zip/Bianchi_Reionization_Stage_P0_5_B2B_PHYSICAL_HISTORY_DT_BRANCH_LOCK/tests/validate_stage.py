from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

root = Path(__file__).resolve().parents[1]
data = root / 'data'

state = json.loads((root / 'STAGE_STATE.json').read_text())
results = json.loads((root / 'results.json').read_text())
spectra = json.loads((root / 'SPECTRUM_LOCK.json').read_text())
pred = pd.read_csv(data / 'predecessor_summary.csv')
ledger = pd.read_csv(data / 'forward_history_photon_ledger.csv')
branches = pd.read_csv(data / 'all_pseudo_arclength_points.csv.gz')
folds = pd.read_csv(data / 'fold_persistence.csv')
orders = pd.read_csv(data / 'temporal_orders.csv')
base = pd.read_csv(data / 'dt_base_solutions.csv')
accepted = pd.read_csv(data / 'accepted_physical_branch.csv')

assert state['status'] == 'DURABLE_PASS__PHYSICAL_HISTORY_AND_DT_BRANCH_LOCK'
assert results['verdict'] == state['status']
assert len(spectra) == 4
assert abs(sum(spectra[0]['source_fraction']) - 1.0) < 1e-14
assert spectra[0]['source_fraction'][3] == 0.0
assert pred.predecessor_exists_all_dt.all()
assert set(pred.lane) == set(x['lane'] for x in spectra)
assert ledger.relative_ledger_residual.abs().max() < 1e-6
assert branches.residual_inf.abs().max() < 1e-9
assert branches.minimum_fraction.min() > 0.0
assert not folds.persistent_fold.any()
assert not folds.candidate_dt_count.astype(bool).any()
assert orders.observed_order.between(0.8, 1.2).all()
assert base.physical_endpoint_relative_error.min() > 0.0
for lane, part in base.groupby('lane'):
    p = part.sort_values('dt_Myr', ascending=False)
    assert np.all(np.diff(p.physical_endpoint_relative_error.to_numpy()) < 0.0)
assert len(accepted) == 20
assert (accepted.eta.abs() < 1e-15).all()

lock = json.loads((root / 'RECOVERY_INPUT_LOCK.json').read_text())
for rec in lock['inputs']:
    path = root / rec['copied_path']
    h = hashlib.sha256(path.read_bytes()).hexdigest()
    assert h == rec['sha256']

print('P0.5-B2B durable gates: PASS')
