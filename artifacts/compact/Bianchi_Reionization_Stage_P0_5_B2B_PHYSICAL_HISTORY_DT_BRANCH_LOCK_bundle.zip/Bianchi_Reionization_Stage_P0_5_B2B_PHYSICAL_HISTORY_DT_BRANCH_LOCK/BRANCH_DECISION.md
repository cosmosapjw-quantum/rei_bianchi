# Branch decision

## Accepted primary branch

The accepted primary branch is the eta=0 branch of
`MFP_BASELINE_E_MINUS_2P5_1_TO_4_RYD` at each timestep, selected by continuity with the
forward-generated predecessor. The tested continuation interval is roughly
`-0.45 <= log(epsilon/epsilon_ref) <= 0.45`, corresponding to a factor of
about 0.638--1.568 around the reference emissivity.

## Fold decision

No tangent-orientation reversal or singular-value fold candidate was found in
any of the four spectrum lanes at any of the five timestep refinements.
Therefore:

`NO_PERSISTENT_FOLD_IN_TESTED_LOCAL_WINDOW`.

This is not a global no-fold theorem outside the tested emissivity interval.
LOCA/two-parameter escalation is not triggered.

## Temporal decision

The measured global orders lie in
`0.998397744--1.000392713` and
approach one, as expected for backward Euler. The single-step endpoint errors
decrease with local order
`1.998279--1.999959`.

The midpoint operator used by the final physical-history interval is z=5.55.
An earlier branch rerun at z=5.50 left a timestep-independent endpoint offset;
that run is retained only in receipts and was superseded before final judgment.
