# Stage P0.5-B2B — Physical history and timestep branch lock

## Verdict

`DURABLE_PASS__PHYSICAL_HISTORY_AND_DT_BRANCH_LOCK`

The physical MFP spectrum, forward-generated predecessors, five-timestep
continuation family, first-order convergence, and branch identity are locked.
No maintenance fitting, source/f_esc calibration, or Bianchi geometry was
started.

## Main result

The primary lane uses `J_nu proportional nu^-1.5` on 1--4 Ryd, hence
`dN/dE proportional E^-2.5`, with source fractions

`[0.6727341885901934, 0.23916139005996803, 0.08810442134983842, 0.0]`.

Source emission above 4 Ryd is exactly zero. The fourth photon number is only
a numerical positivity floor.

All four spectrum lanes generate positive predecessors by direct forward
evolution from z=6.0 to 5.5. The primary endpoint is

- Gamma_HI = 1.11263249e-13 s^-1
- x_HII = 0.999918334
- x_HeII = 0.997719125
- x_HeIII = 0.002214520
- T_b = 15201.496 K

This is an amplitude-audited predictive fixture, not an observational fit.

## Branch sweep

Five timesteps were tested:

`[0.05, 0.025, 0.0125, 0.00625, 0.003125] Myr`.

Across 600 continuation points:

- max scaled residual: 9.936e-11
- minimum species fraction: 3.294e-05
- minimum Jacobian singular value: 2.531e-05
- fold candidates: 0

No persistent fold was found in the tested local interval
`-0.45 <= log(epsilon/epsilon_ref) <= 0.45`. This is not a global no-fold
claim outside that window.

## Timestep continuity

The global convergence order lies in
`0.998398--1.000393`,
consistent with backward Euler. Single-step endpoint errors have local order
`1.998279--1.999959`.

The final branch rerun uses the same z=5.55 frozen midpoint operator as the
last physical-history interval. This removes the superseded z=5.50
coefficient-centering offset.

## Remaining boundary

B2B does not authorize Bianchi I/V/II. The next gate is physical
maintenance/unresolved/topology closure. Source-population calibration follows
only after that closure.
