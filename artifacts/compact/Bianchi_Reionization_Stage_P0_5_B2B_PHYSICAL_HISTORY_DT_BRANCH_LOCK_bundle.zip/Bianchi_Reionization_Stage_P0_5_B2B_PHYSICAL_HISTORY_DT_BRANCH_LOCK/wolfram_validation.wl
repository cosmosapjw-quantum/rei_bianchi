ClearAll["Global`*"];

Clear[amp, expo, hP, energy];
nuOfE = energy/hP;
photonNumberPerEnergy = FullSimplify[
  amp nuOfE^(-expo)/(hP nuOfE) * (1/hP),
  Assumptions -> {amp > 0, hP > 0, energy > 0, expo > 0}
];
energyLogSlope = FullSimplify[energy D[Log[photonNumberPerEnergy], energy]];

Clear[e];
intervals = {{13.60, 24.59}, {24.59, 39.50}, {39.50, 54.42}};
weights = (Integrate[e^(-5/2), {e, #[[1]], #[[2]]}] &) /@ intervals;
fractions = N[Append[weights/Total[weights], 0], 16];
expectedFractions = {0.6727341885901934, 0.23916139005996803,
  0.08810442134983842, 0.0};
fractionResidual = Max[Abs[fractions - expectedFractions]];

residuals = {
 dn1 + phi0 - phi1 - em1 + ai1 + af1,
 dn2 + phi1 - phi2 - em2 + ai2 + af2,
 dn3 + phi2 - phi3 - em3 + ai3 + af3,
 dn4 + phi3 - phi4 - em4 + ai4 + af4
};
totalResidual = Expand[Total[residuals]];
expectedTotal = dn1 + dn2 + dn3 + dn4 - em1 - em2 - em3 - em4 +
  ai1 + ai2 + ai3 + ai4 + af1 + af2 + af3 + af4 + phi0 - phi4;
internalFluxResidual = FullSimplify[totalResidual - expectedTotal];

Clear[hh, lam, totalTime];
beLogError = Series[-(totalTime/hh) Log[1-hh lam] - lam totalTime,
  {hh,0,3}];
beLeadingCoefficient = Coefficient[Normal[beLogError], hh, 1];

Clear[gamRate, kap, sigmaEff, store, redLoss];
absorptionProxy = gamRate kap/sigmaEff;
causalEmission = absorptionProxy + store + redLoss;
localSourceMissingTerms = FullSimplify[causalEmission - absorptionProxy];

orders = <|
 "MFP" -> {0.9988345949807794, 0.9994802280579482, 0.9998658883616705, 1.0001869014098717},
 "Blackbody" -> {0.9983977443761249, 0.9992337733024795, 0.9996893766984261, 0.9999887843510531},
 "HardPowerLaw" -> {0.998511397068316, 0.9992885699719503, 0.9997150364431399, 0.9999988019396271},
 "Eminus4" -> {0.9996011483301142, 0.9998890902076218, 1.0001280192273654, 1.000392713484064}
|>;
keys = Keys[orders];
orderGate = AssociationThread[keys, (And @@ Thread[0.8 < # < 1.2] &) /@ Values[orders]];
maxOrderDeviation = AssociationThread[keys, Max[Abs[#-1]] & /@ Values[orders]];

<|
 "PhotonNumberSpectrum" -> photonNumberPerEnergy,
 "EnergyLogSlope" -> energyLogSlope,
 "Alpha1p5Gives" -> FullSimplify[energyLogSlope /. expo -> 3/2],
 "MFPBaselineFractions" -> fractions,
 "FractionResidual" -> fractionResidual,
 "PrimaryAbove4RydSourceFraction" -> Last[fractions],
 "TotalGroupResidual" -> totalResidual,
 "InternalFluxCancellationResidual" -> internalFluxResidual,
 "BackwardEulerLogErrorSeries" -> beLogError,
 "BackwardEulerLeadingErrorCoefficient" -> beLeadingCoefficient,
 "CausalEmission" -> causalEmission,
 "LocalSourceMissingTerms" -> localSourceMissingTerms,
 "TemporalOrderGate" -> orderGate,
 "MaximumAbsoluteOrderDeviationFromOne" -> maxOrderDeviation
|>