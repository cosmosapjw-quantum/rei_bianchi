@Web+Wolfram Stage P0.5-B2C-MAINTENANCE-TOPOLOGY-LOCK를 실행해줘.

B2B의 primary MFP physical spectrum, forward-generated predecessor,
accepted eta=0 dt->0-continuous branch, causal photon ledger와 full-OTS
chemistry를 정본으로 유지한다. B2A backward predecessor와 E^-4 spectrum은
auditor로만 유지한다.

1. 계산 전에 새 durable B2C directory, input lock, stage state, receipts,
   manifest와 SHA256SUMS를 생성해줘.

2. ionized-phase absorption을
   N_abs,ion=N_maint,diffuse+N_unresolved
   로 분해하고, N_maint,diffuse는 동일 topology/density lane의 full-OTS
   H/He recombination integral로 직접 계산해줘.

3. N_unresolved<0이면 clipping하지 말고 해당 topology/opacity lane을
   fail closed해줘.

4. topology lanes를
   SHARP_INSIDE_OUT,
   SMOOTH_BANDPASS_INSIDE_OUT,
   OUTSIDE_IN_DIAGNOSTIC,
   Q_M_EQUALS_Q_V_DIAGNOSTIC
   로 유지하고 Q_V,Q_M, maintenance, unresolved, front, f_front를 비교해줘.

5. maintenance 5% gate는 동일 IGM definition/topology lane 내부의
   numerical/closure consistency에만 적용하고, 서로 다른 clumping/IGM
   definitions 사이의 차이는 astrophysical systematic으로 보존해줘.

6. Cloudy hard-X-ray/thermal discrepancy table을 local microphysics auditor로
   사용하되 Case-B lane은 SH95/PyNeb를 truth anchor로 유지해줘.

7. 이번 B2C에서는 source population/f_esc calibration과 Bianchi geometry를
   시작하지 마.

8. N_unresolved>=0, 0<=f_front<=1, photon ledger residual<1e-8, 동일-lane
   maintenance mismatch<5%를 통과한 뒤에만 B2D source-ensemble calibration을
   승인해줘.
