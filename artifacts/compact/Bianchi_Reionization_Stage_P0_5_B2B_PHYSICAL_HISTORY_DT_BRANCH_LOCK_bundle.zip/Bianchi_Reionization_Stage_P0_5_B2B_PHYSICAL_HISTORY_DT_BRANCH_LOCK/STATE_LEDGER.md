# State ledger

## Final state

- Stage: `P0.5-B2B-PHYSICAL-HISTORY-AND-DT-BRANCH-LOCK`
- Status: `DURABLE_PASS__PHYSICAL_HISTORY_AND_DT_BRANCH_LOCK`
- Provenance: `POST_INTERRUPTION_NEW_STAGE`
- Canonical physical lane: `MFP_BASELINE_E_MINUS_2P5_1_TO_4_RYD`
- Accepted branch: eta=0, forward-predecessor continuous
- Persistent fold: none in tested local window
- LOCA escalation: not triggered
- PETSc crosscheck: unavailable, nonblocking

## Rebuild/correction receipts retained

- first forward-ledger postprocessing was under-resolved and rebuilt;
- dormant G4 scaling initially produced a spurious rank defect and was rebuilt;
- branch operator was corrected from endpoint z=5.50 to the final-history midpoint z=5.55 before final judgment.

No superseded result is used in `results.json`.

## Forward-ledger method clarification

The final durable ledger is an independent adaptive quadrature over the dense BDF interpolant. The earlier receipt proposing cumulative ODE ledger variables records a failed/rebuild intention and is not the final method.
