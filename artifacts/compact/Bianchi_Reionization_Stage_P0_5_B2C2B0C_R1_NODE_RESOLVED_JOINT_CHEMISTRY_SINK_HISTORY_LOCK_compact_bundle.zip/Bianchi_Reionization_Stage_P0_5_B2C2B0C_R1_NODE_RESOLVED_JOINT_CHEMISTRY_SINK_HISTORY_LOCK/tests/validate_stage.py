from pathlib import Path
import json
import pandas as pd

R = Path(__file__).resolve().parents[1]
D = R / 'data'
r = json.loads((R / 'results.json').read_text())
assert r['verdict'].startswith('DURABLE_FAIL_CLOSED')
assert r['B2C2B_authorization'] is False
assert r['gates']['photon_partition_residual_max'] < 1e-10
assert r['gates']['H_nuclei_residual_max'] < 1e-12
assert r['gates']['He_nuclei_residual_max'] < 1e-12
assert r['gates']['reaction_limiter_weighted_max'] > 1e-4
assert r['gates']['sink_volume_filling_max'] > 1
assert r['gates']['post_photo_total_required_H_over_cosmic_H'] > 1
f = pd.read_csv(D / 'first_interval_refinement' / 'first_interval_refinement_status.csv')
assert bool(f[f.substeps == 1].success.iloc[0])
assert bool(f[f.substeps == 2].success.iloc[0])
assert not bool(f[f.substeps == 4].success.iloc[0])
assert not bool(f[f.substeps == 8].success.iloc[0])
s = json.loads((R / 'symbolic_failure_results.json').read_text())
assert s['status'] == 'PASS_EXACT_STRUCTURAL_DIVERGENCE'
assert s['Limit_x_to_1_minus_CloudMass'] == 'oo'
assert not (D / 'accepted_node_resolved_history.npz').exists()
print('B2C2B0C-R1 verification: DURABLE FAIL-CLOSED; B2C2B denied; R2A required')
