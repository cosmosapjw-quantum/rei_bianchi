# Bianchi Reionization — Stage R0-A/R0-B

## Verdict

\[
\boxed{
\text{R0-A}
=
\text{PASS with a U-OTS H/He baseline and full-OTS interface}
}
\]

\[
\boxed{
\text{R0-B}
=
\text{PASS with adaptive scattering-order truncation}
}
\]

The main architectural change is now implemented:

\[
\boxed{
\text{ionizing UV chemistry}
\quad\text{and}\quad
\text{CMB Thomson transport}
}
\]

are separate radiation sectors.

The UV sector supplies

\[
x_e,\quad T_b,\quad \widetilde n_e,
\]

while the CMB sector uses them only through the finite-tilt Thomson
opacity and the baryon/radiation four-force ledger.

---

## R0-A. Homogeneous photon-conserving UV chemistry

### H-only analytical relaxation

For frozen rates

\[
\dot x
=
\Gamma(1-x)-R x,
\]

\[
x_{\rm eq}=\frac{\Gamma}{\Gamma+R},
\]

\[
x(t+\Delta t)
=
x_{\rm eq}
+
(x_0-x_{\rm eq})e^{-(\Gamma+R)\Delta t}.
\]

The exact time average is

\[
\bar x
=
x_{\rm eq}
+
(x_0-x_{\rm eq})
\frac{1-e^{-(\Gamma+R)\Delta t}}
{(\Gamma+R)\Delta t}.
\]

The integrated primary-ionization and recombination counts satisfy

\[
\Gamma\Delta t(1-\bar x)
-
R\Delta t\,\bar x
=
x_1-x_0.
\]

Wolfram reduced the ODE, initial-condition, equilibrium, small-step and
photon-ionization ledger residuals to zero.

### H/He matrix relaxation

The five-state vector is

\[
z=
(x_{\rm HI},x_{\rm HII},
x_{\rm HeI},x_{\rm HeII},x_{\rm HeIII}).
\]

For frozen time-averaged electron density,

\[
\dot z=A(\bar n_e)z
\]

was solved by one matrix exponential. The average state was obtained from
an augmented exponential, and \(\bar n_e\) was iterated to convergence.

The representative test gave:

\[
\max_j\left|\sum_iA_{ij}\right|
=
5.55\times10^{-17},
\]

\[
\Delta(x_{\rm HI}+x_{\rm HII})
=
1.11\times10^{-16},
\]

\[
\Delta(x_{\rm HeI}+x_{\rm HeII}+x_{\rm HeIII})
=
2.22\times10^{-16}.
\]

All populations remained positive.

Against the direct nonlinear H/He ODE:

| dimensionless \(\Delta t\) | step error | time-average error |
|---:|---:|---:|
| 0.05 | \(1.86\times10^{-5}\) | \(2.84\times10^{-5}\) |
| 0.10 | \(1.43\times10^{-4}\) | \(1.07\times10^{-4}\) |
| 0.20 | \(1.02\times10^{-3}\) | \(3.76\times10^{-4}\) |
| 0.40 | \(5.95\times10^{-3}\) | \(1.09\times10^{-3}\) |
| 0.80 | \(2.19\times10^{-2}\) | \(2.06\times10^{-3}\) |

Thus the C2-Ray-style time-average closure is accurate, but a
\(10^{-4}\)-level chemistry target requires a rate-scaled timestep near
the 0.1 level in this test.

### Three-group photon ledger

The adopted threshold groups are compatible with

\[
13.6,\quad24.6,\quad54.4\ {\rm eV}.
\]

For constant source and total interaction rate \(\chi_g\),

\[
N_g^{n+1}
=
N_g^n e^{-\chi_g\Delta t}
+
S_g\frac{1-e^{-\chi_g\Delta t}}{\chi_g}.
\]

The removed photons

\[
A_g=N_g^n+S_g\Delta t-N_g^{n+1}
\]

were allocated among H I, He I, He II and an unresolved sink in
proportion to their opacities.

The test residuals were

\[
\epsilon_{N_\gamma}
=
3.47\times10^{-18},
\]

\[
\epsilon_E=0.
\]

The same ledger split the absorbed photon energy into ionization
threshold energy and photoheating.

### Sink closure

The production interface is

\[
(C_{\rm eff},\lambda_{{\rm mfp},g})
=
\mathcal S(
\Delta_b,T_b,x_e,\Gamma_{\rm HI};
\theta_{\rm sink}
).
\]

A synthetic monotone closure was used only to test the fixed-point
algorithm. It converged to

\[
\Gamma_{\rm HI}=0.2498783006
\]

with residual

\[
4.72\times10^{-16}.
\]

This numerical function is not a fitted SCRIPT formula.

### Full OTS

A generic recombination-photon yield matrix was added as an interface.
Its test ledger closed to

\[
1.73\times10^{-18}.
\]

The actual H/He run remains a U-OTS/case-B baseline until the physical
yield and opacity tables are calibrated.

---

## R0-B. Exact-loss successive scattering

Let

\[
\mathcal U_0(t_2,t_1)
\]

be the exact Bianchi geodesic, frequency, screen and finite-tilt
loss propagator inherited from G1/P1. The in-scattering-order hierarchy is

\[
F^{[0]}(t)
=
\mathcal U_0(t,t_*)F_*,
\]

\[
F^{[r+1]}(t_0)
=
\int_{t_*}^{t_0}
dt\,
\mathcal U_0(t_0,t)
\mathcal C_{\rm in}(t)
F^{[r]}(t).
\]

The full solution is

\[
F=\sum_{r=0}^{\infty}F^{[r]}.
\]

For the constant paired-grid auditor this hierarchy was evaluated by one
lower-block-triangular matrix exponential and compared with the full
G1/P1 operator exponential.

### Remainder bound

Define an interaction norm

\[
\Xi
\ge
\int
\|\mathcal C_{\rm in}^{I}(t)\|\,dt.
\]

Then

\[
\|R_N\|
\le
\|F_*\|
\sum_{r=N+1}^{\infty}
\frac{\Xi^r}{r!}.
\]

For \(\Xi<N+2\),

\[
\boxed{
\|R_N\|
\le
\|F_*\|
\frac{\Xi^{N+1}}{(N+1)!}
\frac{1}{1-\Xi/(N+2)}.
}
\]

The implemented a-posteriori estimator computes one extra term:

\[
\boxed{
\epsilon_N^{\rm ap}
=
\frac{\|F^{[N+1]}\|}
{\left[1-\Xi/(N+2)\right]
 \left\|\sum_{r=0}^{N}F^{[r]}\right\|}.
}
\]

The stop condition is imposed separately on every protected observable.

### Auditor results

At \(\tau=0.06\),

\[
\Xi=0.11986356.
\]

The state errors for orders \(N=0,\ldots,4\) were

\[
5.75\times10^{-2},\
1.61\times10^{-3},\
3.01\times10^{-5},\
4.23\times10^{-7},\
4.77\times10^{-9}.
\]

At \(N=2\), the next-term ratio was

\[
2.97\times10^{-5},
\]

while the actual error was

\[
3.01\times10^{-5}.
\]

The a-posteriori multiplier was only \(1.0309\).

### T/E/B

At \(\tau=0.06\), \(N=2\) gave

\[
\epsilon_T=1.08\times10^{-4},
\]

\[
\epsilon_E=1.19\times10^{-4},
\]

\[
\epsilon_B=4.66\times10^{-6}.
\]

At \(\tau=0.10\),

\[
\epsilon_T=4.94\times10^{-4},
\quad
\epsilon_E=5.41\times10^{-4},
\quad
\epsilon_B=2.14\times10^{-5}.
\]

### Four-force and photon number

Four-force is much more sensitive because it is a small cancellation.

At \(\tau=0.06\), the relative four-force errors for
\(N=0,\ldots,4\) were

\[
20.79,\quad
0.577,\quad
1.08\times10^{-2},\quad
1.51\times10^{-4},\quad
1.70\times10^{-6}.
\]

The corresponding photon-number residuals were

\[
4.72\times10^{-2},\
1.31\times10^{-3},\
2.44\times10^{-5},\
3.43\times10^{-7},\
3.85\times10^{-9}.
\]

Thus a fixed \(N=2\) rule is rejected.

### Spectral distortion

A six-frequency curvature diagnostic was used: blackbody amplitude and
the first log-temperature tangent were projected out, and the remaining
spectrum was measured. A fitted second log-temperature derivative served
as a \(u_2\)-like proxy; it is not yet the exact Stebbins invariant moment.

At \(\tau=0.06\), \(N=2\) errors were

\[
\epsilon_{\rm spectrum}=2.42\times10^{-5},
\]

\[
\epsilon_{\rm distortion}=1.71\times10^{-5},
\]

\[
\epsilon_{u_2{\rm-like}}=1.70\times10^{-5}.
\]

At \(N=3\), these fell to about

\[
2.4\times10^{-7}.
\]

---

## Production decision

No universal \(N_{\rm sc}=2\) default is accepted.

The production rule is:

1. compute through the candidate order \(N\);
2. compute one additional term;
3. evaluate the a-posteriori bound for
   \(T,E,B\), photon number, four-force and spectral distortion;
4. stop only when all protected outputs meet tolerance.

For reionization-like optical depths near \(0.06\):

- \(N=3\) is normally sufficient for map-level \(T/E/B\) and spectral
  outputs;
- \(N=4\) is required in the present test for a four-force tolerance
  tighter than \(10^{-4}\).

## Open gates

1. Physical full-OTS H/He tables.
2. Calibrated SCRIPT/FlexRT sink closure.
3. Exact Stebbins central moments.
4. Time-dependent source hierarchy on a full all-Bianchi CF4 trajectory.
5. Optional invariant correction of truncated scattering sums.
