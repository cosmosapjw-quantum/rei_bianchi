# Stage R0-A/R0-B source lock

Primary sources used:

1. Mellema, Iliev, Alvarez & Shapiro,
   “C^2-Ray: A new method for photon-conserving transport of ionizing radiation,”
   arXiv:astro-ph/0508416.
   Key inherited ideas: absorbed-photon conservation, analytical ionization
   relaxation, time-averaged ionized fraction/optical depth.

2. Friedrich et al.,
   “Radiative transfer of energetic photons: X-rays and helium ionization
   in C2-Ray,” MNRAS 421 (2012) 2232.
   Key inherited ideas: coupled H/He chemistry, multifrequency heating,
   full OTS interface, secondary-ionization hooks.

3. Choudhury & Paranjape,
   “Photon number conservation and the large-scale 21 cm power spectrum
   in semi-numerical models of reionization,” arXiv:1807.00836.
   Key inherited idea: explicit global photon ledger.

4. Choudhury & Chakraborty,
   “Capturing Small-Scale Reionization Physics: A Sub-Grid Model for
   Photon Sinks with SCRIPT,” arXiv:2504.03384v2.
   Key inherited idea: clumping factor, mean free path and photoionization
   rate must be solved as a linked closure rather than independent knobs.

5. Cain & D’Aloisio,
   “FlexRT — A fast and flexible cosmological radiative transfer code for
   reionization studies I,” arXiv:2409.04521.
   Key inherited idea: generalized opacity is a closure interface.

6. Challinor,
   “Microwave background polarization in cosmological models,”
   arXiv:astro-ph/9911481.
   Key inherited idea: exact screen-tensor polarized transport in general
   spacetime geometry.

7. Allakhverdian & Naumov,
   “Infinite Series Solution of the Time-Dependent Radiative Transfer
   Equation in Anisotropically Scattering Media,” arXiv:2401.15698.
   Key inherited idea: terms classified by exact scattering order.

8. Stebbins,
   “CMB Spectral Distortions from the Scattering of Temperature
   Anisotropies,” arXiv:astro-ph/0703541.
   Key inherited idea for the next stage: Lorentz-invariant central
   temperature moments and nonperturbative cold-electron spectral mixing.

Durable auditor:
  Bianchi_Reionization_Stage_G1_P1_bundle.zip
  SHA-256:
  662c57fcde5ff59dcf9088cc9692837c827ab742d3afcc14623f3f0ffc45709e
