(* ::Package:: *)

(*
  Bianchi Reionization Stage R0-A/R0-B

  Scope:
    R0-A: homogeneous ionizing-UV chemistry in baryon proper time
    R0-B: exact-loss successive-scattering expansion for CMB reionization

  Conventions:
    metric signature (-,+,+,+)
    epsilon_123 = +1
    Q+iU <-> spin s=+2
    Q-iU <-> spin s=-2

  Durable dependencies:
    G1/P1 paired-grid Thomson auditor
    G1/P1 CF4 Bianchi-I characteristic and exact screen/Jones transport

  Important qualification:
    The H/He numerical relaxation below is the U-OTS/case-B baseline.
    Full coupled OTS is represented by an admissible recombination-photon
    yield matrix and is not yet calibrated to the Friedrich et al. tables.
*)

ClearAll["Global`*"];

(* ------------------------------------------------------------------ *)
(* R0-A1. H-only C2-Ray analytical relaxation                         *)
(* ------------------------------------------------------------------ *)

HRelaxation[x0_, gamma_, recomb_, dt_] := Module[
  {lam, xeq, x1, xbar, nion, nrec},
  lam = gamma + recomb;
  xeq = gamma/lam;
  x1 = xeq + (x0 - xeq) Exp[-lam dt];
  xbar =
    xeq +
    (x0 - xeq) (1 - Exp[-lam dt])/(lam dt);
  nion = gamma dt (1 - xbar);
  nrec = recomb dt xbar;
  <|
    "FinalIonizedFraction" -> x1,
    "TimeAverageIonizedFraction" -> xbar,
    "PrimaryIonizationsPerAtom" -> nion,
    "RecombinationsPerAtom" -> nrec,
    "LedgerResidual" -> nion - nrec - (x1 - x0)
  |>
];

(* ------------------------------------------------------------------ *)
(* R0-A2. Frozen-ne H/He matrix exponential and average                *)
(* ------------------------------------------------------------------ *)

HHeRateMatrix[ne_, p_Association] := Module[
  {m = ConstantArray[0., {5, 5}],
   gH, rH, g1, r1, g2, r2},

  {gH, rH, g1, r1, g2, r2} =
    Lookup[
      p,
      {"gH", "rH", "gHeI", "rHeII", "gHeII", "rHeIII"}
    ];

  (* state = {HI,HII,HeI,HeII,HeIII}; columns are source states *)
  m[[1, 1]] = -gH;
  m[[2, 1]] =  gH;
  m[[1, 2]] =  rH ne;
  m[[2, 2]] = -rH ne;

  m[[3, 3]] = -g1;
  m[[4, 3]] =  g1;
  m[[3, 4]] =  r1 ne;
  m[[4, 4]] = -(r1 ne + g2);
  m[[5, 4]] =  g2;
  m[[4, 5]] =  r2 ne;
  m[[5, 5]] = -r2 ne;

  m
];

ExactStepAndAverage[m_?MatrixQ, z0_?VectorQ, dt_] := Module[
  {n, augmented, result},
  n = Length[z0];
  augmented =
    ArrayFlatten[
      {
        {m, ConstantArray[0., {n, n}]},
        {IdentityMatrix[n], ConstantArray[0., {n, n}]}
      }
    ];
  result =
    MatrixExp[dt augmented].
      Join[z0, ConstantArray[0., n]];
  {
    result[[1 ;; n]],
    result[[n + 1 ;; 2 n]]/dt
  }
];

HHePicardStep[
  z0_, dt_, nH_, nHe_, rates_Association,
  tolerance_: 10^-13, maximumIterations_: 100
] := Module[
  {guess = z0, ne, matrix, final, average, iteration = 0},

  Do[
    iteration = k;
    ne =
      nH guess[[2]] +
      nHe (guess[[4]] + 2 guess[[5]]);

    matrix = HHeRateMatrix[ne, rates];
    {final, average} =
      ExactStepAndAverage[matrix, z0, dt];

    If[
      Norm[average - guess, Infinity] < tolerance,
      Break[]
    ];
    guess = average,
    {k, maximumIterations}
  ];

  <|
    "Final" -> final,
    "Average" -> average,
    "Iterations" -> iteration,
    "AverageElectronDensity" -> ne
  |>
];

(* ------------------------------------------------------------------ *)
(* R0-A3. Homogeneous multigroup photon-conserving update              *)
(* ------------------------------------------------------------------ *)

MultigroupPhotonStep[
  n0_List, source_List, opacitySpecies_?MatrixQ,
  sinkRate_List, photonEnergy_List, thresholdEnergy_List, dt_
] := Module[
  {chi, n1, removed, speciesAbs, sinkAbs,
   ionizationEnergy, heatingEnergy, sinkEnergy},

  chi = Total[opacitySpecies] + sinkRate;

  n1 =
    Table[
      n0[[g]] Exp[-chi[[g]] dt] +
      source[[g]] (1 - Exp[-chi[[g]] dt])/chi[[g]],
      {g, Length[n0]}
    ];

  removed = n0 + source dt - n1;

  speciesAbs =
    Table[
      removed[[g]] opacitySpecies[[s, g]]/chi[[g]],
      {s, Dimensions[opacitySpecies][[1]]},
      {g, Length[n0]}
    ];

  sinkAbs = removed sinkRate/chi;

  ionizationEnergy =
    Sum[
      speciesAbs[[s, g]] thresholdEnergy[[s]],
      {s, Length[thresholdEnergy]},
      {g, Length[n0]}
    ];

  heatingEnergy =
    Sum[
      speciesAbs[[s, g]]
        (photonEnergy[[g]] - thresholdEnergy[[s]]),
      {s, Length[thresholdEnergy]},
      {g, Length[n0]}
    ];

  sinkEnergy = sinkAbs.photonEnergy;

  <|
    "FinalPhotons" -> n1,
    "SpeciesAbsorptions" -> speciesAbs,
    "SinkAbsorptions" -> sinkAbs,
    "PhotonLedgerResidual" ->
      Max[
        Abs[
          n0 + source dt - n1 -
          Total[speciesAbs] - sinkAbs
        ]
      ],
    "EnergyLedgerResidual" ->
      n0.photonEnergy + dt source.photonEnergy -
      n1.photonEnergy - ionizationEnergy -
      heatingEnergy - sinkEnergy
  |>
];

(* ------------------------------------------------------------------ *)
(* R0-A4. Full-OTS interface                                          *)
(* ------------------------------------------------------------------ *)

OTSPhotonLedger[yieldMatrix_, recombinationEvents_] := Module[
  {internalIonizations, escaped},
  internalIonizations = yieldMatrix.recombinationEvents;
  escaped =
    (1 - Total[yieldMatrix]).recombinationEvents;
  <|
    "InternalIonizations" -> internalIonizations,
    "EscapedOrSubthreshold" -> escaped,
    "LedgerResidual" ->
      Total[recombinationEvents] -
      Total[internalIonizations] - escaped
  |>
];

(* ------------------------------------------------------------------ *)
(* R0-B1. Exact-loss successive-scattering hierarchy                  *)
(* ------------------------------------------------------------------ *)

(*
  d F[0]/d tau = -D F[0]
  d F[r+1]/d tau = -D F[r+1] + K F[r]

  Full:
    dF/dtau = (-D+K)F.

  For constant D,K the hierarchy is obtained from a lower block
  triangular matrix exponential. In a general Bianchi spacetime replace
  Exp[-(tau2-tau1)D] by the exact CF4 geodesic/screen/finite-tilt loss
  propagator U0(tau2,tau1).
*)

ScatteringHierarchyBlock[dmat_, kmat_, nterms_Integer] :=
  ArrayFlatten[
    Table[
      Which[
        i == j, -dmat,
        i == j + 1, kmat,
        True, ConstantArray[0., Dimensions[dmat]]
      ],
      {i, nterms}, {j, nterms}
    ]
  ];

ScatteringTerms[
  dmat_, kmat_, initial_, tau_, maximumOrder_Integer
] := Module[
  {block, enlarged, result, terms},
  block =
    ScatteringHierarchyBlock[
      dmat, kmat, maximumOrder + 2
    ];
  enlarged =
    Join[
      initial,
      ConstantArray[
        0.,
        (maximumOrder + 1) Length[initial]
      ]
    ];
  result =
    MatrixExp[tau block].enlarged;
  terms =
    Partition[result, Length[initial]];
  Take[terms, maximumOrder + 2]
];

RemainderBound[xi_, order_Integer] :=
  xi^(order + 1)/Factorial[order + 1]/
  (1 - xi/(order + 2));

APosterioriBound[
  nextTerm_, partialSum_, xi_, order_Integer
] :=
  Norm[nextTerm]/
  Norm[partialSum]/
  (1 - xi/(order + 2));

(* ------------------------------------------------------------------ *)
(* R0-B2. Stop rule                                                   *)
(* ------------------------------------------------------------------ *)

(*
  Compute one term beyond the reported order.
  Stop at order N only if

      ||F[N+1]|| /
      ((1 - Xi/(N+2)) ||Sum_{r=0}^N F[r]||)
      < epsilonObservable

  for every protected output:
    state norm, T/E/B, photon number, four-force, spectral moment proxy.

  In the executed auditor:
    tau=0.06
      N=2 state error       3.01e-5
      N=2 T/E errors        ~1.1e-4
      N=2 four-force error  1.08e-2
      N=3 four-force error  1.51e-4
      N=4 four-force error  1.70e-6

  Thus no fixed N=2 production rule is accepted.
*)

Print["Stage R0-A/R0-B consolidated definitions loaded."];
