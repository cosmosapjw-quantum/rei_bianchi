# Bianchi Reionization — Stage T2-D0/T2-D1 Verification Ledger

## Scope

- Transport grid: Lebedev-26, normalized weights
  - 6 axis nodes, weight 1/21
  - 12 edge nodes, weight 4/105
  - 8 cube-corner nodes, weight 9/280
- Collision grid: Lebedev-14, normalized weights
  - 6 axis nodes, weight 1/15
  - 8 cube-corner nodes, weight 3/40
- Scalar band limit: L = 2, M = 9 real/complex spherical-harmonic modes.
- Generic relative grid rotation:
  - axis = Normalize[{2,-1,3}]
  - angle = 0.731 rad

## Scalar maps

With physical quadrature weights W_T and W_C,

A = Y_C (Y_T^† W_T Y_T)^(-1) Y_T^† W_T,

A^sharp = W_T^(-1) A^† W_C.

Because both Gram matrices equal I for L <= 2,

A = Y_C Y_T^† W_T,
A^sharp = Y_T Y_C^† W_C.

The addition-theorem kernel is

K_2(mu) = sum_{l=0}^2 (2l+1) P_l(mu)
        = -3/2 + 3 mu + (15/2) mu^2,

A_qp = wbar_T,p K_2(k_C,q . k_T,p).

## Exact symbolic gates

All returned exact zero:

- A 1_T - 1_C
- A^sharp 1_C - 1_T
- w_C^T A - w_T^T
- W_T A^sharp - A^T W_C
- first moments of both grids
- second-moment residuals of both grids
- fourth-moment residuals of both grids

Direct monomial cubature audit:

- Lebedev-14 is exact for every monomial through total degree 5; first failure at degree 6, maximum normalized-sphere residual 4/315.
- Lebedev-26 is exact for every monomial through total degree 7; first failure at degree 8, maximum normalized-sphere residual 2/315.
- Odd-degree residuals vanish beyond those formal degrees because both rules are antipodally symmetric; this does not raise the polynomial exactness degree.

## Numerical harmonic and projector gates

At 70–80 digit working precision on the rotated grid pair:

- max weighted Y_lm restriction error, l <= 2: zero to about 40 displayed digits
- max weighted Y_lm prolongation error, l <= 2: zero to about 40 displayed digits
- A^sharp A band-limited round trip: zero to about 76 displayed digits using high-precision coefficients
- rank(A) = rank(A^sharp) = rank(A^sharp A) = rank(A A^sharp) = 9
- trace(A^sharp A) = trace(A A^sharp) = 9
- all nine nonzero weighted singular values of A equal 1
- A^sharp A is the W_T-orthogonal projector onto the sampled L<=2 subspace
- A A^sharp is the W_C-orthogonal projector onto the sampled L<=2 subspace

An arbitrary 26-node vector is therefore not expected to round-trip. One random test had relative W_T error about 0.86784; applying the projector twice was idempotent to about 1.4e-16 in the machine-random test.

## Aliasing onset

Using weighted L2 output norms and normalized complex Y_lm inputs:

Transport-grid input -> collision-grid low band:

- l = 3,4,5: zero to roughly 76 digits
- l = 6: first nonzero alias, max over m about 1.10856044039

Collision-grid input -> transport-grid low band:

- l = 3: zero to roughly 76 digits
- l = 4: first nonzero alias, max over m about 0.87729189885

These onsets match the cubature degrees: products with the retained L=2 basis have total degree l+2.

## Positivity verdict

The raw harmonic maps are not positivity preserving.

Aligned exact-grid minima:

- min(A) = -1/14
- min(A^sharp) = -1/8

The kernel is negative for

((-1-sqrt(6))/5) < mu < ((-1+sqrt(6))/5).

On the generic rotated pair:

- worst restriction impulse raw minimum: -0.08562301755
- conservative limiter theta: 0.35738749289
- limited minimum: 0
- weighted-number residual: zero to about 77 digits
- worst state-prolongation impulse raw minimum: -0.13485625264
- same limiter theta: 0.35738749289
- limited minimum: 0
- weighted-number residual: zero to about 76 digits

For a positive L<=2 field with raw target minimum about 0.88769794, theta=1 and the limiter changed nothing.

### Structural no-go

For one row of a positive constant-preserving linear map, let alpha_p >= 0 and sum alpha_p = 1. Dipole exactness requires

sum_p alpha_p k_p = k_q,

with all source and target directions unit. Equality in

|sum alpha_p k_p| <= sum alpha_p |k_p| = 1

forces every source direction with nonzero alpha_p to equal k_q. Hence a generic nonnested sphere-grid map cannot be simultaneously:

1. row-positive,
2. constant preserving,
3. pointwise dipole exact.

For the rotated 26/14 pair there were no coincident directions; the minimum source-target angular separation was about 13.56581894 degrees.

Therefore the interface must distinguish:

- state restriction/prolongation: harmonic map followed by a nonlinear conservative positivity limiter when needed;
- signed collision-source pullback: the unmodified linear weighted adjoint A^sharp, so number conservation remains exact.

## Spin-2 screen-phase interface

For a boost Lambda(v), source photon p=(1,k), and target photon p~=Lambda p,

D = p~^0,
k~^a = p~^a/D - n~^a.

Map a source screen basis s_A by

s^map_A = S~ Lambda s_A,

then compare it with the canonical target basis e~_B:

R_BA = e~_B . s^map_A.

The interface defines psi by

s^map_1 = cos(psi) e~_1 + sin(psi) e~_2,
s^map_2 = -sin(psi) e~_1 + cos(psi) e~_2.

Thus, for

P_+ = Q+iU  (spin weight s=-2),
P_- = Q-iU  (spin weight s=+2),

P_+~ = exp(+2 i psi) P_+,
P_-~ = exp(-2 i psi) P_-.

Equivalently Phi_s = exp(-i s psi).

An arbitrary-tilt numerical test with

v = {0.31,-0.22,0.41}, |v| = 0.55910642994

returned:

- direction forward/inverse residual: zero to about 69 digits
- mapped screen Gram residual: zero to about 68 digits
- R^T R-I: zero to about 67 digits
- det(R)-1: zero to about 67 digits
- phase forward/inverse product minus 1: zero to about 67 digits
- symbolic Stokes identity (Q+iU)'-(cos psi+i sin psi)^2(Q+iU): exactly zero

For an aberrated spin-s restriction, the future operator should be

A_s = Phi_s Y_source,s (Y_T,s^† W_T Y_T,s)^(-1) Y_T,s^† W_T,

where Y_source,s is evaluated at the inverse-aberrated source directions corresponding to collision-grid target nodes. The signed pullback is

A_s^sharp = W_T^(-1) A_s^† W_C.

## Gate verdict

- D0 grid definitions and cubature audit: PASS
- D1 constant preservation: PASS
- D1 number conservation: PASS
- weighted-adjoint pullback: PASS
- Y_lm exactness for l<=2: PASS
- A^sharp A band-limited round trip: PASS
- arbitrary nodal round trip: PROJECTOR, not inverse
- aliasing characterization: PASS
- raw linear positivity: FAIL, structurally unavoidable on generic nonnested grids
- conservative scalar positivity limiter: PASS as a nonlinear state-transfer repair
- spin-2 screen-phase interface: DEFINED and local boost round-trip verified

## Next stage

Stage T2-D2 should construct the actual spin-weighted restriction using inverse-aberrated source directions and screen phases, then test pure E/B modes, phase signs, weighted adjointness, coherency-cone preservation, and boost round trips under increasing transport/collision band limits.
