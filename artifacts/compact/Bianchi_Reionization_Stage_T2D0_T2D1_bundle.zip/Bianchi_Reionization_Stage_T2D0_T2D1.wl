(* ::Package:: *)

(*
  Bianchi reionization Stage T2-D0 / T2-D1

  Scope
    - Lebedev-26 transport grid -> Lebedev-14 collision grid.
    - Scalar l<=2 harmonic restriction A and weighted-adjoint pullback ASharp.
    - Exact constant and number conservation.
    - Y_lm exactness, aliasing onset, and ASharp.A projector tests.
    - Positivity audit and conservative nonlinear scalar limiter.
    - Spin-2 screen-phase interface for later aberrated restriction.

  Conventions
    metric signature (-,+,+,+)
    epsilon_123 = +1
    Lebedev weights below are normalized to sum to one; physical sphere
    weights are 4 Pi times these normalized weights.

  Important design conclusion
    On generic nonnested sphere grids no row-positive, constant-preserving
    linear point-evaluation map can be dipole-exact. Therefore the harmonic
    map and positivity must be separated: use a nonlinear limiter for state
    transfer, but retain the linear weighted adjoint for signed source pullback.
*)

ClearAll["Global`*"];
$MaxExtraPrecision = 3000;
workPrec = 80;
maxAbs[x_] := Max[Abs[Flatten[N[x, workPrec]]]];

(* ---------------------------------------------------------------------- *)
(* Lebedev grids                                                           *)
(* ---------------------------------------------------------------------- *)

lebedev14Exact[] := Module[{axes, corners, dirs, weights},
  axes = {{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
  corners = Flatten[
    Table[{sx,sy,sz}/Sqrt[3], {sx,{-1,1}}, {sy,{-1,1}}, {sz,{-1,1}}],
    2
  ];
  dirs = Join[axes, corners];
  weights = Join[ConstantArray[1/15,6], ConstantArray[3/40,8]];
  {dirs, weights}
];

lebedev26Exact[] := Module[{axes, edges, corners, dirs, weights},
  axes = {{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
  edges = DeleteDuplicates @ Flatten[
    Table[Permutations[{sx/Sqrt[2], sy/Sqrt[2], 0}],
      {sx,{-1,1}}, {sy,{-1,1}}],
    2
  ];
  corners = Flatten[
    Table[{sx,sy,sz}/Sqrt[3], {sx,{-1,1}}, {sy,{-1,1}}, {sz,{-1,1}}],
    2
  ];
  dirs = Join[axes, edges, corners];
  weights = Join[
    ConstantArray[1/21,6],
    ConstantArray[4/105,12],
    ConstantArray[9/280,8]
  ];
  {dirs, weights}
];

(* Real orthonormal harmonic basis spanning l<=2. *)
realH2[{x_,y_,z_}] := {
  1/Sqrt[4 Pi],
  Sqrt[3/(4 Pi)] x,
  Sqrt[3/(4 Pi)] y,
  Sqrt[3/(4 Pi)] z,
  Sqrt[15/(4 Pi)] x y,
  Sqrt[15/(4 Pi)] y z,
  Sqrt[15/(4 Pi)] z x,
  Sqrt[15/(16 Pi)] (x^2-y^2),
  Sqrt[5/(16 Pi)] (3 z^2-1)
};

kernelL2[mu_] := 1 + 3 mu + 5 LegendreP[2,mu];

{collisionDirsExact, collisionWeights0} = lebedev14Exact[];
{transportDirsExact, transportWeights0} = lebedev26Exact[];

(* Generic relative orientation for the numerical gate. *)
rotationAxis = N[Normalize[{2,-1,3}], workPrec];
rotationAngle = SetPrecision[731/1000, workPrec];
relativeRotation = N[RotationMatrix[rotationAngle, rotationAxis], workPrec];
collisionDirs = N[(relativeRotation.#)& /@ collisionDirsExact, workPrec];
transportDirs = N[transportDirsExact, workPrec];
collisionWeights = N[4 Pi collisionWeights0, workPrec];
transportWeights = N[4 Pi transportWeights0, workPrec];
WC = DiagonalMatrix[collisionWeights];
WT = DiagonalMatrix[transportWeights];

(* Addition-theorem representation of the l<=2 restriction. *)
A = N[
  Table[
    transportWeights0[[p]] kernelL2[collisionDirs[[q]].transportDirs[[p]]],
    {q,Length[collisionDirs]}, {p,Length[transportDirs]}
  ],
  workPrec
];

ASharp = Inverse[WT].Transpose[A].WC;
PT = ASharp.A;
PC = A.ASharp;

(* ---------------------------------------------------------------------- *)
(* Exact scalar identities on the aligned exact grids                      *)
(* ---------------------------------------------------------------------- *)

AExact = Table[
  transportWeights0[[p]]
    kernelL2[collisionDirsExact[[q]].transportDirsExact[[p]]],
  {q,14},{p,26}
];

ASharpExact = Table[
  collisionWeights0[[q]]
    kernelL2[transportDirsExact[[p]].collisionDirsExact[[q]]],
  {p,26},{q,14}
];

exactConstantRestriction = FullSimplify[
  AExact.ConstantArray[1,26]-ConstantArray[1,14]
];
exactConstantProlongation = FullSimplify[
  ASharpExact.ConstantArray[1,14]-ConstantArray[1,26]
];
exactNumberRestriction = FullSimplify[
  collisionWeights0.AExact-transportWeights0
];
exactWeightedAdjoint = FullSimplify[
  DiagonalMatrix[transportWeights0].ASharpExact
  -Transpose[AExact].DiagonalMatrix[collisionWeights0]
];

(* ---------------------------------------------------------------------- *)
(* Complex Y_lm tests and aliasing                                         *)
(* ---------------------------------------------------------------------- *)

anglePair[k_] := Module[{z,phi},
  z = N[k[[3]],workPrec];
  phi = If[Abs[k[[1]]]+Abs[k[[2]]] < 10^-50,
    0,
    ArcTan[k[[1]],k[[2]]]
  ];
  {ArcCos[Min[1,Max[-1,z]]],phi}
];

ylmVector[dirs_,l_,m_] := N[
  (SphericalHarmonicY[l,m,Sequence@@anglePair[#]])& /@ dirs,
  workPrec
];

weightedNorm[x_,W_] := Sqrt[Re[Conjugate[x].W.x]];
modeList = Flatten[Table[{l,m},{l,0,2},{m,-l,l}],1];
YT = Transpose[(ylmVector[transportDirs,#[[1]],#[[2]]]& /@ modeList)];
YC = Transpose[(ylmVector[collisionDirs,#[[1]],#[[2]]]& /@ modeList)];

restrictionYlmError = Max@Table[
  weightedNorm[A.YT[[All,j]]-YC[[All,j]],WC],
  {j,Length[modeList]}
];
prolongationYlmError = Max@Table[
  weightedNorm[ASharp.YC[[All,j]]-YT[[All,j]],WT],
  {j,Length[modeList]}
];

transportAliasing = Table[
  {l,Max@Table[
    weightedNorm[A.ylmVector[transportDirs,l,m],WC],
    {m,-l,l}
  ]},
  {l,3,10}
];

collisionAliasing = Table[
  {l,Max@Table[
    weightedNorm[ASharp.ylmVector[collisionDirs,l,m],WT],
    {m,-l,l}
  ]},
  {l,3,10}
];

bandCoefficients = N[
  Table[(j+I(-1)^j)/(17+j),{j,1,9}],
  workPrec
];
bandState = YT.bandCoefficients;
bandRoundTripResidual = PT.bandState-bandState;

(* ---------------------------------------------------------------------- *)
(* Positivity limiter and no-go diagnostic                                 *)
(* ---------------------------------------------------------------------- *)

limitPositive[state_,weights_] := Module[{avg,minState,theta,out},
  avg = (weights.state)/Total[weights];
  minState = Min[state];
  theta = If[minState>=0,
    1,
    If[avg<=0,0,Min[1,avg/(avg-minState)]]
  ];
  out = avg ConstantArray[1,Length[state]]
        +theta(state-avg ConstantArray[1,Length[state]]);
  <|"State"->out,"Theta"->theta,"Average"->avg|>
];

(* Structural no-go:
   If row weights alpha_p are nonnegative and sum to one, and
   Sum alpha_p k_p = k_target with all vectors unit, equality in the triangle
   inequality forces every supported k_p to equal k_target. Thus a generic
   nonnested grid cannot have a positive constant- and dipole-exact linear
   point-evaluation map. *)

maxSourceDots = Table[
  Max[transportDirs.collisionDirs[[q]]],
  {q,Length[collisionDirs]}
];
minimumGridSeparation = Min[ArcCos[maxSourceDots]];

worstRestrictionFlatIndex = First@Ordering[Flatten[A],1];
{worstQ,worstP} = QuotientRemainder[
  worstRestrictionFlatIndex-1,
  Length[transportDirs]
]+{1,1};
restrictionImpulse = UnitVector[Length[transportDirs],worstP];
restrictionRaw = A.restrictionImpulse;
restrictionLimited = limitPositive[restrictionRaw,collisionWeights];

worstProlongationFlatIndex = First@Ordering[Flatten[ASharp],1];
{worstP2,worstQ2} = QuotientRemainder[
  worstProlongationFlatIndex-1,
  Length[collisionDirs]
]+{1,1};
prolongationImpulse = UnitVector[Length[collisionDirs],worstQ2];
prolongationRaw = ASharp.prolongationImpulse;
prolongationLimited = limitPositive[prolongationRaw,transportWeights];

(* ---------------------------------------------------------------------- *)
(* Spin-screen phase interface                                             *)
(* ---------------------------------------------------------------------- *)

eta4 = DiagonalMatrix[{-1,1,1,1}];
observer0 = {1,0,0,0};
minkowskiDot[a_,b_] := a.eta4.b;

boostMatrix[velocity_] := Module[{v2,gamma,top,bottom},
  v2 = velocity.velocity;
  gamma = 1/Sqrt[1-v2];
  top = Join[{gamma},-gamma velocity];
  bottom = Table[
    Join[
      {-gamma velocity[[i]]},
      IdentityMatrix[3][[i]]
        +((gamma-1)/v2)velocity[[i]]velocity
    ],
    {i,3}
  ];
  Join[{top},bottom]
];

referenceAxis[k_] := IdentityMatrix[3][[First@Ordering[Abs[k],1]]];
canonicalScreenBasis[k_] := Module[{ref,e1,e2},
  ref = referenceAxis[k];
  e1 = Normalize[Cross[ref,k]];
  e2 = Cross[k,e1];
  {e1,e2}
];

screenProjectorMixed[observer_,direction4_] :=
  IdentityMatrix[4]
  +Outer[Times,observer,eta4.observer]
  -Outer[Times,direction4,eta4.direction4];

screenPhaseInterface[velocity_,sourceDirection_] := Module[
  {lambda,pSource,pTarget,doppler,targetDirection4,targetDirection,
   sourceBasis3,sourceBasis4,targetProjector,rawMapped,b1,b2,
   mappedBasis,targetBasis3,targetBasis4,rotation2,psi,phasePlus,phaseMinus},

  lambda = boostMatrix[velocity];
  pSource = Join[{1},sourceDirection];
  pTarget = lambda.pSource;
  doppler = pTarget[[1]];
  targetDirection4 = pTarget/doppler-observer0;
  targetDirection = Rest[targetDirection4];

  sourceBasis3 = canonicalScreenBasis[sourceDirection];
  sourceBasis4 = (Join[{0},#]& /@ sourceBasis3);
  targetProjector = screenProjectorMixed[observer0,targetDirection4];
  rawMapped = (targetProjector.(lambda.#))& /@ sourceBasis4;

  b1 = rawMapped[[1]]/Sqrt[minkowskiDot[rawMapped[[1]],rawMapped[[1]]]];
  b2 = rawMapped[[2]]-minkowskiDot[rawMapped[[2]],b1]b1;
  b2 = b2/Sqrt[minkowskiDot[b2,b2]];
  mappedBasis = {b1,b2};

  targetBasis3 = canonicalScreenBasis[targetDirection];
  targetBasis4 = (Join[{0},#]& /@ targetBasis3);
  rotation2 = Table[
    minkowskiDot[targetBasis4[[i]],mappedBasis[[j]]],
    {i,2},{j,2}
  ];

  (* Convention:
       mapped e1 = cos(psi) target e1 + sin(psi) target e2.
     Hence P_plus = Q+iU acquires Exp[+2 I psi], while
     P_minus = Q-iU acquires Exp[-2 I psi]. *)
  psi = ArcTan[rotation2[[1,1]],rotation2[[2,1]]];
  phasePlus = (rotation2[[1,1]]+I rotation2[[2,1]])^2;
  phaseMinus = Conjugate[phasePlus];

  <|
    "Doppler"->doppler,
    "SourceDirection"->sourceDirection,
    "TargetDirection"->targetDirection,
    "MappedBasis"->mappedBasis,
    "TargetBasis"->targetBasis4,
    "Rotation2"->rotation2,
    "Psi"->psi,
    "PhasePlus"->phasePlus,
    "PhaseMinus"->phaseMinus
  |>
];

(* Later spin-s restriction, for target collision directions q:

   sourceDirections[q] = inverse-aberrated direction associated with target q
   phase_s[q] = Exp[-I s psi[q]]

   ASpin[s] = DiagonalMatrix[phase_s]
              . YSource[s]
              . Inverse[ConjugateTranspose[YTSpin].WT.YTSpin]
              . ConjugateTranspose[YTSpin].WT

   where P_plus=Q+iU has s=-2 and P_minus=Q-iU has s=+2.
   The signed source pullback is the weighted adjoint

   ASpinSharp[s] = Inverse[WT].ConjugateTranspose[ASpin[s]].WC.
*)

(* Compact result association. *)
results = <|
  "NodeCounts"->{Length[transportDirs],Length[collisionDirs]},
  "ExactConstantRestriction"->exactConstantRestriction,
  "ExactConstantProlongation"->exactConstantProlongation,
  "ExactNumberRestriction"->exactNumberRestriction,
  "ExactWeightedAdjoint"->exactWeightedAdjoint,
  "YlmRestrictionError"->restrictionYlmError,
  "YlmProlongationError"->prolongationYlmError,
  "BandRoundTripInfinityNorm"->Max[Abs[bandRoundTripResidual]],
  "TransportAliasing"->transportAliasing,
  "CollisionAliasing"->collisionAliasing,
  "RestrictionMinimumEntry"->Min[Flatten[A]],
  "ProlongationMinimumEntry"->Min[Flatten[ASharp]],
  "MinimumGridSeparationRadians"->minimumGridSeparation,
  "RestrictionLimiterTheta"->restrictionLimited["Theta"],
  "RestrictionLimitedMinimum"->Min[restrictionLimited["State"]],
  "RestrictionLimiterNumberResidual"->
    collisionWeights.restrictionLimited["State"]
    -transportWeights.restrictionImpulse,
  "ProlongationLimiterTheta"->prolongationLimited["Theta"],
  "ProlongationLimitedMinimum"->Min[prolongationLimited["State"]],
  "ProlongationLimiterNumberResidual"->
    transportWeights.prolongationLimited["State"]
    -collisionWeights.prolongationImpulse
|>;

results
