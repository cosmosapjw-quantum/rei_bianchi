/*
 * PETSc SNESNEWTONAL scaffold for P0.5-B2A.
 *
 * Status: IMPLEMENTED_NOT_COMPILED_PETSC_UNAVAILABLE.
 *
 * This adapter intentionally contains no model-specific finite differences.
 * B2AResidualAndJacobian() and B2AEmissivityTangent() are the only callbacks
 * that must be wired to the durable residual/Jacobian implementation.
 */
#include <petscsnes.h>

typedef struct {
  PetscReal log_eps_min;
  PetscReal log_eps_max;
  void *model_ctx;
} B2AContext;

/* User-provided durable model hooks. */
PETSC_EXTERN PetscErrorCode B2AResidualAndJacobian(Vec U, PetscReal log_eps,
                                                   Vec F, Mat J, void *ctx);
PETSC_EXTERN PetscErrorCode B2AEmissivityTangent(Vec U, PetscReal log_eps,
                                                 Vec Q, void *ctx);

static PetscReal MapLoadToLogEps(PetscReal lambda, const B2AContext *ctx)
{
  return ctx->log_eps_min + lambda * (ctx->log_eps_max - ctx->log_eps_min);
}

static PetscErrorCode FormResidual(SNES snes, Vec U, Vec F, void *vctx)
{
  B2AContext *ctx = (B2AContext *)vctx;
  PetscReal lambda, log_eps;
  PetscFunctionBeginUser;
  PetscCall(SNESNewtonALGetLoadParameter(snes, &lambda));
  log_eps = MapLoadToLogEps(lambda, ctx);
  PetscCall(B2AResidualAndJacobian(U, log_eps, F, NULL, ctx->model_ctx));
  PetscFunctionReturn(PETSC_SUCCESS);
}

static PetscErrorCode FormJacobian(SNES snes, Vec U, Mat J, Mat P, void *vctx)
{
  B2AContext *ctx = (B2AContext *)vctx;
  PetscReal lambda, log_eps;
  PetscFunctionBeginUser;
  PetscCall(SNESNewtonALGetLoadParameter(snes, &lambda));
  log_eps = MapLoadToLogEps(lambda, ctx);
  PetscCall(B2AResidualAndJacobian(U, log_eps, NULL, J, ctx->model_ctx));
  if (P != J) PetscCall(MatCopy(J, P, SAME_NONZERO_PATTERN));
  PetscFunctionReturn(PETSC_SUCCESS);
}

/* PETSc defines this as the tangent load vector.  The chain factor converts
 * dF/d(log epsilon) to dF/d(lambda). */
static PetscErrorCode FormTangentLoad(SNES snes, Vec U, Vec Q, void *vctx)
{
  B2AContext *ctx = (B2AContext *)vctx;
  PetscReal lambda, log_eps, scale;
  PetscFunctionBeginUser;
  PetscCall(SNESNewtonALGetLoadParameter(snes, &lambda));
  log_eps = MapLoadToLogEps(lambda, ctx);
  scale = ctx->log_eps_max - ctx->log_eps_min;
  PetscCall(B2AEmissivityTangent(U, log_eps, Q, ctx->model_ctx));
  PetscCall(VecScale(Q, scale));
  PetscFunctionReturn(PETSC_SUCCESS);
}

PetscErrorCode ConfigureB2ASNESNEWTONAL(SNES snes, Vec r, Mat J,
                                        B2AContext *ctx)
{
  PetscFunctionBeginUser;
  PetscCall(SNESSetType(snes, SNESNEWTONAL));
  PetscCall(SNESSetFunction(snes, r, FormResidual, ctx));
  PetscCall(SNESSetJacobian(snes, J, J, FormJacobian, ctx));
  PetscCall(SNESNewtonALSetFunction(snes, FormTangentLoad, ctx));
  /* Select exact/normal correction, step size and lambda bounds through the
   * official options database, e.g.
   *   -snes_newtonal_correction_type exact
   *   -snes_newtonal_step_size 0.02
   *   -snes_newtonal_lambda_min 0
   *   -snes_newtonal_lambda_max 1
   */
  PetscCall(SNESSetFromOptions(snes));
  PetscFunctionReturn(PETSC_SUCCESS);
}
