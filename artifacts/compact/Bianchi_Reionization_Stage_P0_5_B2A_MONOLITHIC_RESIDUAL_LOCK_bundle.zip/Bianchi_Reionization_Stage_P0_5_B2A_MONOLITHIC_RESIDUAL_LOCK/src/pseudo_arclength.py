"""Custom bordered predictor-corrector pseudo-arclength continuation.

This is a local numerical reference for the newly reconstructed B2A residual.
It does not inherit B1's reduced-fold value as a premise.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import jax
jax.config.update("jax_enable_x64", True)
import jax.numpy as jnp
import numpy as np

STAGE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(STAGE/"src"))
from monolithic_model import residual, transform_z_to_y

fixture=json.loads((STAGE/"checkpoints"/"known_state_fixture.json").read_text())
solution=json.loads((STAGE/"checkpoints"/"known_state_solution.json").read_text())
p={k:jnp.asarray(v,dtype=jnp.float64) for k,v in fixture["parameters"].items()}
logeps0=float(fixture["log_emissivity_target"])
z0=np.asarray(solution["Z"],float)

@jax.jit
def F_jax(z,eta):
    return residual(z,jnp.array(logeps0)+eta,p)

Jz_jax=jax.jit(jax.jacfwd(F_jax,argnums=0))
Jeta_jax=jax.jit(jax.jacfwd(F_jax,argnums=1))

# Warm-up compilation.
_ = np.asarray(F_jax(jnp.asarray(z0),jnp.array(0.0)))
_ = np.asarray(Jz_jax(jnp.asarray(z0),jnp.array(0.0)))
_ = np.asarray(Jeta_jax(jnp.asarray(z0),jnp.array(0.0)))

def F(z,eta): return np.asarray(F_jax(jnp.asarray(z),jnp.array(eta)),float)
def Jz(z,eta): return np.asarray(Jz_jax(jnp.asarray(z),jnp.array(eta)),float)
def Jeta(z,eta): return np.asarray(Jeta_jax(jnp.asarray(z),jnp.array(eta)),float)

def damped_newton_fixed(eta,zguess,tol=1e-11,maxiter=25):
    z=np.array(zguess,float)
    for it in range(maxiter):
        r=F(z,eta); nr=np.max(np.abs(r))
        if nr<tol:return z,it+1
        dz=np.linalg.solve(Jz(z,eta),-r)
        alpha=1.0
        accepted=False
        for _ in range(15):
            zn=z+alpha*dz
            if np.max(np.abs(F(zn,eta))) < (1-1e-4*alpha)*nr:
                z=zn;accepted=True;break
            alpha*=0.5
        if not accepted:z=z+0.1*dz
    raise RuntimeError(f"fixed-eta Newton failed eta={eta}, residual={np.max(np.abs(F(z,eta)))}")

def tangent(z,eta,orientation):
    A=np.column_stack([Jz(z,eta),Jeta(z,eta)])
    _,_,vh=np.linalg.svd(A)
    t=vh[-1]
    if t[-1]*orientation<0:t=-t
    return t/np.linalg.norm(t)

def correct(xpred,tprev,tol=1e-10,maxiter=25):
    x=np.array(xpred,float)
    for it in range(maxiter):
        z=x[:9];eta=x[9]
        r=np.r_[F(z,eta),np.dot(tprev,x-xpred)]
        nr=np.max(np.abs(r))
        if nr<tol:return x,it+1
        A=np.vstack([np.column_stack([Jz(z,eta),Jeta(z,eta)]),tprev])
        dx=np.linalg.solve(A,-r)
        alpha=1.0;accepted=False
        for _ in range(15):
            xn=x+alpha*dx
            rn=np.r_[F(xn[:9],xn[9]),np.dot(tprev,xn-xpred)]
            if np.max(np.abs(rn)) < (1-1e-4*alpha)*nr:
                x=xn;accepted=True;break
            alpha*=0.5
        if not accepted:x=x+0.1*dx
    raise RuntimeError(f"corrector failed residual={np.max(np.abs(r))}")

def margins(z):
    s=transform_z_to_y(jnp.asarray(z))
    return {"min_photon":float(np.min(np.asarray(s["N"]))),
            "min_fraction":float(min(s["xHII"],1-s["xHII"],s["xHeI"],s["xHeII"],s["xHeIII"])),
            "u_th":float(s["u"]),"GammaHI":float(s["GammaHI"])}

def record(direction,index,x,nfev,t):
    z=x[:9];eta=x[9];J=Jz(z,eta);sv=np.linalg.svd(J,compute_uv=False);m=margins(z)
    return {"direction":direction,"index":index,"eta":float(eta),
            "emissivity":float(np.exp(logeps0+eta)),"GammaHI":m["GammaHI"],
            "residual_inf":float(np.max(np.abs(F(z,eta)))),"min_singular_J":float(sv[-1]),
            "condition_J":float(sv[0]/sv[-1]),"corrector_iterations":int(nfev),
            **m,"Z":z.tolist(),"tangent":t.tolist()}

def run(direction,nsteps=11,ds=0.018):
    eta1=direction*0.008
    z1,n1=damped_newton_fixed(eta1,z0)
    xprev=np.r_[z0,0.0];xcur=np.r_[z1,eta1]
    t=(xcur-xprev)/np.linalg.norm(xcur-xprev)
    if t[-1]*direction<0:t=-t
    rows=[record(direction,0,xprev,0,t),record(direction,1,xcur,n1,t)]
    for k in range(2,nsteps):
        xpred=xcur+ds*t
        xnew,nit=correct(xpred,t)
        tnew=tangent(xnew[:9],xnew[9],direction)
        if np.dot(tnew,t)<0:tnew=-tnew
        xprev,xcur,t=xcur,xnew,tnew
        rows.append(record(direction,k,xcur,nit,t))
    return rows

rows=run(-1)+run(1)
(STAGE/"data"/"pseudo_arclength_branch.json").write_text(json.dumps(rows,indent=2),encoding="utf-8")
import csv
fields=["direction","index","eta","emissivity","GammaHI","residual_inf","min_singular_J","condition_J","corrector_iterations","min_photon","min_fraction","u_th"]
with (STAGE/"data"/"pseudo_arclength_branch.csv").open("w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows([{k:r[k] for k in fields} for r in rows])

summary={"status":"NUMERICALLY_VALIDATED_LOCAL_BRANCH_REFERENCE","parameter":"eta=log(epsilon/epsilon_target)",
         "point_count":len(rows),"eta_range":[min(r["eta"] for r in rows),max(r["eta"] for r in rows)],
         "emissivity_range":[min(r["emissivity"] for r in rows),max(r["emissivity"] for r in rows)],
         "GammaHI_range":[min(r["GammaHI"] for r in rows),max(r["GammaHI"] for r in rows)],
         "max_residual_inf":max(r["residual_inf"] for r in rows),
         "minimum_singular_J":min(r["min_singular_J"] for r in rows),
         "minimum_fraction_margin":min(r["min_fraction"] for r in rows),
         "fold_detected":bool(min(r["min_singular_J"] for r in rows)<1e-6),
         "B1_reduced_fold_role":"AUDITOR_ONLY_NOT_USED_AS_PREMISE",
         "interpretation":"Local reconstructed-model continuation only; no source calibration or maintenance fitting."}
(STAGE/"data"/"pseudo_arclength_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
print(json.dumps(summary,indent=2))
if summary["max_residual_inf"]>=1e-9 or summary["minimum_fraction_margin"]<=0:raise SystemExit(2)
