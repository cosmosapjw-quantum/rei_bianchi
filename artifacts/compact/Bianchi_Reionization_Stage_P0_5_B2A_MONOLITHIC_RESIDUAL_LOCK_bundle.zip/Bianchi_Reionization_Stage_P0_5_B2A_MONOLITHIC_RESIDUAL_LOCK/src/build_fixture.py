"""Build the post-interruption fixed-z regression fixture.

The B1 current state is used only as a regression target. The previous state
is reconstructed from the new B2A physical RHS so that no transcript-only B2
quantity is inherited.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

import jax
jax.config.update("jax_enable_x64", True)
import jax.numpy as jnp
import numpy as np
import pandas as pd
from scipy.integrate import quad
from scipy.interpolate import PchipInterpolator

from monolithic_model import (
    C_LIGHT,
    KB_ERG,
    MPC_CM,
    physical_rhs,
    transform_y_to_z,
)

STAGE = Path(__file__).resolve().parents[1]
B1 = STAGE / "inputs" / "extracted_P0_5_B1" / "Bianchi_Reionization_Stage_P0_5_B1_PHOTON_ALLOCATION_QMASS_LOCK"
P04 = STAGE / "inputs" / "extracted_P0_4" / "Bianchi_Reionization_Stage_P0_4_PAPER_CODE_CHECKPOINT_REGRESSION"

fixed = json.loads((B1 / "inputs" / "p05_fixed_z_result.json").read_text())
raw = np.loadtxt(P04 / "data" / "environment_mfp_energies.txt")
density_map = pd.read_csv(P04 / "data" / "density_mapping_colossus_1_3_10_port.csv")

ZCOS = float(fixed["z"])
DT = float(fixed["dt_Myr"]) * 1.0e6 * 365.25 * 86400.0
GAMMA_TARGET = float(fixed["target_Gamma_HI_s-1"])
EPS_TARGET = float(fixed["inferred_emissivity_s_cMpc3"])

# Cosmology and densities.
H0 = 67.4 * 1.0e5 / MPC_CM
OM, OL = 0.315, 0.685
HUBBLE = H0 * math.sqrt(OM * (1.0 + ZCOS) ** 3 + OL)
NH0 = 1.88e-7
YHE = 0.079
nH = NH0 * (1.0 + ZCOS) ** 3
nHe = YHE * nH

# Four transport groups. The regression fixture uses a deliberately soft
# photon-number spectrum E^-4 so that the B1 low-HeIII state has a physical
# reconstructed predecessor. This is a numerical fixture, not source calibration.
SPECTRAL_ALPHA = -4.0
groups = [(13.60, 24.59), (24.59, 39.50), (39.50, 54.42), (54.42, 100.0)]

def integral_power(lo: float, hi: float, alpha: float = SPECTRAL_ALPHA) -> float:
    return (hi ** (alpha + 1.0) - lo ** (alpha + 1.0)) / (alpha + 1.0)

source_fraction = np.array([integral_power(a, b) for a, b in groups])
source_fraction /= source_fraction.sum()

# Verner cross sections and source-weighted group averages.
def verner_sigma(species: str, energy: float) -> float:
    params = {
        "HI": (13.60, 0.4298, 5.475e4, 32.88, 2.963, 0.0, 0.0, 0.0),
        "HeI": (24.59, 13.61, 949.2, 1.469, 3.188, 2.039, 0.4434, 2.136),
        "HeII": (54.42, 1.720, 1.369e4, 32.88, 2.963, 0.0, 0.0, 0.0),
    }
    eth, e0, sigma0, ya, pp, yw, y0, y1 = params[species]
    if energy < eth:
        return 0.0
    x = energy / e0 - y0
    y = math.sqrt(x*x + y1*y1)
    return 1e-18 * sigma0 * ((x-1.0)**2 + yw*yw) * y**(0.5*pp-5.5) / (1.0 + math.sqrt(y/ya))**pp

def group_average_sigma_and_excess(species: str, threshold: float) -> tuple[np.ndarray, np.ndarray]:
    sigmas=[]; excess=[]
    for lo,hi in groups:
        norm=quad(lambda E: E**SPECTRAL_ALPHA, lo, hi, epsabs=0.0, epsrel=1e-10)[0]
        sig=quad(lambda E: E**SPECTRAL_ALPHA*verner_sigma(species,E), lo, hi, epsabs=0.0, epsrel=1e-8)[0]/norm
        if sig>0.0:
            heat=quad(lambda E: E**SPECTRAL_ALPHA*verner_sigma(species,E)*max(E-threshold,0.0), lo, hi, epsabs=0.0, epsrel=1e-8)[0]/(norm*sig)
        else:
            heat=0.0
        sigmas.append(sig); excess.append(heat)
    return np.asarray(sigmas), np.asarray(excess)

sigma_HI, excess_HI = group_average_sigma_and_excess("HI", 13.60)
sigma_HeI, excess_HeI = group_average_sigma_and_excess("HeI", 24.59)
sigma_HeII, excess_HeII = group_average_sigma_and_excess("HeII", 54.42)

# Build P0.4 raw-table global opacity versus Gamma_12 at z=5.5.
energies = np.array([13.6, 14.48, 16.7, 20.05, 25.5, 39.5])
cols = ["z", "zre", "gamma", "density"] + [f"mfp_{e:g}" for e in energies]
df = pd.DataFrame(raw, columns=cols)
df = df[np.isclose(df["z"], ZCOS)].copy()

map55 = density_map[np.isclose(density_map["z"], ZCOS)].sort_values("density_sigma")
density_weights = map55["effective_GH_weight"].to_numpy()
raw_densities = np.array([-1.73, 0.0, 1.73])

Qmid, Qdz = 6.58, 1.63
def Q(z: float) -> float:
    return 0.5 * (1.0 - math.tanh((z - Qmid) / Qdz))

def zre_weights(nodes: np.ndarray) -> dict[float, float]:
    nodes = np.array(sorted(nodes), dtype=float)
    mids = 0.5 * (nodes[:-1] + nodes[1:])
    lo = np.r_[ZCOS, mids]
    hi = np.r_[mids, np.inf]
    masses = np.array([Q(a) - (0.0 if np.isinf(b) else Q(b)) for a, b in zip(lo, hi)])
    masses = np.maximum(masses, 0.0)
    masses /= masses.sum()
    return dict(zip(nodes, masses))

opacity_rows = []
for gamma in sorted(df["gamma"].unique()):
    gamma_df = df[np.isclose(df["gamma"], gamma)]
    complete_zre = []
    kappa_by_zre = {}
    for zre in sorted(gamma_df["zre"].unique()):
        if zre < ZCOS:
            continue
        sub = gamma_df[np.isclose(gamma_df["zre"], zre)]
        vectors = []
        valid = True
        for dens in raw_densities:
            row = sub[np.isclose(sub["density"], dens)]
            if len(row) != 1:
                valid = False
                break
            vectors.append(row.iloc[0, 4:].to_numpy(dtype=float))
        if valid:
            vectors = np.asarray(vectors)
            kappa_by_zre[zre] = np.sum(density_weights[:, None] / vectors, axis=0)
            complete_zre.append(zre)
    if not complete_zre:
        continue
    zw = zre_weights(np.asarray(complete_zre))
    kappa = sum(zw[zr] * kappa_by_zre[zr] for zr in complete_zre)
    opacity_rows.append([gamma, *kappa])

opacity = np.asarray(opacity_rows)
if len(opacity) < 5:
    raise RuntimeError(f"Insufficient opacity nodes: {len(opacity)}")

# Discrete source-spectrum energy weights inside G1 and G2a.
def discrete_weights(es: np.ndarray) -> np.ndarray:
    w = es ** SPECTRAL_ALPHA
    return w / w.sum()

w1 = discrete_weights(energies[:4])
w2 = discrete_weights(energies[4:])
kappa_g1 = opacity[:, 1:5] @ w1
kappa_g2 = opacity[:, 5:7] @ w2

logg = np.log(opacity[:, 0])
pchip1 = PchipInterpolator(logg, np.log(kappa_g1), extrapolate=True)
pchip2 = PchipInterpolator(logg, np.log(kappa_g2), extrapolate=True)
pchip_coeffs = np.stack([pchip1.c, pchip2.c])
fit1 = np.exp(pchip1(logg))
fit2 = np.exp(pchip2(logg))
fit_rel = np.concatenate([fit1/kappa_g1-1.0, fit2/kappa_g2-1.0])

pd.DataFrame({
    "Gamma12": opacity[:,0],
    "kappa_G1_cMpc_inv": kappa_g1,
    "kappa_G2a_cMpc_inv": kappa_g2,
    "fit_G1_cMpc_inv": fit1,
    "fit_G2a_cMpc_inv": fit2,
}).to_csv(STAGE / "data" / "opacity_gamma_fit_nodes.csv", index=False)

# Current target physical state.
sigma_eff = float(source_fraction @ sigma_HI)
N_total = GAMMA_TARGET * MPC_CM**3 / (C_LIGHT * (1.0 + ZCOS)**3 * sigma_eff)
N_target = source_fraction * N_total
x_target = np.array([fixed["xHII"], fixed["xHeII"], fixed["xHeIII"]], dtype=float)
T_target = float(fixed["T_K"])
ne_target = nH*x_target[0] + nHe*(x_target[1] + 2.0*x_target[2])
npart_target = nH + nHe + ne_target
u_target = 1.5 * npart_target * KB_ERG * T_target

# Redshift group coefficients for an E^-1.5 photon-number spectrum.
def redshift_coeff(lo: float, hi: float, alpha: float=SPECTRAL_ALPHA) -> float:
    return lo**(alpha+1.0) / integral_power(lo, hi, alpha)

red_coeff = np.array([redshift_coeff(a, b) for a, b in groups])

base_params = {
    "z_cos": jnp.array(ZCOS),
    "dt": jnp.array(DT),
    "Hubble": jnp.array(HUBBLE),
    "nH_phys": jnp.array(nH),
    "nHe_phys": jnp.array(nHe),
    "source_fraction": jnp.asarray(source_fraction),
    "redshift_coeff": jnp.asarray(red_coeff),
    "sigma_HI": jnp.asarray(sigma_HI),
    "sigma_HeI": jnp.asarray(sigma_HeI),
    "sigma_HeII": jnp.asarray(sigma_HeII),
    "log_kappa_knots": jnp.asarray(logg),
    "log_kappa_pchip_coeffs": jnp.asarray(pchip_coeffs),
    "sigma_ots_H24": jnp.array(verner_sigma("HI", 24.59)),
    "sigma_ots_HeI24": jnp.array(verner_sigma("HeI", 24.59)),
    "sigma_ots_H41": jnp.array(verner_sigma("HI", 40.8)),
    "sigma_ots_HeI41": jnp.array(verner_sigma("HeI", 40.8)),
    "sigma_ots_H54": jnp.array(verner_sigma("HI", 54.42)),
    "sigma_ots_HeI54": jnp.array(verner_sigma("HeI", 54.42)),
    "sigma_ots_HeII54": jnp.array(verner_sigma("HeII", 54.42)),
    "excess_HI_eV": jnp.asarray(excess_HI),
    "excess_HeI_eV": jnp.asarray(excess_HeI),
    "excess_HeII_eV": jnp.asarray(excess_HeII),
    # Temporary values for RHS evaluation.
    "N_prev": jnp.asarray(N_target),
    "x_prev": jnp.asarray(x_target),
    "u_prev": jnp.array(u_target),
    "scale_N": jnp.asarray(N_target),
    "scale_x": jnp.ones(3),
    "scale_u": jnp.array(u_target),
    "scale_gamma": jnp.array(GAMMA_TARGET),
}

z_target = transform_y_to_z(
    jnp.asarray(N_target),
    jnp.array(x_target[0]),
    jnp.array(x_target[1]),
    jnp.array(x_target[2]),
    jnp.array(u_target),
    jnp.array(GAMMA_TARGET),
)
state_target = {
    "N": jnp.asarray(N_target),
    "xHII": jnp.array(x_target[0]),
    "xHeI": jnp.array(1.0-x_target[1]-x_target[2]),
    "xHeII": jnp.array(x_target[1]),
    "xHeIII": jnp.array(x_target[2]),
    "u": jnp.array(u_target),
    "GammaHI": jnp.array(GAMMA_TARGET),
}
rhs = physical_rhs(state_target, jnp.array(EPS_TARGET), base_params)

N_prev = N_target - DT * np.asarray(rhs["N"])
x_prev = x_target - DT * np.asarray(rhs["x"])
u_prev = u_target - DT * float(rhs["u"])

if np.any(N_prev <= 0.0):
    raise RuntimeError(f"Nonpositive reconstructed previous photons: {N_prev}")
if not (0.0 < x_prev[0] < 1.0 and x_prev[1] > 0.0 and x_prev[2] > 0.0 and x_prev[1]+x_prev[2] < 1.0):
    raise RuntimeError(f"Invalid reconstructed previous fractions: {x_prev}")
if u_prev <= 0.0:
    raise RuntimeError(f"Nonpositive reconstructed previous energy: {u_prev}")

params = {
    **base_params,
    "N_prev": jnp.asarray(N_prev),
    "x_prev": jnp.asarray(x_prev),
    "u_prev": jnp.array(u_prev),
    "scale_N": jnp.maximum(jnp.asarray(N_target), 1.0),
    "scale_x": jnp.ones(3),
    "scale_u": jnp.array(u_target),
    "scale_gamma": jnp.array(GAMMA_TARGET),
}

# Serialize only plain arrays/scalars.
plain_params = {}
for key, value in params.items():
    arr = np.asarray(value)
    plain_params[key] = float(arr) if arr.ndim == 0 else arr.tolist()

fixture = {
    "provenance": "POST_INTERRUPTION_RECONSTRUCTED_FIXTURE",
    "known_state_role": "B1_CURRENT_STATE_REGRESSION_TARGET_ONLY",
    "previous_state_role": "RECONSTRUCTED_FROM_B2A_RHS",
    "z_cos": ZCOS,
    "dt_seconds": DT,
    "dt_Myr": fixed["dt_Myr"],
    "emissivity_target_s_cMpc3": EPS_TARGET,
    "log_emissivity_target": math.log(EPS_TARGET),
    "target": {
        "N_gamma_cMpc3": N_target.tolist(),
        "xHII": x_target[0],
        "xHeII": x_target[1],
        "xHeIII": x_target[2],
        "u_th_erg_cm3": u_target,
        "Gamma_HI_s_inv": GAMMA_TARGET,
        "T_K": T_target,
        "Z": np.asarray(z_target).tolist(),
    },
    "previous_reconstructed": {
        "N_gamma_cMpc3": N_prev.tolist(),
        "xHII": x_prev[0],
        "xHeII": x_prev[1],
        "xHeIII": x_prev[2],
        "u_th_erg_cm3": u_prev,
    },
    "regression_spectrum": {
        "photon_number_power_law_index": SPECTRAL_ALPHA,
        "role": "SOFT_NUMERICAL_FIXTURE_NOT_SOURCE_CALIBRATION",
        "source_fraction": source_fraction.tolist(),
        "sigma_HI_cm2": sigma_HI.tolist(),
        "sigma_HeI_cm2": sigma_HeI.tolist(),
        "sigma_HeII_cm2": sigma_HeII.tolist(),
    },
    "opacity_fit": {
        "interpolation_convention": "PCHIP in log Gamma12 -> log kappa_cMpc_inv",
        "knots_log_Gamma12": logg.tolist(),
        "coefficients_scipy_pchip": pchip_coeffs.tolist(),
        "max_abs_relative_node_error": float(np.max(np.abs(fit_rel))),
        "Gamma12_nodes": opacity[:,0].tolist(),
    },
    "parameters": plain_params,
}
(STAGE / "checkpoints" / "known_state_fixture.json").write_text(
    json.dumps(fixture, indent=2), encoding="utf-8"
)

print(json.dumps({
    "target_N_min": float(N_target.min()),
    "previous_N_min": float(N_prev.min()),
    "target_x": x_target.tolist(),
    "previous_x": x_prev.tolist(),
    "target_u": u_target,
    "previous_u": u_prev,
    "opacity_fit_max_rel": float(np.max(np.abs(fit_rel))),
    "opacity_node_count": int(len(opacity)),
}, indent=2))
