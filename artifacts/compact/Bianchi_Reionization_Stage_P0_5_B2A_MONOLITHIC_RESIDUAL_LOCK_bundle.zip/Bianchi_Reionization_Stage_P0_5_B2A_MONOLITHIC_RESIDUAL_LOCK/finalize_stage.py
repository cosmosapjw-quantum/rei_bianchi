from __future__ import annotations

import datetime as dt
import hashlib
import json
import platform
import subprocess
import zipfile
from pathlib import Path

import pandas as pd

S=Path('/mnt/data/Bianchi_Reionization_Stage_P0_5_B2A_MONOLITHIC_RESIDUAL_LOCK')
OUT=Path('/mnt/data')

def sha(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

j=json.loads((S/'data/jacobian_test_results.json').read_text())
c=json.loads((S/'data/pseudo_arclength_summary.json').read_text())
fixture=json.loads((S/'checkpoints/known_state_fixture.json').read_text())
w=json.loads((S/'wolfram_validation_results.json').read_text())
input_lock=json.loads((S/'RECOVERY_INPUT_LOCK.json').read_text())
auditor=json.loads((S/'data/B1_reduced_fold_auditor.json').read_text())
now=dt.datetime.now(dt.timezone.utc).isoformat()

results={
 'stage':'P0.5-B2A-DURABLE-MONOLITHIC-RESIDUAL-LOCK',
 'verdict':'DURABLE_PASS_WITH_RECONSTRUCTED_FIXTURE_SCOPE',
 'provenance':'POST_INTERRUPTION_RECONSTRUCTION',
 'input_hashes':{x['label']:x['sha256'] for x in input_lock['inputs']},
 'residual':{
   'physical_unknowns':['N_gamma_1','N_gamma_2','N_gamma_3','N_gamma_4','x_HII','x_HeII','x_HeIII','u_th','Gamma_HI'],
   'unconstrained_unknowns':['log_N1','log_N2','log_N3','log_N4','logit_xHII','helium_logit_HeII','helium_logit_HeIII','log_u_th','log_Gamma_HI'],
   'component_count':9,
   'scaled_residual_inf':j['solved_scaled_residual_inf'],
   'known_state_rms_relative_regression':j['known_state_rms_relative_regression'],
   'transform_roundtrip_norm':j['transform_roundtrip_norm'],
 },
 'derivatives':{
   'JAX_version':json.loads((S/'state/RUNTIME_ENVIRONMENT.json').read_text())['jax'],
   'AD_FD_best_step':j['AD_FD']['best_step'],
   'AD_FD_relative_discrepancy':j['AD_FD']['best_relative_discrepancy'],
   'JVP_max_relative_discrepancy':j['JVP_max_relative_discrepancy'],
   'Jacobian_minimum_singular_value':j['Jacobian']['minimum_singular_value'],
   'Jacobian_condition_number':j['Jacobian']['condition_number'],
 },
 'continuation':c,
 'wolfram':w,
 'PETSc':json.loads((S/'src/petsc_adapter_status.json').read_text()),
 'fixture_scope':{
   'known_state_role':fixture['known_state_role'],
   'previous_state_role':fixture['previous_state_role'],
   'regression_spectrum':fixture['regression_spectrum'],
   'opacity_interpolation':fixture['opacity_fit']['interpolation_convention'],
   'opacity_node_error':fixture['opacity_fit']['max_abs_relative_node_error'],
 },
 'B1_reduced_fold_auditor':auditor,
 'forbidden_work_confirmed_not_started':['source population/f_esc calibration','maintenance partition fitting','Bianchi geometry extension'],
 'next_gate':'P0.5-B2B-PHYSICAL-BRANCH-AND-MAINTENANCE-LOCK'
}
(S/'results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False),encoding='utf-8')

readme=f'''# Stage P0.5-B2A — Durable monolithic residual lock

## Verdict

\[
\boxed{{\text{{P0.5-B2A}}=\text{{DURABLE PASS WITH RECONSTRUCTED-FIXTURE SCOPE}}}}
\]

This is the first P0.5-B2 artifact created after the runtime interruption.
No transcript-only B2 result was inherited.

## What is durable now

- the four canonical input bundle hashes are re-verified and copied inside
  the stage;
- positivity-preserving transformed variables are implemented;
- a 9-component monolithic residual is executable;
- the B1 current state is reproduced as a regression target;
- the previous timestep state is explicitly labelled as reconstructed from
  the new B2A RHS;
- JAX Jacobian, central finite differences and JVP tests pass;
- a custom bordered predictor-corrector pseudo-arclength branch was executed;
- a PETSc `SNESNEWTONAL` C adapter is scaffolded without making PETSc a blocker;
- Wolfram independently verifies the transforms, residual count and OTS
  nucleus conservation.

## Numerical gates

| gate | result |
|---|---:|
| solved scaled residual | {j['solved_scaled_residual_inf']:.3e} |
| AD vs central FD Jacobian | {j['AD_FD']['best_relative_discrepancy']:.3e} |
| maximum JVP discrepancy | {j['JVP_max_relative_discrepancy']:.3e} |
| known-state RMS relative regression | {j['known_state_rms_relative_regression']:.3e} |
| transform round-trip norm | {j['transform_roundtrip_norm']:.3e} |
| minimum Jacobian singular value | {j['Jacobian']['minimum_singular_value']:.3e} |
| Jacobian condition number | {j['Jacobian']['condition_number']:.3e} |

The derivative acceptance gates were

\[
\|F\|_\infty<10^{{-10}},\qquad
\epsilon_{{\rm AD/FD}}<10^{{-7}},\qquad
\epsilon_{{\rm JVP}}<10^{{-10}}.
\]

All pass.

## Continuation result

The custom continuation contains {c['point_count']} points over

\[
{c['eta_range'][0]:.3f}\le
\eta=\log(\epsilon/\epsilon_\star)
\le {c['eta_range'][1]:.3f}.
\]

Its maximum residual is {c['max_residual_inf']:.3e}, the minimum fraction
margin is {c['minimum_fraction_margin']:.3e}, and the minimum Jacobian
singular value is {c['minimum_singular_J']:.3e}. No fold was detected in
this local reconstructed model.

This **does not refute or inherit** the B1 reduced-fold auditor. The residual
and previous-state construction are different; see
`data/B1_reduced_fold_auditor.json`.

## Critical fixture qualification

The B1 state was durable, but the previous timestep state and source-group
spectrum were not. B2A therefore reconstructed the previous state from the
new RHS and used a deliberately soft numerical spectrum

\[
dN/dE\propto E^{{-4}}.
\]

This is labelled `SOFT_NUMERICAL_FIXTURE_NOT_SOURCE_CALIBRATION`. It cannot be
used as an astrophysical source prior or reionization prediction.

The low-energy opacity uses PCHIP interpolation of P0.4 raw-table
`PUBLIC_REPO_EXACT` opacity versus \(\Gamma_{{12}}\), reproducing all 12
stored nodes to {fixture['opacity_fit']['max_abs_relative_node_error']:.1e}.

## PETSc status

`petsc4py`/PETSc is absent in the current runtime. The official
`SNESNEWTONAL` callback structure is provided in
`src/petsc_snesnewtonal_adapter.c`; it was not compiled or presented as an
executed result. The JAX/SciPy continuation is the executed reference.

## Scope boundary

This stage intentionally did **not** start:

- source population or escape-fraction calibration;
- maintenance/unresolved/front fitting;
- Bianchi I/V/II transport.

The next stage must replace the reconstructed regression fixture with a
durable physical previous-state/source-history input before treating branch
geometry as scientific.
'''
(S/'00_READ_FIRST.md').write_text(readme,encoding='utf-8')

ledger=f'''# B2A state ledger

| item | provenance state | evidence |
|---|---|---|
| Canonical input hashes | DURABLE_VERIFIED | `RECOVERY_INPUT_LOCK.json` |
| 9-component residual code | RECONSTRUCTED | `src/monolithic_model.py` |
| B1 current state | DURABLE_VERIFIED input | `inputs/extracted_P0_5_B1/.../p05_fixed_z_result.json` |
| Previous timestep state | RECONSTRUCTED | `checkpoints/known_state_fixture.json` |
| Soft E^-4 spectrum | RECONSTRUCTED numerical fixture | `checkpoints/known_state_fixture.json` |
| Residual/Jacobian/JVP gates | DURABLE_VERIFIED post-reconstruction | `data/jacobian_test_results.json` |
| Custom pseudo-arclength | DURABLE_VERIFIED post-reconstruction | `data/pseudo_arclength_branch.csv` |
| B1 reduced fold | AUDITOR_ONLY | `data/B1_reduced_fold_auditor.json` |
| PETSc adapter | IMPLEMENTED_NOT_COMPILED | `src/petsc_adapter_status.json` |
| Wolfram checks | DURABLE_VERIFIED post-reconstruction | `wolfram_validation_results.json` |
| Source/f_esc calibration | NOT_STARTED | forbidden scope |
| Maintenance partition fitting | NOT_STARTED | forbidden scope |
| Bianchi geometry extension | NOT_STARTED | forbidden scope |
'''
(S/'STATE_LEDGER.md').write_text(ledger,encoding='utf-8')

next_prompt='''@Web+Wolfram Stage P0.5-B2B-PHYSICAL-BRANCH-AND-MAINTENANCE-LOCK를 실행해줘.

B2A의 durable monolithic residual/JAX Jacobian/custom continuation을 정본으로
유지하되, B2A의 reconstructed previous state와 E^-4 soft regression spectrum은
과학 입력으로 승격하지 마.

1. causal photon-reservoir history와 source spectrum을 durable physical input으로
   재구성하여 previous state를 forward evolution에서 생성하고, backward-fitted
   fixture를 교체해줘.
2. dt={0.05,0.025,0.0125,0.00625,0.003125} Myr 각각에서 full residual branch를
   추적하고 fold persistence, minimum singular value, positivity, dt->0 branch
   continuity를 검증해줘.
3. PETSc가 있는 환경에서는 SNESNEWTONAL adapter를 compile/run하여 JAX/SciPy
   branch와 비교하되, PETSc 부재를 blocker로 만들지 마.
4. branch lock 이후에만 full-OTS recombination maintenance를 이용해
   absorption=diffuse maintenance+unresolved sink partition을 물리적으로 다시
   구성하고 negative unresolved lane은 fail closed해줘.
5. source population/f_esc calibration과 Bianchi geometry는 아직 시작하지 마.
'''
(S/'NEXT_STAGE_PROMPT.md').write_text(next_prompt,encoding='utf-8')

# Final state and receipts.
state=json.loads((S/'STAGE_STATE.json').read_text())
state.update({
 'status':'COMPLETED',
 'verdict':results['verdict'],
 'current_substage':'FINALIZED',
 'last_update_utc':now,
 'completed_substages':list(dict.fromkeys(state['completed_substages']+['CUSTOM_PSEUDO_ARCLENGTH','PETSC_SCAFFOLD','WOLFRAM_VALIDATION','FINAL_VALIDATION','FINALIZATION'])),
 'known_open_gates':['physical previous-state/source-history fixture','dt-sequence physical branch lock','maintenance partition physics','PETSc crosscheck when dependency is available'],
})
state['scientific_claims'].append({'claim':'B2A durable residual lock passes within reconstructed numerical fixture scope','provenance':'RECONSTRUCTED_AND_NUMERICALLY_VALIDATED','evidence':'results.json'})
(S/'STAGE_STATE.json').write_text(json.dumps(state,indent=2),encoding='utf-8')

receipts=[
 {'receipt_id':'B2A-0003','utc':now,'substage':'CUSTOM_PSEUDO_ARCLENGTH','status':'PASS','outputs':['src/pseudo_arclength.py','data/pseudo_arclength_branch.csv','data/pseudo_arclength_summary.json']},
 {'receipt_id':'B2A-0004','utc':now,'substage':'PETSC_SCAFFOLD','status':'IMPLEMENTED_NOT_COMPILED','outputs':['src/petsc_snesnewtonal_adapter.c','src/petsc_adapter_status.json']},
 {'receipt_id':'B2A-0005','utc':now,'substage':'WOLFRAM_VALIDATION','status':'PASS','outputs':['wolfram_validation.wl','wolfram_validation_results.json']},
 {'receipt_id':'B2A-0006','utc':now,'substage':'FINAL_VALIDATION','status':'PASS','outputs':['tests/validate_stage.py','logs/final_validation.log']},
 {'receipt_id':'B2A-0007','utc':now,'substage':'FINALIZATION','status':'PASS','outputs':['00_READ_FIRST.md','results.json','STATE_LEDGER.md','NEXT_STAGE_PROMPT.md','MANIFEST.json','SHA256SUMS']},
]
with (S/'RUN_RECEIPTS.jsonl').open('a') as f:
 for r in receipts:f.write(json.dumps(r)+'\n')

# Final runtime snapshot.
env=json.loads((S/'state/RUNTIME_ENVIRONMENT.json').read_text())
env['finalized_utc']=now
env['final_process_snapshot']=subprocess.check_output(['bash','-lc','ps -eo pid,ppid,stat,etime,cmd --sort=pid'],text=True).splitlines()
(S/'state/RUNTIME_ENVIRONMENT.json').write_text(json.dumps(env,indent=2),encoding='utf-8')

# Final manifest and SHA sums.
entries=[]
for p in sorted(S.rglob('*')):
 if p.is_file() and p.name not in {'MANIFEST.json','SHA256SUMS'}:
  entries.append({'path':str(p.relative_to(S)),'size_bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns,'sha256':sha(p)})
manifest={'stage':state['stage'],'verdict':results['verdict'],'generated_utc':now,'file_count':len(entries),'files':entries}
(S/'MANIFEST.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
lines=[]
for p in sorted(S.rglob('*')):
 if p.is_file() and p.name!='SHA256SUMS':lines.append(f'{sha(p)}  {p.relative_to(S)}')
(S/'SHA256SUMS').write_text('\n'.join(lines)+'\n',encoding='utf-8')

# Validate once after final files, then bundle.
val=subprocess.run(['python',str(S/'tests/validate_stage.py')],capture_output=True,text=True,check=True)
(S/'logs/post_finalize_validation.log').write_text(val.stdout+val.stderr,encoding='utf-8')
# Refresh manifest to include post-final validation log.
entries=[]
for p in sorted(S.rglob('*')):
 if p.is_file() and p.name not in {'MANIFEST.json','SHA256SUMS'}:
  entries.append({'path':str(p.relative_to(S)),'size_bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns,'sha256':sha(p)})
manifest={'stage':state['stage'],'verdict':results['verdict'],'generated_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'file_count':len(entries),'files':entries}
(S/'MANIFEST.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
lines=[]
for p in sorted(S.rglob('*')):
 if p.is_file() and p.name!='SHA256SUMS':lines.append(f'{sha(p)}  {p.relative_to(S)}')
(S/'SHA256SUMS').write_text('\n'.join(lines)+'\n',encoding='utf-8')

bundle=OUT/'Bianchi_Reionization_Stage_P0_5_B2A_MONOLITHIC_RESIDUAL_LOCK_bundle.zip'
with zipfile.ZipFile(bundle,'w',compression=zipfile.ZIP_DEFLATED) as zf:
 for p in sorted(S.rglob('*')):
  if p.is_file():zf.write(p,arcname=f'{S.name}/{p.relative_to(S)}')

print(json.dumps({'verdict':results['verdict'],'file_count':len(entries),'bundle':str(bundle),'bundle_size':bundle.stat().st_size,'bundle_sha256':sha(bundle),'validation':val.stdout.strip()},indent=2))
