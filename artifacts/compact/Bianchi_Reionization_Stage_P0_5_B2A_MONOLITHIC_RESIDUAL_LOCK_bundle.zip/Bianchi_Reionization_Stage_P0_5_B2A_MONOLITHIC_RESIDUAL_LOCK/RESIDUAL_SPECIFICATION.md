# P0.5-B2A monolithic residual specification

## Provenance boundary

This residual is a **post-interruption reconstruction**. It inherits only the
four hash-locked input bundles in `RECOVERY_INPUT_LOCK.json`. No numerical
P0.5-B2 value from the transcript is used as a scientific premise.

The P0.5-B1 state at

\[
z=5.5,\qquad \Delta t=0.0125\ {\rm Myr}
\]

is a regression target only. The previous state was reconstructed by applying
the new B2A physical right-hand side backward over one step. It is labelled
`RECONSTRUCTED_FROM_B2A_RHS` in `checkpoints/known_state_fixture.json`.

## Physical conventions and dimensions

- metric convention inherited from the project: \((- + + +)\);
- all local chemistry is in the homogeneous baryon frame;
- \(c, k_B\) and physical units are retained;
- \(N_{\gamma,g}\): photons per comoving Mpc\(^3\);
- \(u_{\rm th}\): physical thermal energy density, erg cm\(^{-3}\);
- \(\Gamma\): s\(^{-1}\);
- \(\kappa\): comoving Mpc\(^{-1}\).

## Unconstrained variables

\[
Z=(z_{N_1},\ldots,z_{N_4},z_H,z_{\rm HeII},z_{\rm HeIII},z_u,z_\Gamma).
\]

The physical variables are

\[
N_{\gamma,g}=e^{z_{N_g}},\qquad
x_{\rm HII}=\sigma(z_H),
\]

\[
(x_{\rm HeI},x_{\rm HeII},x_{\rm HeIII})
=\operatorname{softmax}(0,z_{\rm HeII},z_{\rm HeIII}),
\]

\[
u_{\rm th}=e^{z_u},\qquad \Gamma_{\rm HI}=e^{z_\Gamma}.
\]

Hence positivity, hydrogen bounds and helium normalization are algebraic,
not enforced by clipping.

## Nine residual components

The scaled nonlinear system is

\[
\widehat F(Z;\epsilon,\Delta t)=0,
\]

with four photon residuals, one hydrogen residual, two helium residuals, one
thermal residual and one photoionization closure residual.

### Photon groups

For four UV groups,

\[
F_{\gamma,g}=N_{g}^{n+1}-N_g^n-
\Delta t\left[\epsilon f_g-(\chi_g+R_g)N_g+
R_{g+1}N_{g+1}\right],
\]

where the last term is absent in the highest group. The redshift coefficients
are the finite-volume boundary fluxes for the regression power-law spectrum.
The low-energy H I opacity is a PCHIP interpolation of the P0.4
`PUBLIC_REPO_EXACT` raw-table opacity versus \(\Gamma_{12}\). Explicit He I
and He II opacity is added only in energy groups where the corresponding
threshold is crossed.

### H/He chemistry

Primary photoionization and collisional ionization are combined with the
Friedrich-style full-OTS event vectors. The five population ordering is

\[
({\rm HI,HII,HeI,HeII,HeIII}).
\]

Every OTS event vector separately preserves H and He nuclei; this was checked
symbolically in Wolfram and is recorded in `wolfram_validation_results.json`.
The backward-Euler chemistry residuals are

\[
F_H=x_{\rm HII}^{n+1}-x_{\rm HII}^{n}-\Delta t\,\dot x_{\rm HII},
\]

\[
F_{\rm HeII}=x_{\rm HeII}^{n+1}-x_{\rm HeII}^{n}-\Delta t\,\dot x_{\rm HeII},
\]

\[
F_{\rm HeIII}=x_{\rm HeIII}^{n+1}-x_{\rm HeIII}^{n}-\Delta t\,\dot x_{\rm HeIII}.
\]

### Thermal internal energy

\[
T=\frac{2u_{\rm th}}{3k_B(n_H+n_{\rm He}+n_e)}.
\]

The thermal block contains photoheating, recombination cooling, collisional
excitation/ionization, free-free cooling and FLRW expansion work:

\[
F_u=u^{n+1}-u^n-\Delta t\,[\mathcal H-\Lambda-3Hp].
\]

### Gamma closure

\[
F_\Gamma=\Gamma_{\rm HI}-
\frac{c(1+z)^3}{{\rm Mpc}^3}
\sum_g \bar\sigma_{{\rm HI},g}N_{\gamma,g}.
\]

## Scaling

Photon residuals are divided by the target group populations, chemistry by
unit fraction scales, thermal energy by the target \(u_{\rm th}\), and the
photoionization closure by the target \(\Gamma_{\rm HI}\). The solver and
Jacobian tests operate on this dimensionless residual.

## Regression spectrum firewall

The known B1 state contains a very small He III fraction. A hard
\(dN/dE\propto E^{-1.5}\) reconstruction has no physical previous state over
the locked timestep. B2A therefore uses a deliberately soft numerical
fixture

\[
\frac{dN}{dE}\propto E^{-4},
\]

with group fractions recorded in the fixture JSON. This choice is explicitly
`SOFT_NUMERICAL_FIXTURE_NOT_SOURCE_CALIBRATION`. It may not be cited as an
astrophysical source model.

## Scope exclusions

This stage does not perform source-population or escape-fraction calibration,
maintenance-partition fitting, or any Bianchi geometry extension.
