ClearAll["Global`*"];

xh[t_] := 1/(1+Exp[-t]);
den[a_,b_] := 1+Exp[a]+Exp[b];
hei[a_,b_] := 1/den[a,b];
heii[a_,b_] := Exp[a]/den[a,b];
heiii[a_,b_] := Exp[b]/den[a,b];

transformChecks=Assuming[Element[{t,a,b},Reals],{
 FullSimplify[0<xh[t]<1],
 FullSimplify[hei[a,b]>0&&heii[a,b]>0&&heiii[a,b]>0],
 FullSimplify[hei[a,b]+heii[a,b]+heiii[a,b]-1],
 FullSimplify[D[xh[t],t]-xh[t](1-xh[t])]
}];

sj=FullSimplify[D[{hei[a,b],heii[a,b],heiii[a,b]},{{a,b}}],
 Assumptions->Element[{a,b},Reals]];

pp=24/25; ll=57/40; mm=737/1000;
ww=(ll-mm)+mm yy;
ahh=vv ww+(1-vv) ff zz;
ahee=vv mm (1-yy)+(1-vv) ff (1-zz);
ch={
 {1,-1,0,0,0},
 {-yy,yy,yy,-yy,0},
 {-pp,pp,1,-1,0},
 {-(1-y2a-y2b),1-y2a-y2b,-y2b,1+y2b-y2a,-1+y2a},
 {-1,1,0,1,-1},
 {-ahh,ahh,-ahee,1+ahee,-1}
};

<|
 "TransformChecks"->transformChecks,
 "SoftmaxJacobian"->sj,
 "SoftmaxJacobianColumnSums"->
  FullSimplify[Total[sj],Assumptions->Element[{a,b},Reals]],
 "StoichiometricNucleusResiduals"->
  FullSimplify[Table[{{1,1,0,0,0}.ch[[i]],
   {0,0,1,1,1}.ch[[i]]},{i,Length[ch]}]],
 "ResidualComponentCount"->4+1+2+1+1,
 "LogPositiveDerivatives"->{D[Exp[q],q],D[Exp[u],u],D[Exp[g],g]}
|>
