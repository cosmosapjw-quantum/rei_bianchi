# Web source lock for numerical APIs

Only primary official documentation was used.

## JAX

- Official JAX Autodiff Cookbook: `jax.jacfwd` and `jax.jacrev` compute full
  Jacobians; near-square Jacobians are suitable for `jacfwd`.
- Official JAX JVP documentation: `jax.jvp` computes Jacobian-vector products
  without materializing a separate derivative implementation.
- Official JAX test utilities document finite-difference gradient/JVP checks.

The runtime lock is in `state/RUNTIME_ENVIRONMENT.json`.

## PETSc

- `SNESNEWTONAL` is PETSc's Newton arc-length continuation solver.
- Official options include arc-length step size, continuation-step limits,
  load-parameter bounds, regularization and exact/normal corrections.
- `SNESNewtonALSetFunction` supplies the tangent-load callback.
- `SNESNewtonALGetLoadParameter` exposes the current load parameter inside
  residual and tangent-load callbacks.

`petsc4py` is absent in this runtime. PETSc is therefore a scaffolded
cross-check, not a blocker or an executed result.
