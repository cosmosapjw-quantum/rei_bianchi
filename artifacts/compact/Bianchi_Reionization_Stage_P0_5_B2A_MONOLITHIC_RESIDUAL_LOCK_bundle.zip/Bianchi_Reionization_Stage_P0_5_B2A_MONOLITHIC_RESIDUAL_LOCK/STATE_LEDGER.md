# B2A state ledger

| item | provenance state | evidence |
|---|---|---|
| Canonical input hashes | DURABLE_VERIFIED | `RECOVERY_INPUT_LOCK.json` |
| 9-component residual code | RECONSTRUCTED | `src/monolithic_model.py` |
| B1 current state | DURABLE_VERIFIED input | `inputs/extracted_P0_5_B1/.../p05_fixed_z_result.json` |
| Previous timestep state | RECONSTRUCTED | `checkpoints/known_state_fixture.json` |
| Soft E^-4 spectrum | RECONSTRUCTED numerical fixture | `checkpoints/known_state_fixture.json` |
| Residual/Jacobian/JVP gates | DURABLE_VERIFIED post-reconstruction | `data/jacobian_test_results.json` |
| Custom pseudo-arclength | DURABLE_VERIFIED post-reconstruction | `data/pseudo_arclength_branch.csv` |
| B1 reduced fold | AUDITOR_ONLY | `data/B1_reduced_fold_auditor.json` |
| PETSc adapter | IMPLEMENTED_NOT_COMPILED | `src/petsc_adapter_status.json` |
| Wolfram checks | DURABLE_VERIFIED post-reconstruction | `wolfram_validation_results.json` |
| Source/f_esc calibration | NOT_STARTED | forbidden scope |
| Maintenance partition fitting | NOT_STARTED | forbidden scope |
| Bianchi geometry extension | NOT_STARTED | forbidden scope |
