"""Validate all durable P0.5-B2A gates."""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

import pandas as pd

STAGE=Path(__file__).resolve().parents[1]
EXPECTED={
 "RECOVERY":"f5c09f162434523ea0a1e982215afcbf41a64dac81685c1eea8ba7c27b244c6f",
 "P0_5_B1":"275836168ea4b939b65386d59179d99c15672d1a67b768fd76e9cbe95a4275f9",
 "P0_4":"9a373b3f1a8ba87a495606a7b87285dca35930510861ac313adc8d3b8e983d4c",
 "CLOUDY_AUDIT":"ca07474b444be9a35b5816450b9c872bb70f22ffb0c67642ddb2295956107191",
}
lock=json.loads((STAGE/'RECOVERY_INPUT_LOCK.json').read_text())
actual={x['label']:x['sha256'] for x in lock['inputs']}
assert actual==EXPECTED,(actual,EXPECTED)

j=json.loads((STAGE/'data/jacobian_test_results.json').read_text())
assert j['overall_pass']
assert j['solved_scaled_residual_inf']<1e-10
assert j['AD_FD']['best_relative_discrepancy']<1e-7
assert j['JVP_max_relative_discrepancy']<1e-10

c=json.loads((STAGE/'data/pseudo_arclength_summary.json').read_text())
assert c['max_residual_inf']<1e-9
assert c['minimum_fraction_margin']>0
branch=pd.read_csv(STAGE/'data/pseudo_arclength_branch.csv')
assert branch['residual_inf'].max()<1e-9
assert branch['min_fraction'].min()>0

w=json.loads((STAGE/'wolfram_validation_results.json').read_text())
assert w['status']=='PASS' and w['ResidualComponentCount']==9
assert all(pair==[0,0] for pair in w['StoichiometricNucleusResiduals'])

p=json.loads((STAGE/'src/petsc_adapter_status.json').read_text())
assert p['status']=='IMPLEMENTED_NOT_COMPILED_PETSC_UNAVAILABLE'

for source in ['src/monolithic_model.py','src/build_fixture.py','src/pseudo_arclength.py','tests/run_b2a_tests.py']:
 subprocess.run([sys.executable,'-m','py_compile',str(STAGE/source)],check=True)

print('P0.5-B2A durable validation: PASS')
