"""B2A residual/Jacobian/JVP and known-state regression gates."""
from __future__ import annotations

import json
import math
from pathlib import Path
import sys

import jax
jax.config.update("jax_enable_x64", True)
import jax.numpy as jnp
import numpy as np
from scipy.optimize import root

STAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STAGE / "src"))
from monolithic_model import residual, physical_vector, transform_z_to_y, transform_y_to_z

fixture = json.loads((STAGE / "checkpoints" / "known_state_fixture.json").read_text())

def to_jax(v):
    return jnp.asarray(v, dtype=jnp.float64)

p = {k: to_jax(v) for k, v in fixture["parameters"].items()}
z_target = np.asarray(fixture["target"]["Z"], dtype=float)
logeps = float(fixture["log_emissivity_target"])

f = lambda z: residual(z, jnp.array(logeps), p)
jac = jax.jacfwd(f)

r_target = np.asarray(f(jnp.asarray(z_target)))

# Solve from a deterministic perturbation.
perturb = np.array([2e-3, -1e-3, 1.5e-3, -2e-3, 1e-3, -1e-3, 1.2e-3, -8e-4, 7e-4])
z0 = z_target + perturb
sol = root(
    lambda z: np.asarray(f(jnp.asarray(z)), dtype=float),
    z0,
    jac=lambda z: np.asarray(jac(jnp.asarray(z)), dtype=float),
    method="hybr",
    options={"xtol": 1e-11, "maxfev": 1000},
)
if not sol.success:
    raise RuntimeError(f"Root solve failed: {sol.message}")
z_star = sol.x
r_star = np.asarray(f(jnp.asarray(z_star)), dtype=float)
J_ad = np.asarray(jac(jnp.asarray(z_star)), dtype=float)

# Central finite-difference Jacobian, step scan. Select the best verified step.
def fd_jacobian(z: np.ndarray, h: float) -> np.ndarray:
    cols=[]
    for j in range(len(z)):
        dz=np.zeros_like(z); dz[j]=h
        cols.append((np.asarray(f(jnp.asarray(z+dz)))-np.asarray(f(jnp.asarray(z-dz))))/(2*h))
    return np.column_stack(cols)

fd_records=[]
best=None
for h in [1e-4,3e-5,1e-5,3e-6,1e-6,3e-7]:
    J_fd=fd_jacobian(z_star,h)
    rel=np.linalg.norm(J_ad-J_fd)/max(1.0,np.linalg.norm(J_ad))
    fd_records.append({"step":h,"relative_discrepancy":float(rel)})
    if best is None or rel<best[0]: best=(rel,h,J_fd)
fd_rel,fd_h,J_fd=best

# JVP consistency in three deterministic directions.
directions=[]
for k in range(3):
    v=np.sin(np.arange(1,10)*(k+1.37))
    v=v/np.linalg.norm(v)
    _,jvp=jax.jvp(f,(jnp.asarray(z_star),),(jnp.asarray(v),))
    direct=J_ad@v
    rel=np.linalg.norm(np.asarray(jvp)-direct)/max(1.0,np.linalg.norm(direct))
    directions.append({"index":k,"relative_discrepancy":float(rel)})

# Transform and physical regression.
state=transform_z_to_y(jnp.asarray(z_star))
y=np.asarray(physical_vector(jnp.asarray(z_star),p))
target_N=np.asarray(fixture["target"]["N_gamma_cMpc3"])
target_phys=np.r_[target_N,
                  fixture["target"]["xHII"],fixture["target"]["xHeII"],fixture["target"]["xHeIII"],
                  fixture["target"]["u_th_erg_cm3"],fixture["target"]["Gamma_HI_s_inv"]]
reg_rel=np.linalg.norm((y-target_phys)/np.maximum(np.abs(target_phys),1e-300))/math.sqrt(len(y))

z_round=np.asarray(transform_y_to_z(state["N"],state["xHII"],state["xHeII"],state["xHeIII"],state["u"],state["GammaHI"]))
roundtrip=np.linalg.norm(z_round-z_star)

he_sum=float(state["xHeI"]+state["xHeII"]+state["xHeIII"])
positivity={
 "minimum_photon":float(np.min(np.asarray(state["N"]))),
 "xHII":float(state["xHII"]),
 "xHeI":float(state["xHeI"]),
 "xHeII":float(state["xHeII"]),
 "xHeIII":float(state["xHeIII"]),
 "helium_sum":he_sum,
 "u_th":float(state["u"]),
 "GammaHI":float(state["GammaHI"]),
}

sv=np.linalg.svd(J_ad,compute_uv=False)
results={
 "stage":"P0.5-B2A",
 "target_scaled_residual_inf":float(np.max(np.abs(r_target))),
 "solved_scaled_residual_inf":float(np.max(np.abs(r_star))),
 "root_success":bool(sol.success),
 "root_nfev":int(sol.nfev),
 "root_njev":int(getattr(sol,"njev",-1)),
 "known_state_rms_relative_regression":float(reg_rel),
 "transform_roundtrip_norm":float(roundtrip),
 "AD_FD":{
   "best_step":float(fd_h),
   "best_relative_discrepancy":float(fd_rel),
   "scan":fd_records,
 },
 "JVP":directions,
 "JVP_max_relative_discrepancy":float(max(x["relative_discrepancy"] for x in directions)),
 "Jacobian":{
   "shape":list(J_ad.shape),
   "singular_values":sv.tolist(),
   "minimum_singular_value":float(sv[-1]),
   "condition_number":float(sv[0]/sv[-1]),
 },
 "positivity":positivity,
 "gates":{
   "scaled_residual_lt_1e-10":bool(np.max(np.abs(r_star))<1e-10),
   "AD_FD_lt_1e-7":bool(fd_rel<1e-7),
   "JVP_lt_1e-10":bool(max(x["relative_discrepancy"] for x in directions)<1e-10),
   "transform_roundtrip_lt_1e-10":bool(roundtrip<1e-10),
   "physical_constraints":bool(
      positivity["minimum_photon"]>0 and 0<positivity["xHII"]<1 and
      min(positivity["xHeI"],positivity["xHeII"],positivity["xHeIII"])>0 and
      abs(he_sum-1)<1e-14 and positivity["u_th"]>0 and positivity["GammaHI"]>0),
 },
 "solution_Z":z_star.tolist(),
 "solution_Y":y.tolist(),
}
results["overall_pass"]=all(results["gates"].values())

(STAGE/"data"/"jacobian_ad.npy").write_bytes(np.asarray(J_ad).tobytes())
np.savetxt(STAGE/"data"/"jacobian_ad.csv",J_ad,delimiter=",")
np.savetxt(STAGE/"data"/"jacobian_fd_best.csv",J_fd,delimiter=",")
(STAGE/"data"/"jacobian_test_results.json").write_text(json.dumps(results,indent=2),encoding="utf-8")
(STAGE/"checkpoints"/"known_state_solution.json").write_text(json.dumps({
  "provenance":"POST_INTERRUPTION_RECONSTRUCTED_SOLUTION",
  "log_emissivity":logeps,"Z":z_star.tolist(),"Y":y.tolist(),
  "scaled_residual_inf":results["solved_scaled_residual_inf"]},indent=2),encoding="utf-8")

print(json.dumps({
 "overall_pass":results["overall_pass"],
 "residual_inf":results["solved_scaled_residual_inf"],
 "AD_FD":fd_rel,
 "JVP_max":results["JVP_max_relative_discrepancy"],
 "known_state_rms_relative":reg_rel,
 "min_singular":results["Jacobian"]["minimum_singular_value"],
 "condition":results["Jacobian"]["condition_number"],
},indent=2))
if not results["overall_pass"]:
    raise SystemExit(2)
