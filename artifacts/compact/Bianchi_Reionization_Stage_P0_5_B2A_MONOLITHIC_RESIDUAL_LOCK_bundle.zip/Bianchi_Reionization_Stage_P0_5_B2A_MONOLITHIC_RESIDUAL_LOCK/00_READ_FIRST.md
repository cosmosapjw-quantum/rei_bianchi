# Stage P0.5-B2A — Durable monolithic residual lock

## Verdict

\[
\boxed{\text{P0.5-B2A}=\text{DURABLE PASS WITH RECONSTRUCTED-FIXTURE SCOPE}}
\]

This is the first P0.5-B2 artifact created after the runtime interruption.
No transcript-only B2 result was inherited.

## What is durable now

- the four canonical input bundle hashes are re-verified and copied inside
  the stage;
- positivity-preserving transformed variables are implemented;
- a 9-component monolithic residual is executable;
- the B1 current state is reproduced as a regression target;
- the previous timestep state is explicitly labelled as reconstructed from
  the new B2A RHS;
- JAX Jacobian, central finite differences and JVP tests pass;
- a custom bordered predictor-corrector pseudo-arclength branch was executed;
- a PETSc `SNESNEWTONAL` C adapter is scaffolded without making PETSc a blocker;
- Wolfram independently verifies the transforms, residual count and OTS
  nucleus conservation.

## Numerical gates

| gate | result |
|---|---:|
| solved scaled residual | 1.230e-14 |
| AD vs central FD Jacobian | 3.082e-10 |
| maximum JVP discrepancy | 9.382e-17 |
| known-state RMS relative regression | 6.809e-15 |
| transform round-trip norm | 9.026e-13 |
| minimum Jacobian singular value | 1.031e-04 |
| Jacobian condition number | 1.548e+04 |

The derivative acceptance gates were

\[
\|F\|_\infty<10^{-10},\qquad
\epsilon_{\rm AD/FD}<10^{-7},\qquad
\epsilon_{\rm JVP}<10^{-10}.
\]

All pass.

## Continuation result

The custom continuation contains 22 points over

\[
-0.170\le
\eta=\log(\epsilon/\epsilon_\star)
\le 0.170.
\]

Its maximum residual is \(2.201\times10^{-14}\), the minimum fraction
margin is \(9.074\times10^{-5}\), and the minimum Jacobian singular value is
\(1.031\times10^{-4}\). No fold was detected in this local reconstructed
model.

This **does not refute or inherit** the B1 reduced-fold auditor. The residual
and previous-state construction are different; see
`data/B1_reduced_fold_auditor.json`.

## Critical fixture qualification

The B1 state was durable, but the previous timestep state and source-group
spectrum were not. B2A therefore reconstructed the previous state from the
new RHS and used a deliberately soft numerical spectrum

\[
\frac{dN}{dE}\propto E^{-4}.
\]

This is labelled `SOFT_NUMERICAL_FIXTURE_NOT_SOURCE_CALIBRATION`. It cannot be
used as an astrophysical source prior or reionization prediction.

The low-energy opacity uses PCHIP interpolation of the P0.4 raw-table
`PUBLIC_REPO_EXACT` opacity versus \(\Gamma_{12}\), reproducing all 12 stored
nodes to \(4.4\times10^{-16}\).

## PETSc status

`petsc4py`/PETSc is absent in the current runtime. The official
`SNESNEWTONAL` callback structure is provided in
`src/petsc_snesnewtonal_adapter.c`; it was not compiled or presented as an
executed result. The JAX/SciPy continuation is the executed reference.

## Scope boundary

This stage intentionally did **not** start:

- source population or escape-fraction calibration;
- maintenance/unresolved/front fitting;
- Bianchi I/V/II transport.

The next stage must replace the reconstructed regression fixture with a
durable physical previous-state/source-history input before treating branch
geometry as scientific.
