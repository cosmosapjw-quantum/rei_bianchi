"""Validate the durable P0.5-B1 stage tables."""

from pathlib import Path
import json
import numpy as np
import pandas as pd

root = Path(__file__).resolve().parent
data = root / "data"

allocation = pd.read_csv(data / "photon_allocation_all_lanes.csv")
intervals = pd.read_csv(data / "causal_photon_interval_ledger.csv")
wrong = pd.read_csv(data / "gamma_mfp_local_source_audit.csv")
qmap = pd.read_csv(data / "qv_qm_mapping.csv")
continuation = json.loads((root / "continuation_record.json").read_text())

assert allocation.relative_full_ledger_residual.abs().max() < 1e-12
assert intervals.relative_ledger_residual.abs().max() < 1e-12
assert intervals.minimum_group_emission_rate.min() >= 0.0

primary = allocation[
    allocation.lane == "INSIDE_OUT_SELF_SHIELD_PRIMARY"
]
assert primary.f_front_of_absorptions.between(0.0, 1.0).all()
assert (qmap.Q_M_inside_out >= qmap.Q_V).all()
assert (qmap.Q_M_outside_in <= qmap.Q_V).all()
assert wrong.relative_error.min() > 0.0

fold = continuation["selected_reduced_fold"]
assert continuation["low_root_Gamma_HI_s_inv"] < fold["Gamma_HI_s_inv"]
assert fold["Gamma_HI_s_inv"] < continuation["high_root_Gamma_HI_s_inv"]

print("P0.5-B1 durable gates: PASS")
