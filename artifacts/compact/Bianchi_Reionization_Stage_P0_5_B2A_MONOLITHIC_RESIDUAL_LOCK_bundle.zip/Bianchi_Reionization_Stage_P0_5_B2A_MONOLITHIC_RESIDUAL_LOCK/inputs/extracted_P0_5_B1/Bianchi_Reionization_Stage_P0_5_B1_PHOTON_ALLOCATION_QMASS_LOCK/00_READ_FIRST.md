# Stage P0.5-B1 — Photon allocation and mass-weighted ionization lock

## Verdict

\[
oxed{	ext{P0.5-B1}=	ext{PARTIAL PASS}}
\]

The comoving photon ledger, emission/absorption firewall, \(Q_V/Q_M\)
separation, species-resolved front cost, allocation bounds, causal Green
inversion, and Cloudy discrepancy audit pass.

The gate is not complete because:

1. the SCRIPT/MHR \(Q_M\) closure is not topology-calibrated;
2. the inherited constant unresolved-sink partition disagrees with an
   independent recombination-maintenance estimate;
3. the durable P0.5-A/B bundle does not contain the monolithic nonlinear
   residual and Jacobian needed for a full pseudo-arclength continuation.

Therefore P0.5-C Bianchi I/V/II is not authorized.

## 1. Photon reservoir and Gamma-MFP inversion

For comoving photon numbers,

\[
rac{dN_g^c}{dt}+\Phi_{g-1/2}-\Phi_{g+1/2}
=
\dot N_{{m em},g}^c
-\dot N_{{m abs,ion},g}^c
-\dot N_{{m abs,front},g}^c.
\]

Internal group-boundary redshift fluxes telescope. The total ledger retains
only the outer spectral boundaries.

The local Gamma-MFP inversion measures an absorption proxy:

\[
\dot N_{m abs}^c
=
\Gamma_{m HI}\kappa/\sigma_{m eff}.
\]

The causal emission rate additionally contains photon storage and threshold
redshift loss:

\[
oxed{
\dot N_{m em}^c
=
\dot N_{m abs}^c
+rac{dN_\gamma^c}{dt}
+\dot N_{m red}^c.
}
\]

Treating the old absorption proxy directly as emission causes the next-step
Gamma error to range from **4.51% to 28.13%**. The causal Green inversion
reproduces the prescribed reservoir/Gamma history to numerical precision.
The largest interval photon-ledger residual is below
\(8	imes10^{-16}\).

## 2. Volume- and mass-weighted ionization

The primary topology lane uses an inside-out, self-shielding MHR/SCRIPT-style
conditional density interval:

\[
\Delta_{m low}<\Delta<\Delta_{m ss}.
\]

It is constrained to reproduce the supplied volume fraction \(Q_V\), while

\[
Q_M=\int_{m ionized}\Delta P_V(\Delta)\,d\Delta.
\]

Across the inherited \(4.8\le z\le6.0\) history,

\[
0.02246\le Q_M-Q_V\le0.11791
\]

for the inside-out primary lane. The outside-in diagnostic gives

\[
-0.37272\le Q_M-Q_V\le-0.34956.
\]

The equality \(Q_M=Q_V\) is retained only as a diagnostic limit.

The species-resolved front cost is

\[
oxed{
\dot N_{m front}^c
=
n_H^c\dot Q_{{m HII},M}
+n_{m He}^c
\left(
\dot Q_{{m HeII},M}
+2\dot Q_{{m HeIII},M}
ight).
}
\]

## 3. Photon allocation

The full interval ledger is

\[
\dot N_{m em}
=
\dot N_{m store}
+\dot N_{m red}
+\dot N_{m maint}
+\dot N_{m unresolved}
+\dot N_{m front}.
\]

For the primary inside-out lane,

\[
0.05474\le
f_{m front}
=
rac{\dot N_{m front}}
{\dot N_{m front}+\dot N_{m maint}+\dot N_{m unresolved}}
\le0.34597.
\]

The front share of total causal emission is \(6.67\%\)–\(28.06\%\).
Storage is signed and ranges from \(-56.5\%\) to \(+54.6\%\) of the total
emission; a negative value means release from the ionizing photon reservoir,
not a negative physical sink.

The maximum full-ledger residual is \(8.1	imes10^{-16}\).

### Maintenance warning

The opacity-partition maintenance estimate is only \(0.689\) times the
independent recombination-maintenance estimate at the median. Across the
history, the relative difference ranges from \(-48.5\%\) to \(+109.3\%\).

Therefore the current \(f_{m front}\) is a **diagnostic reconstruction**,
not a calibrated physical allocation.

## 4. Implicit branch continuation

The recorded \(0.05\)-Myr roots are

\[
\Gamma_{m low}=2.26265	imes10^{-13}\ {m s^{-1}},
\qquad
ho_{m Picard}=0.780,
\]

\[
\Gamma_{m high}=3.44000	imes10^{-13}\ {m s^{-1}},
\qquad
ho_{m Picard}=1.233.
\]

A cubic-Hermite response matching both roots and both local Picard
derivatives has one interior reduced fold:

\[
\Gamma_{m fold}=2.79775	imes10^{-13}\ {m s^{-1}},
\]

\[
\dot N_{{m em,fold}}
=5.28624	imes10^{50}\ {m s^{-1}\,cMpc^{-3}}.
\]

The extrapolation-root ambiguity was removed by accepting only fold zeros
strictly between the two recorded roots.

This remains a reduced surrogate. Physical branch selection is the branch
continuous with the previous state and the \(dt	o0\) sequence—not simply the
branch on which Picard happens to converge.

## 5. Matched-input Cloudy audit

The Case-B lane agrees with Cloudy in neutral hydrogen to **1.03%** at fixed
\(10^4\) K, consistent with retaining SH95/PyNeb as the truth anchor.

The deliberately reduced full-atom comparator shows the missing physics
rather than fitting it away:

| lane | temperature error | H I error | He II error | heating error |
|---|---:|---:|---:|---:|
| hard power law | -2.40% | -43.8% | -32.2% | -36.1% |
| 80,000 K blackbody | -6.42% | -40.3% | -26.7% | -36.1% |

The temperature agreement is much better than the species/heating agreement.
The missing full diffuse field, detailed atomic structure, and omitted
heating/cooling channels must become an explicit correction/emulator table.

## 6. Final gate state

Passed:

- comoving group photon conservation;
- internal redshift-flux telescoping;
- emission/absorption distinction;
- causal Green inversion;
- \(Q_V/Q_M\) firewall;
- species-resolved front ledger;
- \(0\le f_{m front}\le1\);
- reduced continuation;
- Cloudy discrepancy audit.

Open:

- calibrated topology-to-\(Q_M\) closure;
- physical maintenance/unresolved/front partition;
- full-block pseudo-arclength continuation;
- source population and \(f_{m esc}\) calibration;
- predictive simultaneous reproduction of \(\Gamma_{m HI}(z)\) and \(Q_M(z)\).

\[
oxed{	ext{P0.5-C Bianchi I/V/II remains NOT AUTHORIZED.}}
\]
