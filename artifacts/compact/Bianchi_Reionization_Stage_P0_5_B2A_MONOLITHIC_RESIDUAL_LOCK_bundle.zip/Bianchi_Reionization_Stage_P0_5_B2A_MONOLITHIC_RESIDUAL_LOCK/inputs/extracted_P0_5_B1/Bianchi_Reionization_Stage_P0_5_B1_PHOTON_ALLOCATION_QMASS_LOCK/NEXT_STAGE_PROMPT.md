@Web+Wolfram Stage P0.5-B2-BRANCH-AND-SOURCE-CALIBRATION를 실행해줘.

P0.5-B1의 causal photon reservoir, Q_V/Q_M firewall, species-resolved
front ledger, full-OTS component firewall와 Cloudy matched-input
discrepancy table을 정본으로 유지한다.

1. P0.5-A/B의 monolithic nonlinear residual과 Jacobian을 durable executable로
   재구성하고, dt와 emissivity의 2-parameter pseudo-arclength continuation을
   실제 full block에서 수행해줘. Reduced Hermite continuation은 auditor로만
   유지해줘.

2. dt->0 previous-state branch를 physical branch로 고정하고 folds, branch
   switching, positivity, Jacobian minimum singular value와 timestep-halving
   convergence를 검증해줘.

3. SCRIPT/MHR inside-out Q_M closure를 alternative density/topology closures와
   비교하고 topology uncertainty를 Q_M, front cost, f_front에 전파해줘.

4. opacity-partition maintenance와 direct full-OTS recombination maintenance를
   일치시키도록 unresolved-sink/maintenance partition을 물리적으로
   재구성해줘. 임의 scalar correction으로 맞추지 마.

5. causal emission history를 UV luminosity function, xi_ion,
   source-population mixture와 연결하여 f_esc prior를 calibration해줘.

6. Cloudy hard-X-ray/thermal discrepancies를 species, heating and cooling
   channel별 correction table로 만들되, Case-B-valid lane에서는
   SH95/PyNeb를 truth anchor로 유지해줘.

7. predictive source model이 Gamma_HI(z), Q_M(z), T_b(z)를 동시에
   재현하고 photon ledger residual <1e-8, |Delta Q_M|<1e-4를 만족할 때만
   P0.5-C Bianchi I/V/II를 승인해줘.
