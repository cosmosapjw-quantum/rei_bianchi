ClearAll["Global`*"];

residuals = {
 dn1 + p0 - p1 - em1 + ai1 + af1,
 dn2 + p1 - p2 - em2 + ai2 + af2,
 dn3 + p2 - p3 - em3 + ai3 + af3,
 dn4 + p3 - p4 - em4 + ai4 + af4
};
totalResidual = Expand[Total[residuals]];

photonRule = photonN -> gamRate/(cc sigmaEff);
absorption = FullSimplify[cc kap photonN /. photonRule];
causalEmission = absorption + store + redloss;

qvOutside = 1/2 Erfc[-aa/Sqrt[2]];
qmOutside = 1/2 Erfc[-(aa-sig)/Sqrt[2]];
qvInside = 1/2 Erfc[aa/Sqrt[2]];
qmInside = 1/2 Erfc[(aa-sig)/Sqrt[2]];

frontCost = nHc dqHM + nHec (dqHeIIM + 2 dqHeIIIM);

K = {{k11,0},{k21,k22}};
aVec = {a1,a2};
eSol = FullSimplify[LinearSolve[K,aVec],
 Assumptions->{k11!=0,k22!=0}];

<|
 "GroupResiduals"->residuals,
 "TotalGroupResidual"->totalResidual,
 "TelescopingBoundaryPart"->p0-p4,
 "AbsorptionFromGammaMFP"->absorption,
 "CausalEmission"->causalEmission,
 "LocalSourceMissingTerms"->store+redloss,
 "QmOutsideOfQv"->
  FullSimplify[qmOutside /. aa->Sqrt[2] InverseErf[2 qv-1],
   Assumptions->{0<qv<1,sig>0}],
 "QmInsideOfQv"->
  FullSimplify[qmInside /. aa->Sqrt[2] InverseErfc[2 qv],
   Assumptions->{0<qv<1,sig>0}],
 "InsideNumeric"->
  N[{qvInside,qmInside,qmInside-qvInside}/.{aa->0.2,sig->0.7},14],
 "OutsideNumeric"->
  N[{qvOutside,qmOutside,qmOutside-qvOutside}/.{aa->0.2,sig->0.7},14],
 "SpeciesFrontCost"->frontCost,
 "CausalVolterraInverse"->eSol,
 "CausalVolterraResidual"->FullSimplify[K.eSol-aVec]
|>
