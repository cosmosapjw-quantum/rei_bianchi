ClearAll["Global`*"];
sigmaZ = 0.4370478501014517`16;
sNodes = {-Sqrt[3],0,Sqrt[3]};
dnlRoot = {-0.46315120789071496`16,-9.999976386452635`16*^-6,1.75527804804149`16};
dlin[x_] := -1.35`16 (1+x)^(-2/3) + 0.78785`16 (1+x)^(-0.58661)
             - 1.12431`16 (1+x)^(-1/2) + 1.68647`16;
rootResiduals = N[dlin /@ dnlRoot/sigmaZ - sNodes,14];
eta = 0.9637299671653621`16;
w = {1/6,2/3,1/6};
effRoot = eta w/(1+dnlRoot);

Clear[p,kd1,kd2,km1,km2];
meanLocalRatio = p km1/kd1 + (1-p) km2/kd2;
globalOpacityRatio = (p km1+(1-p)km2)/(p kd1+(1-p)kd2);

<|
 "RootInverseResiduals"->rootResiduals,
 "RootEffectiveWeights"->N[effRoot,14],
 "RootWeightSum"->N[Total[effRoot],14],
 "AveragingNoncommutativity"->
  Factor[Together[meanLocalRatio-globalOpacityRatio]],
 "SignReversalExample"->
  N[{meanLocalRatio-1,globalOpacityRatio-1}/.
   {p->1/2,kd1->2,km1->1,kd2->1/4,km2->1/2},14],
 "GHResiduals"->
  {FullSimplify[Total[w]-1],FullSimplify[w.sNodes],
   FullSimplify[w.(sNodes^2)-1]}
|>
