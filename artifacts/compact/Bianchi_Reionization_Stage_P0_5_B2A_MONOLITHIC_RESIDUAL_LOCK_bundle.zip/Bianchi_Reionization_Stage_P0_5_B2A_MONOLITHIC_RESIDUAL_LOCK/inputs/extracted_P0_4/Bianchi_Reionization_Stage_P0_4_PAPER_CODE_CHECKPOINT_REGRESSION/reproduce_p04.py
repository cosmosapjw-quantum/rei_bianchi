"""P0.4 paper-code-checkpoint regression.

Inputs
------
1. Zenodo environment_mfp_energies.txt
2. P0.2 sanitized checkpoint
3. MFP repository source lock at commit 245acdac...

The script deliberately separates:
- mean of local fractional MFP changes,
- global opacity averaging,
- uniform / z_re / Gamma / joint weights.

Colossus is pinned to 1.3.10 for release-time reproducibility. If the exact
wheel is unavailable, use the source-equivalent Eisenstein-Hu/sigma8/growth
port recorded in the bundle and compare its sigma(R,z) table before accepting
results.

Do not replace this workflow with a scalar -10% density correction.
"""
from __future__ import annotations

# The executable, tested numerical outputs are distributed in data/*.csv.
# A full rerun requires torch, numpy, pandas and scipy, plus the P0.2 checkpoint.
# The equations, exact source SHAs and dependency pin are in source_lock.json
# and colossus_pin.json.
#
# Core definitions:
#
#   dlin(dNL) =
#     -1.35(1+dNL)^(-2/3)
#     +0.78785(1+dNL)^(-0.58661)
#     -1.12431(1+dNL)^(-1/2)
#     +1.68647
#
#   R0 = Rcell*(3/(4*pi))^(1/3)
#   s = dlin/[growth(z)*sigma(R0,0)]
#
#   kappa_delta =
#     eta/sqrt(pi) Sum_i w_i kappa(s_i)/(1+dNL_i)
#
#   lambda_global =
#     Q(z) / Integral[-dQ/dzre * kappa_delta dzre]
#
# Evaluate both:
#   mean_env(lambda_delta/lambda_mean - 1)
# and
#   lambda_global_delta/lambda_global_mean - 1
# because they do not commute.
