# P0.3 D10 retirement notice

P0.3 introduced a diagnostic lane in which an effective density variance was
tuned so that the 13.6-eV, z=5--6 mean-density correction equalled -10%.

That lane is now retired:

\[
\boxed{\mathrm{D10}=\texttt{RETIRED\_CALIBRATION\_DIAGNOSTIC}}
\]

It must not be used in production opacity, chemistry, emissivity, uncertainty,
or plots presented as physical predictions.

Reasons:

1. The public repository already defines the density mapping and continuous
   eta normalization.
2. The raw RT table and release checkpoint agree extremely well on
   environment-level density response.
3. Density effects depend strongly on photon energy, redshift, Gamma and
   reionization-history weighting.
4. The mean of local fractional MFP changes is not the same statistic as the
   fractional change of the globally opacity-averaged MFP; the two may even
   have opposite signs.

Historical P0.3 D10 tables remain preserved solely for audit provenance.
The canonical lanes are MEAN_DENSITY, RAW_ZENODO_DIRECT and
PUBLIC_REPO_EXACT.
