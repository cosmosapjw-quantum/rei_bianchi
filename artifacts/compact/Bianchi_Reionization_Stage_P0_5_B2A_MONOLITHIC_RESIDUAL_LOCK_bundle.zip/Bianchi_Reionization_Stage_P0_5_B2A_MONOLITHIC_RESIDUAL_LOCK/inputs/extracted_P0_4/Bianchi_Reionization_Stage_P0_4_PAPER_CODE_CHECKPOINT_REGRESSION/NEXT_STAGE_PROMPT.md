@Web+Wolfram Stage P0.5-MONOLITHIC-OPACITY-FULLOTS-CHEMISTRY를 실행해줘.

P0.4의 정본 lane을 유지한다:
- MEAN_DENSITY baseline
- RAW_ZENODO_DIRECT auditor
- PUBLIC_REPO_EXACT primary
- D10은 RETIRED_CALIBRATION_DIAGNOSTIC이며 사용 금지

1. PUBLIC_REPO_EXACT의 energy/redshift-dependent kappa_g(z), Q(z),
   Gamma_12(z)와 R0-C/R1-A full-OTS H/He rate matrix를 하나의 implicit
   Picard/Rosenbrock loop에서 동시에 풀어줘.

2. unknowns를
   {n_gamma,g, x_HII, x_HeII, x_HeIII, T_b, Gamma_HI, emissivity}
   로 두고, photon-number, ionization-threshold energy, photoheating,
   recombination-photon OTS, cooling 및 expansion ledger를 모두 닫아줘.

3. density correction은 scalar -10%를 쓰지 말고 P0.4의 full
   E-z-history opacity table을 그대로 사용해줘. RAW_ZENODO_DIRECT와
   PUBLIC_REPO_EXACT 차이는 model discrepancy로 전파해줘.

4. Gamma measurement posterior와 evolving-Gamma history systematic을
   분리하고, emulator residual은 checkpoint-vs-raw cell table로
   conditional covariance를 구성해줘.

5. 39.5-54.4 eV 및 HeII threshold 이상은 Verner/Friedrich atomic lane을
   사용하고, Cloudy C25 hard-spectrum/thermal benchmark를 실제 실행해줘.

6. FLRW homogeneous limit에서 Durrer-type coupled ODE smoke test,
   C2-Ray H-only regression, full-OTS H/He conservation, positivity,
   stiff convergence를 검증해줘.

7. output으로 x_e^ion(z), T_b(z), Q(z), tau, Gamma_HI(z),
   dotN_gamma(z), kappa_g(z)와 uncertainty decomposition을 제공해줘.

P0.5가 닫힌 뒤 full-frequency G1/P1와 Stebbins moments의 monolithic
time-dependent Bianchi I/V/II audit로 복귀해줘.
