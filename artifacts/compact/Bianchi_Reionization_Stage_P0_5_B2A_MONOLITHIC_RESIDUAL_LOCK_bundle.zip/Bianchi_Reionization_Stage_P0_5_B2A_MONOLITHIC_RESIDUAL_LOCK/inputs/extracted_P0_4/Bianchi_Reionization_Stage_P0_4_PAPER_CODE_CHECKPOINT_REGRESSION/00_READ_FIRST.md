# Stage P0.4 — Paper / Public Code / Checkpoint Regression

## Verdict

\[
\boxed{\text{P0.4}=\text{CONDITIONAL PASS}}
\]

The public density mapping, the Zenodo raw RT table and the release checkpoint
are mutually consistent. The previous D10 fitted correction is retired.

The paper's “about 10%” density statement is reproducible as a representative
environment-level statistic and in selected redshift/energy/global-weight
combinations. It is **not** a universal 13.6-eV correction to the globally
opacity-averaged MFP.

## Main numerical result

The mean of local environment-level fractional MFP changes is

\[
-9.01\%\quad\text{(raw RT, 13.6 eV)}
\]

and

\[
-8.88\%\quad\text{(release checkpoint, 13.6 eV)}.
\]

Their environment-by-environment correlation is \(0.99875\).

However, the exact public continuous-\(z_{\rm re}\), central-\(\Gamma\),
opacity-first global calculation gives a 13.6-eV effect ranging from

\[
-3.64\%\ \text{to}\ +4.84\%
\]

over \(4.8\le z\le6.0\), with a mean of \(+1.11\%\).

At higher energy the global effect becomes more negative; the mean at
39.5 eV is \(-12.04\%\).

## Why both statements can be true

The following statistics do not commute:

\[
\left\langle\frac{\lambda_\delta}{\lambda_0}-1\right\rangle
\]

and

\[
\frac{\langle\kappa_0\rangle}{\langle\kappa_\delta\rangle}-1.
\]

Wolfram produced an explicit positive-input counterexample in which the first
is \(+25\%\) and the second is \(-33.3\%\). Thus a quoted “ten-percent MFP
effect” must always specify the energy, redshift, history weights and the
order in which opacity and ratios are averaged.

## Dependency lock

The MFP repository declares only `colossus>=1.3`; the original author
environment is not recorded. This bundle pins Colossus 1.3.10 as an inferred
release-time reproducibility dependency:

- wheel: `colossus-1.3.10-py2.py3-none-any.whl`
- SHA-256:
  `162a4fe67cfe3f48076b68655ad57adc0533d808365ad9a6eb8a215896fe85a8`

The exact wheel could not be downloaded in the sandbox. A source-equivalent
implementation of the public algorithm was used and its sigma/density/eta
table is distributed. This is a transparent limitation, not a claim that the
original training environment has been recovered.

## Canonical lanes

- `MEAN_DENSITY`: baseline
- `RAW_ZENODO_DIRECT`: raw simulation-table auditor
- `PUBLIC_REPO_EXACT`: production global-opacity lane
- `D10`: retired calibration diagnostic

## Remaining limitation

The public continuous calculation evaluates the checkpoint on a continuous
\(z_{\rm re}\) grid. The raw table is irregular; its continuous interpolation
requires some nearest-neighbour filling and is retained as diagnostic only.
The checkpoint/raw cell comparison shows the network is not the source of
the discrepancy.
