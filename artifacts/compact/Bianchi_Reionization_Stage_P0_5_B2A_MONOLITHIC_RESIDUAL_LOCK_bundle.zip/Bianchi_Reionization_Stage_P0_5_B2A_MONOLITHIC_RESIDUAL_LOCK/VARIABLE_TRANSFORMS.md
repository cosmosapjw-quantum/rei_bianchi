# Variable transforms and exact constraints

The transform is implemented in `src/monolithic_model.py`.

## Hydrogen

\[
x_{\rm HII}=\frac{1}{1+e^{-z_H}},\qquad
\frac{dx_{\rm HII}}{dz_H}=x_{\rm HII}(1-x_{\rm HII}).
\]

For finite real \(z_H\), \(0<x_{\rm HII}<1\).

## Helium

With \(D=1+e^a+e^b\),

\[
x_{\rm HeI}=D^{-1},\qquad
x_{\rm HeII}=e^aD^{-1},\qquad
x_{\rm HeIII}=e^bD^{-1}.
\]

All three fractions are positive and sum exactly to one. The columns of the
softmax Jacobian sum to zero, so infinitesimal variations preserve helium
normalization.

## Positive extensive variables

\[
N_{\gamma,g}=e^{z_{N_g}},\qquad
u_{\rm th}=e^{z_u},\qquad
\Gamma_{\rm HI}=e^{z_\Gamma}.
\]

Their derivatives with respect to the logarithmic coordinates equal the
physical variables themselves and are strictly positive.

Wolfram symbolic output is stored in `wolfram_validation_results.json`.
