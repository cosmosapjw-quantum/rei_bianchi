@Web+Wolfram Stage P0.5-B2B-PHYSICAL-BRANCH-AND-MAINTENANCE-LOCK를 실행해줘.

B2A의 durable monolithic residual/JAX Jacobian/custom continuation을 정본으로
유지하되, B2A의 reconstructed previous state와 E^-4 soft regression spectrum은
과학 입력으로 승격하지 마.

1. causal photon-reservoir history와 source spectrum을 durable physical input으로
   재구성하여 previous state를 forward evolution에서 생성하고, backward-fitted
   fixture를 교체해줘.
2. dt={0.05,0.025,0.0125,0.00625,0.003125} Myr 각각에서 full residual branch를
   추적하고 fold persistence, minimum singular value, positivity, dt->0 branch
   continuity를 검증해줘.
3. PETSc가 있는 환경에서는 SNESNEWTONAL adapter를 compile/run하여 JAX/SciPy
   branch와 비교하되, PETSc 부재를 blocker로 만들지 마.
4. branch lock 이후에만 full-OTS recombination maintenance를 이용해
   absorption=diffuse maintenance+unresolved sink partition을 물리적으로 다시
   구성하고 negative unresolved lane은 fail closed해줘.
5. source population/f_esc calibration과 Bianchi geometry는 아직 시작하지 마.
