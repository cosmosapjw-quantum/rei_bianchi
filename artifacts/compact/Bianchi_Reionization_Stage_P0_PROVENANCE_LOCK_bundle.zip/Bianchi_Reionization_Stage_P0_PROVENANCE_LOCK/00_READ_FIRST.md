# P0-PROVENANCE-LOCK — final audit

## Overall verdict

**CONDITIONAL PASS.**

The public pyC2Ray production chemistry is locked as an H-only C2-Ray
regression source. The Friedrich/Hui-Gnedin/Cox rate hierarchy and full-OTS
channel algebra are implemented and numerically validated in a separate
backend. The public MFP emulator implementation is pinned, but the paper
checkpoint, scalers, training table and held-out split are missing; no paper
performance is claimed locally.

Status totals are intentionally strict:

- `DESIGN_ONLY`: interfaces or missing-asset routes
- `IMPLEMENTED`: runnable code without an accepted validation gate
- `NUMERICALLY_VALIDATED`: local algebra/regression tests passed
- `PHYSICALLY_CALIBRATED`: **none in this bundle**

## Critical findings

1. **pyC2Ray is H-only in the audited production path.**
   It evolves one HII fraction at fixed input temperature and does not consume
   its optional heating tables in chemistry.

2. **The standalone H wrapper default is inconsistent.**
   The active code derives

   `colh0 = 1.3e-8*0.83/13.598^2 = 5.8354099424698882e-11`,

   while `solver/hydrogen.py` defaults to `1.3e-8`. The latter is
   `222.777836` times larger and changed the one-zone final ionized fraction
   by `2.160%` in the recorded
   fixture.

3. **The public Python Friedrich draft is not production code.**
   It contains an undefined `xHeI_old`, TODO/FIXME sections and malformed
   Hui-Gnedin denominator parenthesization. At `T=10^4 K`, the draft HII
   case-B expression is `1.877`
   times the source-locked formula.

4. **The MFP paper assets are missing.**
   The repository provides training/load/save code, but the paper checkpoint,
   fitted scaler values, training table and held-out sample identities were
   not present. The reported 1.6% median error is metadata only.

5. **The sink envelope is partial.**
   Numeric cross-calibration contains a SCRIPT/MHR fiducial proxy and the
   existing lognormal fallback. The MFP-emulator rows are explicit
   `MISSING_ASSET` records, not fabricated predictions.

## Cross-calibration scope

The table spans

- `z = 5,6,7`
- `Delta_cell = 0.5,1,3`
- `T = 1e4,2e4 K`
- `Gamma_12 = 0.03,0.3,3`
- `E = 13.6,25.5,39.5 eV`

The two implemented closures are grey 13.6-eV references repeated across
energy solely to keep a common grid. That energy treatment is labelled in
every row and is not a claim of frequency-resolved MFP physics.

The downstream `x_e`, `T_b` and `d tau/dz` columns are one-zone response
fixtures. They are numerically tested but not physically calibrated.

## MFP fail-closed rules

- `4 <= z <= z_re`
- `5 <= z_re <= 15`
- `0.03 <= Gamma_12 <= 30`
- `-sqrt(3) <= density_sigma <= sqrt(3)`
- `13.6 <= E <= 39.5 eV`
- checkpoint SHA-256 must match an approved digest
- no `Delta_cell -> density_sigma` conversion without a smoothing-variance
  calibration
- no explicit He opacity may be added while training species coverage is
  `UNKNOWN`
- `lambda_proper = lambda_comoving/(1+z_V)`

## Durable outputs

- source and commit inventory
- pyC2Ray implementation inventory
- formula-level provenance registry with per-formula SHA-256
- H/He rate and cooling tables
- rate comparison and one-zone regression
- full-OTS channel ledger
- MFP asset/domain audit and fail-closed wrapper
- sink cross-calibration and partial systematic envelope
- status ledger and recursive SHA-256 manifest

## Digest scope

Remote GitHub source files are identified by immutable commit and Git blob
SHA-1. Since raw remote bytes were not materialized by the connector, their
canonical local provenance records—not fictitious remote bytes—receive
SHA-256. See `DIGEST_SCOPE.md` and `provenance_records/INDEX.json`.
