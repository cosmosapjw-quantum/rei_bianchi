"""Fail-closed wrapper for the Tohfa et al. MFP emulator.

No prediction is allowed unless a paper checkpoint (including scalers) has
been supplied and its digest has been approved. The wrapper also blocks all
inputs outside the source-locked training domain.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import hashlib
import math


class MissingAssetError(RuntimeError):
    pass


class OutOfDomainError(ValueError):
    pass


class SpeciesCoverageUnknownError(RuntimeError):
    pass


@dataclass(frozen=True)
class Domain:
    z_min: float = 4.0
    z_re_min: float = 5.0
    z_re_max: float = 15.0
    gamma12_min: float = 0.03
    gamma12_max: float = 30.0
    density_sigma_min: float = -math.sqrt(3.0)
    density_sigma_max: float = math.sqrt(3.0)
    energy_eV_min: float = 13.6
    energy_eV_max: float = 39.5


class FailClosedMFP:
    def __init__(
        self,
        checkpoint: str | Path,
        approved_sha256: str,
        species_coverage: str = "UNKNOWN",
    ) -> None:
        self.checkpoint = Path(checkpoint)
        self.domain = Domain()
        self.species_coverage = species_coverage
        if not self.checkpoint.is_file():
            raise MissingAssetError(f"Checkpoint missing: {self.checkpoint}")
        digest = hashlib.sha256(self.checkpoint.read_bytes()).hexdigest()
        if digest != approved_sha256:
            raise MissingAssetError(
                f"Checkpoint SHA-256 mismatch: expected {approved_sha256}, got {digest}"
            )
        from mfp_emulator import MFPEmulator
        self.model = MFPEmulator()
        self.model.load(str(self.checkpoint))

    def validate(self, *, z, z_re, gamma12, density_sigma, energy_eV):
        d = self.domain
        if not (d.z_min <= z <= z_re):
            raise OutOfDomainError("Require 4 <= z <= z_re")
        if not (d.z_re_min <= z_re <= d.z_re_max):
            raise OutOfDomainError("z_re outside [5,15]")
        if not (d.gamma12_min <= gamma12 <= d.gamma12_max):
            raise OutOfDomainError("Gamma_12 outside [0.03,30]")
        if not (d.density_sigma_min <= density_sigma <= d.density_sigma_max):
            raise OutOfDomainError("density/sigma outside [-sqrt(3),sqrt(3)]")
        if not (d.energy_eV_min <= energy_eV <= d.energy_eV_max):
            raise OutOfDomainError("energy outside [13.6,39.5] eV")

    def predict_cMpc(self, **kwargs) -> float:
        self.validate(**kwargs)
        return self.model.predict(
            z=kwargs["z"],
            z_re=kwargs["z_re"],
            gamma=kwargs["gamma12"],
            density=kwargs["density_sigma"],
            energy_eV=kwargs["energy_eV"],
        )

    def opacity_proper_pMpc_inv(self, **kwargs) -> float:
        """kappa_proper = (1+z_V)/lambda_comoving."""
        lam_cMpc = self.predict_cMpc(**kwargs)
        return (1.0 + kwargs["z"]) / lam_cMpc

    def assert_additive_helium_safe(self) -> None:
        if self.species_coverage == "UNKNOWN":
            raise SpeciesCoverageUnknownError(
                "Training H/He opacity coverage is unknown; additive He opacity is blocked."
            )
