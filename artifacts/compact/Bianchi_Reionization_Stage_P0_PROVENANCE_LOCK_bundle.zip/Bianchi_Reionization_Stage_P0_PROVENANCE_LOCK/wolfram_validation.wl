ClearAll["Global`*"];
evToK = 11604.518121550082;
ethH = 13.598;
colActive = 1.3*10^-8*0.83/ethH^2;
colWrapper = 1.3*10^-8;

lambdaH[T_] := 315614/T;
alphaBHG[T_] :=
  2.753*10^-14 lambdaH[T]^1.5/
   (1+(lambdaH[T]/2.740)^0.407)^2.242;
alphaPy[T_] := 2.59*10^-13 (T/10^4)^(-0.7);

alphaADraft[T_] :=
  1.269*10^-13 (315608/T)^1.503/
   (((1+604613/T)^0.47)^1.923);
alphaAHG[T_] :=
  1.269*10^-13 lambdaH[T]^1.503/
   (1+(lambdaH[T]/0.522)^0.470)^1.923;

betaCoxHI[T_] := 5.835*10^-11 Sqrt[T] Exp[-157804/T];
betaHGHI[T_] := Module[{ll=lambdaH[T]},
  21.11 T^-1.5 Exp[-ll/2] ll^-1.089/
   (1+(ll/0.354)^0.874)^1.101
];

<|
 "ActiveDerivedColh0" -> colActive,
 "WrapperDefaultOverActive" -> colWrapper/colActive,
 "PyAlphaBOverHGAt1e4" -> alphaPy[10^4]/alphaBHG[10^4],
 "DraftAlphaAOverCorrectAt1e4" -> alphaADraft[10^4]/alphaAHG[10^4],
 "CoxHGSwitchRatioHIAt2e5" -> betaCoxHI[2*10^5]/betaHGHI[2*10^5]
|>
