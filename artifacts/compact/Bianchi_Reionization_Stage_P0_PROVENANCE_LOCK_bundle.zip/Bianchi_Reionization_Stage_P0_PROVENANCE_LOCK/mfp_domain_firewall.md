# MFP emulator domain and double-counting firewall

Pinned repository: `htohfa/mean-free-path-emulator` at
`245acdac81ac3a186cecc1bc399b213471a8b8ab`.

## Hard domain

- `4 <= z <= z_re`
- `5 <= z_re <= 15`
- `0.03 <= Gamma_12 <= 30`
- `-sqrt(3) <= density_sigma <= sqrt(3)`
- `13.6 <= E/eV <= 39.5`

The density variable is **not** the cell overdensity `Delta_b`; it is the
box-scale density contrast in units of the training-field standard deviation.
No `Delta_b -> density_sigma` conversion is accepted without a separately
calibrated smoothing-scale variance.

## Length conversion

The emulator returns comoving Mpc:

`lambda_proper_pMpc = lambda_comoving_cMpc / (1+z_V)`

and

`kappa_proper_pMpc^-1 = (1+z_V)/lambda_comoving_cMpc`.

`z_V` is the volume-scale-factor label, not a directional observed redshift.

## Helium firewall

The audited public repository did not include the paper training table or
metadata proving whether H I, He I, He II and thermal-feedback opacity were
included. Therefore the default species coverage is `UNKNOWN`. The code must
refuse to add explicit helium opacity to emulator opacity until a signed
coverage contract is supplied.

## Asset state

- implementation: `IMPLEMENTED`
- pretrained checkpoint: `MISSING`
- fitted scalers: `MISSING_WITH_CHECKPOINT`
- training table: `MISSING`
- held-out split/sample IDs: `MISSING`
- locally reproduced 1.6% median error: `NO`
