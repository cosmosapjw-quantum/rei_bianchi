# Digest-scope clarification

The GitHub connector returned immutable commit IDs, file paths, and Git blob
SHA-1 values, but it did not materialize every upstream raw file as local bytes.
This bundle therefore does **not** invent raw-upstream SHA-256 values.

For each upstream source file and commit, the bundle stores:

1. repository and immutable commit,
2. path and Git blob SHA-1 where available,
3. a canonical local provenance-record JSON,
4. SHA-256 of that canonical local record.

Formulae carry per-formula SHA-256 in `formula_registry.json`.
All generated numerical tables and reports carry file SHA-256 in the recursive
manifest and `SHA256SUMS`.
