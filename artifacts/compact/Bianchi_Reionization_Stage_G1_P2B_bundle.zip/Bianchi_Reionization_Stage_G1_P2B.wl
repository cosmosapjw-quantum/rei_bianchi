(* ::Package:: *)

(*
  Bianchi Reionization Stage G1/P2-B

  Canonical conventions
    metric signature (-,+,+,+)
    epsilon_123 = +1
    Q+iU <-> spin s=+2
    Q-iU <-> spin s=-2

  Verdict
    PASS as a resolved one-shot/macro collision map.
    FAIL as a conversion-at-every-microstep time integrator.

  Accepted macro map
    X_n^out =
      Pi_cone,affine [
        R_-^high
        Exp[h L_e]
        R_+^positive
        X_n^in
      ]

  Production revision
    Keep the paired/dual electron-energy state persistent during collision
    substeps. Perform fixed<->paired synchronization only at macro operator
    boundaries. A repeated map
        F_h = R_- Exp[h L_e] R_+
    is inconsistent at fixed energy resolution because
        Limit[h->0] F_h = R_- R_+ != I.
*)

ClearAll["Global`*"];

(* ------------------------------------------------------------------ *)
(* A. Positive number-energy remap                                    *)
(* ------------------------------------------------------------------ *)

NumberEnergyWeights[e0_, e1_, et_] := {
  (e1 - et)/(e1 - e0),
  (et - e0)/(e1 - e0)
};

PositiveNumberEnergyRemap[ygrid_List, delta_] := Module[
  {energy = Exp[ygrid], n = Length[ygrid], r, target, j, beta},
  r = ConstantArray[0., {n, n}];
  Do[
    target = Exp[ygrid[[i]] + delta];
    Which[
      target <= First[energy],
        r[[1, i]] = 1.,
      target >= Last[energy],
        r[[-1, i]] = 1.,
      True,
        j = Max[
          1,
          Min[n - 1, LengthWhile[energy, # <= target &]]
        ];
        beta =
          (target - energy[[j]])/
          (energy[[j + 1]] - energy[[j]]);
        r[[j, i]] = 1 - beta;
        r[[j + 1, i]] = beta
    ],
    {i, n}
  ];
  r
];

(* ------------------------------------------------------------------ *)
(* B. Cubic number-energy corrected high-order candidate              *)
(* ------------------------------------------------------------------ *)

HighOrderShiftMatrix[ygrid_List, delta_] := Module[
  {energy = Exp[ygrid], n = Length[ygrid],
   low, r, targetY, j, ids, ys, weights, amat, targetMoments},

  low = PositiveNumberEnergyRemap[ygrid, delta];
  r = ConstantArray[0., {n, n}];

  Do[
    targetY = ygrid[[i]] + delta;

    If[
      targetY <= ygrid[[2]] || targetY >= ygrid[[-2]],

      r[[All, i]] = low[[All, i]],

      j = Max[
        2,
        Min[n - 2, LengthWhile[ygrid, # <= targetY &]]
      ];
      ids = {j - 1, j, j + 1, j + 2};
      ys = ygrid[[ids]];

      weights = Table[
        Product[
          If[q == ell, 1,
            (targetY - ys[[q]])/(ys[[ell]] - ys[[q]])
          ],
          {q, 4}
        ],
        {ell, 4}
      ];

      amat = {
        ConstantArray[1., 4],
        energy[[ids]]
      };
      targetMoments = {1., Exp[targetY]};

      weights =
        weights +
        Transpose[amat].
          LinearSolve[
            amat.Transpose[amat],
            targetMoments - amat.weights
          ];

      r[[ids, i]] = weights
    ],
    {i, n}
  ];
  r
];

(* ------------------------------------------------------------------ *)
(* C. Local coherency cone and outer affine projection                *)
(* ------------------------------------------------------------------ *)

CoherencyConeProjectCell[v_List] := Module[
  {intensity = v[[1]], pol = v[[2 ;; 3]], radius},

  radius = Norm[pol];

  Which[
    radius <= intensity,
      v,

    radius <= -intensity,
      {0., 0., 0.},

    True,
      Join[
        {(radius + intensity)/2},
        ((radius + intensity)/(2 radius)) pol
      ]
  ]
];

CoherencyConeProject[z_List, nenergy_Integer] :=
  Flatten[
    CoherencyConeProjectCell /@ Partition[z, 3]
  ];

ScaledMomentMatrix[energy_List] := Module[
  {n = Length[energy], centre, scale, es, a},

  centre = (Max[energy] + Min[energy])/2;
  scale = (Max[energy] - Min[energy])/2;
  es = (energy - centre)/scale;

  a = ConstantArray[0., {6, 3 n}];

  Do[
    a[[1, 3 j - 2]] = 1;
    a[[2, 3 j - 1]] = 1;
    a[[3, 3 j]] = 1;

    a[[4, 3 j - 2]] = es[[j]];
    a[[5, 3 j - 1]] = es[[j]];
    a[[6, 3 j]] = es[[j]],
    {j, n}
  ];

  a
];

DykstraConeAffine[
  high_List,
  feasibleTarget_List,
  energy_List,
  tolerance_: 10^-10,
  maxIterations_: 10000
] := Module[
  {n = Length[energy], a, projectionMatrix,
   target, x, p, q, y, z, iter = 0,
   affineResidual = Infinity, coneMargin = -Infinity},

  a = ScaledMomentMatrix[energy];
  projectionMatrix =
    Transpose[a].Inverse[a.Transpose[a]];

  target = a.Flatten[feasibleTarget];
  x = Flatten[high];
  p = 0 x;
  q = 0 x;

  Do[
    iter = k;

    y =
      x + p +
      projectionMatrix.(target - a.(x + p));

    p = x + p - y;

    z = CoherencyConeProject[y + q, n];
    q = y + q - z;
    x = z;

    If[
      Mod[k, 20] == 0,

      affineResidual =
        Norm[a.x - target, Infinity];

      coneMargin =
        Min[
          (#[[1]] - Norm[#[[2 ;; 3]]]) &
            /@ Partition[x, 3]
        ];

      If[
        Max[affineResidual, -coneMargin] < tolerance,
        Break[]
      ]
    ],
    {k, maxIterations}
  ];

  <|
    "State" -> Partition[x, 3],
    "Iterations" -> iter,
    "ScaledAffineResidual" ->
      Norm[a.x - target, Infinity],
    "ConeMargin" ->
      Min[
        (#[[1]] - Norm[#[[2 ;; 3]]]) &
          /@ Partition[x, 3]
      ]
  |>
];

(* ------------------------------------------------------------------ *)
(* D. Macro dual-grid collision map                                   *)
(* ------------------------------------------------------------------ *)

(*
  For each direction p:
    D_p = E_e/E_n.

  Forward:
    X_e,p = D_p^3 R_p^+ S_p X_n,p.

  Paired collision:
    X_e^out = Exp[h L_e] X_e^in
  or its invariant/cone-preserving uniformization action.

  Reverse candidate:
    X_n,p^H =
      D_p^-3 R_p^H S_p^-1 X_e,p^out.

  Safe feasible reverse:
    X_n,p^L =
      D_p^-3 R_p^- S_p^-1 X_e,p^out.

  Final:
    X_n,p^out =
      Projection[
        X_n,p^H;
        local coherency cones,
        matrix number/energy moments of X_n,p^L
      ].
*)

(* ------------------------------------------------------------------ *)
(* E. Temporal-consistency diagnostic                                 *)
(* ------------------------------------------------------------------ *)

(*
  A conversion at every microstep defines
      F_h = R_- Exp[h L_e] R_+.

  Consistency requires F_0 = I.
  But
      F_0 = R_- R_+.

  For a periodic first-order fractional shift alpha:
      R_- R_+
        = I
          + alpha(1-alpha)(S_+ + S_- - 2 I).

  Therefore F_0 != I for every noninteger shift. The method does not
  possess a temporal order at fixed energy resolution when synchronization
  is repeated as h -> 0.
*)

FractionalRoundTripIdentity[
  n_Integer,
  alpha_
] := Module[{id, shiftPlus, shiftMinus, rplus, rminus},

  id = IdentityMatrix[n];

  shiftPlus = Table[
    If[j == Mod[i, n] + 1, 1, 0],
    {i, n}, {j, n}
  ];

  shiftMinus = Transpose[shiftPlus];

  rplus =
    (1 - alpha) id + alpha shiftPlus;

  rminus =
    (1 - alpha) id + alpha shiftMinus;

  FullSimplify[
    rminus.rplus -
    (
      id +
      alpha (1 - alpha)
        (shiftPlus + shiftMinus - 2 id)
    )
  ]
];

Print["Stage G1/P2-B consolidated definitions loaded."];
