# Stage G1/P2-B architecture notice

## What passed

A single dual-grid macro collision map passes once the energy grid is
resolved:

\[
X_n
\to
X_e
\to
e^{hL_e}X_e
\to
X_n^{\rm candidate}
\to
\Pi_{\rm cone,affine}X_n^{\rm candidate}.
\]

At \(N_y=64\), the paired closure error is \(0.836\%\), the outer
projection is inactive, the stiff paired stationarity residual is
\(5.25\times10^{-13}\), and the four-force ledger closes at roundoff.

## What failed

The same conversion cannot be inserted at every micro time step.

\[
F_h=R_-e^{hL_e}R_+
\]

has

\[
F_0=R_-R_+\ne I.
\]

It is therefore inconsistent under time-step refinement at fixed energy
resolution.

## Production correction

Maintain a persistent paired electron-energy state during collision
evolution. Synchronize with the normal transport state only at macro
operator boundaries, with one outer cone–affine projection after each
synchronization.
