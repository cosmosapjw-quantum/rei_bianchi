# Bianchi Reionization — Stage G1/P2-B

## Verdict

\[
\boxed{
\text{G1/P2-B}
=
\text{PASS as a resolved one-shot macro collision map}
}
\]

but

\[
\boxed{
\text{G1/P2-B}
=
\text{FAIL as a fixed↔paired conversion at every micro time step}.
}
\]

The dual/paired electron-energy collision representation solves the stiff
equilibrium failure found in P2-A. A single forward conversion, paired
uniformization, and single reverse conversion preserve photon number,
electron-frame energy, the coherency cone, the Thomson four-force
orthogonality, and the physical paired equilibrium.

However, the conversion pair is not an exact inverse on a finite energy
grid. Consequently the map

\[
F_h=R_-e^{hL_e}R_+
\]

does not approach the identity as \(h\to0\). It therefore cannot be
repeated at every refined microstep while retaining temporal consistency.

The production revision is to keep a persistent paired/dual collision
state and synchronize it with the normal transport state only at macro
operator boundaries.

---

## 1. Paired angular collision core

The finite-tilt test used

\[
\boldsymbol v_e=(0.31,-0.22,0.41),
\qquad
|\boldsymbol v_e|=0.55910643.
\]

The Doppler range was

\[
0.53742848\le \mathcal D_p\le1.81306072.
\]

The exact boost-direction round trip was zero at displayed precision, and
the Stokes screen maps were orthogonal to

\[
8.88\times10^{-16}.
\]

For the Lebedev-14 angular Thomson operator,

\[
\operatorname{rank}L_e=41,
\qquad
\dim\ker L_e=1.
\]

The left-invariant residual was

\[
9.65\times10^{-18}.
\]

For

\[
T_e=I+\frac{L_e}{\nu},
\qquad
\nu=\max_p\mathcal D_p,
\]

the fully polarized impulse scan gave

\[
\min\lambda_{\rm coh}(T_ex)
=
-2.78\times10^{-17},
\]

with zero failures below \(-10^{-12}\).

---

## 2. Positive one-shot macro map

The safe map used positive number-and-energy preserving forward and reverse
spectral deposition.

On \(N_y=40\), \(\Delta y=16/39\):

| \(h\) | paired closure error | number residual | electron-energy residual | ghost fraction | paired stationarity | four-force relative error |
|---:|---:|---:|---:|---:|---:|---:|
| 0.5 | \(4.7355\times10^{-2}\) | \(1.33\times10^{-15}\) | \(1.78\times10^{-15}\) | \(1.93\times10^{-5}\) | \(6.83\times10^{-1}\) | \(2.48\times10^{-16}\) |
| 5 | \(3.7011\times10^{-2}\) | \(4.44\times10^{-16}\) | \(1.33\times10^{-15}\) | \(3.77\times10^{-5}\) | \(1.02\times10^{-2}\) | \(4.22\times10^{-16}\) |
| 20 | \(3.6967\times10^{-2}\) | \(1.33\times10^{-15}\) | \(8.88\times10^{-16}\) | \(3.71\times10^{-5}\) | \(8.85\times10^{-5}\) | \(1.39\times10^{-16}\) |
| 100 | \(3.6966\times10^{-2}\) | \(4.44\times10^{-16}\) | \(4.44\times10^{-16}\) | \(3.71\times10^{-5}\) | \(5.25\times10^{-13}\) | \(4.33\times10^{-16}\) |

Thus:

- the stiff paired equilibrium is reached;
- the normal-grid ghost occupancy remains \(O(10^{-5})\), rather than
  growing to unity as in P2-A;
- the normal and paired four-force calculations agree at roundoff;
- photon number and electron energy are conserved.

This closes the stiff-equilibrium and stress-energy gates for a single
macro synchronization.

---

## 3. High-order reverse candidate

The forward conversion remained the safe positive map. The reverse
candidate used a cubic interpolation in \(y=\ln E\), followed by an exact
columnwise correction of photon number and energy.

| \(N_y\) | raw cone minimum | low-order closure | high-order closure | matrix-number residual |
|---:|---:|---:|---:|---:|
| 32 | \(-4.38\times10^{-6}\) | \(5.3588\times10^{-2}\) | \(2.9130\times10^{-2}\) | \(5.33\times10^{-15}\) |
| 48 | \(-2.55\times10^{-10}\) | \(2.6293\times10^{-2}\) | \(1.3860\times10^{-2}\) | \(1.78\times10^{-15}\) |
| 64 | \(-6.93\times10^{-16}\) | \(1.6290\times10^{-2}\) | \(8.3614\times10^{-3}\) | \(8.88\times10^{-15}\) |

The observed closure orders were

\[
1.7848,\qquad1.7249.
\]

The order is below the nominal cubic order because the forward conversion
remains the positive two-point map. Nevertheless, \(N_y=64\) is the first
tested grid to pass the one-percent paired-closure gate.

---

## 4. Outer cone–affine projection

At \(N_y=64\), the raw high-order cone violation was only

\[
-6.93\times10^{-16},
\]

so the projection was inactive and its correction norm was zero.

At the coarse \(N_y=32\) grid, the outer Dykstra projection changed the
candidate by only

\[
1.77\times10^{-6}
\]

relative norm, far below the one-percent fail-closed threshold, and
restored the cone margin to zero.

However, even after centring and scaling the energy constraint, the
coarse solve reached the iteration cap with

\[
\epsilon_{\rm affine,scaled}
=
9.28\times10^{-9},
\]

corresponding to an absolute physical-energy residual
\(1.77\times10^{-5}\). The coarse \(N_y=32\) projection is therefore not
accepted for production despite its tiny correction norm.

The resolved rule is:

\[
\boxed{
N_y=64:\ \text{projection inactive, PASS};
\qquad
N_y=32:\ \text{fail closed on affine solver tolerance}.
}
\]

---

## 5. Temporal-consistency obstruction

For a periodic first-order fractional shift,

\[
R_+
=
(1-\alpha)I+\alpha S_+,
\]

\[
R_-
=
(1-\alpha)I+\alpha S_-.
\]

Wolfram verified the exact identity

\[
\boxed{
R_-R_+
=
I+
\alpha(1-\alpha)
(S_++S_--2I).
}
\]

Therefore

\[
\lim_{h\to0}
R_-e^{hL_e}R_+
=
R_-R_+
\neq I
\]

for a noninteger shift.

For \(\alpha=0.37\),

\[
\|R_-R_+-I\|_\infty=0.9324,
\]

and the second-largest eigenvalue modulus is

\[
0.86345318.
\]

Repeated synchronization of a localized positive spectrum produced the
following \(L^1\) deviations from the initial state:

| synchronizations | \(L^1\) deviation |
|---:|---:|
| 1 | 0.2767 |
| 2 | 0.4074 |
| 4 | 0.6231 |
| 8 | 0.8943 |
| 16 | 1.1143 |
| 32 | 1.2027 |
| 64 | 1.2119 |

The state approaches the uniform discrete mode. This is the same
remapping diffusion that appeared as a ghost manifold in P2-A, now
revealed as a temporal-consistency obstruction.

Consequently there is no conventional temporal order at fixed
\(\Delta y\) if the fixed↔paired conversion is repeated under time-step
refinement.

---

## 6. Production architecture

The accepted structure is now:

\[
\boxed{
\text{persistent paired electron-energy collision state}
}
\]

together with a normal transport state.

Synchronization occurs only at macro operator boundaries:

1. one positive or matrix-cone-projected forward conversion;
2. paired invariant/cone-preserving uniformization;
3. one high-order reverse conversion;
4. one outer cone–affine projection.

The following are forbidden:

- conversion inside every Poisson term;
- Dykstra/SOCP projection inside uniformization;
- fixed↔paired conversion at every refined microstep.

A temporal refinement study must keep the number of synchronization
events fixed, or refine \(\Delta y\) jointly so that the synchronization
defect is below the temporal truncation error.

---

## 7. Stop-rule decision

Smooth resolved gate:

\[
\frac{\|\Pi(x_H)-x_H\|}{\|x_H\|}
<1\%.
\]

At \(N_y=64\), the projection is inactive and the paired closure error is

\[
0.8361\%.
\]

Thus the one-shot macro-map criterion passes.

The repeated-microstep criterion fails structurally. The next stage must
therefore build a persistent dual-state synchronization scheme rather
than further optimizing the current one-shot map.

## Next stage

```text
@Wolfram Stage G1/P2-C를 실행해줘.
G1/P2-B의 one-shot macro map을 정본으로 유지하되 fixed normal-energy
transport state와 paired electron-energy collision state를 동시에 유지하는
persistent dual-state scheme을 구성해줘. CF4 geometry substeps 동안 paired
grid의 Doppler labels와 screen bases를 time-dependent하게 갱신하고,
fixed↔paired synchronization은 macro Strang boundaries에서만 시행해줘.
synchronization defect estimator, adaptive resynchronization criterion,
photon number/electron-energy/four-force exchange, coherency cone,
second-order macro temporal convergence를 검증해줘. 이 gate가 통과하면
Bianchi V의 a_B direction-drift vertical slice로 넘어가줘.
```
