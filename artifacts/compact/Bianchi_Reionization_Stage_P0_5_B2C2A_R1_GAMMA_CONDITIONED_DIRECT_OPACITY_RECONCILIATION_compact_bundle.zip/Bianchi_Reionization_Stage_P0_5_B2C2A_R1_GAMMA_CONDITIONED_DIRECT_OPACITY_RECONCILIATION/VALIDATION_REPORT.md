# Validation report

## Overall assessment

**Ready for B2C2B with a numerical target caveat.**

The physical-component blocker is resolved without clipping, species
renormalization or free opacity fitting. The canonical operator changes
materially and the history is independently re-evolved.

| Check | Result |
|---|---:|
| central response identity | 0 |
| legacy runtime reproduction | 2.213e-16 |
| legacy byte/table formula | 7.620e-16 |
| raw-response/JAX-PCHIP auditor | 4.953e-04 |
| direct table vs fresh quadrature | 1.169e-03 |
| canonical photon ledger | 2.931e-10 |
| component sum | 6.105e-16 |
| negative physical components | 0 |
| smallest FlexRT-cell error | 1.977e-04 |
| refinement order | 0.974535--1.000000 |

The photon ledger passes the hard \(10^{-8}\) gate but does not reach the
\(10^{-10}\) engineering target. B2C2B must retain this caveat and should
tighten the integration before PR 2 assembly, without fitting sink values to
the residual.

Provenance checks:

- legacy history: auditor only;
- canonical history: direct-operator re-evolution from \(z=6\);
- no mixed rows;
- numerical residuals are not physical sinks;
- unresolved sink is not computed in R1;
- recombination remains external;
- geometry remains FLRW control.
