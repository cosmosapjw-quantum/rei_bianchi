# Stage P0.5-B2C2A-R1 — Gamma-conditioned direct-opacity reconciliation

## Verdict

\[
\boxed{
\text{P0.5-B2C2A-R1}
=
\texttt{DURABLE\_PASS;\ B2C2B\ AUTHORIZED}
}
\]

The inherited B2C2A fail-closed result was preserved. R1 reconstructed the
current-Gamma response without free normalization, reproduced the legacy
operator, separated normalization and group-shape effects, and re-evolved the
exact-zero-G3 history because the canonical operator changed materially.

## Opacity lock

\[
R_\Gamma(E,z,\Gamma)
=
\frac{\kappa_{\rm raw}(E,z,\Gamma)}
{\kappa_{\rm raw}(E,z,\Gamma_{\rm central})},
\]

\[
\boxed{
\kappa_{\rm eff}
=
\kappa_{\rm PUBLIC}R_\Gamma.
}
\]

At central Gamma, \(R_\Gamma=1\) exactly. No extrapolation outside the raw
domain \(0.03\le\Gamma_{12}\le30\) occurs.

## Parallel operator result

Legacy runtime reproduction:

\[
2.213e-16.
\]

Byte/table sparse-node reproduction:

\[
7.620e-16.
\]

The independent raw-response/JAX-PCHIP difference reaches

\[
4.953e-04
\]

and remains a numerical auditor.

The PUBLIC-anchor normalization changes the inherited low-energy rates by

\[
+0.1180\text{ to }+0.3521,
\]

while direct group shape contributes

\[
-0.2347\text{ to }-0.0818.
\]

The net operator change reaches

\[
\boxed{0.249821}.
\]

## History reconciliation

The canonical history was re-evolved from \(z=6\):

```text
CANONICAL_DIRECT_REEVOLVED
```

The largest relative history-state difference is

\[
1.193467.
\]

At \(z=5.5\),

\[
\frac{\Delta\Gamma_{\rm HI}}{\Gamma_{\rm HI}}
=
+0.026836,
\]

\[
\frac{\Delta T_b}{T_b}
=
-0.005794.
\]

Legacy and canonical rows must not be mixed downstream.

## Physical gates

- negative physical opacity/absorption components: 0;
- component-sum residual: 6.105e-16;
- primary G3 and external He II absorption: exact zero;
- direct quadrature/table residual: 1.169e-03.

The photon ledger gives

\[
\epsilon_\gamma^{\max}=2.931e-10.
\]

This passes the hard \(10^{-8}\) gate but misses the \(10^{-10}\) target.

FlexRT cell refinement reaches

\[
\epsilon_{\rm cell}^{\min}=1.977e-04,
\]

with order

\[
0.974535\le p\le1.000000.
\]

## Scope

- unresolved sink: not computed;
- front allocation: not computed;
- source/fesc calibration: not started;
- recombination: external and unloaded;
- primitive/Bianchi geometry: not transplanted;
- background: FLRW control receipts only.

## Decision

B2C2B is authorized to subtract diffuse maintenance from the R1 canonical
physical absorption components. Every negative physical subtraction component
must fail closed; no clipping or redistribution is allowed.
