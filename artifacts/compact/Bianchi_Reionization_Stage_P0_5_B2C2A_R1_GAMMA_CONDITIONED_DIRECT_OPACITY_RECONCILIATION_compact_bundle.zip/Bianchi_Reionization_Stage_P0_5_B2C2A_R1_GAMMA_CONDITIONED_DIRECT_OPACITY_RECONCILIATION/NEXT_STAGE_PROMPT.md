@Web+Wolfram Stage P0.5-B2C2B-UNRESOLVED-SINK-CLOSURE-LOCK를 실행해줘.

B2C2A-R1의 canonical operator
PUBLIC_ANCHORED_RAW_GAMMA_RESPONSE_DIRECT_ENERGY_GROUP,
CANONICAL_DIRECT_REEVOLVED history, physical-component decomposition,
numerical-residual registry, exact-zero primary G3, FLRW receipts,
neutral-island exclusion ledger와 recombination external-dependency receipt를
정본으로 유지한다.

1. 새 durable B2C2B directory, input lock, stage state, receipts,
   manifest와 SHA256SUMS를 계산 전에 생성해줘.

2. Legacy B2C1C/B2C2A histories를 production input으로 섞지 마.
   다음 R1 files만 canonical absorption evidence로 사용해줘.

   - canonical_direct_history.csv
   - canonical_direct_photon_ledger.csv
   - reconciled_group_total_absorption.csv
   - reconciled_physical_component_absorption.csv
   - CANONICAL_OPERATOR_LOCK.json

3. Primary external diffuse-maintenance vector는 B2C1C HeIII-decay gate를
   반영하여

   (m_HI->HII, m_HeI->HeII, 0)

   으로 고정해줘. HeIII recombination은 species/thermal/internal-OTS
   ledger에만 유지하고 external G3 maintenance에 넣지 마.

4. B2C0 phase-space full-OTS maintenance와 B2C1A/B transmission geometry를
   R1 canonical history에서 다시 평가해줘. Legacy history에 단순 보간하지
   마.

5. Component/group별로

   Ndot_unresolved,c,g^c =
     Ndot_abs,ion,c,g^c - Ndot_maint,diffuse,c,g^c

   를 계산해줘.

6. 모든 physical component, group, redshift interval에서

   Ndot_unresolved,c,g^c >= 0

   을 hard gate로 사용해줘. 음수는 clipping하거나 species/group 사이에
   재분배하지 말고 durable blocker table로 저장해줘.

7. 다음 numerical/operator residuals는 physical unresolved sink에서
   제외해줘.

   - LEGACY_RAW_RESPONSE_INTERPOLATOR_RESIDUAL
   - CENTRAL_GAMMA_NORMALIZATION_RESIDUAL
   - GROUP_SHAPE_DISCRETIZATION_RESIDUAL
   - CANONICAL_CHANGE_RESIDUAL

8. Neutral-island transfer는 EXCLUDED_NOT_ZERO로 유지하고 unresolved
   ionized sink에 포함하지 마.

9. Species-threshold maintenance를 group photons에 배분할 때 B2C1B direct
   finite-tau allocation을 사용하고 photon conservation, threshold support,
   nonnegativity와 group sum을 검증해줘.

10. R1 photon ledger는 hard 1e-8을 통과하지만 target 1e-10에는 못
    미쳤다. 가능하면 tolerance를 강화하되 sink를 ledger residual에 맞춰
    fitting하지 마.

11. FlexRT finite-cell auditor와 differential-hazard consistency를 다시
    실행해 smallest-cell error <1%, first-order refinement를 확인해줘.

12. Wolfram으로 subtraction identity, threshold support, group sum,
    exact-zero G3/HeII와 double-count firewall을 검증해줘.
    Precise Special Functions는 닫힌 analytic limit에만 사용해줘.

13. 이번 B2C2B에서는 front allocation, Q_M front growth,
    source/f_esc calibration, recombination implementation,
    primitive geometry transplant와 Bianchi feedback을 시작하지 마.

모든 unresolved physical components가 nonnegative하고 ledgers가 닫힌
뒤에만 B2C2C front/Q_M/full-ledger stage를 승인해줘.
