# B2C2A blocker resolution

## Inherited failure

B2C2A found negative signed residuals when the PUBLIC_REPO_EXACT
central-Gamma absolute opacity was applied directly to a trajectory whose
actual Gamma differed from the public central value. That fail-closed result
is preserved.

## R1 residual classes

1. `LEGACY_RAW_RESPONSE_INTERPOLATOR_RESIDUAL`

Difference between the independent raw-response PCHIP and the inherited JAX
runtime PCHIP evaluator.

2. `CENTRAL_GAMMA_NORMALIZATION_RESIDUAL`

\[
\dot N_{\rm PUBLIC\times response}^{\rm legacy}
-
\dot N_{\rm inherited}^{\rm legacy}.
\]

3. `GROUP_SHAPE_DISCRETIZATION_RESIDUAL`

\[
\dot N_{\rm PUBLIC\times response}^{\rm direct}
-
\dot N_{\rm PUBLIC\times response}^{\rm legacy}.
\]

4. `CANONICAL_CHANGE_RESIDUAL`

\[
\dot N_{\rm canonical}^{\rm direct}
-
\dot N_{\rm inherited}^{\rm legacy}.
\]

All are numerical/operator residuals. None is an astrophysical unresolved
sink.

## Resolution

- central response is exactly one;
- inherited runtime closure is reproduced to machine precision;
- byte/table sparse-node formula is reproduced independently;
- direct-energy closure changes the operator materially;
- the history is re-evolved from \(z=6\);
- the new history has no negative physical opacity/absorption component;
- primary G3 and external He II absorption remain exactly zero.

## Canonical decision

```text
operator:
PUBLIC_ANCHORED_RAW_GAMMA_RESPONSE_DIRECT_ENERGY_GROUP

history:
CANONICAL_DIRECT_REEVOLVED

legacy history:
AUDITOR_ONLY_DO_NOT_MIX
```
