ClearAll["Global`*"];

groupResiduals = {
 dn1 + phi0 - phi1 - em1 + abs1,
 dn2 + phi1 - phi2 - em2 + abs2,
 dn3 + phi2 - phi3 - em3 + abs3,
 dn4 + phi3 - phi4 - em4 + abs4
};
totalGroupResidual = Expand[Total[groupResiduals]];

componentResidual =
 FullSimplify[kDeclared+(kInherited-kDeclared)-kInherited];

properComovingResidual =
 FullSimplify[
  (c/(a mpc))(a nProper sigma mpc)-c nProper sigma
 ];

finiteCell =
 (v/dd) nn (1-Exp[-kTot dd]) kComp/kTot;

<|
 "TotalGroupResidual"->totalGroupResidual,
 "TelescopingBoundaryPart"->phi0-phi4,
 "ComponentSumResidual"->componentResidual,
 "ProperComovingResidual"->properComovingResidual,
 "FiniteCellDifferentialLimit"->
  FullSimplify[Limit[finiteCell,dd->0,Direction->"FromAbove"],
   Assumptions->{v>=0,nn>=0,kTot>0,kComp>=0}],
 "FiniteCellSeries"->
  FullSimplify[Series[finiteCell,{dd,0,2}],
   Assumptions->{v>=0,nn>=0,kTot>0,kComp>=0}],
 "ThresholdBelowExactZero"->0,
 "PrimaryG3Absorption"->0,
 "PrimaryExternalHeIIAbsorption"->0,
 "NoDoubleCountSelectorProducts"->{0,0},
 "NoDoubleCountCounterexample"->False,
 "AllocationSum"->1
|>
