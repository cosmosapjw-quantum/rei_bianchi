# R1 runtime-interruption recovery addendum

## Incident

An earlier R1 scratch tree disappeared from both the execution container and
the user-visible artifact filesystem. Conversation text and previously
reported scratch numbers were not accepted as durable evidence.

## Recovery action

A new stage was created before computation with provenance

```text
RUNTIME_INTERRUPTION_RECOVERY_RECONSTRUCTED
```

The following were performed again from currently present canonical bundles:

1. SHA-256 and ZIP CRC verification;
2. PUBLIC-anchor and raw-response construction;
3. legacy runtime and byte/formula reproduction;
4. direct-energy operator evaluation;
5. exact-zero-G3 history re-evolution from z=6;
6. physical-component decomposition;
7. FlexRT refinement;
8. Wolfram and Precise Special Functions audits;
9. fresh final science execution;
10. comprehensive validator.

## Accepted evidence

Only files in the reconstructed stage, its manifest, SHA256SUMS, final science
log and passing validator are authoritative. The two reconstructed failed
attempts remain under `state/` and are not production inputs.

## Outcome

```text
DURABLE_PASS_B2C2B_AUTHORIZED
```

with the explicit numerical caveat that the photon ledger passes the hard
1e-8 gate but does not reach the 1e-10 engineering target.
