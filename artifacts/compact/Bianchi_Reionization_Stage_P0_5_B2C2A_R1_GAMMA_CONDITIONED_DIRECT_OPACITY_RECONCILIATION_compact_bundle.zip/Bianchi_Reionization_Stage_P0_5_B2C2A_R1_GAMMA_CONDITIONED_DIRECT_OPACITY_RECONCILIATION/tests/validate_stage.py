from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
D = ROOT / "data"

results = json.loads((ROOT / "results.json").read_text())
assert results["verdict"] == "PASS_B2C2B_AUTHORIZED"
assert results["inherited_B2C2A_verdict"].startswith("FAIL_CLOSED")
assert results["B2C2B_authorization"] == "AUTHORIZED"

g = results["gates"]
assert g["central_response_max_abs_minus_one"] < 1e-12
assert g["legacy_history_reproduction_relative_residual_max"] < 1e-12
assert g["legacy_byte_formula_relative_residual_max"] < 1e-12
assert g["canonical_operator_change_relative_max"] > 1e-3
assert g["canonical_history_photon_ledger_relative_residual_max"] < 1e-8
assert g["canonical_component_sum_relative_residual_max"] < 1e-8
assert g["direct_quadrature_vs_tabled_fit_relative_residual_max"] < 0.01
assert g["physical_component_nonnegative"] is True
assert g["material_negative_physical_component_count"] == 0
assert g["raw_Gamma_domain_pass"] is True
assert g["primary_G3_and_external_HeII_exact_zero"] is True
assert g["cell_smallest_relative_difference_max"] < 0.01
assert 0.8 < g["cell_observed_order_range"][0] < 1.2
assert 0.8 < g["cell_observed_order_range"][1] < 1.2

decision = json.loads(
    (ROOT / "HISTORY_RECONCILIATION_DECISION.json").read_text()
)
assert decision["canonical_operator_changed"] is True
assert decision["history_action"] == "REEVOLVED_FROM_Z6_DO_NOT_MIX"
assert decision["legacy_history_status"] == "AUDITOR_ONLY"
assert decision["B2C2B_authorized"] is True

response = pd.read_csv(D / "raw_response_anchor_audit.csv")
assert response.central_response_max_abs_minus_one.max() < 1e-12
assert (response.trajectory_gamma12_min >= response.gamma12_min).all()
assert (response.trajectory_gamma12_max <= response.gamma12_max).all()
assert (response.extrapolation == "FORBIDDEN").all()

legacy = pd.read_csv(D / "operator_reconciliation_on_legacy_history.csv")
assert legacy.legacy_reproduction_relative_residual.max() < 1e-12
assert (
    legacy.physical_unresolved_sink_interpretation_allowed == False
).all()

byte = pd.read_csv(D / "legacy_operator_byte_formula_regression.csv")
assert byte.relative_residual.max() < 1e-12

residuals = pd.read_csv(D / "numerical_residual_registry.csv")
assert (residuals.registry_class == "NUMERICAL_OR_OPERATOR_CLOSURE").all()
assert (residuals.physical_unresolved_sink == False).all()
required = {
    "LEGACY_RAW_RESPONSE_INTERPOLATOR_RESIDUAL",
    "CENTRAL_GAMMA_NORMALIZATION_RESIDUAL",
    "GROUP_SHAPE_DISCRETIZATION_RESIDUAL",
    "CANONICAL_CHANGE_RESIDUAL",
}
assert required.issubset(set(residuals.residual_name.unique()))

history = pd.read_csv(D / "canonical_direct_history.csv")
assert set(history.history_provenance) == {"CANONICAL_DIRECT_REEVOLVED"}
assert (history.N4_exact == 0.0).all()
assert (history.Gamma_HeII_exact == 0.0).all()
assert np.all(np.diff(history.z.to_numpy()) < 0.0)

ledger = pd.read_csv(D / "canonical_direct_photon_ledger.csv")
assert set(ledger.history_provenance) == {"CANONICAL_DIRECT_REEVOLVED"}
assert ledger.relative_photon_ledger_residual.abs().max() < 1e-8
assert (ledger.absorption_G3_rate == 0.0).all()
assert (ledger.N4_exact == 0.0).all()
assert (ledger.Gamma_HeII_exact == 0.0).all()

groups = pd.read_csv(D / "reconciled_group_total_absorption.csv")
assert groups.component_sum_relative_residual.max() < 1e-8
assert (groups["total_absorption_rate_s-1_cMpc-3"] >= 0.0).all()

components = pd.read_csv(D / "reconciled_physical_component_absorption.csv")
assert (components["absorption_rate_s-1_cMpc-3"] >= -1.0).all()
assert (components.minimum_kappa_cMpc_inv >= -1e-14).all()
assert (components.physical_component == True).all()
heii = components[components.component == "EXPLICIT_HEII_ATOMIC"]
assert (heii["absorption_rate_s-1_cMpc-3"] == 0.0).all()

fit = pd.read_csv(D / "direct_group_fit_audit.csv")
assert (
    fit.direct_quadrature_vs_tabled_fit_relative_residual_max.max() < 0.01
)

cell = pd.read_csv(D / "cell_deposition_refinement.csv")
smallest = (
    cell.sort_values("delta_chi_cMpc")
    .groupby(["interval_index", "sequence", "group", "component"])
    .first()
)
smallest = smallest[smallest.differential_hazard_rate.abs() > 1.0]
assert smallest.relative_difference.max() < 0.01
orders = cell[np.isfinite(cell.observed_order)]
assert orders.observed_order.min() > 0.8
assert orders.observed_order.max() < 1.2

operator_lock = json.loads((ROOT / "CANONICAL_OPERATOR_LOCK.json").read_text())
assert operator_lock["group_shape"]["canonical"] == "DIRECT_ENERGY_GROUP"
assert operator_lock["history"]["action"] == "REEVOLVED_FROM_Z6_DO_NOT_MIX"

recomb = json.loads(
    (ROOT / "RECOMBINATION_EXTERNAL_DEPENDENCY_RECEIPT.json").read_text()
)
assert recomb["dependency_status"] == "EXTERNAL_NOT_LOADED"
assert recomb["contains_astrophysical_reionization"] is False
assert recomb["R1_provider_invoked"] is False
assert recomb["R1_surrogate_used"] is False

background = [
    json.loads(line)
    for line in (ROOT / "background_snapshot_receipts.jsonl").read_text().splitlines()
    if line.strip()
]
assert len(background) == 5
assert all(row["background_model"] == "FLRW_CONTROL" for row in background)
assert all(row["geometry_reused_without_mutation"] for row in background)
assert all(
    row["absorption_history_provenance"] == "CANONICAL_DIRECT_REEVOLVED"
    for row in background
)

neutral = json.loads((ROOT / "neutral_island_exclusion_ledger.json").read_text())
assert neutral["R1_status"] == "EXCLUDED_NOT_ZERO"
assert neutral["included_in_ionized_absorption"] is False

wolfram = json.loads((ROOT / "wolfram_validation_results.json").read_text())
assert wolfram["status"] == "PASS"
assert wolfram["ComponentSumResidual"] == 0
assert wolfram["ProperComovingResidual"] == 0
assert wolfram["ThresholdBelowExactZero"] == 0
assert wolfram["PrimaryG3Absorption"] == 0
assert wolfram["PrimaryExternalHeIIAbsorption"] == 0
assert wolfram["NoDoubleCountCounterexample"] is False

special = json.loads(
    (D / "special_function_powerlaw_rational_audit.json").read_text()
)
assert float(special["relative_difference"]) < 1e-15
assert special["production_operator"] == "direct numerical quadrature"

state = json.loads((ROOT / "STAGE_STATE.json").read_text())
# State is finalized only after this validator; pre-final values are allowed.
assert state["stage"] == results["stage"]

attempts = [
    ROOT / "state" / "ATTEMPT_1_RECONSTRUCTED_FAIL_MISSING_HEI_AND_LEDGER_RESOLUTION",
    ROOT / "state" / "ATTEMPT_2_RECONSTRUCTED_FAIL_RAW_VS_JAX_PCHIP_RESIDUAL",
]
assert all(path.exists() for path in attempts)

print(
    "P0.5-B2C2A-R1 verification: PASS; "
    "B2C2B_AUTHORIZED; photon-ledger hard gate PASS, target caveat retained"
)
