from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from gamma_conditioned_reconciliation import (
    ResponseAnchoredOpacity,
    legacy_discrete_weights,
)

def test_legacy_weights_and_response_contract():
    assert np.isclose(legacy_discrete_weights("G1").sum(), 1.0)
    assert np.isclose(legacy_discrete_weights("G2a").sum(), 1.0)
    assert hasattr(ResponseAnchoredOpacity, "conditioned_node_kappa")
    assert hasattr(ResponseAnchoredOpacity, "direct_group_kappa")
