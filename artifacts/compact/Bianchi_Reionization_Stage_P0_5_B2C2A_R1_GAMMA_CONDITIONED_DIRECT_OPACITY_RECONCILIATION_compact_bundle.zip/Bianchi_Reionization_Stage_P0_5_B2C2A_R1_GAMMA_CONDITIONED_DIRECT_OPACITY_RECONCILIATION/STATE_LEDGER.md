# R1 state ledger

## Runtime interruption recovery

The first scratch R1 tree disappeared from both the execution container and
artifact kernel. Its transcript numbers were not accepted as durable evidence.

This stage was reconstructed from currently present canonical bundles and is
labelled

```text
RUNTIME_INTERRUPTION_RECOVERY_RECONSTRUCTED
```

## Reconstructed attempts

### Attempt 1 — fail closed

- G2a explicit He I omitted from the reconciliation comparator;
- photon-ledger quadrature insufficient for the hard gate.

### Attempt 2 — fail closed

- byte/table formula was correct;
- independent raw SciPy PCHIP and inherited JAX runtime PCHIP differed near
  the low-Gamma boundary.

### Attempt 3 — accepted

- runtime legacy closure evaluated with the inherited JAX PCHIP formula;
- raw/JAX difference retained as an explicit numerical residual;
- exact-zero-G3 history re-evolved with tighter solver/quadrature settings.

## Current authority

```text
operator:
PUBLIC_ANCHORED_RAW_GAMMA_RESPONSE_DIRECT_ENERGY_GROUP

history:
CANONICAL_DIRECT_REEVOLVED

legacy:
AUDITOR_ONLY_DO_NOT_MIX
```

B2C2B may use only the R1 canonical history, photon ledger and physical
component tables.
