# Web source lock

## Mean-free-path emulator

**Tohfa et al., arXiv:2602.03923.**

R1 locks the following interpretation:

- the emulator depends on wavelength/energy, redshift, local reionization
  redshift, photoionization rate and large-scale density;
- the public table is a central-Gamma absolute opacity anchor;
- the raw table supplies only the dimensionless current-Gamma response;
- no free normalization or fit to inherited absorption is permitted.

## FlexRT

**Cain & D'Aloisio, JCAP 12 (2024) 025, arXiv:2409.04521.**

R1 uses FlexRT only as an architectural and finite-cell deposition auditor:

- adaptive ray tracing;
- replaceable IGM-opacity treatment;
- finite-cell deposition converges to the homogeneous differential-hazard
  operator under cell refinement.

## SCRIPT sink closure

**Choudhury & Chakraborty, arXiv:2504.03384.**

Emissivity, clumping, mean free path and photoionization rate are not treated
as unrelated normalization knobs. R1 therefore preserves normalization and
group-shape residuals explicitly rather than relabelling them as astrophysical
unresolved sinks.

## Neutral islands

**D'Aloisio et al., arXiv:2311.06348.**

Neutral-island transfer remains a separately provenance-locked component. It
is excluded from the ionized-medium decomposition without being assumed zero.

No web source replaces a durable upstream table, source file or history.
