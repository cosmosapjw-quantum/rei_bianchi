# Gamma-conditioned direct-opacity reconciliation specification

## Conventions

\[
g_{ab}=(-,+,+,+),\qquad \epsilon_{123}=+1.
\]

\[
[N_{\gamma,g}^{c}]={\rm cMpc^{-3}},
\qquad
[\kappa^c]={\rm cMpc^{-1}}.
\]

With \(a=(1+z)^{-1}\),

\[
v_\chi=\frac{c}{a\,{\rm Mpc}_{\rm cm}},
\]

and

\[
\dot N_{\rm abs,c,g}^{c}
=
v_\chi N_{\gamma,g}^{c}\bar\kappa_{c,g}^{c}
\]

has units s\(^{-1}\) cMpc\(^{-3}\).

Atomic proper opacity is converted by

\[
\kappa_{s,\rm atom}^{c}
=
a\,n_s^{\rm proper}\sigma_s\,{\rm Mpc}_{\rm cm}.
\]

## Public anchor and raw response

At the six locked nodes

\[
E_i=(13.60,14.48,16.70,20.05,25.50,39.50)\ {\rm eV},
\]

\[
R_\Gamma(E,z,\Gamma)
=
\frac{\kappa_{\rm raw}(E,z,\Gamma)}
{\kappa_{\rm raw}(E,z,\Gamma_{\rm central}(z))},
\]

\[
\boxed{
\kappa_{\rm eff}(E,z,\Gamma)
=
\kappa_{\rm PUBLIC}(E,z)R_\Gamma(E,z,\Gamma).
}
\]

The same P0.4 conventions are retained:

- effective Gauss-Hermite density weights;
- opacity average \(\sum_iw_i/\lambda_i\);
- conditional \(P(z_{\rm re}|\mathrm{ionized},z)\);
- locked eta/global averaging;
- no energy, redshift or Gamma extrapolation.

No normalization is fitted to the B2C1C absorption history.

## Parallel group operators

### Legacy runtime auditor

The inherited JAX PCHIP evaluator and sparse-node group formula are reproduced
directly. The independent raw SciPy-response interpolator difference is stored
as `LEGACY_RAW_RESPONSE_INTERPOLATOR_RESIDUAL`.

### Direct-energy canonical operator

The source-projected within-group shape is integrated directly against the
Gamma-conditioned opacity. The difference from sparse-node closure is stored
as `GROUP_SHAPE_DISCRETIZATION_RESIDUAL`.

Neither residual is a physical unresolved sink.

## History policy

The canonical operator changes the legacy absorption materially. Therefore the
exact-zero-G3 history is re-evolved from \(z=6\) and assigned provenance

```text
CANONICAL_DIRECT_REEVOLVED
```

The B2C1C history remains `AUDITOR_ONLY_DO_NOT_MIX`.

## Component firewall

- 13.6--39.5 eV: effective H I only;
- above 39.5 eV: explicit atomic H I;
- He I begins at 24.59 eV;
- He II begins at 54.42 eV;
- primary G3 and external He II absorption remain exactly zero;
- neutral islands remain excluded but not zero.

## FlexRT auditor

\[
D_{c,g}(\Delta\chi)
=
\frac{v_\chi}{\Delta\chi}N_{\gamma,g}^{c}
\int\phi_g(E)
[1-e^{-\kappa_{\rm tot}^{c}(E)\Delta\chi}]
\frac{\kappa_c^c(E)}{\kappa_{\rm tot}^c(E)}dE.
\]

Wolfram gives the differential limit

\[
D_{c,g}
=
v_\chi N_{\gamma,g}^{c}\bar\kappa_{c,g}^{c}
-\frac{\Delta\chi}{2}
v_\chi N_{\gamma,g}^{c}
\overline{\kappa_c^c\kappa_{\rm tot}^c}
+O(\Delta\chi^2).
\]
