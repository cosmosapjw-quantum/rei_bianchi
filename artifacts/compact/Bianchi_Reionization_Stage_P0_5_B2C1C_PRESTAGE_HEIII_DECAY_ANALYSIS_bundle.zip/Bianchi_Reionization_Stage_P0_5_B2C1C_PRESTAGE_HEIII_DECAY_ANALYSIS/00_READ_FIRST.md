# B2C1C pre-stage He III decay analysis

This is a derived auditor, not a completed B2C1C stage.

For the primary MFP source, external G3 support is exactly zero. The full-OTS mean-field He III equation is

\[
\dot x_{\rm HeIII}=n_e C_{\rm HeII}x_{\rm HeII}-n_e\alpha_{\rm eff}^{\rm OTS}x_{\rm HeIII},
\]

with

\[
\alpha_{\rm eff}^{\rm OTS}=\alpha_B+(1-y_{2a})(\alpha_A-\alpha_B).
\]

Across z=6.0 to 5.5, the durable primary history gives:

- cosmic time: 109.011411 Myr;
- effective recombination time: 372.884--505.485 Myr;
- collisional/recombination source ratio: 1.609e-15--2.562e-13;
- predicted exact-zero-G3 survival: 0.776193318;
- actual B2B survival: 0.779211791;
- relative difference: -0.3874%;
- predicted x_HeIII(z=5.5): 0.00220594141041;
- B2B x_HeIII(z=5.5): 0.00221451991097.

The close agreement indicates that the next stage is primarily an exact source-support and durable coupled-ledger regression. Binwise collisional signs must still be retained because hot phase-space bins can differ from the mean history.
