@Web+Wolfram Stage P0.5-B2C1C-PRIMARY-HEIII-DECAY-LOCK를 실행해줘.

B2C1B의 exact primary G3 source=0, atomic support matrix, direct finite-tau transmission, full-OTS event algebra와 B2B primary physical history를 정본으로 유지한다.

1. 새 durable stage directory와 input/state/receipt/manifest/hash 장부를 계산 전에 생성한다.
2. primary에서 N_gamma,G3^source=0 및 Gamma_HeII^ext=0을 algebraic exact constraint로 둔다.
3. static m_HeII->HeIII maintenance equation을 제거하고,
   dx_HeIII/dt = n_e C_HeII x_HeII - n_e alpha_eff^OTS x_HeIII
   로 전환한다. alpha_eff^OTS는 full-OTS event-vector sum에서 직접 계산한다.
4. unsupported B2C1B demand가 -n_He^c dx_HeIII/dt의 recombination 부분과 일치하는지 단계별로 검증한다.
5. z=6.0에서 5.5까지 H/He/T를 coupled forward evolve하고, external G3 photon floor를 완전히 제거한다.
6. global HeIII derivative와 phase-space binwise rate signs를 분리한다. Global primary decay를 검사하되 hot-bin positive collisional source는 clipping하지 않고 ledger에 남긴다.
7. mean-history auditor targets: t_rec^OTS=373--505 Myr, collisional/recombination <=3e-13, survival approximately 0.7762. 이 수치들은 fitting target이 아니라 regression auditor다.
8. photon/H/He/energy/heating/cooling ledgers, positivity, dt-halving 및 p=1 temporal order를 검증한다.
9. blackbody/hard-power-law auditors에서는 G3를 유지해 static-support와 decay operator를 비교한다.
10. unresolved sink, front allocation, f_esc calibration, Bianchi geometry는 시작하지 않는다.
