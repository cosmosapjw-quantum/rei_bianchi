# Web and literature source lock

## Verner photoionization fits

D. A. Verner et al., *Atomic Data for Astrophysics. II. New Analytic Fits for
Photoionization Cross Sections of Atoms and Ions*, ApJ 465, 487 (1996),
arXiv:astro-ph/9601009.

Use:
- ground-state HI, HeI and HeII analytic cross sections;
- threshold-to-high-energy operator;
- exact zero below the physical ionization threshold.

## Friedrich et al. H/He C2-Ray

M. M. Friedrich et al., *Radiative transfer of energetic photons:
X-rays and helium ionization in C2-Ray*, MNRAS 421, 2232 (2012),
arXiv:1201.0602.

Use:
- full OTS H/He event algebra;
- photon-conserving absorption;
- frequency intervals separated by HI/HeI/HeII thresholds;
- species allocation by relative optical-depth contribution;
- stellar-like sources mainly maintain singly ionized helium, while hard
  sources activate the HeII-ionizing channel.

## Tohfa et al. MFP simulation/source lock

arXiv:2602.03923v3.

Use:
- primary source \(J_\nu\propto\nu^{-1.5}\);
- source support limited to 1--4 Ryd;
- primary G3 source occupation exactly zero;
- P0.4 MFP remains a circularity auditor only when used as a local path length.

No web value is used as an unfrozen numerical replacement for the durable
B2B/B2C0/B2C1A artifacts.
