# Source-support and He III maintenance ledger

## Primary MFP-consistent source

\[
J_\nu\propto\nu^{-1.5},
\qquad 1\le E/{\rm Ryd}\le4.
\]

Its locked source occupations are approximately

\[
(0.672734,\ 0.239161,\ 0.088104,\ 0)
\]

for \((G_1,G_{2a},G_{2b},G_3)\).

Because only G3 has HeII photoionization support,

\[
A_{{\rm HeII},G_1}
=
A_{{\rm HeII},G_{2a}}
=
A_{{\rm HeII},G_{2b}}
=0
\]

and the primary source has

\[
a_{G_3}=0.
\]

The B2C0 full-OTS kernel nevertheless has a positive external
HeII-to-HeIII maintenance demand. Therefore

\[
\boxed{\texttt{PRIMARY\_SOURCE\_CANNOT\_MAINTAIN\_HEIII}}.
\]

The unsupported demand is roughly
\(4.24\times10^{47}\)--\(6.85\times10^{47}\)
photons s\(^{-1}\) cMpc\(^{-3}\), about 0.225%--0.279% of the total
maintenance demand.

This is a physical source-support conclusion, not an operator failure.
H and HeI support close exactly. The G3 transmission/allocation operator is
defined as an operator-only table but carries no primary source photons.

## Hard auditors

The 80,000-K blackbody and hard power-law lanes have nonzero G3 occupations
and their nonnegative group-supply cones close at every tested redshift.
Their normalized support residuals are at floating-point level.

The instantaneous B2B reservoir fractions are not forced to represent a
static maintenance equilibrium. `fixed_reservoir_supply_auditor_exact_primary_zero.csv`
is therefore an auditor only.

## Forbidden repairs

- numerical G3 floor amplification;
- assignment of HeII demand to G1/G2a/G2b;
- threshold relaxation;
- reinsertion of full-OTS internal photons into the external source.

## Required next change

In the primary stellar lane, HeIII must become a time-dependent decay/
recombination variable with zero external HeII photoionization source. This
gate must close before unresolved-sink/front accounting is opened.
