# Finite-optical-depth transmission and allocation specification

For group \(g\) and species \(s\),

\[
\tau_s(E)
=
\frac12 n_s L_s\sigma_s(E),
\]

\[
\tau_g(E)=\sum_s\tau_s(E).
\]

Production transmission is the direct spectral average

\[
F_g
=
\frac{\int_{G_g}\phi_g(E)e^{-\tau_g(E)}\,dE}
{\int_{G_g}\phi_g(E)\,dE}.
\]

The shortcut

\[
e^{-\langle\tau_g\rangle_\phi}
\]

is not used as the production operator. Spectral hardening is retained.

For absorbed photons,

\[
A_{s,g}
=
\frac{
\int_{G_g}
\phi_g(E)
[1-e^{-\tau_g(E)}]
\frac{\tau_s(E)}{\tau_g(E)}
\,dE
}{
\int_{G_g}
\phi_g(E)
[1-e^{-\tau_g(E)}]
\,dE
}.
\]

Hard properties:

\[
A_{s,g}\ge0,
\]

\[
\sum_s A_{s,g}=1
\quad\text{when group absorption is nonzero},
\]

and unsupported species have \(A_{s,g}=0\) exactly.

The reference uses 64 Gauss-Legendre nodes per group. Production node counts
are 12, 24, 24 and 32 for G1, G2a, G2b and G3. The maximum relative
reference/production discrepancies are about \(1.63\times10^{-5}\) for
transmission and \(1.21\times10^{-5}\) for allocation.
