# Atomic group and support lock

## Groups

\[
G_1=[13.60,24.59)\ {\rm eV},
\]

\[
G_{2a}=[24.59,39.50]\ {\rm eV},
\]

\[
G_{2b}=(39.50,54.42)\ {\rm eV},
\]

\[
G_3=[54.42,100]\ {\rm eV}.
\]

The 39.5-eV split is an implementation/provenance boundary, not a new atomic
threshold. It separates the MFP-emulator domain from the explicit high-energy
atomic lane.

## Species support

| species | G1 | G2a | G2b | G3 |
|---|---:|---:|---:|---:|
| HI | 1 | 1 | 1 | 1 |
| HeI | 0 | 1 | 1 | 1 |
| HeII | 0 | 0 | 0 | 1 |

Below-threshold cross sections are exactly zero. No epsilon support is used.

## Atomic data

The operator uses Verner ground-state photoionization fits for HI, HeI and
HeII. The durable outputs are:

- `data/atomic_operator_table.csv.gz`
- `data/source_projected_moments.csv`
- `data/threshold_audit.csv`
- `data/atomic_monotonicity_audit.csv`

All threshold-free supported intervals have zero detected positive-slope
violations on the high-resolution audit grid.
