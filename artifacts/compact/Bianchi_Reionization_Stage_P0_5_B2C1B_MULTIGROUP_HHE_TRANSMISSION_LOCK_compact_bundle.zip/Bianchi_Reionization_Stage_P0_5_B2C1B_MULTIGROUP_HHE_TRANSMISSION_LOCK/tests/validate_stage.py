from pathlib import Path
import json
import numpy as np
import pandas as pd

root = Path(__file__).resolve().parents[1]
data = root / "data"

results = json.loads((root / "results.json").read_text())
assert results["verdict"] == "DURABLE_PASS_WITH_PRIMARY_HEIII_UNSUPPORTED"

support_matrix = pd.read_csv(data / "species_support_matrix.csv").set_index("species")
assert support_matrix.loc["HI", ["G1","G2a","G2b","G3"]].all()
assert not support_matrix.loc["HeI", "G1"]
assert support_matrix.loc["HeI", ["G2a","G2b","G3"]].all()
assert not support_matrix.loc["HeII", ["G1","G2a","G2b"]].any()
assert support_matrix.loc["HeII", "G3"]

thresholds = pd.read_csv(data / "threshold_audit.csv")
atomic = thresholds[
    thresholds.species.isin(["HI","HeI","HeII"])
    & thresholds.below_threshold_exact_zero.eq(True)
]
assert len(atomic) == 3
assert (atomic.sigma_just_below_cm2 == 0.0).all()
assert (atomic.sigma_at_threshold_cm2 > 0.0).all()

occupation = pd.read_csv(data / "source_occupation_table.csv")
primary_g3 = occupation[
    (occupation.lane == "MFP_BASELINE_E_MINUS_2P5_1_TO_4_RYD")
    & (occupation.group == "G3")
].iloc[0]
assert primary_g3.source_occupation == 0.0
assert bool(primary_g3.exact_primary_G3_zero)

regression = pd.read_csv(data / "spectrum_lock_regression.csv")
assert regression.max_absolute_difference.max() < 1e-8
assert regression[
    regression.lane == "MFP_BASELINE_E_MINUS_2P5_1_TO_4_RYD"
].primary_G3_exact_zero.all()

convergence = pd.read_csv(data / "quadrature_convergence.csv")
assert convergence.F_relative_mismatch.max() < 0.01
assert convergence.A_relative_mismatch_max_with_floor.max() < 0.01

transmission = pd.read_csv(data / "group_transmission_summary.csv")
assert transmission.allocation_sum_error_max.max() < 1e-10
assert transmission.F_reference.between(0.0, 1.0).all()
assert transmission.F_production.between(0.0, 1.0).all()

allocation = pd.read_csv(data / "species_allocation_summary.csv")
assert (allocation.A_reference >= -1e-15).all()
assert (allocation.A_production >= -1e-15).all()
unsupported = allocation[~allocation.supported]
assert (unsupported.A_reference == 0.0).all()
assert (unsupported.A_production == 0.0).all()

monotonic = pd.read_csv(data / "atomic_monotonicity_audit.csv")
assert monotonic.positive_slope_violation_count.sum() == 0

support = pd.read_csv(data / "maintenance_source_support.csv")
primary = support[
    support.lane == "MFP_BASELINE_E_MINUS_2P5_1_TO_4_RYD"
]
assert (primary.status == "PRIMARY_SOURCE_CANNOT_MAINTAIN_HEIII").all()
assert (primary["m_HeII_to_HeIII_s-1_cMpc-3"] > 0.0).all()
assert primary.primary_G3_source_exact_zero.all()
assert np.allclose(
    primary["residual_HeII_s-1_cMpc-3"],
    primary["m_HeII_to_HeIII_s-1_cMpc-3"],
    rtol=1e-12,
    atol=0.0,
)

hard = support[
    support.lane.isin(
        ["CLOUDY_BLACKBODY_80000K","CLOUDY_HARD_POWERLAW_FNU_MINUS_1P5"]
    )
]
assert (hard.status == "FULL_SUPPORT_CLOSED").all()
assert hard.support_relative_residual.max() < 1e-12

fixed = pd.read_csv(data / "fixed_reservoir_supply_auditor_exact_primary_zero.csv")
fixed_primary = fixed[
    fixed.lane == "MFP_BASELINE_E_MINUS_2P5_1_TO_4_RYD"
]
assert (fixed_primary.reservoir_fraction_G3 == 0.0).all()
assert (fixed_primary.primary_G3_floor_policy == "EXACT_ZERO").all()

hardening = pd.read_csv(data / "spectral_hardening_audit.csv")
assert hardening.Jensen_expected_nonnegative_difference.all()
assert (hardening.F_direct_mean_exp >= hardening.F_exp_of_mean_tau - 1e-14).all()

wolfram = json.loads((root / "wolfram_validation_results.json").read_text())
assert wolfram["status"] == "PASS"
assert wolfram["AllocationSumResidual"] == 0
assert wolfram["AllocationBoundsCounterexample"] is False
assert wolfram["PrimaryNoG3PositiveHeIIDemandSolution"] is False
assert wolfram["FullOTSStoichiometricResidual"] == [0,0,0,0,0]
assert wolfram["PythonWolframSigmaRelativeDifferenceMax"] < 1e-12

state = json.loads((root / "STAGE_STATE.json").read_text())
assert state["status"] == "DURABLE_PASS_WITH_PRIMARY_HEIII_UNSUPPORTED"

assert (root / "MFP_CIRCULARITY_LEDGER.json").exists()
assert (root / "SOURCE_SUPPORT_LEDGER.md").exists()
assert (root / "SOURCE_SUPPORT_SEMANTICS.json").exists()
assert (
    data / "fixed_reservoir_supply_auditor_PRELIMINARY_NUMERICAL_G3_FLOOR.csv"
).exists()

print("P0.5-B2C1B durable gates: PASS_WITH_PRIMARY_HEIII_UNSUPPORTED")
