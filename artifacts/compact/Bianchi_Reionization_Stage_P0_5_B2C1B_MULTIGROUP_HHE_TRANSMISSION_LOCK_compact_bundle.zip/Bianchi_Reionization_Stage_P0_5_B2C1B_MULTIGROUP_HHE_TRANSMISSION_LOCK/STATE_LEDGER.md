# B2C1B state ledger

## Provenance

- New post-interruption durable stage.
- Recovery, B2B, B2C0, B2C1A and Cloudy audit bundle hashes were verified
  before calculation.
- Transcript-only B2C1B values were not inherited.

## Authoritative numerical run

`src/multigroup_hhe_transmission.py` generated:

- atomic operator and source-projected moment tables;
- threshold/support audits;
- direct finite-optical-depth group transmission;
- species allocation matrices;
- quadrature convergence;
- common-scale and species-length sensitivity;
- source-support cone ledgers.

The process exited successfully. The Python startup spreadsheet warmup warning
is unrelated to the scientific calculation and is retained in the log.

## Auditor correction

A preliminary fixed-reservoir-ratio file retained the B2B numerical G3 floor
in the primary lane. It has been quarantined as

```text
data/fixed_reservoir_supply_auditor_PRELIMINARY_NUMERICAL_G3_FLOOR.csv
```

The authoritative auditor is

```text
data/fixed_reservoir_supply_auditor_exact_primary_zero.csv
```

with primary G3 set exactly to zero and the remaining reservoir fractions
renormalized.

## Current authority

Primary:
- common-gas calibrated Jeans length;
- direct spectral transmission;
- direct absorbed-photon species allocation;
- exact primary source-support matrix.

Auditor only:
- hard spectrum lanes;
- species-specific path-length factors;
- MFP path length;
- fixed instantaneous reservoir ratios;
- E^-4 numerical spectrum;
- primary G3 operator-only table.

## Physical conclusion

The primary source closes H and HeI maintenance but cannot maintain HeIII.
This is not repaired in B2C1B. The next required stage is a primary HeIII
decay/recombination evolution with external HeII photoionization fixed to zero.

## Forbidden work

- unresolved-sink subtraction;
- front allocation;
- source/fesc calibration;
- Bianchi propagation.
