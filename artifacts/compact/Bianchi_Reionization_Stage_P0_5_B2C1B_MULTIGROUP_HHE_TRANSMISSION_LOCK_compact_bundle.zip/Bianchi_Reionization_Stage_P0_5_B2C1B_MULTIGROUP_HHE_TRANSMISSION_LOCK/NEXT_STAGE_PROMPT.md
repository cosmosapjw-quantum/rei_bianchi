@Web+Wolfram Stage P0.5-B2C1C-PRIMARY-HEIII-DECAY-LOCK를 실행해줘.

B2C1B의 atomic groups, exact support matrix, direct finite-tau H/He
transmission, photon allocation, common-gas Jeans geometry와 primary
G3 source occupation=0을 정본으로 유지한다.

1. 계산 전에 새 durable B2C1C directory, input lock, stage state,
   receipts, manifest와 SHA256SUMS를 생성해줘.

2. Primary MFP source에서 external HeII photoionization을

   Gamma_HeII^ext = 0

   으로 정확히 고정하고, 수치 floor G3 photon을 사용하지 마.

3. Primary HeIII를 static maintenance target에서 time-dependent state로
   전환해줘. Full H/He chemistry에서

   d x_HeIII/dt =
      n_e C_HeII(T) x_HeII
      - n_e alpha_HeIII^eff(T) x_HeIII
      + full-OTS internal-coupling terms

   을 사용하고 external G3 photoionization term은 넣지 마.

4. B2B primary physical history의 z=6.0 state에서 시작하여 z=5.5까지
   HeIII, HeII, HeI, H species와 T_b를 coupled하게 재진화해줘.
   같은 source/amplitude history를 사용하되 primary G3 external source는
   exact zero로 유지해줘.

5. T~1.4e4-1.6e4 K에서 collisional HeII ionization이 recombination보다
   작은지 수치적으로 확인하고, 그렇다면 x_HeIII의 monotonic decay를
   gate로 사용해줘. 조건이 깨지는 bin에서는 monotonicity를 강제하지 말고
   rate-sign ledger를 저장해줘.

6. HeIII recombination photons의 full-OTS H/He cross-ionization은 내부
   chemistry event로 유지하고, external source group에 재삽입하지 마.

7. photon number, H/He nuclei, ionization-threshold energy, photoheating 및
   cooling ledgers를 닫고, timestep-halving과 positivity를 검증해줘.

8. hard-power-law 및 8e4 K blackbody auditor에서는 G3 source를 유지하여
   static-support branch와 decay branch를 비교해줘.

9. 이번 B2C1C에서는 unresolved sink subtraction, front allocation,
   source/f_esc calibration과 Bianchi geometry를 시작하지 마.

Primary HeIII decay gate가 닫힌 뒤에만 B2C2에서
N_abs,ion=N_maint,diffuse+N_unresolved
및 species-resolved front allocation을 열어줘.
