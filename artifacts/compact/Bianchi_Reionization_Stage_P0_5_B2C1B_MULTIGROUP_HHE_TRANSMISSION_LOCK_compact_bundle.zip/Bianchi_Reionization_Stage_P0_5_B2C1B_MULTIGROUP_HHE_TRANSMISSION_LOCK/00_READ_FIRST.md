# Stage P0.5-B2C1B — Multigroup H/He transmission lock

## Verdict

\[
\boxed{
\text{P0.5-B2C1B}
=
\texttt{DURABLE\_PASS\_WITH\_PRIMARY\_HEIII\_UNSUPPORTED}
}
\]

The atomic H/He operator, source-projected moments, finite-optical-depth
spectral transmission, photon-conserving species allocation, common-gas
geometry and hard-source support operators all pass.

The primary MFP-consistent source has exact zero G3 occupation while the
full-OTS kernel requires a positive HeII-to-HeIII maintenance rate. This
demand is deliberately left unsupported. The next stage must convert primary
HeIII from a static maintenance quantity to a decay/recombination variable.

## Atomic group lock

\[
G_1=[13.60,24.59)\ {\rm eV},
\]

\[
G_{2a}=[24.59,39.50]\ {\rm eV},
\]

\[
G_{2b}=(39.50,54.42)\ {\rm eV},
\]

\[
G_3=[54.42,100]\ {\rm eV}.
\]

| species | G1 | G2a | G2b | G3 |
|---|---:|---:|---:|---:|
| HI | 1 | 1 | 1 | 1 |
| HeI | 0 | 1 | 1 | 1 |
| HeII | 0 | 0 | 0 | 1 |

Below-threshold cross sections are exactly zero. The 39.5-eV boundary is an
MFP-domain/provenance split rather than an atomic threshold.

## Source occupation

Primary MFP source:

\[
(w_1,w_{2a},w_{2b},w_3)
=
(0.672734189,0.239161390,0.088104421,0).
\]

The 80,000-K blackbody auditor has

\[
w_3=0.020741,
\]

and the hard power-law auditor has

\[
w_3=0.078725.
\]

The primary G3 zero is algebraic and is not a small numerical occupation.

## Source-projected cross sections

For the \(E^{-2.5}\) photon weighting, the principal group averages are:

| group | HI [cm2] | HeI [cm2] | HeII [cm2] |
|---|---:|---:|---:|
| G1 | \(3.51466\times10^{-18}\) | 0 | 0 |
| G2a | \(7.32596\times10^{-19}\) | \(5.37173\times10^{-18}\) | 0 |
| G2b | \(2.13041\times10^{-19}\) | \(2.45608\times10^{-18}\) | 0 |
| G3 | \(6.39821\times10^{-20}\) | \(1.00977\times10^{-18}\) | \(8.69574\times10^{-19}\) |

Python and Wolfram agree to

\[
1.921e-15
\]

relative.

## Finite-optical-depth operator

Production uses

\[
F_g
=
\frac{\int_{G_g}\phi_g(E)e^{-\tau_g(E)}\,dE}
{\int_{G_g}\phi_g(E)\,dE},
\]

not

\[
e^{-\langle\tau_g\rangle}.
\]

A representative high-opacity G3 audit shows a relative difference as large
as

\[
7.298\%
\]

between these two expressions.

Absorbed photons are assigned by

\[
A_{s,g}
=
\frac{
\int \phi_g(1-e^{-\tau_g})
\frac{\tau_s}{\tau_g}\,dE
}{
\int \phi_g(1-e^{-\tau_g})\,dE
}.
\]

All allocations are nonnegative, exactly threshold respecting, and sum to
one to machine precision.

## Quadrature gate

The 64-node-per-group reference is compared with the production grid
\((12,24,24,32)\).

\[
\max\epsilon_F
=
1.631e-05,
\]

\[
\max\epsilon_A
=
1.214e-05,
\]

both far below the 1% gate.

## Representative z=5.5 operator

Primary lane:

| group | source occupation | F | A_HI | A_HeI | A_HeII |
|---|---:|---:|---:|---:|---:|
| G1 | 0.672734 | 0.995955 | 1 | 0 | 0 |
| G2a | 0.239161 | 0.998787 | 0.699424 | 0.300576 | 0 |
| G2b | 0.088104 | 0.999586 | 0.596882 | 0.403118 | 0 |
| G3 | 0 | 0.497531 | 0.000080 | 0.000080 | 0.999840 |

The G3 row is an operator-only response. It does not imply a primary G3
photon population.

For hard auditors, G3 is almost completely absorbed by HeII:

\[
A_{{\rm HeII},G3}
\simeq
0.999773
\quad\text{(blackbody)},
\]

\[
A_{{\rm HeII},G3}
\simeq
0.999721
\quad\text{(hard power law)}.
\]

## Source-support gate

Primary external maintenance demand has

\[
m_{\rm HeII\to HeIII}
=
(4.236e+47,6.848e+47)
\ {\rm photons\,s^{-1}\,cMpc^{-3}},
\]

about

\[
0.2249\%\text{--}0.2792\%
\]

of total maintenance.

Since

\[
w_{G3}^{\rm primary}=0
\]

and HeII support is zero in G1/G2a/G2b, there is no nonnegative primary source
solution for this component.

\[
\boxed{\texttt{PRIMARY\_SOURCE\_CANNOT\_MAINTAIN\_HEIII}}
\]

H and HeI close. Blackbody and hard-power-law support cones close at all
tested redshifts with normalized residuals at floating-point precision.

The fixed instantaneous B2B group ratios are retained only as transient
non-equilibrium auditors. Support-cone closure does not mean that one scalar
source amplitude must reproduce a time-dependent reservoir's exact group
ratios.

## Length geometry

Primary geometry is

\[
L_{\rm HI}=L_{\rm HeI}=L_{\rm HeII}=\chi_JL_J.
\]

Species-specific factors

\[
\chi_{\rm HeI},\chi_{\rm HeII}\in\{0.5,1,2\}
\]

are sensitivity auditors only. They change G3 transmission substantially but
do not remove the primary source-support obstruction.

MFP path length remains circularity-auditor only.

## Full-OTS closure

Wolfram verifies

\[
B\,m_{\rm ext}+S_{\rm rec}^{\rm OTS}=0
\]

exactly for a supported maintenance vector. Hard-lane numerical
stoichiometric residuals normalized to maintenance are below

\[
6.370e-16.
\]

OTS internal photons are never inserted into external group source
occupation.

## Final decision

Passed:

- atomic groups and exact species support;
- Verner operator tables and moments;
- direct finite-\(\tau\) transmission;
- photon-conserving species allocation;
- production/reference quadrature;
- common-gas Jeans geometry;
- hard-source support cone;
- full-OTS conservation;
- Wolfram cross-check.

Fail-closed physical conclusion:

- primary stellar source cannot statically maintain HeIII.

Not started:

- unresolved sink;
- front allocation;
- source/fesc calibration;
- Bianchi propagation.

\[
\boxed{
\text{B2C1C primary-HeIII decay lock is required before B2C2.}
\]
