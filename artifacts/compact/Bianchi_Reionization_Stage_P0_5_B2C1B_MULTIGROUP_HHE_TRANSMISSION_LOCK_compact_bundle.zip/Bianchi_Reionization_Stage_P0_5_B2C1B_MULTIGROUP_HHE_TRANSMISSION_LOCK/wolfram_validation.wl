ClearAll["Global`*"];

params=<|
"HI"-><|"Eth"->13.60`40,"E0"->0.4298`40,"sigma0"->5.475*^4,
 "ya"->32.88`40,"p"->2.963`40,"yw"->0`40,"y0"->0`40,"y1"->0`40|>,
"HeI"-><|"Eth"->24.59`40,"E0"->13.61`40,"sigma0"->949.2`40,
 "ya"->1.469`40,"p"->3.188`40,"yw"->2.039`40,
 "y0"->0.4434`40,"y1"->2.136`40|>,
"HeII"-><|"Eth"->54.42`40,"E0"->1.720`40,"sigma0"->1.369*^4,
 "ya"->32.88`40,"p"->2.963`40,"yw"->0`40,"y0"->0`40,"y1"->0`40|>
|>;

sigma[sp_,en_?NumericQ]:=Module[{q=params[sp],x,y},
 If[en<q["Eth"],0,
  x=en/q["E0"]-q["y0"];
  y=Sqrt[x^2+q["y1"]^2];
  10^-18 q["sigma0"]((x-1)^2+q["yw"]^2)
   y^(q["p"]/2-11/2)/(1+Sqrt[y/q["ya"]])^q["p"]
 ]
];

groups=<|
"G1"->{13.60`30,24.59`30},
"G2a"->{24.59`30,39.50`30},
"G2b"->{39.50`30,54.42`30},
"G3"->{54.42`30,100.0`30}
|>;
phi[en_?NumericQ]:=en^(-5/2);

sigmaBars=Association@Table[
 g->Association@Table[
  sp->N[
   NIntegrate[phi[e]sigma[sp,e],{e,groups[g][[1]],groups[g][[2]]},
    WorkingPrecision->50,AccuracyGoal->30,PrecisionGoal->30]/
   NIntegrate[phi[e],{e,groups[g][[1]],groups[g][[2]]},
    WorkingPrecision->50,AccuracyGoal->30,PrecisionGoal->30],20],
  {sp,{"HI","HeI","HeII"}}],
 {g,Keys[groups]}];

thresholdAudit=Association@Table[
 sp->{sigma[sp,params[sp]["Eth"]-10^-12],
      sigma[sp,params[sp]["Eth"]],
      sigma[sp,params[sp]["Eth"]+10^-12]},
 {sp,{"HI","HeI","HeII"}}];

Clear[t1,t2,t3];
tot=t1+t2+t3;
allocationSum=FullSimplify[
 Total[{t1,t2,t3}/tot]-1,
 Assumptions->{t1>=0,t2>=0,t3>=0,tot>0}];
allocationBounds=Reduce[
 t1>=0&&t2>=0&&t3>=0&&tot>0&&
 ((t1/tot<0||t1/tot>1)||(t2/tot<0||t2/tot>1)||
  (t3/tot<0||t3/tot>1)),
 {t1,t2,t3},Reals];

Clear[a1,a2,a3,mH,mHeI,mHeII,h12,h13,q22,q23];
primaryNoSolution=Reduce[
 a1>=0&&a2>=0&&a3>=0&&mHeII>0&&
 a1+h12 a2+h13 a3==mH&&q22 a2+q23 a3==mHeI&&0==mHeII,
 {a1,a2,a3,mH,mHeI,mHeII,h12,h13,q22,q23},Reals];

Clear[q33];
hardTriangular={{1,h12,h13},{0,q22,q23},{0,0,q33}};
hardDet=Det[hardTriangular];

stoichMatrix={{-1,0,0},{1,0,0},{0,-1,0},{0,1,-1},{0,0,1}};
source={sHI,-sHI,sHeI,-sHeI-sHeIII,sHeIII};
mext={sHI,sHeI,-sHeIII};
stoich=FullSimplify[stoichMatrix.mext+source];

meanExp=NIntegrate[Exp[-2/e^3],{e,1,2},WorkingPrecision->40];
expMean=Exp[-NIntegrate[2/e^3,{e,1,2},WorkingPrecision->40]];

<|
 "SigmaBarsPowerLawEminus2p5"->sigmaBars,
 "ThresholdAuditBelowAtAbove"->thresholdAudit,
 "AllocationSumResidual"->allocationSum,
 "AllocationBoundsCounterexample"->allocationBounds,
 "PrimaryNoG3PositiveHeIIDemandSolution"->primaryNoSolution,
 "HardTriangularDeterminant"->hardDet,
 "FullOTSStoichiometricResidual"->stoich,
 "FiniteTauMeanExp"->N[meanExp,20],
 "ExpOfMeanTau"->N[expMean,20],
 "FiniteTauDifference"->N[meanExp-expMean,20]
|>
