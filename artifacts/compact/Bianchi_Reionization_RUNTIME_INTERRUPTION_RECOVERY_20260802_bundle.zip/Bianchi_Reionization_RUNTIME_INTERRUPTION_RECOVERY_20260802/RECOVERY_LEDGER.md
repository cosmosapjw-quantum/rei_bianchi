# RECOVERY LEDGER — RUNTIME_INTERRUPTION_RECOVERY

Recovery snapshot: `2026-08-02T06:26:09.722876+00:00`  
Runtime rehydration start: approximately `2026-08-02T06:15:01+00:00`

## Recovery verdict

The prior interaction is **not** treated as a continuous successful run.
The runtime was rehydrated at about 06:15 UTC: all 199 pre-recovery file mtimes
fall within roughly 41 seconds of PID 1 startup. These mtimes are inventory
facts, not original creation chronology.

No scientific computation process is currently running. The last independently
recoverable scientific checkpoint is:

\[
\boxed{\text{P0.5-B1-PHOTON-ALLOCATION-QMASS-LOCK}}
\]

Its bundle is internally hash-verified and its durable validation script was
rerun after interruption with PASS.

The requested next stage,
`P0.5-B2-MONOLITHIC-BRANCH-MAINTENANCE-LOCK`, has no durable state and is
classified `MISSING`. Recovery stops here; no B2 science has been executed.

## Stage ledger

| Stage | Artifact state | Scientific-claim state | Durable evidence | Recovery disposition |
|---|---|---|---|---|
| T2-A/T2-B | PARTIALLY_RECOVERED | PARTIALLY_RECOVERED | Top-level .wl/.json/.md present; no original bundle/hash/state ledger. | Current bytes hashed in T2_RECONSTRUCTED_HASHES.tsv; numerical gates not promoted. |
| T2-C | PARTIALLY_RECOVERED | PARTIALLY_RECOVERED | ZIP passes CRC; .wl/.json/.md present; no internal hash index or execution log. | Bundle extracted and recovery hashes generated; verdict remains non-inherited. |
| T2-D0/T2-D1 | PARTIALLY_RECOVERED | PARTIALLY_RECOVERED | ZIP passes CRC; no internal hash index or original execution log. | Artifact reconstructed; scientific result requires rerun before reuse. |
| T2-D2 | PARTIALLY_RECOVERED | PARTIALLY_RECOVERED | ZIP passes CRC; correction notice exists; no original hash/state ledger. | Artifact reconstructed; numerical claims not promoted. |
| T2-D3/T2-E0 | PARTIALLY_RECOVERED | PARTIALLY_RECOVERED | ZIP passes CRC; no original hash/state ledger. | Artifact reconstructed; numerical claims not promoted. |
| T2-E1/G0 | PARTIALLY_RECOVERED | PARTIALLY_RECOVERED | ZIP passes CRC; no original hash/state ledger. | Artifact reconstructed; numerical claims not promoted. |
| G1/P0 | DURABLE_VERIFIED | PARTIALLY_RECOVERED | Bundle CRC pass; manifest 4/4 hashes pass; result/notice/code present. | Artifact verified. Manifest says blocks ran individually, not monolithic WolframKernel. |
| G1/P1 | DURABLE_VERIFIED | PARTIALLY_RECOVERED | Bundle CRC pass; manifest 4/4 hashes pass. | Artifact verified; monolithic rerun absent by manifest. |
| G1/P2-A | DURABLE_VERIFIED | PARTIALLY_RECOVERED | Bundle CRC pass; manifest 4/4 hashes pass. | Artifact verified; route decision preserved. |
| G1/P2-B | DURABLE_VERIFIED | PARTIALLY_RECOVERED | Bundle CRC pass; manifest 4/4 hashes pass. | Artifact verified; parser/502 exclusions recorded in manifest. |
| G1/P2-C | MISSING | MISSING | No file, bundle, directory, log, process, or state ledger. | Do not inherit or cite. |
| R0-A/R0-B | DURABLE_VERIFIED | PARTIALLY_RECOVERED | Bundle CRC pass; manifest 4/4 hashes pass. | Artifact verified; consolidated Wolfram file was not monolithically rerun. |
| R0-C/R1-A | DURABLE_VERIFIED | PARTIALLY_RECOVERED | Bundle CRC pass; manifest 7/7 hashes pass; Python auditor present. | Artifact verified; mixed Python/Wolfram execution, no monolithic job. |
| R1-B/B0 | TRANSCRIPT_ONLY | TRANSCRIPT_ONLY | No uniquely named R1-B/B0 artifact. Transcript reused R0-C/R1-A files. | Unique scientific claims must be rerun; do not inherit. |
| P0-PROVENANCE-LOCK | DURABLE_VERIFIED | DURABLE_VERIFIED | Bundle CRC pass; SHA256SUMS 38/38 and manifest records pass. | Complete bundle reconstructed into recovery area. |
| P0.1-PUBLIC-WORKAROUND-LOCK | DURABLE_VERIFIED | DURABLE_VERIFIED | Bundle CRC pass; SHA256SUMS 16/16 pass. | Complete bundle reconstructed. |
| P0.2-ZENODO-ASSET-LOCK | DURABLE_VERIFIED | DURABLE_VERIFIED | Bundle CRC pass; SHA256SUMS 14/14 pass; checkpoint/data are included. | Complete bundle reconstructed. |
| P0.3-GLOBAL-OPACITY-LOCK | DURABLE_VERIFIED | PARTIALLY_RECOVERED | Bundle CRC pass; SHA256SUMS 29/29 pass; scripts/tables/status present. | Artifact verified; recorded Wolfram endpoint limitations remain. |
| P0.4-PAPER-CODE-CHECKPOINT-REGRESSION | DURABLE_VERIFIED | DURABLE_VERIFIED | Bundle CRC pass; SHA256SUMS 26/26 pass; raw/checkpoint tables included. | Complete bundle reconstructed. |
| P0.5-A/B | DURABLE_VERIFIED | DURABLE_VERIFIED | Bundle CRC pass; SHA256SUMS 29/29 pass; branch/history tables included. | Complete bundle reconstructed. |
| P0.5-CLOUDY-C25-AUDIT | PARTIALLY_RECOVERED | DURABLE_VERIFIED | Audit bundle CRC pass; SHA256SUMS 48/48; benchmark inputs/outputs/logs present. Current source tree and binaries absent. | Split archive recombined with matching hash; uncompressed tar and source identity files reconstructed. Binaries not present in uploaded source archive. |
| P0.5-B1-PHOTON-ALLOCATION-QMASS-LOCK | DURABLE_VERIFIED | RECONSTRUCTED | Bundle CRC pass; SHA256SUMS 25/25; validation script present. | Bundle extracted and validate_stage.py rerun after interruption: PASS. |
| P0.5-B2-MONOLITHIC-BRANCH-MAINTENANCE-LOCK | MISSING | MISSING | No matching artifact, log, manifest, process, or partial work directory. | Not executed. Resume only after recovery closure. |
| P0.5-C Bianchi I/V/II | MISSING | MISSING | No artifact; prior state explicitly marked NOT_AUTHORIZED. | Do not start during recovery. |

## Bundle integrity

- Stage bundles audited: **19**
- `DURABLE_VERIFIED` bundles with working internal hash index: **14**
- CRC-valid but originally unhashed early T2 bundles: **5**
- Bundle CRC failures: **0**
- Internal-hash mismatches among hashed bundles: **0**

Detailed bundle evidence is in `BUNDLE_AUDIT.tsv`.

## Runtime and harness state

- Scientific processes: **0**
- Active WolframKernel: **none**
- Active Cloudy process: **none**
- Active build/test process: **none**
- Current stage harness receipt for B2: **missing**
- Disk/inode and all process/file records: `RECOVERY_INVENTORY.tsv`

## Cloudy recovery state

The official Cloudy `c25.00` tag is independently visible upstream at commit
`fb07fa71`; the reconstructed archive identifies itself as Cloudy C25 in
`README.md` and `version.cpp`. The verified Cloudy audit bundle contains hashed
benchmark inputs/outputs, build records, and the official Case-A/B grid output.
The current runtime does not contain the prior built executable; only the source
archive has been reconstructed.

## Provenance firewall

- `DURABLE_VERIFIED` means the current artifact and its original hash/state
  evidence are present and verified.
- `PARTIALLY_RECOVERED` numbers are not promoted to fresh scientific premises.
- `TRANSCRIPT_ONLY` and `MISSING` numbers/verdicts are not inherited at all.
- `RECONSTRUCTED` identifies artifacts recreated after interruption from verified
  bundles or split archives; it does not imply the original numerical experiment
  was rerun.

## Resume point

After this recovery ledger is accepted, the only legitimate continuation is to
start P0.5-B2 **from the reconstructed, validated P0.5-B1 bundle**. It must create
its own durable work directory, per-step logs, manifest, hashes, and state ledger
before reporting any scientific result.
