# MISSING OR REBUILT ARTIFACTS

Snapshot: `2026-08-02T06:26:09.722876+00:00`

## Rebuilt during this recovery

1. **Complete bundle extraction trees**
   - All 19 stage bundles were CRC-tested and extracted under
     `reconstructed_bundles/`.
   - Fourteen bundles had an internal manifest or SHA-256 index whose entries all
     matched. Five early T2 bundles had no internal hash index; their current bytes
     were hashed in `T2_RECONSTRUCTED_HASHES.tsv` but their numerical claims were not
     upgraded.

2. **Cloudy combined archive**
   - Reconstructed from `aa -> ab -> ac -> ad -> ae`.
   - Reconstructed gzip SHA-256:
     `fb0932b0934811313571fab957ba11c0b1a05f5ee67b23c442999f1e89850064`.
   - `gzip -t` passed.
   - Uncompressed tar SHA-256:
     `8cf73d430e522725d35942651fa83d21405790f340525a32c4210d6e5f1f43f9`.
   - `README.md`, `source/Makefile`, `source/version.cpp`, and the official
     Case-A/B test input were selectively extracted and hashed.

3. **P0.5-B1 validation**
   - The complete verified bundle was extracted.
   - `validate_stage.py` was rerun after the interruption and returned
     `P0.5-B1 durable gates: PASS`.

## Still missing

1. **P0.5-B2-MONOLITHIC-BRANCH-MAINTENANCE-LOCK**
   - No artifact, log, work directory, manifest, or process exists.
   - Status: `MISSING`.
   - No scientific number or verdict from this stage may be inherited.

2. **R1-B/B0 unique stage artifact**
   - The transcript reported a stage, but no uniquely named artifact exists.
   - Status: `TRANSCRIPT_ONLY`.

3. **G1/P2-C and P0.5-C geometry stages**
   - Proposed but not executed.
   - Status: `MISSING`.

4. **Current Cloudy executable/source build tree**
   - The original runtime source tree and binaries are absent.
   - The user-uploaded source archive has been reconstructed and source identity
     files extracted, but the archive contains no prebuilt `cloudy.exe`,
     `libcloudy.a`, or `vh128sum.exe`.
   - The hashed benchmark outputs and build record remain durable inside the
     verified Cloudy audit bundle; current executable state is not restored.

5. **Original T2 execution logs and hash ledgers**
   - T2-A/T2-B through T2-E1/G0 retain result/code files and valid ZIPs where
     applicable, but no original execution logs or internal hash/state ledgers.
   - Status: `PARTIALLY_RECOVERED`; numerical claims require rerun before being
     used as a fresh scientific premise.

## Extracted-directory truncation repaired

The runtime-mounted P0 stage directories were incomplete relative to their own
`SHA256SUMS` files. Missing-member counts before reconstruction were:

- P0 provenance: 22
- P0.1: 7
- P0.2: 5
- P0.3: 14
- P0.4: 11
- P0.5-A/B: 17
- P0.5-B1: 10
- Cloudy audit: 40

Every corresponding bundle was intact and internally verified, so complete
copies were reconstructed under `reconstructed_bundles/` without overwriting
those partial runtime-mounted directories.
