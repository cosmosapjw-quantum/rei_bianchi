# Stage G1/P1 architecture notice

G1/P1 confirms the G1/P0 rejection of the standard SSP2 collision update
and supplies a practical positive exponential action.

## Accepted collision action

For

\[
L=-D+UV,\qquad
\nu\ge\max D,
\]

use

\[
T=I+\frac{L}{\nu}
\]

and positive Poisson uniformization. This preserves the coherency cone and
all left invariants term by term. In the certified stiff regime, replace
the sum by the positive equilibrium projector \(R_0C\).

## Ghost-remap revision

A scalar or componentwise positivity limiter is not sufficient for
polarization. The accepted high-order ghost remap projects the full
\((I,Q,U)\) field onto the intersection of the local Lorentz cones and the
six matrix number/energy constraints.

## Remaining distinction

The exponential action has been validated on an exact paired-energy grid.
The fixed-grid high-order ghost remap has been validated separately.
Their fully fused production implementation is the next gate.
