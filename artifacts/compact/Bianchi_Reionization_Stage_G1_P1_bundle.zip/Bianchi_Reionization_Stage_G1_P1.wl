(* ::Package:: *)

(*
  Bianchi Reionization Stage G1/P1

  Canonical conventions:
    metric signature (-,+,+,+)
    epsilon_123 = +1
    Q+i U <-> spin s=+2
    Q-i U <-> spin s=-2

  Accepted architecture:
    1. noncommuting Bianchi-I CF4 characteristic;
    2. exact screen/Jones differential transport with polar retraction;
    3. matrix-valued high-order ghost remap followed by projection onto
       (affine matrix number/energy constraints) intersected with the
       local coherency Lorentz cones;
    4. finite-tilt paired-grid direct-six-moment Thomson generator
         L x = -D x + U (V x);
    5. matrix-free invariant/cone-preserving exponential action by
       uniformization, with a stiff null-projector branch.

  Core Wolfram blocks were executed separately. This file consolidates the
  accepted formulas and implementation skeleton.
*)

ClearAll["Global`*"];
$MaxExtraPrecision = 5000;

(* ---------------------------------------------------------------------- *)
(* A. CF4 characteristic and exact screen/Jones transport                 *)
(* ---------------------------------------------------------------------- *)

c1 = 1/2 - Sqrt[3]/6;
c2 = 1/2 + Sqrt[3]/6;
a1 = (3 - 2 Sqrt[3])/12;
a2 = (3 + 2 Sqrt[3])/12;

CF4Matrix[K_, t_, h_, c_:1] := Module[{K1, K2, B1, B2},
  K1 = K[t + c1 h];
  K2 = K[t + c2 h];
  B1 = -c h (a1 K1 + a2 K2);
  B2 = -c h (a2 K1 + a1 K2);
  MatrixExp[B1].MatrixExp[B2]
];

DirectionDot[K_, k_, c_:1] :=
  -c (IdentityMatrix[3] - Outer[Times, k, k]).K.k;

ScreenGenerator[K_, k_, c_:1] := Module[{kd},
  kd = DirectionDot[K, k, c];
  Outer[Times, kd, k] - Outer[Times, k, kd]
];

ScreenRetract[q_, Sraw_] := Module[{k, P, T, G, S},
  k = Normalize[q];
  P = IdentityMatrix[3] - Outer[Times, k, k];
  T = P.Sraw;
  G = Transpose[T].T;
  S = T.MatrixPower[G, -1/2];
  If[Det[Transpose[{S[[All, 1]], S[[All, 2]], k}]] < 0,
    S[[All, 2]] = -S[[All, 2]]
  ];
  S
];

CF4RetractedStep[K_, t_, h_, q_, S_, c_:1] := Module[
  {K1, K2, B1, B2, E1, E2, qg1, qg2, O1, O2,
   C1, C2, qmid, qnew, Smid, Snew},
  K1 = K[t + c1 h];
  K2 = K[t + c2 h];
  B1 = -c h (a1 K1 + a2 K2);
  B2 = -c h (a2 K1 + a1 K2);
  E1 = MatrixExp[B1];
  E2 = MatrixExp[B2];

  qg1 = CF4Matrix[K, t, c1 h, c].q;
  qg2 = CF4Matrix[K, t, c2 h, c].q;
  O1 = ScreenGenerator[K[t + c1 h], Normalize[qg1], c];
  O2 = ScreenGenerator[K[t + c2 h], Normalize[qg2], c];

  C1 = h (a1 O1 + a2 O2);
  C2 = h (a2 O1 + a1 O2);

  qmid = E2.q;
  qnew = E1.qmid;
  Smid = ScreenRetract[qmid, MatrixExp[C2].S];
  Snew = ScreenRetract[qnew, MatrixExp[C1].Smid];
  {qnew, Snew}
];

(* Jones components stay constant in the transported screen basis. *)
SpatialCoherency[S_, J_] := S.J.ConjugateTranspose[S];

(* ---------------------------------------------------------------------- *)
(* B. Matrix-valued high-order ghost remap                                *)
(* ---------------------------------------------------------------------- *)

(*
  Store each real, linearly polarized 2x2 coherency block by
      x_j = {I_j,Q_j,U_j},
  with the local Lorentz-cone constraint
      I_j >= Sqrt[Q_j^2+U_j^2].

  The high-order candidate is projected onto the intersection of:
    - all local coherency cones;
    - six global affine constraints:
        sum I, sum Q, sum U,
        sum E I, sum E Q, sum E U.
*)

ConeProjectCell[v_] := Module[{t = v[[1]], x = v[[2 ;; 3]], r},
  r = Norm[x];
  Which[
    r <= t, v,
    r <= -t, {0., 0., 0.},
    True, Join[{(r + t)/2}, ((r + t)/(2 r)) x]
  ]
];

ConeProject[z_, n_Integer] :=
  Flatten[ConeProjectCell /@ Partition[z, 3]];

MomentConstraintMatrix[energy_List] := Module[
  {n = Length[energy], A},
  A = ConstantArray[0., {6, 3 n}];
  Do[
    A[[1, 3 j - 2]] = 1;
    A[[2, 3 j - 1]] = 1;
    A[[3, 3 j]] = 1;
    A[[4, 3 j - 2]] = energy[[j]];
    A[[5, 3 j - 1]] = energy[[j]];
    A[[6, 3 j]] = energy[[j]],
    {j, n}
  ];
  A
];

AffineProject[z_, A_, b_] :=
  z + Transpose[A].LinearSolve[A.Transpose[A], b - A.z];

DykstraConeAffine[
  high_List, energy_List, targetMoments_List,
  maxIterations_:20000, tolerance_:10^-11
] := Module[
  {n = Length[high], A, x, p, q, y, xnew, k = 0,
   affineResidual = Infinity, coneMargin = -Infinity},
  A = MomentConstraintMatrix[energy];
  x = Flatten[high];
  p = 0 x;
  q = 0 x;
  Do[
    k = iter;
    y = AffineProject[x + p, A, targetMoments];
    p = x + p - y;
    xnew = ConeProject[y + q, n];
    q = y + q - xnew;
    x = xnew;
    If[Mod[iter, 20] == 0,
      affineResidual = Norm[A.x - targetMoments, Infinity];
      coneMargin = Min@Table[
        x[[3 j - 2]] - Norm[x[[{3 j - 1, 3 j}]]],
        {j, n}
      ];
      If[Max[affineResidual, -coneMargin] < tolerance, Break[]]
    ],
    {iter, maxIterations}
  ];
  <|
    "State" -> Partition[x, 3],
    "Iterations" -> k,
    "AffineResidual" -> Norm[A.x - targetMoments, Infinity],
    "ConeMargin" -> Min@Table[
      x[[3 j - 2]] - Norm[x[[{3 j - 1, 3 j}]]],
      {j, n}
    ]
  |>
];

(*
  The low-order positive remap supplies a feasible targetMoments vector.
  A cubic, number-and-energy-corrected remap supplies the high-order
  candidate. Outer energy bands are full coherency ghost cells, not four
  scalar escape counters.
*)

(* ---------------------------------------------------------------------- *)
(* C. Paired-grid finite-tilt direct-six-moment Thomson operator           *)
(* ---------------------------------------------------------------------- *)

(*
  The validation operator uses electron-frame angular nodes k_e,p and
  angle-dependent normal energies E_n,p,j = E_e,j / D_p, where
      D_p = 1/[Gamma_e (1+v_e.k_e,p)].
  This is an exact paired-grid reference: it is energy-coupled from the
  normal-frame viewpoint but needs no interpolation inside the collision
  exponential.
*)

PatchReferenceAxis[k_] :=
  IdentityMatrix[3][[First @ Ordering[Abs[k], 1]]];

PatchScreenBasis[k_] := Module[{e1},
  e1 = Normalize[Cross[PatchReferenceAxis[k], k]];
  {e1, Cross[k, e1]}
];

SymPack[m_] :=
  {m[[1,1]], m[[2,2]], m[[3,3]], m[[1,2]], m[[1,3]], m[[2,3]]};

SymUnpack[z_] := {
  {z[[1]], z[[4]], z[[5]]},
  {z[[4]], z[[2]], z[[6]]},
  {z[[5]], z[[6]], z[[3]]}
};

MomentEmbed6[k_] := Module[{b, e1, e2, bI, bQ, bU},
  b = PatchScreenBasis[k];
  {e1, e2} = b;
  bI = (Outer[Times, e1, e1] + Outer[Times, e2, e2])/2;
  bQ = (Outer[Times, e1, e1] - Outer[Times, e2, e2])/2;
  bU = (Outer[Times, e1, e2] + Outer[Times, e2, e1])/2;
  Transpose[{SymPack[bI], SymPack[bQ], SymPack[bU]}]
];

MomentReconstruct36[k_] := Module[{b, e1, e2, P, m, F},
  b = PatchScreenBasis[k];
  {e1, e2} = b;
  P = Outer[Times, e1, e1] + Outer[Times, e2, e2];
  Transpose@Table[
    m = SymUnpack[UnitVector[6, r]];
    F = (3/2) P.m.P;
    {
      e1.F.e1 + e2.F.e2,
      e1.F.e1 - e2.F.e2,
      2 e1.F.e2
    },
    {r, 6}
  ]
];

(*
  Build the maps V and U by energy bin:
      m_j = V_j x,
      in_j = U_j m_j.
  The generator is matrix-free:
      LAction[x] = -DVector x + U.(V.x).
*)

LAction[data_, x_] :=
  -data["DVector"] x + data["U"].(data["V"].x);

(* ---------------------------------------------------------------------- *)
(* D. Invariant- and cone-preserving exponential action                   *)
(* ---------------------------------------------------------------------- *)

(*
  Choose nu >= Max[DVector] and define
      T = I + L/nu.
  If U V is a positive in-scattering map, T is a positive map.
  If C L = 0, then C T = C.

  Uniformization:
      exp(h L)x = exp(-mu) Sum_n mu^n/n! T^n x,
      mu = nu h.

  Renormalizing a truncated positive Poisson sequence makes the discrete
  action preserve C exactly while retaining positivity. In the stiff
  branch, use the positive equilibrium projector R0.C.
*)

TAction[data_, nu_, x_] :=
  x + LAction[data, x]/nu;

UniformizationAction[
  data_, nu_, h_, x_,
  tolerance_:10^-14, maximumTerms_:10000
] := Module[
  {mu = nu h, term = x, probability, probabilitySum, y, n = 0},
  probability = Exp[-mu];
  probabilitySum = probability;
  y = probability term;
  While[1 - probabilitySum > tolerance && n < maximumTerms,
    n++;
    term = TAction[data, nu, term];
    probability = probability mu/n;
    y += probability term;
    probabilitySum += probability;
  ];
  <|
    "State" -> y/probabilitySum,
    "Terms" -> n,
    "TailBound" -> 1 - probabilitySum
  |>
];

HybridInvariantExponentialAction[
  data_, nu_, h_, x_, gap_,
  tolerance_:10^-14, moderateMu_:50
] := Module[{mu = nu h, threshold},
  threshold = Log[1/tolerance];
  Which[
    gap h >= threshold,
      <|
        "State" -> data["RightNull"].(data["Invariants"].x),
        "Branch" -> "StiffProjector",
        "TailBound" -> Exp[-gap h]
      |>,
    mu <= moderateMu,
      Append[
        UniformizationAction[data, nu, h, x, tolerance],
        "Branch" -> "Uniformization"
      ],
    True,
      Module[{m = Ceiling[mu/moderateMu], state = x, r},
        Do[
          r = UniformizationAction[
            data, nu, h/m, state, tolerance/m
          ];
          state = r["State"],
          {m}
        ];
        <|
          "State" -> state,
          "Branch" -> "SubsteppedUniformization",
          "Substeps" -> m
        |>
      ]
  ]
];

(* ---------------------------------------------------------------------- *)
(* E. Stress-energy exchange ledger                                       *)
(* ---------------------------------------------------------------------- *)

(*
  With paired-grid invariants c_p = w_e,p/D_p and electron energies E_j:
      Q_e^0 = Sum_j E_j Sum_p c_p Delta I_p / h,
      Q_e^i = Sum_j E_j Sum_p c_p k_e,p^i Delta I_p / h.
  The accepted exponential action gave Q_e^0=0 and hence
      u_e.Q_n=0
  after the inverse Lorentz boost. Always set Q_b=-Q_gamma.
*)

Print["Stage G1/P1 consolidated definitions loaded."];
