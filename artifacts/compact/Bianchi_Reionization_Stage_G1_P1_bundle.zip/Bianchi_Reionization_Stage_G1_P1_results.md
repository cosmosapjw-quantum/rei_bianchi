# Bianchi Reionization — Stage G1/P1

## Verdict

\[
\boxed{
\text{G1/P1}
=
\text{PARTIAL PASS WITH PAIRED-GRID EXPONENTIAL REFERENCE}
}
\]

The main new result is an invariant- and coherency-cone-preserving
matrix-free exponential action for the finite-tilt direct-six-moment
Thomson generator

\[
L=-D+UV.
\]

The action was validated on the exact paired-energy grid, where a common
electron energy bin corresponds to angle-dependent normal-frame energies.
The fixed-grid high-order ghost remap was separately upgraded to a
matrix-valued cone projection, but has not yet been inserted inside the
exponential action.

## 1. CF4 characteristic plus per-substep polar retraction

The coupled noncommuting Bianchi-I characteristic and screen/Jones step
retained fourth-order convergence after a polar retraction was applied
after each CF4 exponential.

Observed orders for \(q\):

```text
4.0112261, 4.0027940, 4.0008308, 4.0025125, 4.0390914
```

Observed orders for the screen:

```text
4.0116033, 4.0028767, 4.0008379, 4.0024835, 4.0379632
```

The maximum orthogonality and transversality residuals were

\[
1.33\times10^{-15},\qquad
1.11\times10^{-16}.
\]

This closes the monolithic retraction-order gate left open in G1/P0.

## 2. Matrix-valued PSD-preserving high-order ghost remap

The state in each energy cell is represented by

\[
x_j=(I_j,Q_j,U_j),
\qquad
I_j\ge\sqrt{Q_j^2+U_j^2}.
\]

A cubic number-and-energy-corrected remap gives the high-order candidate.
It is then projected by Dykstra's method onto the intersection of:

1. every local coherency Lorentz cone;
2. the six affine constraints preserving
   \[
   \sum I,\sum Q,\sum U,\sum EI,\sum EQ,\sum EU.
   \]

For resolved smooth spectra:

| \(N_y\) | low-order error | projected high-order error | moment residual |
|---:|---:|---:|---:|
| 64 | \(1.1477\times10^{-3}\) | \(3.0644\times10^{-5}\) | \(1.78\times10^{-15}\) |
| 128 | \(3.6723\times10^{-4}\) | \(2.5304\times10^{-6}\) | \(5.33\times10^{-15}\) |
| 256 | \(1.3349\times10^{-4}\) | \(2.3397\times10^{-7}\) | \(7.11\times10^{-15}\) |

The last two observed orders were approximately

\[
3.60,\qquad3.43.
\]

In an adversarial nearly rank-one spectrum, the raw cone margin was

\[
-4.1860\times10^{-3},
\]

whereas the projected margin was zero to roundoff, with

\[
\|\Delta M_{\rm affine}\|_\infty
=
6.04\times10^{-14}
\]

and a \(1.29\%\) relative correction.

At \(N_y=32\), the projection did not reach the affine tolerance after
4000 iterations. The implementation must fail closed and fall back to
the low-order positive remap or enlarge the ghost domain in this case.

## 3. Invariant-preserving exponential action

Let

\[
\nu\ge\max_iD_i,
\qquad
T=I+\frac{L}{\nu}.
\]

For the accepted direct-six-moment construction, \(T\) is a positive map
on the product coherency cone. If \(C L=0\), then

\[
C T=C.
\]

The uniformization formula is

\[
e^{hL}x
=
e^{-\mu}
\sum_{n=0}^{\infty}
\frac{\mu^n}{n!}T^n x,
\qquad
\mu=\nu h.
\]

Every term preserves the cone and invariants. The truncated positive
Poisson sequence is normalized to unit sum, so the implemented action
preserves invariants exactly up to floating-point arithmetic.

The validation operator had

\[
N_{\rm state}=84,\qquad
N_{\rm moment}=12,
\]

and Doppler range

\[
0.53742848\le\mathcal D_p\le1.81306072.
\]

Residuals:

\[
\|CL\|_\infty=1.03\times10^{-17},
\]

\[
\|LR_0\|_\infty=2.25\times10^{-16},
\]

\[
\|CR_0-I\|_\infty=0.
\]

The minimum coherency eigenvalue after one application of
\(T=I+L/\nu\), scanned over fully polarized impulses, was

\[
-5.55\times10^{-17},
\]

consistent with roundoff.

Against `MatrixExp`, the matrix-free uniformization action gave:

| \(h\) | relative error | Poisson terms for tail \(<10^{-14}\) |
|---:|---:|---:|
| 0.1 | \(3.21\times10^{-16}\) | 9 |
| 1 | \(3.65\times10^{-16}\) | 20 |
| 5 | \(4.53\times10^{-16}\) | 40 |
| 20 | \(5.78\times10^{-16}\) | 91 |

All output cone minima were positive.

## 4. Stiff branch

The measured nonzero spectral gap was

\[
g=0.2344274997.
\]

For

\[
g h\ge\log(1/\varepsilon)
\]

the action switches to the positive equilibrium projector

\[
P_0=R_0C.
\]

At \(h=50\),

\[
\frac{\|e^{50L}x-P_0x\|}{\|P_0x\|}
=
9.13\times10^{-7}.
\]

The projector itself preserved invariants to

\[
2.22\times10^{-16}
\]

and had a minimum coherency eigenvalue

\[
0.50219946.
\]

For intermediate steps too large for a single Poisson sum but not yet
asymptotic, repeated moderate-\(\mu\) uniformization steps preserve both
the cone and invariants.

## 5. Stress-energy exchange

For a nontrivial finite-tilt state, the integrated electron-frame
four-force was

\[
Q_{\gamma,e}^{\mu}
=
\left(
5.08\times10^{-17},
-0.01248307,
0.00939508,
0.00141010
\right).
\]

Thus the Thomson electron-frame energy transfer vanished to roundoff.
After the inverse boost,

\[
u_e\cdot Q_\gamma
=
-5.11\times10^{-17},
\]

and with

\[
Q_b^\mu=-Q_\gamma^\mu
\]

the total exchange residual was exactly zero in the implemented ledger.

## 6. Temporal order

The newly combined CF4 characteristic, screen transport and per-exponential
retraction is fourth order.

The second-order CF4–exponential Strang gate from G1/P0 is retained. The
new uniformization action agrees with `MatrixExp` to at most
\(5.8\times10^{-16}\) over the tested moderate-step range, far below the
temporal truncation errors of that gate. Therefore replacing the dense
exponential by the accepted action does not change the verified
second-order result at the tested tolerance.

A fresh full fixed-grid radiation sweep, with the high-order ghost remap
inside every exponential action, remains open.

## Final architecture

\[
\boxed{
G^{\rm CF4,retracted}_{h/2}
\;
\mathcal E^{\rm inv+cone}_{hL_{\rm Th}}
\;
G^{\rm CF4,retracted}_{h/2}
}
\]

where \(\mathcal E^{\rm inv+cone}\) is:

- normalized Poisson uniformization for moderate \(\nu h\);
- repeated moderate uniformization for the intermediate regime;
- the positive null-space projector for the certified stiff regime.

## Open gates

1. Insert the fixed-grid matrix-valued ghost remap inside the exponential
   action instead of using the paired-grid reference.
2. Certify a production lower bound for the nonzero spectral gap.
3. Repeat the complete time/energy/angular convergence study at
   production angular resolution.
4. Replace the dense validation matrices by pure matrix-free `D`, `U`,
   `V`, remap and screen actions.
