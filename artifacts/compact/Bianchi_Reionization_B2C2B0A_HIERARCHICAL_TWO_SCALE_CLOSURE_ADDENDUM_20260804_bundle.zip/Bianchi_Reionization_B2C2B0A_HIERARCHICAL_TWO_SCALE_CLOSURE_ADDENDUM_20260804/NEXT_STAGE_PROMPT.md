@Web+Wolfram Stage P0.5-B2C2B0A-HIERARCHICAL-TWO-SCALE-OPACITY-CHEMISTRY-CLOSURE-LOCK를 실행해줘.

B2C2A-R1의 canonical current-Gamma direct-opacity operator,
CANONICAL_DIRECT_REEVOLVED history, B2C0 phase-space full-OTS kernel,
B2C1A/B transmission/allocation operators, P0.4 density/z_re/Gamma
conventions, exact-zero primary G3, FLRW receipts, neutral-island exclusion과
recombination external-dependency receipt를 정본으로 유지한다.

기존 flat joint index (Delta,T,z_re)는 사용하지 마. P0.4 density는
box-scale environment이고 B2C0 Delta는 local gas overdensity이므로
hierarchical two-scale measure를 구성해줘.

1. 계산 전에 새 durable B2C2B0A directory, input lock, stage state,
   receipts, manifest와 SHA256SUMS를 생성해줘.

2. macro index

   J=(i_D_L,i_zre)

   와 micro index

   I=(i_Delta_sub,i_T)

   를 분리해줘.

   Delta_total = D_L Delta_sub.

3. macro weights W_J는 P0.4 locked large-scale density quadrature,
   conditional z_re history와 global-opacity convention을 사용해줘.

4. 각 macro node에서 micro weights w_(I|J)를 만들고

   Sum_I w_(I|J)=1,
   Sum_I w_(I|J) Delta_sub,I=1

   을 보장해줘.

5. baseline micro closure는

   P(Delta_sub,T|D_L,z_re)
     = P_B2C0(Delta_sub,T)

   로 두되 modeling assumption임을 명시해줘.

   다음 sensitivity auditors를 분리해줘.

   A. macro-density-dependent subgrid variance
   B. T-z_re cooling-age correlation
   C. deterministic vs Beta/Dirichlet ionization moments

6. 모든 local atomic/recombination rate에는

   Delta_total = D_L Delta_sub

   를 사용해줘.

7. 13.6--39.5 eV의 effective H I emulator opacity는 macro-level
   absolute hazard로 유지하고 local atomic H I와 더하지 마.

   kappa_HI,eff,J,g

   를 micro nodes에 배분할 때 다음 conditional shape lanes를 사용해줘.

   A. LOCAL_NEUTRAL_HAZARD_PRIMARY
   B. RECOMBINATION_WEIGHTED_AUDITOR
   C. SCRIPT_SELF_SHIELDING_AUDITOR

   q_HI_(I|J,g)
     = w_(I|J) s_(I|J,g) /
       Sum_M w_(M|J) s_(M|J,g).

   모든 lane에서 macro H I absorption sum은 동일해야 하며, 이
   normalization은 macro opacity fit이 아니라 disaggregation identity다.

8. explicit He I/He II와 high-energy H I opacity는 micro node에서 직접
   계산하고 weighted average해줘. R1 firewall과 threshold support를
   유지해줘.

9. 같은 hierarchical nodes에서 full-OTS chemistry source를 계산해줘.

   S_rec,J,I^OTS
     = S_rec^OTS(D_L Delta_sub,T,y_JI),

   S_rec^global
     = Sum_J W_J Sum_I w_(I|J) S_rec,J,I^OTS.

10. photon allocation hierarchy를

    group -> macro environment -> micro node -> species

    순으로 구성하고

    Sum_(J,I,s) j_abs_(J,I,s,g)
      = Ndot_abs,g

    를 relative error <1e-10으로 검증해줘.

11. IPF/KL projection은 consistent marginals에만 사용해줘.

    - incompatible shared marginal을 IPF로 억지로 고치지 마.
    - structural zero support를 보존해줘.
    - uniform seed와 physical seed의 entropy/KL 의미를 구분해줘.
    - marginal correction norm과 KL change를 저장해줘.

12. 현재 z=6--5.5 primary measure-evolution policy는

    FIXED_WEIGHT_LAGRANGIAN_MACRO_MICRO_PARCELS

    로 잠가줘.

    dot W_J = 0,
    dot w_(I|J) = 0.

    redshift마다 PDF를 재생성하고 dot W storage term을 버리는 구현은
    fail closed해줘.

13. 다음 hard gates를 적용해줘.

    |Sum_J W_J-1| < 1e-12,
    max_J |Sum_I w_(I|J)-1| < 1e-12,

    |Sum_(J,I) W_J w_(I|J) D_L Delta_sub -1| < 1e-10,

    R1 global opacity reproduction <1%,

    B2C0 full-OTS source reproduction <1% in the homogeneous macro-density
    limit,

    node photon allocation residual <1e-10,

    threshold support exact zero,

    primary G3/external HeII exact zero.

14. Wolfram으로 hierarchical normalization, macro/micro allocation sums,
    full-OTS stoichiometry, proper/comoving units와 exact-zero support를
    검증해줘.

    Precise Special Functions는 lognormal/power-law closed moments의
    high-precision oracle로만 사용해줘.

15. 이번 B2C2B0A에서는 history re-evolution, unresolved-sink subtraction,
    front allocation, Q_M growth, source/f_esc calibration, primordial
    recombination implementation, primitive geometry transplant와 Bianchi
    feedback을 시작하지 마.

hierarchical closure가 닫힌 뒤에만
P0.5-B2C2B0B-MATCHED-PHASESPACE-HISTORY-LOCK를 승인해줘.
