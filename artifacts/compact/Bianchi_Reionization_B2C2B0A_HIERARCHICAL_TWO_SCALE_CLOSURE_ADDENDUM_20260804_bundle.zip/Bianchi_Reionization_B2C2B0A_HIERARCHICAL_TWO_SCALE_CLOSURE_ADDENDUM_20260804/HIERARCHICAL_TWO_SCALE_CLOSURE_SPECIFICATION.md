# Hierarchical two-scale opacity–chemistry closure specification

## 1. Distinct density variables

Let

\[
D_L=1+\delta_{L,\rm NL}
\]

be the macro/box-scale nonlinear density factor used by the P0.4 opacity
response.

Let

\[
\Delta_{\rm sub}
\]

be local gas overdensity relative to the macrocell mean, normalized by

\[
\sum_I w_{I|J}\Delta_{{\rm sub},I}=1.
\]

The cosmic-mean local density factor entering atomic and recombination rates
is

\[
\boxed{
\Delta_{\rm tot}=D_L\Delta_{\rm sub}.
}
\]

The global volume weights satisfy

\[
W_{J,I}=W_Jw_{I|J},
\]

\[
W_J\ge0,\quad w_{I|J}\ge0,
\]

\[
\sum_JW_J=1,\qquad
\sum_Iw_{I|J}=1,
\]

\[
\sum_{J,I}W_{J,I}\Delta_{{\rm tot},J,I}=1.
\]

## 2. Macro measure

The macro index

\[
J=(i_L,i_{z_{\rm re}})
\]

uses the locked P0.4 conventions:

- large-scale density quadrature/mapping;
- conditional \(P(z_{\rm re}\mid{\rm ionized},z,D_L)\);
- PUBLIC central-Gamma anchor;
- raw dimensionless current-Gamma response;
- no extrapolation.

The MFP emulator is interpreted as a macro-environment effective H I opacity

\[
\bar\kappa_{{\rm HI,eff},J,g}.
\]

It is not treated as a local gas-density PDF.

## 3. Conditional micro measure

The local index

\[
I=(i_{\rm sub},i_T)
\]

uses the B2C0 finite phase-space domain and conditional temperature/
ionization closure.

Baseline:

\[
P(\Delta_{\rm sub},T\mid D_L,z_{\rm re})
=
P_{B2C0}(\Delta_{\rm sub},T).
\]

This conditional-independence lane is a least-informative baseline, not a
physical theorem.

Sensitivity lanes must include:

1. macro-density-dependent subgrid variance;
2. \(T-z_{\rm re}\) correlation/cooling-age dependence;
3. deterministic versus Beta/Dirichlet ionization moments.

The local rate evaluation uses

\[
n_H^{\rm proper}
=
\bar n_H^{\rm proper}D_L\Delta_{\rm sub}.
\]

## 4. Do not double count effective H I opacity

At \(13.6\)--\(39.5\) eV the emulator already represents unresolved H I
absorption inside the macro environment.

Therefore one must not add

\[
\bar\kappa_{\rm HI,eff}
+
\sum_Iw_{I|J}\kappa_{{\rm HI,atom},I}.
\]

Instead, the macro effective H I hazard is disaggregated over micro nodes using
a nonnegative shape kernel \(s_{I|J,g}\):

\[
q^{\rm HI}_{I|J,g}
=
\frac{w_{I|J}s_{I|J,g}}
{\sum_Mw_{M|J}s_{M|J,g}},
\]

\[
\sum_Iq^{\rm HI}_{I|J,g}=1.
\]

The total macro H I absorption remains exactly anchored:

\[
\sum_I
\dot N_{{\rm abs,HI},J,I,g}
=
\dot N_{{\rm abs,HI},J,g}^{\rm emulator}.
\]

This is a conditional disaggregation, not a fit of the macro opacity.

Required shape lanes:

### A. `LOCAL_NEUTRAL_HAZARD_PRIMARY`

\[
s_{I|J,g}
\propto
n_{{\rm HI},I}\bar\sigma_{{\rm HI},g}
\mathcal F_{I,g}.
\]

### B. `RECOMBINATION_WEIGHTED_AUDITOR`

\[
s_{I|J,g}
\propto
\alpha_H(T_I)
\langle n_en_{\rm HII}\rangle_I.
\]

### C. `SCRIPT_SELF_SHIELDING_AUDITOR`

A local density/self-shielding shape consistent with the SCRIPT-style sink
closure.

Macro H I opacity is identical in all lanes; only the unresolved micro
allocation changes.

## 5. Explicit helium and high-energy atomic opacity

Explicit He I/He II and high-energy H I opacity are evaluated directly at
micro nodes and averaged:

\[
\bar\kappa_{s,J,g}
=
\sum_Iw_{I|J}\kappa_{s,J,I,g}.
\]

The R1 energy firewall remains unchanged.

Primary G3 source and external He II photoionization remain exactly zero.

## 6. Full-OTS chemistry on the same hierarchical nodes

Each micro node carries

\[
y_{J,I}
=
(x_{\rm HII},x_{\rm HeII},x_{\rm HeIII},u)_{J,I}.
\]

Full-OTS source:

\[
S_{{\rm rec},J,I}^{\rm OTS}
=
S_{\rm rec}^{\rm OTS}
(D_L\Delta_{\rm sub},T,y).
\]

Macro and global sources are

\[
S_{{\rm rec},J}^{\rm phase}
=
\sum_Iw_{I|J}S_{{\rm rec},J,I}^{\rm OTS},
\]

\[
S_{\rm rec}^{\rm global}
=
\sum_JW_JS_{{\rm rec},J}^{\rm phase}.
\]

## 7. Photon allocation hierarchy

First distribute group photons among macro environments:

\[
q_{J,g}
=
\frac{W_J\bar\kappa_{J,g}}
{\sum_KW_K\bar\kappa_{K,g}}.
\]

Then distribute effective H I absorption inside \(J\) with
\(q^{\rm HI}_{I|J,g}\), while explicit atomic components use their direct
micro hazards.

Species allocation follows the B2C1B finite-optical-depth operator.

Hard identity:

\[
\sum_{J,I,s}
j^{\rm abs}_{J,I,s,g}
=
\dot N_{{\rm abs},g}.
\]

## 8. Marginal fitting and IPF policy

IPF is used only after the macro and micro variables are correctly separated.

- If marginal constraints are consistent, IPF/minimum-KL projection may fit a
  positive joint table.
- If the shared marginal constraints are infeasible, IPF is not a repair.
  The incompatible marginal definitions must be corrected or conservatively
  remapped first.
- Structural zero support is preserved. If a target marginal requires mass in
  a forbidden cell, fail closed.
- A uniform seed gives a maximum-entropy table; a physical seed gives the
  minimum-discrimination/KL projection relative to that seed.

The baseline hierarchical product measure should require no nontrivial IPF
correction once its marginal definitions are consistent.

## 9. Measure evolution policy

The primary future history lane is

```text
FIXED_WEIGHT_LAGRANGIAN_MACRO_MICRO_PARCELS
```

for the current \(z=6\to5.5\) slice.

\[
\dot W_J=0,\qquad \dot w_{I|J}=0.
\]

Species and thermal states evolve on the fixed parcels. This prevents a hidden
\(\dot W\) storage term.

An Eulerian remap remains a future auditor and must include explicit
weight-flux ledgers.

## 10. B2C2B0A hard gates

Normalization:

\[
\left|\sum_JW_J-1\right|<10^{-12},
\]

\[
\max_J\left|\sum_Iw_{I|J}-1\right|<10^{-12},
\]

\[
\left|
\sum_{J,I}W_Jw_{I|J}D_L\Delta_{\rm sub}-1
\right|<10^{-10}.
\]

Macro opacity:

\[
\frac{
|\sum_JW_J\bar\kappa_{J,g}-\bar\kappa_g^{R1}|
}{
\bar\kappa_g^{R1}
}
<1\%.
\]

Full-OTS source:

\[
\frac{
\|S_{\rm rec}^{\rm hierarchical}-S_{\rm rec}^{B2C0}\|
}{
\|S_{\rm rec}^{B2C0}\|
}
<1\%
\]

for the homogeneous macro-density limit, with the finite macro-density lane
reported separately rather than forced to match.

Photon allocation:

\[
q\ge0,\qquad
\sum_{J,I,s}j^{\rm abs}_{J,I,s,g}
=
\dot N_{{\rm abs},g}
\]

to relative error below \(10^{-10}\).

Threshold support and primary G3/external-HeII exact zero remain hard gates.

No history evolution or unresolved subtraction is allowed in B2C2B0A.
