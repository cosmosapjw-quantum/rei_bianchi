# B2C2B0A hierarchical two-scale closure addendum

## Superseding correction

The previous flat node proposal

\[
I=(i_\Delta,i_T,i_{z_{\rm re}})
\]

conflated two physically different density variables:

1. the P0.4 mean-free-path emulator's **box-scale density**, measured for
   small high-resolution simulation boxes;
2. the B2C0 chemistry kernel's **local gas overdensity**, which controls
   recombination and thermal rates inside an unresolved region.

The corrected closure is hierarchical.

\[
J=(i_L,i_{z_{\rm re}})
\]

labels a macro environment, while

\[
I=(i_{\rm sub},i_T)
\]

labels a local subgrid state inside that environment.

The full node is

\[
K=(J,I)
=
(i_L,i_{z_{\rm re}},i_{\rm sub},i_T).
\]

## Immediate decision

\[
\boxed{
\texttt{
P0.5-B2C2B0A-
HIERARCHICAL-TWO-SCALE-
OPACITY-CHEMISTRY-CLOSURE-LOCK
}
}
\]

replaces the earlier flat-joint B2C2B0A prompt.

No matched history, unresolved sink or front allocation is computed in this
stage.
