# Source lock

1. **Tohfa et al.**, arXiv:2602.03923.
   The MFP emulator predicts mean free path as a function of wavelength,
   redshift, local reionization redshift, photoionization rate and
   **box-scale density**, and can serve as a subgrid opacity prescription.

2. **Sadain et al.**, arXiv:2606.18382.
   Recombination is organized in joint local overdensity-temperature-
   ionization phase space and depends on conditional ionization moments.

3. **Choudhury & Chakraborty**, arXiv:2504.03384v2.
   SCRIPT dynamically links large-scale density, subgrid recombinations,
   self-shielding, mean free path and photoionization rate.

4. **Mellema et al.**, arXiv:astro-ph/0508416.
   Photon depletion by opacity must equal the corresponding photoionizations.

5. **Friedrich et al.**, arXiv:1201.0602.
   H/He multifrequency opacity, thermal evolution and full coupled OTS
   chemistry must be evaluated consistently.

6. **Loukas & Chung**, arXiv:2204.03406.
   IPF estimates the maximum-entropy distribution under consistent categorical
   marginal constraints. In a nonuniform physical seed formulation it is
   interpreted as a minimum-discrimination/KL projection.

7. **Fienberg**, An Iterative Procedure for Estimation in Contingency Tables.
   IPF convergence and structural-zero considerations motivate fail-closed
   support handling.

The two density scales are not identified with each other.
