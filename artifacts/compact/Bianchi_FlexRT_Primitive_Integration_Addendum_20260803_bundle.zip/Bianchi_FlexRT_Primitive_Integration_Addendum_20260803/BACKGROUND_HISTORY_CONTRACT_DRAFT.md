# BackgroundHistory / GeometryBackend contract draft

## Scope

This is a design boundary for the future transplant of `bianchibianchic2` into the Full Bianchi–FlexRT/CAMB-level homogeneous reionization solver. It does **not** transplant or modify the primitive code. The geometry remains an immutable backend/oracle until the reionization state and coupling interfaces are frozen.

## Conventions

- Metric signature: `(-,+,+,+)`.
- Spatial Levi-Civita symbol: `epsilon_123=+1`.
- Primitive frame-rotation convention: `COMMUTATOR`.
- Geometry time chart: Hubble-normalized `tau`; all reionization operators consume baryon proper time `t` and physical lengths.
- All floating-point geometry interfaces require binary64 or stronger reference precision.

## Architecture

```text
GeometryBackend
  -> BackgroundHistory
       -> BackgroundSnapshot(t)
       -> dense interpolation receipt
  -> ReionizationOperator
       -> ReionizationState
       -> Absorption/Maintenance/Front ledgers
  -> MatterSource
       {Omega, q_a, Pi_ab, Q_energy, Q_momentum}
  -> coupled geometry step
```

The reionization operator must never mutate a Bianchi chart state directly. It returns a `MatterSource`; a geometry integrator applies that source through a separately tested coupling adapter.

## GeometryBackend interface

```python
class GeometryBackend(Protocol):
    def initial_state(self, model: ModelSpec) -> GeometryState: ...
    def rhs_tau(self, tau: float, state: GeometryState,
                source: MatterSource) -> GeometryDerivative: ...
    def constraints(self, state: GeometryState) -> ConstraintReceipt: ...
    def snapshot(self, tau: float, state: GeometryState) -> BackgroundSnapshot: ...
```

The primitive archive supplies the initial differential oracle for this interface. Rust acceleration is deferred until the Python oracle and coupling tests are frozen.

## BackgroundSnapshot

Required fields:

```text
snapshot_id / content_sha256
model_id, Bianchi_type, chart_id, branch_id
provenance: source archive hash, solver/version, tolerance receipt

tau                         dimensionless Hubble-normalized time
t                           baryon proper time [s]
ell                         mean length scale [cm]
H                           expansion rate [s^-1]
Theta = 3 H                 [s^-1]

Sigma_ab                    orthonormal-frame shear [s^-1] or normalized + H
N_ab, A_a, R_a              commutation/frame variables with convention tags
constraint_receipt          residuals and projection status

E_alpha^i, e^alpha_i        tetrad/co-tetrad maps
Omega_alpha                 frame angular velocity [s^-1]

u_baryon^a, u_electron^a    unit timelike 4-velocities
beta_baryon^alpha,
beta_electron^alpha         frame tilts
gamma_baryon,
gamma_electron              Lorentz factors

metric_signature            (-,+,+,+)
epsilon_123                 +1
rotation_convention         COMMUTATOR
```

A snapshot may expose both dimensional and Hubble-normalized variables, but every field must state its unit and normalization.

## BackgroundHistory

```python
class BackgroundHistory(Protocol):
    def snapshot_at_t(self, t_s: float) -> BackgroundSnapshot: ...
    def snapshot_at_tau(self, tau: float) -> BackgroundSnapshot: ...
    def interval(self, t0_s: float, t1_s: float) -> BackgroundInterval: ...
    def receipt(self) -> HistoryReceipt: ...
```

The dense interpolant must preserve:

- the accepted chart/branch;
- constraint projection provenance;
- monotone proper time;
- positive `H` and `ell` on the accepted interval;
- interpolation error estimates for all fields consumed by radiative transfer.

## ReionizationState

The state stays independent of geometry:

```text
N_gamma,g or coherency bins
x_HII, x_HeI, x_HeII, x_HeIII
u_thermal / T_b
Gamma_HI, Gamma_HeI, Gamma_HeII
Q_V, Q_M and topology/history state
component opacity and photon ledgers
Jacobian / branch receipt
```

## MatterSource

```python
@dataclass(frozen=True)
class MatterSource:
    Omega: float
    q_alpha: Array[3]
    Pi_alpha_beta: Array[3,3]
    Q_energy: float
    Q_momentum_alpha: Array[3]
    species_receipt: str
```

`Q_energy` and `Q_momentum_alpha` represent exchange between radiation and matter and must close with the corresponding photon four-force. `Pi_ab` is dynamical output of the coupled state; the primitive `general_matter` prescribed-Pi chart remains an auditor until this interface is active.

## Immediate B2C2A compatibility receipt

B2C2A remains an FLRW/homogeneous absorption-decomposition stage. It should add only:

```text
background_snapshot_id
background_snapshot_sha256
background_model = FLRW_CONTROL
proper_time_start_s / proper_time_end_s
H_start_s^-1 / H_end_s^-1
ell_start_cm / ell_end_cm
```

No Bianchi feedback is enabled in PR 2. This receipt makes the photon ledger forward-compatible with PR 4/5 without contaminating the current science gate.

## Primitive reference regressions reserved for PR C0

The context survey created six read-only geometry fixtures over `z=6 -> 5.5`:

- Bianchi I dust
- Bianchi II dust
- Bianchi VI_0 dust
- Bianchi V dust
- Bianchi VI_h with kappa=-4
- constrained tilted class B dust

Constraint/identity residuals are between approximately `1e-16` and `1e-21`. These become adapter regressions only after the BackgroundHistory contract is implemented.

## Non-goals before interface freeze

- No direct insertion of full-OTS/FlexRT variables into every chart RHS.
- No replacement of the current reionization solver by primitive Saha/Peebles routines.
- No Rust hot-path transplant.
- No claim that archive PR documents equal verified Git history.
- No use of the primitive single-fluid tilted chart as the final multifluid state.
