@Web+Wolfram Stage P0.5-B2C2A-IONIZED-ABSORPTION-DECOMPOSITION-LOCK를 실행해줘.

B2C1C의 exact-zero primary G3 support, primary HeIII decay state,
B2C1B direct finite-tau multigroup H/He operator, B2C1A global/F-selected Q
firewall, B2C0 phase-space maintenance kernel와 B2B causal photon history를
정본으로 유지한다.

추가 설계 입력으로 업로드된 `bianchibianchic2` primitive code의
GeometryBackend/BackgroundHistory 구조를 참고하되, 이번 단계에서는
primitive geometry code를 이식하거나 Bianchi feedback을 켜지 마.

1. 계산 전에 새 durable B2C2A directory, input lock, stage state,
   receipts, manifest와 SHA256SUMS를 생성해줘.

2. 이번 stage의 background는 `FLRW_CONTROL`로 유지하되, 모든 interval
   ledger row에 다음 forward-compatible provenance를 추가해줘.

   background_snapshot_id,
   background_snapshot_sha256,
   background_model,
   proper_time_start_s, proper_time_end_s,
   H_start_s^-1, H_end_s^-1,
   ell_start_cm, ell_end_cm.

   이 receipt는 향후 BackgroundHistory adapter를 위한 것이며 현재의
   absorption 수치나 source term을 변경하지 않는다.

3. group별 ionized-phase absorption을 causal photon history에서

   Ndot_abs,ion,g^c =
     (1/Delta t) Integral c kappa_tot,g(t) N_gamma,g^c(t) dt

   로 직접 계산해줘. Photon storage, group-boundary redshift flux,
   ionized absorption과 neutral-front absorption을 분리해줘.

4. opacity component firewall을 다음처럼 고정해줘.

   - 13.6--39.5 eV: P0.4 effective HI opacity가 H-I absorber component의
     정본이다. Explicit diffuse atomic HI opacity를 다시 더하지 마.
   - threshold가 허용되는 HeI/HeII atomic opacity는 별도 component로 유지.
   - 39.5 eV 초과: explicit Verner HI/HeI/HeII high-energy lane.
   - primary G3 source/absorption은 exact zero.
   - neutral-island transfer는 ionized unresolved sink에 넣지 마.

5. 각 group에서 component hazard를 사용해

   A_(s,g) =
     Integral phi_g(E)[1-exp(-tau_tot)] tau_(s,g)/tau_tot dE /
     Integral phi_g(E)[1-exp(-tau_tot)] dE

   를 계산하고, direct 64-node reference와 production quadrature를
   비교해줘.

   A>=0, Sum_s A_(s,g)=1, threshold-zero exact,
   direct/production mismatch <1%를 gate로 사용해줘.

6. species/group absorption table

   Ndot_abs,ion,s,g^c = A_(s,g) Ndot_abs,ion,g^c

   를 생성하고, 모든 component의 provenance를
   EFFECTIVE_HI / EXPLICIT_HI / EXPLICIT_HEI / EXPLICIT_HEII로 표시해줘.

7. causal absorption과 FlexRT-style cell deposition auditor를 독립적으로
   비교해줘. FlexRT의 adaptive ray/opacity 구조는 알고리즘적 참고로만
   사용하고, homogeneous one-zone에서 비교 가능한 photon deposition
   limit만 구현해줘. 상대차 <1%를 engineering gate로 사용해줘.

8. 다음 항목은 이번 B2C2A에서 계산하지 마.

   - Ndot_unresolved = Ndot_abs - Ndot_maint subtraction
   - front를 residual로 정의하는 작업
   - source/f_esc calibration
   - primitive geometry transplant
   - Bianchi feedback

9. symbolic/Wolfram gates:

   - group-boundary redshift flux telescoping
   - component allocation sum
   - no-double-count firewall
   - proper/comoving dimensional conversion
   - primary G3 and HeII external absorption exact zero.

10. Precise Special Functions는 power-law group moments, analytic
    optical-depth limits 또는 hypergeometric/incomplete-beta 형태가 실제로
    존재하는 경우의 high-precision oracle로 사용해줘. Production finite-tau
    operator는 direct numerical quadrature를 정본으로 유지해줘.

B2C2A가 통과한 뒤에만 B2C2B에서

Ndot_unresolved,s,g^c =
  Ndot_abs,ion,s,g^c - Ndot_maint,diffuse,s,g^c

를 계산하고 음수 component를 fail closed해줘.
