# Primitive-integration addendum

This addendum contains two planning artifacts derived from the read-only survey of the uploaded `bianchibianchic2` primitive archive:

1. `BACKGROUND_HISTORY_CONTRACT_DRAFT.md`: the interface boundary for later geometry transplantation.
2. `B2C2A_AUGMENTED_NEXT_STAGE_PROMPT.md`: the immediate B2C2A prompt with forward-compatible background receipts but no Bianchi coupling.

It intentionally contains no modified primitive source code.
