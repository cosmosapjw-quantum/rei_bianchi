@Web+Wolfram Stage P0.5-B2C2B0-PHASESPACE-CHEMISTRY-ABSORPTION-MATCHED-CLOSURE-LOCK를 실행해줘.

B2C2A-R1의 canonical operator
PUBLIC_ANCHORED_RAW_GAMMA_RESPONSE_DIRECT_ENERGY_GROUP,
CANONICAL_DIRECT_REEVOLVED history, exact-zero primary G3,
physical-component absorption, numerical-residual registry, FLRW receipts,
neutral-island exclusion과 recombination external-dependency receipt를
정본으로 유지한다.

이번 단계는 unresolved sink를 계산하는 B2C2B가 아니라, 그 전제인
matched transport-chemistry closure를 잠그는 B2C2B0이다.

1. 새 durable B2C2B0 directory, input lock, stage state, receipts,
   manifest와 SHA256SUMS를 계산 전에 생성해줘.

2. 기존 R1 history는 HOMOGENEOUS_CHEMISTRY_AUDITOR로 강등하고,
   새 canonical history를 z=6에서 재진화해줘. 두 history를 섞지 마.

3. B2C0 phase-space full-OTS source를

   S_rec^phase(t)
     = Integral dDelta dT P_V(Delta,T)
         S_rec^OTS(Delta,T;t)

   로 계산하고, homogeneous recombination source에 더하지 말고
   대체해줘.

4. H Beta 및 He Dirichlet conditional moments, finite Delta-T domain,
   full-OTS opacity fractions와 B2C0 direct/coarse convergence gate를
   유지해줘.

5. R1 physical group/component absorption에서 species photoionization
   event rates를 photon-conservingly 구성해줘.

   j_s,g^abs =
     A_s,g^direct Ndot_abs,g,

   Sum_s j_s,g^abs = Ndot_abs,g,

   threshold 아래 support는 exact zero로 둬.

6. Chemistry source는 independent gamma_s n_s approximation과
   photon-conserving absorption source를 동시에 더하지 마.
   다음 두 lane을 분리해줘.

   A. PHOTON_CONSERVING_COMPONENT_SOURCE_PRIMARY
   B. LEGACY_GAMMA_SPECIES_AUDITOR

7. 새 canonical species evolution에서

   dn/dt =
     B j_abs + S_rec^phase + S_coll

   을 사용하고, H/He nuclei, positivity, thermal energy와 photon-number
   ledger를 닫아줘.

8. 각 interval에서 transition-space identity를 검증해줘.

   B(j_abs - m_ext^phase)
     = dn/dt - S_coll

   relative residual <1e-8,
   target <1e-10.

9. Preflight regression을 fitting 없이 재현해줘.

   - 기존 R1 explicit HeI absorption:
     6.95e48--8.21e48 s^-1 cMpc^-3
   - homogeneous HeI maintenance와의 비:
     0.99285--1.00806
   - phase-space HeI maintenance는 homogeneous보다:
     3.71--3.86 배

   이 차이가 새 coupled history에서 동역학적으로 해소되는지 판정해줘.

10. Phase-space maintenance를 켰을 때 Gamma_HI, Gamma_HeI, T_b,
    x_HII, x_HeII와 photon reservoirs가 바뀌므로 z=6부터 모두 다시
    진화해줘. Legacy/R1 state를 interval 중간에 splice하지 마.

11. FlexRT finite-cell deposition과 differential hazard를 새 history에서
    다시 검증하고 smallest-cell error <1%, first-order refinement를
    요구해줘.

12. Wolfram으로 stoichiometric identity, full-OTS nucleus conservation,
    species/group allocation sum과 exact-zero G3/HeII를 검증해줘.
    Precise Special Functions는 닫힌 analytic limit에만 사용해줘.

13. 이번 B2C2B0에서는

    Ndot_unresolved = Ndot_abs - Ndot_maint

    를 아직 계산하지 마. Front allocation, Q_M growth, source/f_esc,
    recombination implementation, primitive geometry transplant와 Bianchi
    feedback도 시작하지 마.

새 phase-space-coupled canonical history에서 absorption, chemistry,
maintenance와 species storage가 한 ledger로 닫힌 뒤에만
P0.5-B2C2B-UNRESOLVED-SINK-CLOSURE-LOCK를 다시 승인해줘.
