# Why subtraction requires a matched closure

For transition rates \(j_{\rm ext}\), full-OTS maintenance \(m_{\rm ext}\),
stoichiometric matrix \(B\), and species state \(n\),

\[
\dot n
=
B(j_{\rm ext}-m_{\rm ext})
+
\dot n_{\rm coll}
+
\dot n_{\rm front}.
\]

An unresolved sink cannot be inferred from \(j_{\rm ext}-m_{\rm ext}\)
unless both rates were evaluated on the same state distribution and the
storage, collisional and front terms are explicitly accounted for.

The present R1 history uses homogeneous chemistry. The B2C0 phase-space
kernel instead evaluates conditional moments over \(P_V(\Delta,T)\), raising
He I maintenance by a factor \(3.71\)--\(3.86\) relative to the homogeneous
event algebra at the same global state.

The next stage must therefore replace—not add to—the homogeneous
recombination source with the phase-space-averaged full-OTS source and
re-evolve the history before any unresolved-sink subtraction.
