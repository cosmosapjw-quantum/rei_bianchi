# Source lock

Primary literature used for this decision:

1. Mellema et al., **C2-Ray: A new method for photon-conserving transport of
   ionizing radiation**, arXiv:astro-ph/0508416.
   Photon depletion by bound-free opacity must equal the photoionizations
   caused by those photons.

2. Friedrich et al., **Radiative transfer of energetic photons: X-rays and
   helium ionization in C2-Ray**, arXiv:1201.0602.
   Multi-species photoionization, optical depth and full coupled OTS chemistry
   are solved consistently; helium recombination photons couple H and He
   through relative opacity fractions.

3. Choudhury & Chakraborty, **Capturing Small-Scale Reionization Physics:
   A Sub-Grid Model for Photon Sinks with SCRIPT**, arXiv:2504.03384v2.
   Emissivity, clumping, mean free path and photoionization rate require a
   self-consistent shared density/sink closure.

4. Cain & D'Aloisio, **FlexRT I: Code validation**, arXiv:2409.04521.
   Adaptive transport and flexible IGM opacity support a modular opacity
   backend, but chemistry and absorption must still share a photon ledger.

No literature value was fitted to the numerical preflight.
