# B2C2B matched-closure preflight

## Decision

\[
\boxed{
\text{B2C2B as previously written}
=
\texttt{NOT\ AUTHORIZED}
}
\]

The R1 opacity/absorption stage remains a durable pass. The new blocker lies
in the proposed subtraction

\[
\dot N_{\rm unresolved}
=
\dot N_{\rm abs}
-
\dot N_{\rm maint}^{\rm phase-space}.
\]

The canonical R1 history was evolved with homogeneous full-OTS chemistry,
whereas the proposed maintenance term uses the later phase-space
density/temperature closure. These are not the same physical trajectory.

## Preflight result

For H I, R1 absorption exceeds Jeans-selected diffuse maintenance by

\[
2.43\times10^{50}
\text{--}
3.37\times10^{50}
\ {\rm s^{-1}\,cMpc^{-3}}.
\]

A positive unresolved H I sink is therefore plausible.

For He I,

\[
\dot N_{\rm abs,HeI}
=
(6.95\text{--}8.21)\times10^{48},
\]

while phase-space full-OTS maintenance is

\[
\dot N_{\rm maint,HeI}^{\rm phase}
=
(2.69\text{--}3.07)\times10^{49}
\ {\rm s^{-1}\,cMpc^{-3}}.
\]

Every tested interval gives

\[
\dot N_{\rm abs,HeI}
-
\dot N_{\rm maint,HeI}^{\rm phase}
=
-(1.99\text{--}2.25)\times10^{49}.
\]

This is not evidence for a negative physical sink.

At the same canonical midpoint states, homogeneous full-OTS maintenance is

\[
(6.95\text{--}8.26)\times10^{48},
\]

and explicit He I absorption agrees with it within approximately 1%:

\[
0.99285
\le
\frac{\dot N_{\rm abs,HeI}}
{\dot N_{\rm maint,HeI}^{\rm homogeneous}}
\le
1.00806.
\]

Phase-space He I maintenance exceeds the matched homogeneous value by

\[
3.71\text{--}3.86.
\]

## Interpretation

The R1 trajectory has not yet been re-evolved with the B2C0 phase-space
recombination/maintenance closure. Subtracting that closure afterward combines

- transport and chemistry from one trajectory, and
- clumped maintenance from another.

The negative He I result is a closure mismatch, not an unresolved sink.

## Required next stage

\[
\boxed{
\texttt{
P0.5-B2C2B0-
PHASESPACE-CHEMISTRY-ABSORPTION-
MATCHED-CLOSURE-LOCK
}
}
\]

This stage must insert the phase-space full-OTS source into chemistry and
thermal evolution, re-evolve from \(z=6\), and prove that absorbed photons,
species photoionizations, full-OTS maintenance and species storage belong to
one trajectory.

Only after that gate closes should unresolved-sink subtraction be attempted.
