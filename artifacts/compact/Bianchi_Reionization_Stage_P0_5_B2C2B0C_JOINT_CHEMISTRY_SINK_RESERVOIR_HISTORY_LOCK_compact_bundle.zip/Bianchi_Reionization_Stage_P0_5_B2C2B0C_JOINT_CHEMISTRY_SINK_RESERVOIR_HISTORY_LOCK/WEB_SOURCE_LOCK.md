# Web source lock

- Choudhury & Chakraborty, arXiv:2504.03384: SCRIPT links emissivity,
  clumping, mean free path, photoionization rate and density dynamically.
- Mellema et al., arXiv:astro-ph/0508416: photon depletion must equal the
  photoionizations caused by those photons.
- Friedrich et al., arXiv:1201.0602: multifrequency H/He opacity, full OTS
  chemistry and thermal evolution form one coupled non-equilibrium system.
- Cain & D'Aloisio, arXiv:2409.04521: FlexRT provides adaptive transport and
  a flexible opacity backend.
- Nasir et al., arXiv:2108.04837: self-shielding sinks evolve through pressure
  smoothing/photoevaporation over roughly 10--300 Myr and span characteristic
  sizes/columns; used only as an external scale auditor.
- Sobacchi & Mesinger, arXiv:1402.2298: inhomogeneous recombinations and
  ionizing-background feedback are dynamically tracked.

No literature value is fitted to this stage.
