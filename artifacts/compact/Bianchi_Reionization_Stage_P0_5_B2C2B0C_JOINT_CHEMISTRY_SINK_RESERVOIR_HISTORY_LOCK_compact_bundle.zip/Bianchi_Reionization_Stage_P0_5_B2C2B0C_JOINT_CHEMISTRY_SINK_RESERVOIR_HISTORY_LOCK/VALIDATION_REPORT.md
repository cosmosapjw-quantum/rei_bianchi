# Validation report

## Decision

The reduced two-reservoir DAE passes, but the requested node-resolved
B2C2B0C history does not.

| Reduced gate | Maximum residual |
|---|---:|
| nonlinear solve | 6.706e-10 |
| complementarity | 6.706e-10 |
| diffuse H nuclei | 3.865e-11 |
| sink H nuclei | 4.725e-11 |
| diffuse H thermal | 1.594e-11 |
| sink H thermal | 1.102e-11 |
| opacity | 3.018e-16 |
| R1 photon ledger | 2.931e-10 |
| FlexRT smallest cell | 2.468e-05 |

The requested hard scope remains open for node-resolved H/He chemistry,
node thermal states, full H/He thermal energy, independently evolved shape
and sensitivity lanes, finite-rate sink relaxation, and formal temporal
convergence. A single timestep halving changes the most sensitive endpoint
quantity by 1.29%.

B2C2B is therefore not authorized.
