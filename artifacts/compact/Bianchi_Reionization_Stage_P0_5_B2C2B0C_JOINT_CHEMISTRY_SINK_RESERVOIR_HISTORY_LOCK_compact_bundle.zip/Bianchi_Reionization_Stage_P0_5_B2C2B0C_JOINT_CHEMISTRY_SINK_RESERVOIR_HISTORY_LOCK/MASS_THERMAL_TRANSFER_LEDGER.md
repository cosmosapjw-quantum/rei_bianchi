# Mass and thermal transfer ledger

\[
\frac{|N_{H,diff}+N_{H,sink}-N_H|}{N_H}
\le 0.000e+00.
\]

Diffuse and sink H-nuclei residuals are

\[
3.865e-11,
\qquad
4.725e-11.
\]

The reduced H-only thermal residuals are

\[
1.594e-11,
\qquad
1.102e-11.
\]

Active quasi-static mass-transfer timescales span roughly

\[
10.23\text{--}925.09\;\mathrm{Myr}.
\]

The transfer is algebraically conservative, but no independent finite-rate
condensation/photoevaporation law has been locked. Helium heating/cooling is
also absent from the reduced thermal model.
