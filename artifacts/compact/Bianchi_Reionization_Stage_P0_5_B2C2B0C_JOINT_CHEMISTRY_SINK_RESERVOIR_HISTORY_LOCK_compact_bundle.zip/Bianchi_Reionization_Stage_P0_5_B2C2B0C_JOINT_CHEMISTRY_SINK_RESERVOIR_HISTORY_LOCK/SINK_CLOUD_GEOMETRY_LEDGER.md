# Sink cloud geometry ledger

The reduced cloud population spans

\[
n_H=1.336e-03\text{--}2.544e-03
\;\mathrm{cm^{-3}},
\]

\[
R=11.51\text{--}15.81
\;\mathrm{proper\,kpc},
\]

\[
N_{\rm HI}=5.806e+17\text{--}9.111e+17
\;\mathrm{cm^{-2}}.
\]

Cloud abundance is

\[
0.943\text{--}1.840
\;\mathrm{cMpc^{-3}},
\]

and the sink contains

\[
0.0957\text{--}0.2165
\]

of cosmic H, with volume filling fraction below

\[
9.358e-03.
\]

These establish geometric feasibility only; they are not a calibrated
absorber population.
