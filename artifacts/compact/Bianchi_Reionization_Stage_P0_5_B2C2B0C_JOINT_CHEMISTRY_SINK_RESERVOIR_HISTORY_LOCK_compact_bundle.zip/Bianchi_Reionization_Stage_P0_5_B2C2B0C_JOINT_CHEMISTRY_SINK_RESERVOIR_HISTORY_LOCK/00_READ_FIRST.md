# Stage P0.5-B2C2B0C — Joint chemistry/sink reservoir history

## Verdict

\[
\boxed{\text{Reduced global two-reservoir DAE}=\texttt{PASS}}
\]

\[
\boxed{\text{Requested node-resolved B2C2B0C}=\texttt{FAIL\ CLOSED}}
\]

\[
\boxed{\text{B2C2B}=\texttt{NOT\ AUTHORIZED}}
\]

A simultaneous diffuse/sink opacity partition removes the capacity blocker
without clipping. The reduced model closes photon, opacity, H nuclei and
H-only thermal ledgers and establishes a feasible self-shielded cloud
population.

It does not evolve the B2C2B0A parcel states. The shape lanes are macro
redistributions of one global history, helium thermal terms are absent, and
sink relaxation is quasi-static. Hence the exact acceptance condition is not
met.

The sink receives 40.87%--
54.75% of total H absorption,
contains 9.57%--
21.65% of cosmic H, and has volume
filling below 9.358e-03.

Representative cloud ranges:

- density: 1.336e-03--2.544e-03 cm^-3;
- radius: 11.51--15.81 proper kpc;
- neutral column: 5.806e+17--9.111e+17 cm^-2.

Reduced conservation residuals are below 1e-9 and FlexRT refinement is first
order. The single timestep halving leaves a 1.29% maximum endpoint
change, so formal temporal order is not locked.

Next stage:

```text
P0.5-B2C2B0C-R1-NODE-RESOLVED-JOINT-CHEMISTRY-SINK-HISTORY-LOCK
```
