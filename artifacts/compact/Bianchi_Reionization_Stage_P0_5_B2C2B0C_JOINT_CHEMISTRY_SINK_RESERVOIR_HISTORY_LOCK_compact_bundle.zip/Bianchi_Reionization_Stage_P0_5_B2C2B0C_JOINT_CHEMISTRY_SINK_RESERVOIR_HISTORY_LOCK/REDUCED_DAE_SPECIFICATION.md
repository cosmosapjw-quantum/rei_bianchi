# Reduced diffuse/sink DAE specification and scope boundary

The R1 effective H I opacity is split as

\[
\kappa_{\rm HI}^{\rm eff}=\kappa_{\rm diff}+\kappa_{\rm sink},
\]

with simultaneous photon rates

\[
J_{\rm diff}=\frac{\kappa_{\rm diff}}{\kappa_{\rm tot}}J_{\rm tot},
\qquad
J_{\rm sink}=\frac{\kappa_{\rm sink}}{\kappa_{\rm tot}}J_{\rm tot}.
\]

A Fischer--Burmeister condition enforces nonnegative sink absorption and the
bounded diffuse ionization complementarity. The sink is a quasi-static
population of marginally self-shielded Jeans-scale spherical clouds whose
column determines the group opacity.

This is a **global two-reservoir DAE existence proof**. It is not the full
B2C2B0A node-resolved history: individual parcel H/He and thermal states are
not evolved, helium thermal terms are absent, and cloud abundance follows an
instantaneous algebraic opacity condition rather than a validated finite-rate
relaxation law.
