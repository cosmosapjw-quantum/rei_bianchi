# B2C2B0C state ledger

## Durable result

A global diffuse/sink DAE exists and closes reduced H/opacity ledgers. It is
an existence proof for a simultaneous dynamic sink channel.

## Claim boundary

`primary_joint_history.csv` contains global diffuse and sink states, not
individual B2C2B0A parcel histories. The three shape lanes are alternative
macro redistributions of the same global trajectory, not independently
integrated node histories.

Allowed claims: bounded complementarity solution; exact total-opacity and
photon partition; feasible self-shielded cloud geometry; reduced H nuclei and
H-only thermal ledgers.

Forbidden claims: node-resolved matched history completed; full H/He thermal
closure completed; absorber population calibrated; finite relaxation law
validated; B2C2B authorized.
