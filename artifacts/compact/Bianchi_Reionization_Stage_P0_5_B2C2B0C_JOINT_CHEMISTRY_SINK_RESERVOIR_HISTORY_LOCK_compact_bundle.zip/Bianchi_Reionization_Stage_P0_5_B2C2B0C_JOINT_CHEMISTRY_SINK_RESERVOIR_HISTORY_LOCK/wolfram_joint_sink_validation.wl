ClearAll["Global`*"];
kTot = kDiff + kSink;
partitionIdentity = FullSimplify[
 flux kDiff + flux kSink - flux kTot,
 Assumptions -> {flux >= 0, kDiff >= 0, kSink >= 0,
  kTot == kDiff + kSink}
];
phiFB[a_, b_] := Sqrt[a^2+b^2]-a-b;
fbCounterexample = Reduce[
 a >= 0 && b >= 0 && phiFB[a,b] == 0 && a b != 0,
 {a,b}, Reals
];
diffuseBalance = dHIIdiff - dt (Jdiff-Mdiff) + xtr dNsink;
sinkBalance = dHIIsink - dt (Jsink+Csink-Rsink) - xtr dNsink;
totalNucleiTransfer = Expand[diffuseBalance + sinkBalance];
diffuseEnergy = dUdiff - dt Qdiff + utr dNsink;
sinkEnergy = dUsink - dt Qsink - utr dNsink;
totalThermalTransfer = Expand[diffuseEnergy + sinkEnergy];
HPartition = FullSimplify[(Ndiff+Nsink-NH) /. Ndiff -> NH-Nsink];
primaryG3 = FullSimplify[NG3 rateG3 /. NG3 -> 0];
externalHeII = FullSimplify[NG3 rateHeII /. NG3 -> 0];
<|
 "PhotonPartitionIdentity" -> partitionIdentity,
 "FBNonzeroProductCounterexample" -> fbCounterexample,
 "TotalNucleiTransfer" -> totalNucleiTransfer,
 "TotalThermalTransfer" -> totalThermalTransfer,
 "HPartitionResidual" -> HPartition,
 "PrimaryG3" -> primaryG3,
 "ExternalHeII" -> externalHeII
|>
