from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'data'
res=json.loads((ROOT/'results.json').read_text())
assert res['verdict']=='DURABLE_PARTIAL_PASS_REDUCED_DAE_NODE_RESOLVED_GATE_FAIL'
assert res['reduced_two_reservoir_DAE']['status']=='NUMERICALLY_VALIDATED_EXISTENCE_PROOF'
assert res['B2C2B_authorization'] is False
assert res['next_stage'].endswith('NODE-RESOLVED-JOINT-CHEMISTRY-SINK-HISTORY-LOCK')

g=res['hard_reduced_model_gates']
assert g['solver_residual_max']<1e-8
assert g['complementarity_residual_max']<1e-8
assert g['diffuse_H_nuclei_residual_max']<1e-8
assert g['sink_H_nuclei_residual_max']<1e-8
assert g['diffuse_H_thermal_residual_max']<1e-8
assert g['sink_H_thermal_residual_max']<1e-8
assert g['H_partition_nuclei_residual_max']<1e-12
assert g['helium_simplex_residual_max']<1e-12
assert g['diffuse_capacity_deficit_max']<=0
assert g['HI_partition_residual_max']<1e-10
assert g['photon_ledger_residual_max']<1e-8
assert g['opacity_residual_max']<1e-10
assert g['flexrt_smallest_cell_error_max']<0.01
assert 0.8<g['flexrt_order_range'][0]<1.2
assert 0.8<g['flexrt_order_range'][1]<1.2

hist=pd.read_csv(D/'primary_joint_history.csv')
led=pd.read_csv(D/'primary_joint_ledger.csv')
assert hist.x_diffuse.between(0,1).all()
assert hist.x_sink.between(0,1).all()
assert hist.x_HeII.between(0,1).all()
assert hist.x_HeIII.between(0,1).all()
assert (hist.x_HeII+hist.x_HeIII<=1+1e-12).all()
assert (hist.T_diffuse>0).all() and (hist.T_sink>0).all()
assert (hist.N_sink>0).all()
for c in ['complementarity_residual','diffuse_H_nuclei_residual_relative','sink_H_nuclei_residual_relative','diffuse_thermal_residual_relative','sink_thermal_residual_relative']:
    assert led[c].abs().max()<1e-8
assert led.H_partition_nuclei_residual_relative.abs().max()<1e-12
assert led.helium_simplex_residual.abs().max()<1e-12
assert (led.diffuse_capacity_deficit<=0).all()
assert (led.max_sink_opacity_fraction<=1+1e-8).all()
assert (led.sink_volume_filling<=1).all()
assert led.opacity_residual_max.abs().max()<1e-10

ph=pd.read_csv(D/'joint_photon_ledger.csv')
assert ph.HI_partition_residual.abs().max()<1e-10
assert ph.relative_photon_ledger_residual.abs().max()<1e-8
assert ph.total_transport_history_reused_exactly.all()

flex=pd.read_csv(D/'flexrt_diffuse_sink_refinement.csv')
small=(flex.sort_values('delta_chi_cMpc').groupby(['interval_index','group','component']).first())
small=small[small.differential_rate.abs()>1]
assert small.relative_difference.max()<0.01
orders=flex.observed_order.dropna()
assert orders.min()>0.8 and orders.max()<1.2

scope=pd.read_csv(D/'requested_scope_compliance_audit.csv')
status=dict(zip(scope.requirement,scope.status))
assert status['node_resolved_H_He_chemistry']=='MISSING'
assert status['node_resolved_thermal_history']=='MISSING'
assert status['full_H_He_thermal_ledger']=='PARTIAL'
assert status['three_micro_shape_lanes_global_history']=='PARTIAL'
assert status['formal_temporal_order']=='PARTIAL'

shape=pd.read_csv(D/'shape_lane_dynamic_equivalence.csv')
assert shape.global_sink_rate_relative_difference.max()<1e-12
assert set(shape.auditor)=={'RECOMBINATION_WEIGHTED_AUDITOR','SCRIPT_SELF_SHIELDING_AUDITOR'}

conv=pd.read_csv(D/'dt_halving_endpoint_comparison.csv')
assert conv.relative_difference.max()>0.01
assert res['temporal_audit']['formal_order_established'] is False

sym=json.loads((ROOT/'symbolic_joint_sink_results.json').read_text())
assert sym['status']=='PASS_EQUIVALENT_SYMBOLIC_CHECKS'
assert sym['PhotonPartitionIdentity']=='0'
assert sym['HPartitionResidual']=='0'
assert sym['PrimaryG3']==0 and sym['ExternalHeII']==0

w=json.loads((ROOT/'WOLFRAM_EXECUTION_STATUS.json').read_text())
assert w['native_executable_available'] is False
assert w['native_crosscheck_pending'] is True
p=json.loads((ROOT/'PRECISE_SPECIAL_FUNCTIONS_EXECUTION_STATUS.json').read_text())
assert p['plugin_namespace_available'] is False
assert p['production_operator_replaced'] is False

state=json.loads((ROOT/'STAGE_STATE.json').read_text())
assert state['status']=='DURABLE_PARTIAL_PASS_REDUCED_DAE_NODE_RESOLVED_GATE_FAIL'
assert state['B2C2B_authorized'] is False

# Ensure no node-resolved or full matched history is falsely present.
for forbidden in ['node_resolved_joint_history.csv','full_HHe_node_thermal_history.csv','unresolved_sink.csv','front_allocation.csv']:
    assert not (D/forbidden).exists()

print('P0.5-B2C2B0C verification: REDUCED DAE PASS; NODE-RESOLVED GATE FAIL-CLOSED; B2C2B NOT AUTHORIZED')
