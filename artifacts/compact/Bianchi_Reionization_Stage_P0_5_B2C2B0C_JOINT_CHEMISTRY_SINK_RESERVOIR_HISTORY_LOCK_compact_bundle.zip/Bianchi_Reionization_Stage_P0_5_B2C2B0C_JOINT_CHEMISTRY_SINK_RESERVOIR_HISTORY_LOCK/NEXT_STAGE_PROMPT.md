@Web+Wolfram Stage P0.5-B2C2B0C-R1-NODE-RESOLVED-JOINT-CHEMISTRY-SINK-HISTORY-LOCK를 실행해줘.

B2C2B0A의 fixed-weight macro/micro parcels, R1 total opacity and photon
history, B2C2B0C reduced complementarity solution, sink-cloud geometry
existence proof, exact-zero primary G3, FLRW receipts, neutral-island exclusion
및 recombination external-dependency receipt를 정본으로 유지한다.

이번 R1은 global two-reservoir DAE를 node-resolved history로 승격하는
단계다. 현재 reduced history를 full node history로 오인하지 마.

1. 계산 전에 새 durable directory, input lock, stage state, receipts,
   manifest와 SHA256SUMS를 생성해줘.
2. 모든 fixed macro/micro parcel에서 N_H, x_HII, x_HeII, x_HeIII와 u/T를
   실제로 진화하고 dot W_J=dot w_I|J=0을 exact하게 유지해줘.
3. Sink를 최소 macro-resolved reservoir로 승격하여 N_HI,sink,J,
   N_HII,sink,J, u_sink,J, kappa_sink,J,g를 진화해줘.
4. 각 macro/group에서 kappa_total=kappa_diffuse+kappa_sink를 exact하게
   닫고 total opacity에 free normalization을 fitting하지 마.
5. Photon deposition을 group -> macro -> diffuse/sink -> micro -> species
   순으로 photon-conservingly 배분해줘.
6. 각 diffuse node에서 full H/He OTS chemistry와 full H/He thermal source를
   사용해줘. Hydrogen-only reduced thermal model을 상속하지 마.
7. Sink에 recombination, collisional terms, photoheating, cooling, expansion,
   mass/energy transfer를 포함해줘.
8. Quasi-static baseline 외에 10, 100, 300 Myr finite relaxation/evaporation
   auditors를 fitting 없이 구성해줘.
9. LOCAL_NEUTRAL_HAZARD_PRIMARY, RECOMBINATION_WEIGHTED_AUDITOR,
   SCRIPT_SELF_SHIELDING_AUDITOR를 독립 node histories로 진화해줘.
10. Macro-density variance, early-cooler/hotter, Beta/Dirichlet sensitivity도
    동적으로 전파해줘.
11. 모든 lane에서 photon, H/He nuclei, full thermal energy, opacity와
    mass-transfer residual <1e-8, target <1e-10, nuclei <1e-12를 요구해줘.
12. dt, dt/2, dt/4로 temporal order와 Richardson/embedded error를 저장해줘.
13. FlexRT finite-cell refinement를 독립 shape histories마다 실행해줘.
14. R1 fixed-photon control과 total-opacity feedback auditor를 분리해줘.
15. Native Wolfram/Precise runtime이 없으면 pending을 유지하고 exact/high-
    precision fallback을 보존해줘.
16. 이번에도 post-hoc unresolved subtraction, front/Q_M, source/f_esc,
    primordial recombination, primitive geometry/Bianchi feedback은 시작하지 마.

모든 node-resolved lane과 temporal convergence가 닫힌 뒤에만
P0.5-B2C2B-UNRESOLVED-SINK-CLOSURE-LOCK를 승인해줘.
