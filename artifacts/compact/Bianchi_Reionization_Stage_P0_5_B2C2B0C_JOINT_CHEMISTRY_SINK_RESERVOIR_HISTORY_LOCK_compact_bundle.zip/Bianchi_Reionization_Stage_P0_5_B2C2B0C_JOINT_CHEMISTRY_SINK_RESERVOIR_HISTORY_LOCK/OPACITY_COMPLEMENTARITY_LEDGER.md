# Opacity complementarity ledger

Maximum nonlinear residual:

\[
6.706e-10.
\]

Maximum Fischer--Burmeister residual:

\[
6.706e-10.
\]

The sink receives

\[
0.4087
\text{--}
0.5475
\]

of total H absorption. The H partition and R1 photon-ledger residuals are

\[
\epsilon_{\rm partition}=0.000e+00,
\qquad
\epsilon_\gamma=2.931e-10.
\]

The maximum diffuse capacity deficit remains negative,

\[
-5.309e+42\;\mathrm{s^{-1}\,cMpc^{-3}}.
\]
