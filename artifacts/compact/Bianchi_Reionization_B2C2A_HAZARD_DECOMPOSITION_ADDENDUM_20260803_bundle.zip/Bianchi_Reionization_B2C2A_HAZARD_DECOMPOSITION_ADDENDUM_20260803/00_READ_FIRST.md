# B2C2A hazard-decomposition addendum

## Decision

The next stage remains

`P0.5-B2C2A-IONIZED-ABSORPTION-DECOMPOSITION-LOCK`,

but the primary absorption decomposition is now defined at the differential
hazard level. A finite-cell FlexRT deposition formula is an independent
refinement auditor, not the primary species decomposition.

## Primary differential decomposition

For comoving photon number in group g,

\[
\dot N_{{\rm abs},c,g}^{c}
=
\frac{c}{a}N_{\gamma,g}^{c}
\int_{G_g}dE\,\varphi_g(E)\,\kappa_c^{c}(E,t),
\]

where \(\int_{G_g}\varphi_g(E)dE=1\), and c labels opacity components.
The total is the component sum.

In the P0.4 emulator domain,

\[
\kappa_{\rm HI,eff}^{c}(E,z)=1/\lambda_{\rm P0.4}^{c}(E,z).
\]

For explicit atomic species,

\[
\kappa_{s,\rm atom}^{c}(E,t)
=
 a(t)n_s^{p}(t)\sigma_s(E)\,{\rm Mpc}_{\rm cm},
\]

so every opacity is in comoving Mpc inverse units before addition.

## Opacity firewall

- 13.6--39.5 eV: `EFFECTIVE_HI_SUBGRID` is the only H I component.
  Do not add explicit atomic H I again.
- Explicit He I is added only above 24.59 eV.
- Above 39.5 eV: use explicit atomic H I/He I/He II components.
- Primary G3 source and primary external He II absorption remain exact zero.
- Neutral-island transfer remains a separate component.
- Any difference between the inherited total ledger hazard and the sum of
  declared components is recorded as `UNATTRIBUTED_EFFECTIVE_RESIDUAL`; it is
  never silently renormalized into a species.

## FlexRT cell-deposition auditor

For comoving cell length \(\Delta\chi\),

\[
D_{c,g}(\Delta\chi)
=
\frac{c}{a\Delta\chi}N_{\gamma,g}^{c}
\int dE\,\varphi_g(E)
[1-e^{-\kappa_{\rm tot}^{c}(E)\Delta\chi}]
\frac{\kappa_c^{c}(E)}{\kappa_{\rm tot}^{c}(E)}.
\]

The audit must show

\[
D_{c,g}(\Delta\chi)
\to
\dot N_{{\rm abs},c,g}^{c}
\quad (\Delta\chi\to0).
\]

The smallest-cell discrepancy must be below 1%, with monotone/refinement
convergence. Equality at an arbitrary finite cell size is not required.

## External dependencies

Primordial recombination is external. B2C2A starts from the durable B2C1C
handoff and writes a `RECOMBINATION_EXTERNAL_DEPENDENCY_RECEIPT.json`.
No recombination equation or adapter is implemented here.

The uploaded primitive Bianchi code is used only to freeze the future
`BackgroundSnapshot` receipt schema. The B2C2A background is `FLRW_CONTROL`;
no Bianchi feedback or geometry transplant is permitted.

## Next gate

B2C2A performs no maintenance subtraction and no front calculation. Only after
it passes may B2C2B compute

\[
\dot N_{\rm unresolved,c,g}^{c}
=
\dot N_{\rm abs,ion,c,g}^{c}
-
\dot N_{\rm maint,diffuse,c,g}^{c}.
\]
