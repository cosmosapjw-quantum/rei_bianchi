# Absorption-decomposition specification

## 1. State and units

- Photon state: comoving photon number per cMpc^3.
- P0.4 MFP: comoving Mpc.
- Effective opacity: cMpc^-1.
- Atomic density: proper cm^-3.
- Atomic opacity is converted to cMpc^-1 before component addition.
- Loss coefficient in cosmic time:

\[
R_{\rm abs}=(c/a)\kappa^c.
\]

## 2. Energy support

Groups:

- G1: 13.60--24.59 eV
- G2a: 24.59--39.50 eV
- G2b: 39.50--54.42 eV
- G3: 54.42--100 eV

P0.4 has six locked energy nodes:

13.60, 14.48, 16.70, 20.05, 25.50, 39.50 eV.

Use monotone log-energy/log-opacity interpolation inside 13.6--39.5 eV.
No extrapolation beyond this domain.

## 3. Declared components

- `EFFECTIVE_HI_SUBGRID`
- `EXPLICIT_HI_ATOMIC`
- `EXPLICIT_HEI_ATOMIC`
- `EXPLICIT_HEII_ATOMIC`
- `UNATTRIBUTED_EFFECTIVE_RESIDUAL` (diagnostic/fail-closed component)
- `NEUTRAL_ISLAND_TRANSFER` (excluded from ionized absorption)

## 4. Primary group rate

With normalized within-group shape \(\varphi_g\),

\[
\bar\kappa_{c,g}^{c}
=
\int_{G_g}\varphi_g(E)\kappa_c^c(E)dE,
\]

\[
\dot N_{{\rm abs},c,g}^{c}
=
(c/a)N_{\gamma,g}^{c}\bar\kappa_{c,g}^{c}.
\]

The declared component sum must reproduce the inherited causal group
absorption rate. A residual is recorded explicitly; component rates are not
renormalized to conceal it.

## 5. Finite-cell auditor

Use the exact finite-cell deposition formula and a sequence
\(\Delta\chi_m=\Delta\chi_0/2^m\). Verify convergence to the differential
rate. Record observed order and all component allocations.

## 6. Background receipt

Every interval row stores:

- background_snapshot_id and SHA-256
- background_model = FLRW_CONTROL
- proper time endpoints
- Hubble endpoints
- mean length endpoints
- convention and unit tags

This schema is forward-compatible with the primitive `GeometryBackend` but
has no effect on B2C2A numerical physics.

## 7. Hard gates

- photon-ledger residual < 1e-10
- component-sum residual < 1e-8; target < 1e-10
- all declared hazards and rates nonnegative, except that an unattributed
  signed mismatch triggers fail-closed review
- threshold support exact
- primary G3 source/absorption exact zero
- finite-cell smallest-resolution discrepancy < 1%
- no maintenance subtraction
- no front residual
