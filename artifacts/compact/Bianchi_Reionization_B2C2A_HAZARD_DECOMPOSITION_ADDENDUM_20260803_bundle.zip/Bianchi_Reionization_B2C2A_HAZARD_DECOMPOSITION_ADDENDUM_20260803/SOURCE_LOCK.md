# Source lock

Primary external references:

- FlexRT Part I, JCAP 12 (2024) 025, arXiv:2409.04521.
  Adaptive rays compute cell optical depth and deposit photons accordingly;
  the IGM opacity treatment is deliberately flexible.
- Cain, D'Aloisio & Lopez, MNRAS 531 (2024) 1951.
  Explicit FlexRT methodology gives cell optical depth and deposited-photon
  formula using 1-exp(-tau).
- Choudhury & Chakraborty, JCAP 2025(10)114, arXiv:2504.03384.
  Clumping, MFP, photoionization rate and emissivity must be linked through a
  self-consistent sink model rather than treated as independent knobs.
- Tohfa et al., arXiv:2602.03923 (2026 preprint).
  MFP emulator predicts wavelength-, density-, Gamma- and reionization-history
  dependent ionized opacity and may be used as a subgrid opacity prescription.
- Mellema et al., arXiv:astro-ph/0508416.
  Photon-conserving transport equates bound-free photon loss with caused
  photoionizations.
- Friedrich et al., arXiv:1201.0602.
  H/He multifrequency and full-OTS species coupling.
- Roth et al., arXiv:2311.06348.
  Observationally inferred MFP may include both ionized-medium and neutral-
  island opacity; neutral-island transfer must remain explicit.

Local durable sources:

- P0.4 PUBLIC_REPO_EXACT six-energy MFP table.
- B2C1C exact-zero-G3 causal history and ledgers.
- B2C1B atomic support and direct finite-tau operator.
- Recombination externalization contract.
- Primitive BackgroundHistory contract draft.
