@Web+Wolfram Stage P0.5-B2C2A-IONIZED-ABSORPTION-DECOMPOSITION-LOCK를 실행해줘.

B2C1C의 exact-zero primary G3 state와 HeIII decay history,
B2C1B direct multigroup H/He operator, B2C1A Q firewall,
B2C0 phase-space maintenance kernel, B2B causal photon history를 정본으로
유지한다. Primordial recombination은 외부 프로젝트로 유지한다.

1. 계산 전에 새 durable B2C2A directory, input lock, stage state,
   receipts, manifest와 SHA256SUMS를 생성해줘.

2. `RECOMBINATION_EXTERNAL_DEPENDENCY_RECEIPT.json`을 만들고 다음을 잠가줘.

   dependency_status = EXTERNAL_NOT_LOADED,
   ownership = PRIMORDIAL_RECOMBINATION_ONLY,
   current_initial_state_source = B2C1C_DURABLE_HANDOFF,
   contains_astrophysical_reionization = false,
   forbidden_double_count = true.

   이번 stage에서는 recombination equation, surrogate 또는 adapter를
   구현하지 마.

3. Background는 FLRW_CONTROL로 유지하되 모든 interval row에

   background_snapshot_id,
   background_snapshot_sha256,
   background_model,
   proper_time_start_s, proper_time_end_s,
   H_start_s^-1, H_end_s^-1,
   ell_start_cm, ell_end_cm,
   convention_tag, unit_tag

   를 저장해줘. 업로드된 primitive Bianchi code는 receipt/interface
   설계 참고로만 사용하고 geometry transplant와 feedback은 금지한다.

4. P0.4 PUBLIC_REPO_EXACT table의 locked energy nodes

   {13.60,14.48,16.70,20.05,25.50,39.50} eV

   에서 lambda_density_cMpc를 사용해

   kappa_HI,eff^c(E,z)=1/lambda^c(E,z)

   를 구성해줘. 13.6--39.5 eV 내부에서는 monotone logE-logkappa
   interpolation만 허용하고 domain 밖 extrapolation은 fail closed해줘.

5. 모든 opacity를 comoving inverse length로 통일해줘.

   kappa_s,atom^c(E,t)
     = a(t) n_s^proper(t) sigma_s(E) Mpc_cm.

   cosmic-time loss coefficient는 (c/a) kappa^c다.

6. opacity component firewall을 다음처럼 고정해줘.

   - 13.6--39.5 eV:
     EFFECTIVE_HI_SUBGRID가 유일한 HI component다.
     explicit atomic HI를 다시 더하지 마.
   - HeI는 24.59 eV 이상에서 explicit component로 추가.
   - 39.5 eV 초과:
     EXPLICIT_HI_ATOMIC + EXPLICIT_HEI_ATOMIC + EXPLICIT_HEII_ATOMIC.
   - primary G3 source와 primary external HeII absorption은 exact zero.
   - neutral-island transfer는 ionized absorption에 넣지 마.
   - inherited total hazard와 declared component sum의 차이는
     UNATTRIBUTED_EFFECTIVE_RESIDUAL로 기록하고 species에 재정규화하지 마.

7. primary species/component decomposition을 arbitrary finite-cell allocation이
   아니라 differential hazard integral로 정의해줘.

   kappa_bar_(c,g)^c
     = Integral_Gg phi_g(E) kappa_c^c(E) dE,

   Ndot_abs,c,g^c
     = (c/a) N_gamma,g^c kappa_bar_(c,g)^c.

   phi_g는 B2C1B source-projected within-group shape closure를 사용하고,
   shape provenance를 저장해줘.

8. total group rate

   Ndot_abs,g^c = Sum_c Ndot_abs,c,g^c

   를 B2C1C causal absorption ledger와 비교해줘. 상대 residual <1e-8을
   hard gate, <1e-10을 target으로 사용해줘. 불일치를 조용히 rescale하지 마.

9. FlexRT-style cell deposition은 독립 auditor로 구현해줘.

   D_(c,g)(Delta chi)
     = [c/(a Delta chi)] N_gamma,g^c
       Integral phi_g(E)[1-exp(-kappa_tot^c Delta chi)]
       kappa_c^c/kappa_tot^c dE.

   Delta chi를 절반씩 줄여 differential hazard rate로의 convergence를
   검증해줘. 가장 작은 cell에서 상대차 <1%, monotone/refinement
   convergence와 observed order를 저장해줘. 임의 finite cell에서 causal
   rate와 정확히 같아야 한다고 강제하지 마.

10. 다음 durable tables를 만들어줘.

   - group_total_absorption.csv
   - component_hazard_table.csv
   - species_component_absorption.csv
   - opacity_firewall_audit.csv
   - cell_deposition_refinement.csv
   - background_snapshot_receipts.jsonl
   - neutral_island_exclusion_ledger.json

11. symbolic/Wolfram gates:

   - group-boundary redshift-flux telescoping
   - component-sum identity
   - proper/comoving conversion
   - differential limit of finite-cell deposition
   - threshold support exact zero
   - primary G3 and external HeII absorption exact zero
   - no-double-count firewall.

12. Precise Special Functions는 실제로 닫히는 power-law/rational analytic
   limits의 high-precision oracle로만 사용해줘. Finite-tau Verner/emulator
   production integral은 direct numerical quadrature를 정본으로 유지하고,
   incomplete-gamma 계열을 지원되지 않는 다른 함수로 대체하지 마.

13. 이번 B2C2A에서는 다음을 계산하지 마.

   - Ndot_unresolved = Ndot_abs - Ndot_maint
   - front를 ledger residual로 정의하는 작업
   - source/f_esc calibration
   - primitive geometry transplant
   - Bianchi feedback.

B2C2A가 통과한 뒤에만 B2C2B에서

Ndot_unresolved,c,g^c
  = Ndot_abs,ion,c,g^c - Ndot_maint,diffuse,c,g^c

를 계산하고 음수 component를 fail closed해줘.
