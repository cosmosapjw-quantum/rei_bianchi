# B2C1B mounted-state recovery addendum

The mounted B2C1B directory was found to be incompletely hydrated: the validator initially failed because `data/species_support_matrix.csv` was absent, even though it was listed in the durable compact manifest.

The stage was reconstructed from the durable compact bundle without inheriting transcript-only claims.

- Compact bundle SHA-256: `8af1fc647042b576dcb5eecce90c267c050b0ac50d57a73ebd5c6db9d13b264b`
- Compact-manifest files checked: 45
- Missing after reconstruction: 0
- Hash mismatches after reconstruction: 0
- Validator return code: 0
- Validator output: `P0.5-B2C1B durable gates: PASS_WITH_PRIMARY_HEIII_UNSUPPORTED`

The compact bundle is currently verified. The earlier full bundle is not mounted in the present runtime, so the expanded input tree is not being claimed as currently complete. This does not alter the B2C1B scientific verdict stored in the verified compact artifact.
