(* ::Package:: *)

(*
  Bianchi reionization Stage T2-D2

  Scope
    - Lebedev-26 transport grid and rotated Lebedev-14 collision grid.
    - Correct spin convention for Pplus=Q+iU and Pminus=Q-iU.
    - Inverse-aberrated source directions and screen phases.
    - L_T=3 -> L_C=2 spin-harmonic maps.
    - E/B, reality, weighted-adjoint, v->0, +/-v round-trip, patch cocycle.
    - Coherency-cone audit and nonlinear state limiter.
    - Full-state versus six-moment-only Thomson interfaces.

  Conventions
    metric signature (-,+,+,+)
    epsilon_123 = +1
    X_s' = Exp[I s chi] X_s

  Important correction
    Under a real basis rotation B' = R(alpha) B, the complex dyad phase is
    chi=-alpha. Hence X_s' = Exp[-I s alpha] X_s, and

       Q+iU  <-> s=+2,
       Q-iU  <-> s=-2.

    Patch harmonics carry Exp[-I s alphaPatch]. If the mapped source basis
    is R(psi) times the target basis, source-to-target components carry
    Exp[+I s psi].
*)

ClearAll["Global`*"];
$MaxExtraPrecision = 4000;
workPrec = 50;
maxAbs[x_] := Max[Abs[Flatten[N[x, workPrec]]]];
weightedNorm[x_, w_] := Sqrt[Re[Conjugate[x].w.x]];

(* ---------------------------------------------------------------------- *)
(* Lebedev grids                                                           *)
(* ---------------------------------------------------------------------- *)

lebedev14[] := Module[{axes, corners},
  axes = {{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
  corners = Flatten[
    Table[{sx,sy,sz}/Sqrt[3], {sx,{-1,1}}, {sy,{-1,1}}, {sz,{-1,1}}],
    2
  ];
  {
    Join[axes,corners],
    Join[ConstantArray[1/15,6],ConstantArray[3/40,8]]
  }
];

lebedev26[] := Module[{axes, edges, corners},
  axes = {{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
  edges = DeleteDuplicates @ Flatten[
    Table[Permutations[{sx/Sqrt[2],sy/Sqrt[2],0}],
      {sx,{-1,1}}, {sy,{-1,1}}],
    2
  ];
  corners = Flatten[
    Table[{sx,sy,sz}/Sqrt[3], {sx,{-1,1}}, {sy,{-1,1}}, {sz,{-1,1}}],
    2
  ];
  {
    Join[axes,edges,corners],
    Join[
      ConstantArray[1/21,6],
      ConstantArray[4/105,12],
      ConstantArray[9/280,8]
    ]
  }
];

{collisionDirs0, collisionWeights0} = lebedev14[];
{transportDirs0, transportWeights0} = lebedev26[];
relativeRotation = N[
  RotationMatrix[731/1000, Normalize[{2,-1,3}]],
  workPrec
];
collisionDirs = N[(relativeRotation.#)& /@ collisionDirs0, workPrec];
transportDirs = N[transportDirs0, workPrec];
collisionWeights = N[4 Pi collisionWeights0, workPrec];
transportWeights = N[4 Pi transportWeights0, workPrec];
WC = DiagonalMatrix[collisionWeights];
WT = DiagonalMatrix[transportWeights];
WCState = DiagonalMatrix[Join[
  collisionWeights,collisionWeights,collisionWeights
]];
WTState = DiagonalMatrix[Join[
  transportWeights,transportWeights,transportWeights
]];

(* ---------------------------------------------------------------------- *)
(* Patch-covariant spin harmonics                                          *)
(* ---------------------------------------------------------------------- *)

anglePair[k_] := Module[{z, phi},
  z = Clip[k[[3]], {-1,1}];
  phi = If[Abs[k[[1]]] + Abs[k[[2]]] < 10^-40,
    0,
    ArcTan[k[[1]],k[[2]]]
  ];
  {ArcCos[z], phi}
];

standardScreenBasis[k_] := Module[{theta,phi},
  {theta,phi} = anglePair[k];
  {
    {Cos[theta] Cos[phi], Cos[theta] Sin[phi], -Sin[theta]},
    {-Sin[phi], Cos[phi], 0}
  }
];

referenceAxis[k_] := IdentityMatrix[3][[First@Ordering[Abs[k],1]]];

patchScreenBasis[k_] := Module[{e1,e2},
  e1 = Normalize[Cross[referenceAxis[k],k]];
  e2 = Cross[k,e1];
  {e1,e2}
];

patchAngle[k_] := Module[{std,pat},
  std = standardScreenBasis[k];
  pat = patchScreenBasis[k];
  ArcTan[std[[1]].pat[[1]], std[[2]].pat[[1]]]
];

spinYStandard[s_,ell_,m_,k_] := Module[{theta,phi},
  {theta,phi} = anglePair[k];
  (-1)^m Sqrt[(2 ell+1)/(4 Pi)]
    Exp[I m phi] WignerD[{ell,m,-s},theta]
];

spinYPatch[s_,ell_,m_,k_] :=
  Exp[-I s patchAngle[k]] spinYStandard[s,ell,m,k];

spinModes[s_,ellMax_] := Flatten[
  Table[{ell,m},{ell,Abs[s],ellMax},{m,-ell,ell}],
  1
];

spinMatrix[dirs_,s_,ellMax_] := Module[{modes},
  modes = spinModes[s,ellMax];
  Table[
    N[spinYPatch[s,mode[[1]],mode[[2]],k],workPrec],
    {k,dirs},{mode,modes}
  ]
];

scalarModes[ellMax_] := Flatten[
  Table[{ell,m},{ell,0,ellMax},{m,-ell,ell}],
  1
];

scalarMatrix[dirs_,ellMax_] := Module[{modes},
  modes = scalarModes[ellMax];
  Table[
    Module[{ang=anglePair[k]},
      N[SphericalHarmonicY[
        mode[[1]],mode[[2]],ang[[1]],ang[[2]]
      ],workPrec]
    ],
    {k,dirs},{mode,modes}
  ]
];

(* ---------------------------------------------------------------------- *)
(* Lorentz and screen phase                                                *)
(* ---------------------------------------------------------------------- *)

eta4 = DiagonalMatrix[{-1,1,1,1}];
observer0 = {1,0,0,0};
minkowskiDot[a_,b_] := a.eta4.b;

boostMatrix[velocity_] := Module[{v2,gamma,top,bottom},
  v2 = velocity.velocity;
  If[Abs[N[v2]] < 10^-40, Return[IdentityMatrix[4]]];
  gamma = 1/Sqrt[1-v2];
  top = Join[{gamma},-gamma velocity];
  bottom = Table[
    Join[
      {-gamma velocity[[i]]},
      IdentityMatrix[3][[i]]
        +((gamma-1)/v2) velocity[[i]] velocity
    ],
    {i,3}
  ];
  Join[{top},bottom]
];

inverseAberrate[velocity_,targetDirection_] := Module[{p},
  p = boostMatrix[-velocity].Join[{1},targetDirection];
  Rest[p]/p[[1]]
];

screenProjectorMixed[k4_] :=
  IdentityMatrix[4]
  +Outer[Times,observer0,eta4.observer0]
  -Outer[Times,k4,eta4.k4];

screenPhase[
  velocity_,sourceDirection_,sourceBasis3_,
  targetDirection_,targetBasis3_,s_
] := Module[
  {lambda,pTarget,kTarget4,raw,b1,b2,targetBasis4,rotation2,unitPhase},
  lambda = boostMatrix[velocity];
  pTarget = lambda.Join[{1},sourceDirection];
  kTarget4 = pTarget/pTarget[[1]]-observer0;

  raw = (screenProjectorMixed[kTarget4].
         (lambda.Join[{0},#]))& /@ sourceBasis3;
  b1 = raw[[1]]/Sqrt[minkowskiDot[raw[[1]],raw[[1]]]];
  b2 = raw[[2]]-minkowskiDot[raw[[2]],b1]b1;
  b2 = b2/Sqrt[minkowskiDot[b2,b2]];

  targetBasis4 = (Join[{0},#]& /@ targetBasis3);
  rotation2 = Table[
    minkowskiDot[targetBasis4[[i]],{b1,b2}[[j]]],
    {i,2},{j,2}
  ];
  unitPhase = rotation2[[1,1]] + I rotation2[[2,1]];
  unitPhase^s
];

buildSpinMap[
  sourceDirs_,sourceWeights_,targetDirs_,targetWeights_,
  velocity_,s_,ellSource_,ellTarget_
] := Module[
  {hSource,gSource,analysis,sourceEvalDirs,phases,hEval,
   hTarget,gTarget,pTarget,raw},
  hSource = spinMatrix[sourceDirs,s,ellSource];
  gSource = ConjugateTranspose[hSource].
            DiagonalMatrix[sourceWeights].hSource;
  analysis = Inverse[gSource].ConjugateTranspose[hSource].
             DiagonalMatrix[sourceWeights];

  sourceEvalDirs = inverseAberrate[velocity,#]& /@ targetDirs;
  phases = Table[
    screenPhase[
      velocity,
      sourceEvalDirs[[q]],patchScreenBasis[sourceEvalDirs[[q]]],
      targetDirs[[q]],patchScreenBasis[targetDirs[[q]]],
      s
    ],
    {q,Length[targetDirs]}
  ];

  hEval = spinMatrix[sourceEvalDirs,s,ellSource];
  hTarget = spinMatrix[targetDirs,s,ellTarget];
  gTarget = ConjugateTranspose[hTarget].
            DiagonalMatrix[targetWeights].hTarget;
  pTarget = hTarget.Inverse[gTarget].ConjugateTranspose[hTarget].
            DiagonalMatrix[targetWeights];
  raw = DiagonalMatrix[phases].hEval.analysis;

  <|
    "Map"->pTarget.raw,
    "RawMap"->raw,
    "TargetProjector"->pTarget,
    "SourceEvalDirs"->sourceEvalDirs,
    "Phases"->phases
  |>
];

buildScalarMap[
  sourceDirs_,sourceWeights_,targetDirs_,targetWeights_,
  velocity_,ellSource_,ellTarget_
] := Module[
  {hSource,gSource,analysis,sourceEvalDirs,hEval,hTarget,gTarget,pTarget},
  hSource = scalarMatrix[sourceDirs,ellSource];
  gSource = ConjugateTranspose[hSource].
            DiagonalMatrix[sourceWeights].hSource;
  analysis = Inverse[gSource].ConjugateTranspose[hSource].
             DiagonalMatrix[sourceWeights];
  sourceEvalDirs = inverseAberrate[velocity,#]& /@ targetDirs;
  hEval = scalarMatrix[sourceEvalDirs,ellSource];
  hTarget = scalarMatrix[targetDirs,ellTarget];
  gTarget = ConjugateTranspose[hTarget].
            DiagonalMatrix[targetWeights].hTarget;
  pTarget = hTarget.Inverse[gTarget].ConjugateTranspose[hTarget].
            DiagonalMatrix[targetWeights];
  pTarget.hEval.analysis
];

buildStateMap[velocity_] := Module[{a0,aplus,ar,ai,z},
  a0 = buildScalarMap[
    transportDirs,transportWeights,
    collisionDirs,collisionWeights,
    velocity,3,2
  ];
  aplus = buildSpinMap[
    transportDirs,transportWeights,
    collisionDirs,collisionWeights,
    velocity,+2,3,2
  ]["Map"];
  ar = Re[aplus];
  ai = Im[aplus];
  z = ConstantArray[0,{Length[collisionDirs],Length[transportDirs]}];
  ArrayFlatten[
    {
      {a0,z,z},
      {z,ar,-ai},
      {z,ai,ar}
    }
  ]
];

(* ---------------------------------------------------------------------- *)
(* State limiter                                                           *)
(* ---------------------------------------------------------------------- *)

conservativePositiveScalar[state_,weights_] := Module[
  {average,minimum,theta},
  average = weights.state/Total[weights];
  minimum = Min[state];
  theta = If[minimum>=0,
    1,
    If[average<=0,0,Min[1,average/(average-minimum)]]
  ];
  <|
    "State"->average ConstantArray[1,Length[state]]
      +theta(state-average ConstantArray[1,Length[state]]),
    "Theta"->theta
  |>
];

coherencyConeLimit[state_] := Module[
  {nC,iRaw,qRaw,uRaw,iLimited,thetaI,scales},
  nC = Length[collisionDirs];
  iRaw = state[[1;;nC]];
  qRaw = state[[nC+1;;2 nC]];
  uRaw = state[[2 nC+1;;3 nC]];
  {iLimited,thetaI} = Values @ conservativePositiveScalar[
    iRaw,collisionWeights
  ];
  scales = Table[
    If[Sqrt[qRaw[[q]]^2+uRaw[[q]]^2] < 10^-35,
      1,
      Min[1,iLimited[[q]]/Sqrt[qRaw[[q]]^2+uRaw[[q]]^2]]
    ],
    {q,nC}
  ];
  <|
    "State"->Join[iLimited,scales qRaw,scales uRaw],
    "IntensityTheta"->thetaI,
    "PolarizationScales"->scales
  |>
];

(* ---------------------------------------------------------------------- *)
(* Six-moment Thomson factors                                              *)
(* ---------------------------------------------------------------------- *)

vec6[m_] := {m[[1,1]],m[[2,2]],m[[3,3]],m[[1,2]],m[[1,3]],m[[2,3]]};
mat6[z_] := {{z[[1]],z[[4]],z[[5]]},{z[[4]],z[[2]],z[[6]]},{z[[5]],z[[6]],z[[3]]}};

buildThomsonFactors[] := Module[
  {nC,weightsNormalized,vFactor,uFactor},
  nC = Length[collisionDirs];
  weightsNormalized = collisionWeights/(4 Pi);
  vFactor = ConstantArray[0,{6,3 nC}];
  uFactor = ConstantArray[0,{3 nC,6}];

  Do[
    Module[{basis,e1,e2,bI,bQ,bU,pScreen,fOut,iOut,qOut,uOut},
      basis = patchScreenBasis[collisionDirs[[q]]];
      {e1,e2} = basis;
      bI = (Outer[Times,e1,e1]+Outer[Times,e2,e2])/2;
      bQ = (Outer[Times,e1,e1]-Outer[Times,e2,e2])/2;
      bU = (Outer[Times,e1,e2]+Outer[Times,e2,e1])/2;

      vFactor[[All,q]] = weightsNormalized[[q]] vec6[bI];
      vFactor[[All,nC+q]] = weightsNormalized[[q]] vec6[bQ];
      vFactor[[All,2 nC+q]] = weightsNormalized[[q]] vec6[bU];

      pScreen = Outer[Times,e1,e1]+Outer[Times,e2,e2];
      Do[
        fOut = (3/2) pScreen.mat6[UnitVector[6,r]].pScreen;
        iOut = e1.fOut.e1+e2.fOut.e2;
        qOut = e1.fOut.e1-e2.fOut.e2;
        uOut = 2 e1.fOut.e2;
        uFactor[[q,r]] = iOut;
        uFactor[[nC+q,r]] = qOut;
        uFactor[[2 nC+q,r]] = uOut,
        {r,6}
      ]
    ],
    {q,nC}
  ];
  {uFactor,vFactor}
];

{thomsonU,thomsonV} = buildThomsonFactors[];
thomsonElectron = -IdentityMatrix[42]+thomsonU.thomsonV;

(* ---------------------------------------------------------------------- *)
(* Main numerical gate                                                     *)
(* ---------------------------------------------------------------------- *)

velocity = N[{31/100,-22/100,41/100},workPrec];
mapPlus = buildSpinMap[
  transportDirs,transportWeights,
  collisionDirs,collisionWeights,
  velocity,+2,3,2
];
mapMinus = buildSpinMap[
  transportDirs,transportWeights,
  collisionDirs,collisionWeights,
  velocity,-2,3,2
];
APlus = mapPlus["Map"];
AMinus = mapMinus["Map"];
APlusSharp = Inverse[WT].ConjugateTranspose[APlus].WC;
AMinusSharp = Inverse[WT].ConjugateTranspose[AMinus].WC;

stateMap0 = buildStateMap[{0,0,0}];
stateMapV = buildStateMap[velocity];
stateSharp0 = Inverse[WTState].Transpose[stateMap0].WCState;
stateSharpV = Inverse[WTState].Transpose[stateMapV].WCState;

collisionFull0 = stateSharp0.thomsonElectron.stateMap0;
collisionSix0 = -IdentityMatrix[78]
  +stateSharp0.thomsonU.thomsonV.stateMap0;
collisionFullV = stateSharpV.thomsonElectron.stateMapV;
collisionSixV = -IdentityMatrix[78]
  +stateSharpV.thomsonU.thomsonV.stateMapV;

results = <|
  "SpinConvention"-><|
    "PplusSpin"->2,
    "PminusSpin"->-2,
    "PatchFactor"->"Exp[-I s alphaPatch]",
    "BoostFactor"->"Exp[+I s psi]"
  |>,
  "MapConjugationResidual"->maxAbs[AMinus-Conjugate[APlus]],
  "WeightedAdjointPlusResidual"->maxAbs[
    WT.APlusSharp-ConjugateTranspose[APlus].WC
  ],
  "WeightedAdjointMinusResidual"->maxAbs[
    WT.AMinusSharp-ConjugateTranspose[AMinus].WC
  ],
  "ThomsonInscatterRank"->MatrixRank[N[thomsonU.thomsonV,20],
    Tolerance->10^-12],
  "ThomsonNullity"->42-MatrixRank[N[thomsonElectron,20],
    Tolerance->10^-12],
  "FullVsSixIdentityZeroTilt"->maxAbs[
    collisionSix0-collisionFull0
      +IdentityMatrix[78]-stateSharp0.stateMap0
  ],
  "FullVsSixIdentityFiniteTilt"->maxAbs[
    collisionSixV-collisionFullV
      +IdentityMatrix[78]-stateSharpV.stateMapV
  ],
  "FullIntermediateDOF"->42,
  "SixMomentIntermediateDOF"->6
|>;

results
