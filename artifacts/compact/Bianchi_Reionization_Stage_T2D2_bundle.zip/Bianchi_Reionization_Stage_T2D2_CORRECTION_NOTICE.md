# Correction notice for Stage T2-D0/T2-D1 spin convention

The scalar restriction/prolongation results are unchanged.

Replace the earlier spin assignment and phase statements with:

- `Pplus = Q + I U` has spin `s = +2`.
- `Pminus = Q - I U` has spin `s = -2`.
- For a real basis rotation by `alpha`, `X_s' = Exp[-I s alpha] X_s`.
- Patch-gauge spin harmonics use `Exp[-I s alphaPatch]`.
- If the mapped source basis is rotated by `psi` relative to the target basis, the source-to-target component factor is `Exp[+I s psi]`.

This correction is required for regular pole/patch behavior and is verified by the Stage T2-D2 round-trip and patch-cocycle gates.
