# Bianchi Reionization Stage T2-D2 — Spin-2 and Thomson-interface audit

## Status

**PASS WITH A REQUIRED CONVENTION CORRECTION AND REALIZABILITY GATE.**

The scalar T2-D0/T2-D1 results remain valid. Its spin-screen convention paragraph is superseded by the convention below.

## Correct spin convention

For a real screen-basis rotation

\[
(e_1',e_2')=(\cos\alpha\,e_1+\sin\alpha\,e_2,
              -\sin\alpha\,e_1+\cos\alpha\,e_2),
\]

the complex dyad acquires phase \(\chi=-\alpha\). With the project convention
\(X_s'=e^{is\chi}X_s\),

\[
Q+iU\leftrightarrow s=+2,\qquad Q-iU\leftrightarrow s=-2,
\]

\[
X_s'=e^{-is\alpha}X_s.
\]

Hence the spin harmonic in the Cartesian patch basis carries
\(e^{-is\alpha_{\rm patch}}\), while a mapped source basis satisfying
\(B_{\rm mapped}=R(\psi)B_{\rm target}\) contributes the boost phase
\(e^{+is\psi}\).

A direct symbolic Stokes-tensor rotation gave

\[
(Q+iU)'=e^{-2i\alpha}(Q+iU),\qquad
(Q-iU)'=e^{+2i\alpha}(Q-iU).
\]

The earlier dual sign reversal was internally paired for some tests, but it was incompatible with the declared spin convention and produced a pole/patch discontinuity. Fixed endpoint patch bases and the corrected convention remove it.

## Spin-harmonic construction

- Transport grid: Lebedev-26, \(L_T=3\), 12 modes per spin.
- Collision grid: generically rotated Lebedev-14, \(L_C=2\), 5 modes per spin.
- Inverse aberration supplies the source directions for every collision node.
- The target collision state is projected onto the \(L_C=2\) spin subspace.
- The signed pullback is the weighted adjoint.

The corrected maps obey

\[
A_{-2}=A_{+2}^*,
\qquad
W_T A_s^\sharp=A_s^\dagger W_C.
\]

Gram, conjugation, weighted-adjoint, pure-E/B direct-reference, and reality residuals all vanished to the displayed working precision (roughly 27–53 digits depending on the block).

## Pure E/B tests

Physical coefficient pairs satisfying the usual reality condition were used. Both pure-E and pure-B nodal outputs agreed with direct inverse-aberration plus screen-tensor phase transformation, followed by the same \(L_C=2\) projection, with residual zero to about 27 displayed digits.

At \(|v|=0.55910643\), the projected observer-frame decomposition contained cross components:

- pure E input: \(\|B_{\rm out}\|=0.28047037\), \(\|E_{\rm out}\|=0.81691218\);
- pure B input: \(\|E_{\rm out}\|=0.13115690\), \(\|B_{\rm out}\|=0.52116784\).

These are outputs of the finite-tilt, \(L_C=2\)-projected observer representation, not numerical residuals.

## Zero-velocity and round-trip gates

The \(v\to0\) spin map reduced exactly to the ordinary spin-harmonic restriction.

The local null-direction and screen-phase map satisfied an exact \(+v\), then \(-v\), round trip to about 52 displayed digits once fixed grid patch bases were used.

Finite-band round trip errors for a physical \(\ell=2\) field were:

| speed | relative weighted error |
|---:|---:|
| 0 | 0 |
| 0.001 | 7.56868e-7 |
| 0.01 | 7.56879e-5 |
| 0.05 | 1.89284e-3 |
| 0.2 | 3.04486e-2 |
| 0.55910643 | 2.48204e-1 |

For small speed the error is approximately \(0.757v^2\). The local Lorentz map is exact; this is the expected loss from projecting the aberrated field back to \(L_C=2\).

## Patch-transition cocycle

For source and target patch rotations \(\alpha_s,\alpha_t\),

\[
\Phi_s' = e^{is(\alpha_s-\alpha_t)}\Phi_s.
\]

Both \(s=\pm2\) cocycle and field-consistency residuals vanished at roughly 56–57 displayed digits.

Implementation rule: grid-node patch IDs and bases are immutable. Do not reselect a Cartesian reference axis from floating-point round-tripped coordinates.

## Coherency-cone audit

The raw full-state harmonic map is not cone preserving. Scanning fully polarized single-node inputs found

\[
\min_q\left[I_q-\sqrt{Q_q^2+U_q^2}\right]
=-0.23369558,
\]

and \(\min I_q=-0.11481336\).

A two-step nonlinear state limiter was tested:

1. conservative scalar limiter for \(I\), preserving \(\sum_qw_q I_q\);
2. pointwise polarization scaling
   \(P_q\mapsto \min(1,I_q/|P_q|)P_q\).

For the worst case, \(\theta_I=0.47564166\), 11 of 14 polarization nodes were scaled, the final cone margin was zero, and the weighted intensity residual was zero to the displayed precision. A smooth physical band-limited state had raw cone margin 1.95039 and needed no limiting.

The limiter is for positive states only. Signed collision sources must use the linear weighted adjoint without a positivity limiter.

## Full-state versus six-moment Thomson interface

Let \(A\) be the full \((I,Q,U)\) transport-to-collision map, \(A^\sharp\) its weighted adjoint, and

\[
T_e=-I+UV,\qquad \operatorname{rank}(UV)=6
\]

the electron-frame Thomson operator.

The full-state interface is

\[
C_{\rm full}=A^\sharp T_e A
             =-A^\sharp A+A^\sharp UVA.
\]

The six-moment-only interface retains exact local out-scattering:

\[
C_6=-I+A^\sharp UVA.
\]

Therefore

\[
C_6-C_{\rm full}=-(I-A^\sharp A),
\]

which was verified at both zero and finite tilt.

At zero tilt:

- both operators conserve the intensity moment and annihilate the isotropic state;
- on the retained \(L\le2\) subspace they are identical;
- an \(\ell=3\) mode is annihilated by the full-state restriction, so \(C_{\rm full}\) incorrectly gives no out-scattering;
- \(C_6\) correctly gives the local \(-I\) loss term.

The low-rank update remained rank 6. The collision intermediate is reduced from 42 nodal values to 6 symmetric-tensor moments.

A worst unresolved impulse gave six-moment tensor eigenvalues

\[
(-6.8162\times10^{-4},\;1.48190\times10^{-2},\;9.00090\times10^{-2}),
\]

so the direct moment map is not automatically realizability preserving. Production must either derive moments from a cone-limited collision state or apply a trace-preserving PSD projection to the \(3\times3\) moment tensor.

## Production recommendation

Use the six-moment-only in-scattering interface with exact local out-scattering. Keep the full-state path as a validation/reference route and for situations where a resolved electron-frame angular state is otherwise needed.

The complete finite-tilt number-conservation gate must combine this angular block with the T2-C log-energy/Doppler remap; a fixed-energy angular block alone is not the full Lorentz-covariant collision operator.
