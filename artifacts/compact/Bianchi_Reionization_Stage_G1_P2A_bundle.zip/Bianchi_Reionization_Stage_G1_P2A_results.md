# Bianchi Reionization — Stage G1/P2-A

## Verdict

\[
\boxed{
\text{G1/P2-A}
=
\text{PASS as a finite-step/nonstiff reference}
\quad\text{but}\quad
\text{FAIL as the stiff production collision core}
}
\]

The fixed normal-frame log-energy operator

\[
L_0=-D+U_0V_0
\]

was successfully made linear, nonnegative at the uniformization-kernel
level, and exactly conservative on a guard-supported finite-step test.
Its adaptive Poisson uniformization agreed with dense `MatrixExp` at
machine precision.

Nevertheless, repeated positive forward/reverse energy remapping destroys
the exact electron-energy label. In the stiff limit the finite fixed-grid
semigroup relaxes toward inert ghost-energy bins rather than the physical
electron-frame isotropic Thomson family. This is a structural failure, not
a resolution error.

Therefore:

\[
\boxed{\text{Route A is rejected.}}
\]

The selected route is a redefined Route B:

\[
\boxed{
\text{one conversion to a paired/dual electron-energy grid}
\rightarrow
\text{exact positive collision exponential}
\rightarrow
\text{one conversion back}
\rightarrow
\text{outer cone/invariant projection}.
}
\]

---

## 1. Symbolic remap identities

For

\[
E_0<E_t<E_1,
\qquad
\beta=\frac{E_t-E_0}{E_1-E_0},
\]

the two deposition weights are

\[
w_0=1-\beta,
\qquad
w_1=\beta.
\]

Wolfram returned

\[
w_0+w_1-1=0,
\]

\[
E_0w_0+E_1w_1-E_t=0,
\]

and, under the stated assumptions,

\[
w_0>0,\qquad w_1>0.
\]

For \(\nu\ge D>0\),

\[
1-\frac D\nu\ge0.
\]

Thus

\[
T_0=I+\frac{L_0}{\nu}
\]

is a nonnegative survival map plus a positive six-moment in-scattering
map. Cone preservation follows from convexity of the local coherency
Lorentz cone.

---

## 2. Small dense fixed-core gate

The validation model used

\[
N_\Omega=14,\qquad N_y=7,
\]

with three central active energy cells and four guard cells.

\[
N_{\rm state}=294,
\qquad
N_{\rm moment}=42.
\]

Doppler factors were

\[
0.80375153\le D_p\le1.24042844.
\]

No forward active-column escape or reverse reachable-bin escape occurred.

The exact left-invariant residuals were

\[
\|C_NL_0\|_\infty
=
5.55\times10^{-17},
\]

\[
\|C_EL_0\|_\infty
=
6.94\times10^{-17}.
\]

A scan over all active angle–energy impulses and 16 fully polarized
orientations gave

\[
\min\lambda_{\rm coh}(T_0x)
=
-1.11\times10^{-16},
\]

with zero failures below \(-10^{-12}\).

### Adaptive uniformization vs dense exponential

| \(h\) | Poisson terms | relative error | invariant residual | minimum cone margin |
|---:|---:|---:|---:|---:|
| 0.1 | 9 | \(3.97\times10^{-16}\) | \(2.13\times10^{-14}\) | 0.31215 |
| 1 | 18 | \(3.09\times10^{-16}\) | \(1.78\times10^{-15}\) | 0.31215 |
| 5 | 35 | \(6.43\times10^{-16}\) | 0 | 0.28060 |
| 20 | 74 | \(2.69\times10^{-15}\) | 0 | 0.06447 |

This part of P2-A passes.

---

## 3. Reduced determinant-lemma spectrum

For a minimal \(N_y=3\) model:

\[
N_{\rm state}=126,
\qquad
6N_y=18.
\]

Using

\[
\det(\lambda I-L_0)
=
\det(\lambda I+D)
\det\left[
I-V_0(\lambda I+D)^{-1}U_0
\right],
\]

the slow mode was

\[
\lambda_\star=-0.1328304862.
\]

The smallest singular value of the \(18\times18\) reduced matrix at this
mode was exactly zero at the reported precision. A scan between this
mode and the origin found no additional root, with a minimum sampled
singular value \(3.14\times10^{-3}\).

This is **not** a certified physical spectral gap. The nullspace is
dominated by inert ghost states. Consequently the projector branch was
disabled.

An a-posteriori stationarity condition

\[
\frac{\|L_0x_m\|}{\nu\|x_m\|}<10^{-10}
\]

was reached after 177 applications of \(T_0\), but the stationary state
was later identified as the ghost-energy manifold. Thus stationarity
alone is insufficient; the target nullspace must also be physically
identified.

---

## 4. Fixed-grid versus paired-grid four-force

A smooth polarized spectrum was evolved on \([-8,8]\) in log energy.
The wide guard band suppresses boundary contamination.

### Energy convergence

| \(\Delta y\) | fixed/paired spatial four-force error | number residual | electron-energy residual |
|---:|---:|---:|---:|
| 0.5 | \(2.13\times10^{-8}\) | \(-8.05\times10^{-11}\) | \(-1.57\times10^{-7}\) |
| 0.25 | \(9.00\times10^{-9}\) | \(-3.69\times10^{-11}\) | \(-7.70\times10^{-8}\) |
| 0.125 | \(6.41\times10^{-9}\) | \(-2.85\times10^{-11}\) | \(-6.08\times10^{-8}\) |
| 0.0625 | \(6.03\times10^{-9}\) | \(-2.77\times10^{-11}\) | \(-5.90\times10^{-8}\) |

The finest fixed result was

\[
Q_{e,\rm fixed}^{\mu}
=
(-5.90\times10^{-8},
\,2.95365098,
\,-2.03351917,
\,3.74788538),
\]

while the paired reference was

\[
Q_{e,\rm paired}^{\mu}
=
(-8.88\times10^{-16},
\,2.95365099,
\,-2.03351918,
\,3.74788540).
\]

### Angular convergence

The Product-288 paired result was used as reference.

| grid | nodes | paired angular error | fixed total error |
|---|---:|---:|---:|
| Lebedev-14 | 14 | \(8.18\times10^{-2}\) | \(8.18\times10^{-2}\) |
| Lebedev-26 | 26 | \(7.29\times10^{-3}\) | \(7.29\times10^{-3}\) |
| Product-72 | 72 | \(2.19\times10^{-4}\) | \(2.19\times10^{-4}\) |
| Product-128 | 128 | \(5.81\times10^{-6}\) | \(5.81\times10^{-6}\) |
| Product-200 | 200 | \(1.36\times10^{-7}\) | \(1.37\times10^{-7}\) |
| Product-288 | 288 | 0 | \(8.56\times10^{-9}\) |

Thus the \(10^{-4}\) angular threshold is first passed by Product-128 in
this test.

---

## 5. Time convergence

A positive angular-permutation transport generator, chosen not to commute
with \(L_0\), was coupled to the actual uniformization action in a Strang
step. The dense exponential of the combined generator was the reference.

| steps | relative error |
|---:|---:|
| 5 | \(3.3822\times10^{-4}\) |
| 10 | \(8.4739\times10^{-5}\) |
| 20 | \(2.1196\times10^{-5}\) |
| 40 | \(5.2998\times10^{-6}\) |
| 80 | \(1.3250\times10^{-6}\) |
| 160 | \(3.3125\times10^{-7}\) |

Observed orders:

\[
1.9969,\quad
1.9992,\quad
1.9998,\quad
1.99995,\quad
1.99999.
\]

The \(10^{-4}\) time threshold is passed at 10 steps and is well below the
threshold at 40 steps.

---

## 6. Fatal stiff-limit gate

A guard-supported \(N_y=7\) model was chosen for which

\[
\|C_NL_0\|_\infty
=
1.25\times10^{-16},
\]

\[
\|C_EL_0\|_\infty
=
3.61\times10^{-16}.
\]

The operator nullity was

\[
168=14\times4\times3,
\]

exactly the number of inert ghost Stokes degrees of freedom. There was no
additional physical active-energy equilibrium nullspace.

Starting from a central active-energy isotropic state:

| \(h\) | active number fraction | ghost number fraction | total fraction |
|---:|---:|---:|---:|
| 0 | 1 | 0 | 1 |
| 1 | 0.98534 | 0.01466 | 1 |
| 5 | 0.82631 | 0.17369 | 1 |
| 20 | 0.27674 | 0.72326 | 1 |
| 100 | \(5.41\times10^{-4}\) | 0.999459 | 1 |

By contrast, the paired \(N_y=3\) operator had nullity 3: one physical
Thomson equilibrium family per electron-energy bin.

### Interpretation

The product of positive forward and reverse number–energy remaps is a
mean-preserving energy diffusion. Repeated application loses the exact
correlation between angle and electron energy. On a finite fixed grid the
result is absorption into the energy boundaries/ghosts.

Refining \(\Delta y\) delays the process but does not change the wrong
\(h\to\infty\) nullspace. Therefore the local accuracy gates cannot rescue
Route A.

---

## 7. Route decision

Nominal stop tolerance:

\[
10^{-4}.
\]

Local gates:

\[
\epsilon_E=6.03\times10^{-9},
\]

\[
\epsilon_\Omega=5.81\times10^{-6}
\quad\text{at Product-128},
\]

\[
\epsilon_t=5.30\times10^{-6}
\quad\text{at 40 steps}.
\]

All three pass. The hard stiff-equilibrium gate fails.

Hence:

\[
\boxed{\text{Route A: REJECT}}
\]

and

\[
\boxed{
\text{Route B: SELECT}
}
\]

with Route B redefined as:

1. convert the normal fixed-grid state once to a paired/dual
   electron-energy representation;
2. apply the positive invariant-preserving Thomson exponential there;
3. convert back once;
4. apply a single outer coherency-cone and invariant projection;
5. retain the fixed-grid \(L_0\) only as a nonstiff reference/fallback.

The nonlinear projection must not be inserted into the Poisson
uniformization iteration.

## Next Wolfram stage

```text
@Wolfram Stage G1/P2-B를 실행해줘.
P2-A의 fixed-grid semigroup은 stiff limit에서 ghost manifold로 붕괴하므로
production core에서 제외하고, normal fixed-grid state를 한 번 paired/dual
electron-energy grid로 변환한 뒤 G1/P1의 invariant/cone-preserving
uniformization을 적용하고 한 번만 reverse conversion하는 operator를 구성해줘.
reverse-converted candidate를 local coherency cones와 photon number,
electron-frame energy, matrix number-energy affine constraints의 교집합에
outer projection해줘. paired-grid exact reference와 비교하여 projection
inactivity, correction norm, stiff equilibrium, temporal order, four-force,
ghost occupancy를 검증하고, smooth resolved regime에서 correction이 1%를
넘으면 fail closed해줘.
```
