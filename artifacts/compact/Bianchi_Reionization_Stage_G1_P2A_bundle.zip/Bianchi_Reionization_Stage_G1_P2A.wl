(* ::Package:: *)

(*
  Bianchi Reionization Stage G1/P2-A
  Fixed normal-frame energy-grid linear core audit.

  Canonical conventions:
    metric signature (-,+,+,+)
    epsilon_123 = +1
    Q+iU <-> spin s=+2
    Q-iU <-> spin s=-2

  Final verdict:
    PASS as a finite-step/nonstiff positive reference core.
    FAIL as the stiff production collision semigroup.

  Reason:
    nonnegative forward/reverse number-energy remaps are diffusive when
    repeatedly composed inside the collision exponential. On a finite
    fixed normal-energy grid the active radiation drains into the inert
    ghost-energy nullspace. The reduced spectral gap therefore measures
    relaxation toward a numerical ghost manifold, not Thomson equilibrium.

  Production route selected:
    paired/dual electron-energy collision exponential
    + one forward conversion
    + one reverse conversion
    + outer cone/invariant projection.
*)

ClearAll["Global`*"];
$MaxExtraPrecision = 5000;

(* ---------- exact two-point number-energy deposition ---------- *)

NumberEnergyWeights[E0_, E1_, Et_] := {
  (E1 - Et)/(E1 - E0),
  (Et - E0)/(E1 - E0)
};

(* Identities:
     Total[NumberEnergyWeights[E0,E1,Et]] == 1
     {E0,E1}.NumberEnergyWeights[E0,E1,Et] == Et
   under E0 < Et < E1, both coefficients are positive.
*)

NumberEnergyRemap[yGrid_List, delta_] := Module[
  {n = Length[yGrid], energy = Exp[yGrid], r, low, high,
   target, j, beta},
  r = ConstantArray[0., {n, n}];
  low = ConstantArray[0., n];
  high = ConstantArray[0., n];

  Do[
    target = Exp[yGrid[[i]] + delta];
    Which[
      target < First[energy],
        low[[i]] = 1.,
      target > Last[energy],
        high[[i]] = 1.,
      True,
        j = Max[
          1,
          Min[n - 1, LengthWhile[energy, # <= target &]]
        ];
        beta =
          (target - energy[[j]])/
          (energy[[j + 1]] - energy[[j]]);
        r[[j, i]] = 1 - beta;
        r[[j + 1, i]] = beta
    ],
    {i, n}
  ];

  <|"Target" -> r, "LowEscape" -> low, "HighEscape" -> high|>
];

(* ---------- fixed-grid direct-six-moment generator ---------- *)

(*
  Electron-native angular nodes are used during the collision substep.
  Normal angular weights obey w_n,p = D_p^2 w_e,p.

  Forward remap:
      R_p^+ : E_n -> E_e = D_p E_n
  Reverse remap:
      R_p^- : E_e -> E_n = E_e / D_p

  Direct moments:
      V0 x = Sum_p w_e,p D_p^3 E_p R_p^+ x_p

  In-scattering:
      U0 M |_p =
        D_p^-2 R_p^- R_screen,p^-1 U_Th(M,k_e,p)

  Generator:
      L0 = -D + U0 V0.

  Global left invariants:
      C_N x = Sum_p,i w_n,p I_p,i
      C_E x = Sum_p,i w_n,p D_p E_i I_p,i

  On a guard-supported finite-step test:
      C_N L0 = 0
      C_E L0 = 0.
*)

LAction[data_Association, x_] :=
  -data["DVector"]*x + data["U"].(data["V"].x);

UniformizationAction[
  data_Association,
  h_,
  x_,
  tolerance_: 10^-14,
  maximumTerms_: 10000
] := Module[
  {nu = data["Nu"], mu, term, probability, probabilitySum,
   result, n = 0},

  mu = nu*h;
  term = x;
  probability = Exp[-mu];
  probabilitySum = probability;
  result = probability*term;

  While[
    1 - probabilitySum > tolerance && n < maximumTerms,
    n++;
    term = term + LAction[data, term]/nu;
    probability = probability*mu/n;
    result += probability*term;
    probabilitySum += probability
  ];

  <|
    "State" -> result/probabilitySum,
    "Terms" -> n,
    "PoissonTail" -> 1 - probabilitySum
  |>
];

(* ---------- reduced determinant-lemma spectral problem ---------- *)

ReducedMatrix[data_Association, lambda_] :=
  IdentityMatrix[Length[data["V"]]] -
  data["V"].
    DiagonalMatrix[1/(lambda + data["DVector"])].
    data["U"];

(*
  det(lambda I - L0) =
    det(lambda I + D)
    det[I - V0 (lambda I + D)^-1 U0].

  The minimal validation model gave:
      state dimension   = 126
      reduced dimension = 18
      slow reduced root = -0.13283048615194482
      sigma_min(reduced root) = 0.

  This is not a production gap certificate:
  the fixed-grid operator has an inert ghost nullspace, and the root
  measures decay toward that numerical manifold.
*)

(* ---------- production route gate ---------- *)

RouteMetrics = <|
  "EnergyError_dy_0p0625" -> 6.030337486610159*^-9,
  "AngularError_Product128" -> 5.80797711900843*^-6,
  "AngularError_Product200" -> 1.3727614238714896*^-7,
  "TimeError_Strang_N40" -> 5.299804299783025*^-6,
  "NominalTolerance" -> 1.*^-4,
  "LocalAccuracyGate" -> True,

  "StiffActiveFraction_h100" -> 0.000540891273282448,
  "StiffGhostFraction_h100" -> 0.9994591087267269,
  "FixedNullity" -> 168,
  "ExpectedGhostNullity" -> 14*4*3,
  "StiffEquilibriumGate" -> False,

  "RouteA" -> "REJECT",
  "RouteB" -> "SELECT_DUAL_OR_PAIRED_ENERGY_OUTER_PROJECTION"
|>;

RouteMetrics
