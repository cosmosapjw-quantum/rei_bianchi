# G1/P2-A route correction

## Superseded expectation

The low-order fixed normal-energy linear generator \(L_0=-D+U_0V_0\)
was expected to become the production core after sufficient energy and
angular refinement.

## Corrected result

It is an excellent finite-step reference:

- positive uniformization kernel;
- machine-precision agreement with dense `MatrixExp`;
- exact global photon-number and electron-energy invariants on a
  guard-supported test;
- excellent paired-grid four-force convergence.

But its stiff nullspace is wrong. Repeated positive forward/reverse remaps
diffuse electron-energy labels into inert ghost bins. In the invariant
\(N_y=7\) test, 99.9459% of photon number was in ghost cells by \(h=100\).

## Route change

Route A is rejected. Route B is selected in a dual-grid form:

\[
\text{fixed normal transport state}
\to
\text{paired electron-energy collision state}
\to
e^{hL_{\rm Th}}
\to
\text{fixed normal state}
\to
\text{one outer cone/invariant projection}.
\]

The Dykstra/SOCP projection remains outside the exponential action.
