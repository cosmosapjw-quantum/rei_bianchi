"""P0.5-A/B implementation specification.

The executed prototype used:
- P0.4 PUBLIC_REPO_EXACT opacity at central Gamma, with checkpoint-derived local dln(lambda)/dln(Gamma);
- photon groups G1=[13.6,24.59), G2a=[24.59,39.5], G2b=(39.5,54.42);
- emulator H-I opacity as a non-additive total H-I attenuation, explicit H-I as a floor, and explicit He-I/He-II opacities;
- full-OTS H/He event-vector matrix exponentials;
- thermal internal-energy update;
- separate forward(emissivity input) and inverse(Gamma input) APIs.

The primary branch-safe fixed-z result and all exact ledgers are in results.json.
The full tested research prototype was executed in the session; this compact file records its immutable interface and equations, not a claim of a monolithic rerun from this bundle.
"""

FORWARD_UNKNOWNS=("photon_groups","x_HII","x_HeII","x_HeIII","u_th")
FORWARD_DERIVED=("Gamma_HI","Gamma_HeI","Gamma_HeII","opacity","temperature","Q")
INVERSE_INPUTS=("Q_history","Gamma_target_or_posterior","opacity_lane")
INVERSE_OUTPUTS=("emissivity",)
CANONICAL_OPACITY_LANES=("MEAN_DENSITY","RAW_ZENODO_DIRECT","PUBLIC_REPO_EXACT")
RETIRED_LANES=("D10",)

def inverse_identifiability_constraint(Gamma, emissivity, response):
    return Gamma-emissivity*response(Gamma)
