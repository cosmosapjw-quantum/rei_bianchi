ClearAll["Global`*"];
constraint = gam - eps a[gam];
invResidual = FullSimplify[constraint /. eps -> gam/a[gam], Assumptions -> {gam>0,a[gam]>0}];
kHItot=Max[kemu,kHI]; kunres=kHItot-kHI; ktot=kHItot+kHeI+kHeII;
frac={kHI,kunres,kHeI,kHeII}/ktot;
p=24/25; l=57/40; m=737/1000; w=(l-m)+m y;
AH=v w+(1-v) f z; AHe=v m(1-y)+(1-v)f(1-z);
channels={{1,-1,0,0,0},{-y,y,y,-y,0},{-p,p,1,-1,0},
{-(1-y2a-y2b),1-y2a-y2b,-y2b,1+y2b-y2a,-1+y2a},
{-1,1,0,1,-1},{-AH,AH,-AHe,1+AHe,-1}};
<|"InverseResidual"->invResidual,"GammaJacobian"->D[constraint,gam],
"PhotonLedger"->FullSimplify[Total[frac]-1,Assumptions->{kemu>=0,kHI>=0,kHeI>=0,kHeII>=0,ktot>0}],
"OTSResiduals"->Table[{{1,1,0,0,0}.channels[[i]],{0,0,1,1,1}.channels[[i]]},{i,6}]|>