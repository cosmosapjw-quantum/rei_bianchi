#!/usr/bin/env bash
set -euo pipefail
TAG=${CLOUDY_TAG:-c25.00}
ROOT=${CLOUDY_ROOT:-$PWD/cloudy-$TAG}
RUN=${1:-$PWD/run}
if [[ ! -x "$ROOT/source/cloudy.exe" ]]; then
  [[ -d "$ROOT/.git" ]] || git clone --depth 1 --branch "$TAG" https://gitlab.nublado.org/cloudy/cloudy.git "$ROOT"
  make -C "$ROOT/source" -j"${JOBS:-$(nproc)}"
fi
mkdir -p "$RUN"; cp caseB_lowdensity.in hard_xray.in thermal_balance.in "$RUN"/
cd "$RUN"
for m in caseB_lowdensity hard_xray thermal_balance; do "$ROOT/source/cloudy.exe" -r "$m" >"$m.stdout" 2>"$m.stderr"; done
sha256sum * > SHA256SUMS
