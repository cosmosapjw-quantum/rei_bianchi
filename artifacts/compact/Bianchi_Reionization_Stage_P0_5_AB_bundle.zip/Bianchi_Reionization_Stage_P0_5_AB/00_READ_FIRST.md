# Stage P0.5-A/B — Final status

## Verdict

**P0.5-A: PASS with a timestep/branch firewall.**

**P0.5-B: PARTIAL FAIL.** The independent global Q budget does not close when both the observed Gamma history and the target Q history are imposed through the current inverse-emissivity closure.

**Cloudy C25: BLOCKED_BY_RUNTIME_NETWORK.** No Cloudy output is claimed.

**P0.5-C is not authorized yet.**

## Fixed-z result

At z=5.5 and dt=0.0125 Myr, the inverse mode inferred
`6.48891969e+50 photons s^-1 cMpc^-3` for
Gamma_HI=`3.44e-13 s^-1`.

The converged state is

- x_HII = `0.999909259690`
- x_HeII = `0.996188546173`
- x_HeIII = `0.002999924887`
- T_b = `14999.664055 K`

Algebraic forward/inverse Gamma consistency is `2.906e-14`.
An independently iterated forward solve from the previous state agrees to
`4.341e-07` in Gamma.

All photon, photon-energy, H-nucleus, He-nucleus and local primary-ionization ledgers close at 1e-16 or better. The unresolved absorber sink carries 42.7% of absorptions in this fixture and is never double-counted as diffuse-H chemistry or local heating.

## Branch safety

At dt=0.05 Myr the implicit time-averaged equations possess multiple roots / Picard basins. The target inverse root has Picard spectral radius 1.233; a second root has radius 0.780. This is a nonlinear solver property, not evidence for physical plasma bistability.

Step halving restores independent forward/inverse agreement:

- 0.025 Myr: 3.07e-6
- 0.0125 Myr: 3.94e-7
- 0.00625 Myr: 1.27e-7
- 0.003125 Myr: 3.77e-8

The production rule is previous-state continuation, branch audit, and step halving; use branch-tracked block Newton near a fold.

## Regressions

The H-only result differs from the pyC2Ray regression by 2.67e-6.
The Durrer-style coupled radiation/ionization/temperature smoke test converges at first order to a high-accuracy ODE reference. It tests the coupled ODE structure, not Durrer's original 1993 rate coefficients.

## FLRW result

The dynamic Q-history run recomputed the checkpoint opacity after appending newly ionized volume to the z_re histogram. Radiation forward/inverse residuals remained below 1.65e-11 and dynamic opacity was 1.063--1.146 times the prescribed-history opacity.

Nevertheless it ended at Q_budget=`0.999721` while Q_target=`0.898808`. The discrepancy is `0.100913`.

Therefore Q and Gamma cannot both be treated as exact prescribed histories in the current inverse closure. Predictive mode must input a source/escape model and predict Q; inverse mode may condition on Q and Gamma, but the independent Q budget becomes a calibration likelihood.

## Cloudy

Actual clone and tarball-download commands were executed. DNS resolution failed for the official GitLab, data.nublado.org, and the OMA mirror before source transfer. Runnable c25.00 decks and a launcher are included, along with the raw failure logs.
