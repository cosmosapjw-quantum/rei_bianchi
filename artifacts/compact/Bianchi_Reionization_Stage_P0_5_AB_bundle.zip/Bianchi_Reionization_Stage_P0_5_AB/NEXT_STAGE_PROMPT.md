@Web+Wolfram Stage P0.5-B1-Q-CLOSURE-AND-CLOUDY를 실행해줘.

P0.5-A의 component firewall, full-OTS matrix chemistry, thermal-energy ledger와 branch-safe timestep rule을 유지한다.

1. predictive forward mode에서는 source emissivity/escape model을 입력하고 Gamma_HI와 Q(z)를 함께 예측한다.
2. inverse calibration mode에서는 Q(z), Gamma posterior, opacity를 입력해 emissivity/escape parameter를 추론하고 Q-budget residual을 likelihood로 사용한다. Q와 Gamma를 동시에 exact targets로 강제하지 않는다.
3. source efficiency 또는 escape fraction을 block Newton으로 풀어 Q-budget residual을 1e-4 아래로 낮춘다.
4. dt=0.05 Myr implicit roots를 pseudo-arclength/branch-tracked Newton으로 분류하고 accepted branch의 Jacobian 및 timestep-halving consistency를 저장한다.
5. Cloudy C25 c25.00을 network-enabled runtime에서 실제 빌드하고 세 input lane을 실행하여 source, executable, output hashes를 잠근다.
6. 이 gate가 닫힌 뒤에만 P0.5-C의 Bianchi I/V/II UV characteristic 결합을 시작한다.
