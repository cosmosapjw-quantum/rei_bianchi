@Web+Wolfram Stage P0.2-PUBLIC-BENCHMARK-GATE를 실행해줘.

P0.1의 SH95/PyNeb public hydrogenic backend와 bubble-horizon sink bracket을
정본으로 유지한다.

1. SH95 HII/HeIII Cases A/B interpolator를 IGM low-density asymptote,
   nebular grid nodes, Hui-Gnedin overlap에서 전수 검증한다.
2. Cloudy C25를 pinned tag c25.00으로 실행하고 low-density Case-B,
   hard-X-ray, thermal-balance lanes의 output을 hash-lock한다.
3. Case-B lane에서는 SH95/PyNeb를 truth anchor로 사용하고, hard/X-ray
   lane에서만 Cloudy full atom을 auditor로 승격한다.
4. absorber MFP와 SPA/PS bubble horizon을 independent-hazard model로
   결합하여 x_e, T_b, tau, T/E/B의 topology-systematic envelope를 계산한다.
5. Durrer 1993 homogeneous ODE를 smoke-test baseline으로 재현한다.
6. 이 gate가 닫힌 뒤 full-frequency G1/P1와 Stebbins moments의 monolithic
   time-dependent I/V/II audit로 넘어간다.
