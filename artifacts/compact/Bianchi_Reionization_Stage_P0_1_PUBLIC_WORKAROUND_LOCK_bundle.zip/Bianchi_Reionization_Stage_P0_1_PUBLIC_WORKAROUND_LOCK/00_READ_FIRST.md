# Stage P0.1 — PUBLIC WORKAROUND LOCK

## Verdict

`PASS WITH CALIBRATION GATES`.

Private/unavailable artifacts no longer block the solver architecture.

### Rate blocker

The primary public hydrogenic backend is now:

- Storey-Hummer 1995 total recombination tables for H II -> H I and
  He III -> He II, Cases A/B;
- exact PyNeb data blobs pinned at commit
  `7aab5be7cf460e5e063a005253b1d60cffb63ecb`;
- log-bilinear interpolation on the published grid;
- lowest-density column used as an explicit low-density asymptote with
  a first-column/second-column systematic;
- Hui-Gnedin fallback outside the SH95 temperature domain;
- no high-density extrapolation.

This does **not** cover He II -> He I, which remains on the public
Hui-Gnedin + dielectronic backend and is audited against PyNeb He I line
data and Cloudy C25.

At 1e4 K, the low-density SH95/Hui-Gnedin ratios and asymptotic systematics
are in `sh95_validation.csv`. Grid-node interpolation residuals are zero to
floating precision.

### Sink blocker

The unavailable MFP checkpoint is no longer on the critical path.

The transparent public bracket is:

1. absorber MFP from the existing SCRIPT/lognormal self-shielding closures;
2. geometric horizon from a public ionized-bubble estimator:
   `R = 4 R_SPA` or `R = 2.46/k_peak`;
3. spherical one-sided mean path `lambda_geom = 3 <R>_V / 4`;
4. independent-hazard combination
   `1/lambda_eff = 1/lambda_abs + 1/lambda_geom`.

This is a systematic bracket, not a claim to reproduce the private
emulator.

### Thermal blocker

Cloudy C25 is pinned as an external auditor. It is not used to overwrite
SH95 where Case A/B assumptions hold. Three input lanes are supplied:
low-density Case B, hard/X-ray, and thermal balance. They remain
`IMPLEMENTED_TEMPLATE_NOT_EXECUTED` until a C25 binary is run and the
outputs are hash-locked.

### Zenodo blocker

The supplied Zenodo record could not be resolved through the available
web cache. It is no longer required: PyNeb commit and data-blob hashes are
the durable source lock.

## Immediate promotion gates

1. Run the four SH95 backend regression tests.
2. Install Cloudy C25 and execute the three benchmark lanes.
3. Compare SH95/PyNeb and Cloudy in the Case-B-valid lane.
4. Promote Cloudy only for the non-Case-B/hard-spectrum thermal lane.
5. Add the bubble-horizon bracket to the homogeneous sink systematic
   envelope.
6. Only after these pass, run the monolithic full-frequency vs Stebbins
   time-dependent audit.
