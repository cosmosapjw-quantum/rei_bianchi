"""Public, fail-closed Storey-Hummer total-recombination backend.

Data source
-----------
Storey & Hummer (1995), VizieR VI/64, as distributed in PyNeb at commit
7aab5be7cf460e5e063a005253b1d60cffb63ecb.

This backend covers:
- H II -> H I, Cases A/B
- He III -> He II, Cases A/B

It does NOT cover non-hydrogenic He II -> He I recombination.

For IGM electron densities below the SH95 density grid (1e2 cm^-3), the
lowest-density column is treated as a low-density asymptote. The difference
between the first two density columns is returned as a systematic estimate.
No high-density extrapolation is allowed. Outside the SH95 temperature
domain, the source-locked Hui-Gnedin hydrogenic fit is used.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import pandas as pd


class DomainError(ValueError):
    pass


@dataclass(frozen=True)
class Result:
    alpha_cm3_s: float
    backend: str
    systematic_fraction: float


class SH95Backend:
    def __init__(self, csv_path: str | Path):
        self.df = pd.read_csv(csv_path)

    @staticmethod
    def _hg(reaction: str, case: str, T: float) -> float:
        if not (10.0 <= T <= 1e7):
            raise DomainError("Hui-Gnedin fallback locked to 10 K <= T <= 1e7 K")
        if reaction == "HII_to_HI":
            lam = 315614.0 / T
            scale = 1.0
        elif reaction == "HeIII_to_HeII":
            lam = 1263030.0 / T
            scale = 2.0
        else:
            raise DomainError("Only hydrogenic HII and HeIII are supported")
        if case == "A":
            val = 1.269e-13*lam**1.503/(1+(lam/0.522)**0.470)**1.923
        elif case == "B":
            val = 2.753e-14*lam**1.5/(1+(lam/2.740)**0.407)**2.242
        else:
            raise DomainError("case must be A or B")
        return scale*val

    def evaluate(self, reaction: str, case: str, T: float, ne: float) -> Result:
        sub = self.df[(self.df.reaction == reaction) & (self.df.case == case)]
        if sub.empty:
            raise DomainError(f"Unknown reaction/case: {reaction}/{case}")
        Ts = np.sort(sub.temperature_K.unique())
        nes = np.sort(sub.electron_density_cm3.unique())
        arr = (
            sub.pivot(index="temperature_K", columns="electron_density_cm3",
                      values="alpha_cm3_s")
            .loc[Ts, nes].to_numpy()
        )

        if T < Ts[0] or T > Ts[-1]:
            return Result(self._hg(reaction, case, T), "HUI_GNEDIN_T_FALLBACK", float("nan"))
        if ne < nes[0]:
            v0 = 10**np.interp(np.log10(T), np.log10(Ts), np.log10(arr[:,0]))
            v1 = 10**np.interp(np.log10(T), np.log10(Ts), np.log10(arr[:,1]))
            return Result(v0, "SH95_LOW_DENSITY_ASYMPTOTE_NE1E2", abs(v1-v0)/v0)
        if ne > nes[-1]:
            raise DomainError("Electron density above SH95 grid; no extrapolation")

        lt, ln = np.log10(T), np.log10(ne)
        i = np.clip(np.searchsorted(np.log10(Ts), lt)-1, 0, len(Ts)-2)
        j = np.clip(np.searchsorted(np.log10(nes), ln)-1, 0, len(nes)-2)
        ft = (lt-np.log10(Ts[i]))/(np.log10(Ts[i+1])-np.log10(Ts[i]))
        fn = (ln-np.log10(nes[j]))/(np.log10(nes[j+1])-np.log10(nes[j]))
        z = np.log10(arr)
        value = 10**(
            (1-ft)*(1-fn)*z[i,j] + ft*(1-fn)*z[i+1,j]
            + (1-ft)*fn*z[i,j+1] + ft*fn*z[i+1,j+1]
        )
        return Result(value, "SH95_LOG_BILINEAR", 0.0)
