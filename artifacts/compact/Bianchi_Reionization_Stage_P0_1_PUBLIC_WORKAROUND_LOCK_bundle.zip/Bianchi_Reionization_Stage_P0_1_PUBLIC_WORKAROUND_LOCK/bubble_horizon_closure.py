"""Transparent topology-limited MFP closure.

This is not a substitute for unresolved absorber physics. It supplies a
separate geometric horizon which can be combined with an absorber MFP.

Public estimators from Friedrich et al. (2011, arXiv:1006.2016):
- corrected spherical-average scale: R_phys = 4 R_SPA
- ionization power-spectrum scale: R_phys = 2.46/k_peak

For a volume-weighted distribution of spherical bubble radii, the mean
one-sided distance from a uniformly selected interior point to the boundary
along an isotropic direction is 3R/4. Hence lambda_geom = 3 <R>_V / 4.

Independent hazards are combined by
    1/lambda_eff = 1/lambda_abs + 1/lambda_geom.
"""
from __future__ import annotations
import math
import numpy as np


class TopologyDomainError(ValueError):
    pass


def radius_from_spa(R_spa_mpc: float) -> float:
    if R_spa_mpc <= 0:
        raise TopologyDomainError("R_SPA must be positive")
    return 4.0*R_spa_mpc


def radius_from_power_peak(k_peak_mpc_inv: float) -> float:
    if k_peak_mpc_inv <= 0:
        raise TopologyDomainError("k_peak must be positive")
    return 2.46/k_peak_mpc_inv


def mean_geometric_path_from_volume_weighted_radii(radii_mpc, weights=None) -> float:
    r = np.asarray(radii_mpc, dtype=float)
    if np.any(r <= 0):
        raise TopologyDomainError("all radii must be positive")
    w = np.ones_like(r) if weights is None else np.asarray(weights, dtype=float)
    if np.any(w < 0) or w.sum() <= 0:
        raise TopologyDomainError("weights must be nonnegative with positive sum")
    mean_R = np.sum(w*r)/np.sum(w)
    return 0.75*mean_R


def combine_independent_hazards(lambda_abs_mpc: float, lambda_geom_mpc: float) -> float:
    if lambda_abs_mpc <= 0 or lambda_geom_mpc <= 0:
        raise TopologyDomainError("MFPs must be positive")
    return 1.0/(1.0/lambda_abs_mpc + 1.0/lambda_geom_mpc)


def lognormal_volume_weighted_mean_radius(median_R_mpc: float, sigma_lnR: float) -> float:
    if median_R_mpc <= 0 or sigma_lnR < 0:
        raise TopologyDomainError("invalid lognormal parameters")
    return median_R_mpc*math.exp(0.5*sigma_lnR**2)
