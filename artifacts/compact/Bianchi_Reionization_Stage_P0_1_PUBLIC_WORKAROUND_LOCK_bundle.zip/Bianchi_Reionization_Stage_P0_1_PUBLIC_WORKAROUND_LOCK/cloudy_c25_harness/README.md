# Cloudy C25 external benchmark harness

## Pin

```bash
git clone https://gitlab.nublado.org/cloudy/cloudy.git -b c25.00 cloudy-c25
cd cloudy-c25/source
make -j
```

Pinned tag: `c25.00`, release tag short commit `fb07fa71`.

Cloudy is an **auditor**, not the primary source of Case-A/B hydrogenic
recombination coefficients. Cloudy's own FAQ says the Storey-Hummer tables
are more accurate when Case A/B assumptions hold. Cloudy becomes the
preferred benchmark when ground-state collisional excitation, induced
processes, non-Lyman transfer, high density, or X-rays invalidate Case B.

## Three benchmark lanes

1. `caseB_lowdensity.in`
   - low density, stellar spectrum, no X-rays
   - compare H and He II line/recombination outputs to SH95/PyNeb
   - compare equilibrium fractions and thermal balance to the homogeneous solver

2. `hard_xray.in`
   - power-law/X-ray source
   - Case B deliberately invalid
   - use Cloudy full atom as the external benchmark for ionization/heating

3. `thermal_balance.in`
   - H/He gas with fixed density and source
   - save overview, heating and cooling
   - compare channel totals and equilibrium temperature

The templates below use standard C25 command patterns but are marked
`IMPLEMENTED_TEMPLATE_NOT_EXECUTED`; run them against the pinned C25 binary
and lock the resulting output hashes before promotion.
