# Bianchi reionization — Stage T2-C verification ledger

## Scope

This stage advances the exact finite-tilt Thomson block from the paired moving-grid tests of T2-A/T2-B to a fixed log-energy grid and a stiff normal-time implicit solve.

Conventions:

- metric signature `(-,+,+,+)`;
- classical elastic Thomson limit;
- exact finite bulk tilt;
- real symmetric `2 x 2` linear-polarization coherency tensor;
- Stokes `V`, recoil, thermal Comptonization, and Klein–Nishina corrections remain outside this gate.

## 1. Exact moment-space structure

For the rank-six in-scattering factors `U,V^T`, the induced operator on a symmetric `3 x 3` tensor `M` is

\[
K(M)=V^TU(M)=\frac{7}{10}M+\frac{1}{10}\operatorname{tr}(M)I.
\]

Therefore

\[
K=P_{\rm tr}+\frac{7}{10}P_{\rm STF},
\]

with exact eigenvalues

- `1` on the trace sector;
- `7/10` with multiplicity five on the STF sector.

The exact characteristic polynomial returned by Wolfram was

\[
(x-1)(10x-7)^5/10^5.
\]

For a degree-four-exact angular rule, the electron-frame Thomson operator consequently has eigenvalues `0`, `-3/10` (five modes), and `-1` on the remaining angular subspace.

## 2. Conservative fixed-grid remapping

For a fractional right shift `alpha` on a periodic uniform log-energy grid,

\[
R_+=(1-\alpha)I+\alpha S_+,
\qquad
R_-=(1-\alpha)I+\alpha S_-.
\]

Wolfram verified the exact identity

\[
R_-R_+
=I+\alpha(1-\alpha)(S_++S_--2I).
\]

Hence a positive, conservative first-order fixed-grid remap is not exactly invertible: a discrete-Laplacian smoothing remains. At `alpha=1/2` on a six-cell periodic grid, the forward remap has nullity one.

A 24-cell nonperiodic overlap remap with a shift of `2.37` cells gave:

- augmented column-sum residual: zero to about 48 digits;
- random mass-ledger residual: zero to about 47 digits;
- minimum matrix entry: `0`;
- an interior coarse-grid forward/backward relative L1 error of about `4.9044e-2`.

The last value is not a failure of conservation; it quantifies the expected diffusion of the first-order baseline.

### Critical Wolfram-language bug caught

`FractionalPart[-3.091906567872317]` evaluates to approximately `-0.091906567872317`, because it follows `IntegerPart`, not `Floor`. Using it directly generated negative remap weights and destroyed coherency positivity.

The correct definition is

\[
m=\lfloor s\rfloor,
\qquad
\alpha=s-m\in[0,1).
\]

For the same example, `alpha = 0.908093432127683`.

## 3. Photon-number adapted spectral variable

The production remap variable is fixed to

\[
G(y,k)=e^{3y}F(y,k),
\qquad y=\ln(E/E_*),
\]

where `F=E^{-3}J` is the invariant coherency phase-space tensor.

For Doppler factor `D_p`, the forward fixed-grid map is

\[
G_e=D_p^3 R_p G_n.
\]

On paired angular nodes, the normal-frame solid-angle weights are

\[
w_p^{(n)}=D_p^2w_p^{(e)}.
\]

The normal-slice photon-number functional represented on the electron grid is therefore weighted by `w_e/D_p`.

Using a 12-bin periodic log-energy grid, Lebedev-14 angles, and `v=0.55`, Wolfram returned:

- row-sum residual: zero to about 58 digits;
- column-sum residual: zero to about 58 digits;
- minimum remap entry: `0`;
- normal-grid versus electron-grid photon-number representation residual: zero to about 56 digits;
- conjugated Thomson photon-number source: zero to about 56 digits;
- boosted isotropic-equilibrium collision residual: zero to about 58 digits;
- minimum local coherency eigenvalue after the forward remap in the random PSD test: `1.4232948800e-2`.

The periodic grid is an algebraic unit test. A physical nonperiodic spectrum still needs guard cells and a truncation ledger.

## 4. Direction-dependent normal-time collision

In electron angular variables the normal-time collision generator is

\[
L=D(-I+UV^T),
\]

where `D` is diagonal and repeats the directional Doppler factor on the three local coherency components.

Right and left null modes are

\[
Lr=0,
\qquad
\ell_N^TL=0,
\]

with `r` the isotropic unpolarized vector and

\[
\ell_N^T=\ell_e^TD^{-1}.
\]

Wolfram verified both null identities to roughly 89 digits. The spectrum was purely real and non-positive for the test case:

- minimum eigenvalue: about `-1.7590714852`;
- nonzero spectral gap: about `0.2357360016`;
- largest imaginary part: zero.

## 5. Rank-six backward-Euler solve

For optical-depth step `lambda`,

\[
A=I-\lambda L
=A_0-\lambda DU V^T,
\qquad
A_0=I+\lambda D.
\]

The standard Woodbury formula reduces the solve to a `6 x 6` Schur system.

At high precision it agreed exactly with a direct `42 x 42` solve through `lambda=10^6`, but the small Schur matrix becomes ill-conditioned as the trace null mode is approached:

| lambda | standard `6 x 6` condition |
|---:|---:|
| `1e2` | `2.6085104e1` |
| `1e6` | `2.5055043e5` |
| `1e12` | `2.5054680e11` |

In machine precision, the standard Woodbury relative solution error against a 90-digit reference grew from about `3.47e-15` at `lambda=1e2` to `7.27e-6` at `lambda=1e12`, and its conserved-moment error grew to `1.56e-4`.

## 6. Conservation-deflated Woodbury solve

Let

\[
a=\frac{\ell_N^Tb}{\ell_N^Tr},
\qquad
b_\perp=b-ar,
\]

and define

\[
A_0=I+\lambda D,
\quad
U_c=\lambda DU,
\quad
S=I-V^TA_0^{-1}U_c,
\quad
g=V^TA_0^{-1}b_\perp.
\]

Write

\[
x=ar+A_0^{-1}b_\perp+A_0^{-1}U_cy.
\]

The exact conservation condition is

\[
c^Ty=-d,
\quad
c^T=\ell_N^TA_0^{-1}U_c,
\quad
d=\ell_N^TA_0^{-1}b_\perp.
\]

Instead of solving the nearly singular `S y=g` alone, solve the consistent overdetermined system

\[
\begin{bmatrix}S\\c^T\end{bmatrix}y
=
\begin{bmatrix}g\\-d\end{bmatrix}
\]

with pivoted QR or SVD. Normal equations must not be used.

Wolfram machine-precision comparison against a 90-digit direct reference gave:

| lambda | deflated relative solution error | conserved-moment error | augmented `7 x 6` condition |
|---:|---:|---:|---:|
| `1e2` | `1.93e-16` | `0` | `6.64029` |
| `1e6` | `1.99e-16` | `0` | `6.91298` |
| `1e12` | `1.99e-16` | `0` | `6.91301` |

Thus the deflated formulation is asymptotic-preserving in the tested stiff limit, whereas the unmodified Schur solve is not numerically reliable there.

## Gate verdict

- exact rank-six moment algebra: **PASS**;
- first-order conservative overlap remap: **PASS as baseline**;
- exact remap inverse on a fixed positive grid: **REJECT as an invalid production requirement**;
- floor-based negative-shift handling: **PASS after bug fix**;
- fixed-grid `G=e^{3y}F` photon-number ledger: **PASS**;
- boosted isotropic null: **PASS**;
- directional-rate standard Woodbury: **PASS only for non-extreme stiffness**;
- conservation-deflated Woodbury: **PASS through `lambda=1e12` in the reference test**;
- physical nonperiodic high-order remap: **not yet complete**;
- fixed-grid spin-2 angular conversion: **not yet complete**.

## Next stage

Stage T2-D should implement the angular conversion between a high-resolution transport grid and a lower-resolution collision grid. It must include exact aberration, screen-basis phase transport, number-conservative restriction/prolongation, and a weighted adjoint pullback. The scalar/intensity conversion should be closed before the spin-2 polarization block is enabled.
