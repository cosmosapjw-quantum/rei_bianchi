
from __future__ import annotations
import json, time
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
import torch
from p03_common import *

def stats(g):
    x=g.dlog10_lambda.to_numpy()
    return pd.Series({
        'n':len(x),'mean':x.mean(),'std':x.std(ddof=1) if len(x)>1 else 0.0,
        'q025':np.quantile(x,.025),'q16':np.quantile(x,.16),
        'q50':np.quantile(x,.5),'q84':np.quantile(x,.84),'q975':np.quantile(x,.975)
    })

def main():
    torch.set_num_threads(min(8, os.cpu_count() or 4))
    t0=time.time()
    model=MFPModel(CHECKPOINT)
    path=extract_training_data()
    data=np.loadtxt(path)
    nenv=len(data)
    energy_arr=np.repeat(ENERGIES, nenv)
    env_arr=np.tile(np.arange(nenv), len(ENERGIES))
    z=np.tile(data[:,0], len(ENERGIES))
    zre=np.tile(data[:,1], len(ENERGIES))
    gamma=np.tile(data[:,2], len(ENERGIES))
    density=np.tile(data[:,3], len(ENERGIES))
    y=np.concatenate([data[:,4+j] for j in range(len(ENERGIES))])
    idx=np.arange(len(y))
    train_val,test=train_test_split(idx,test_size=.1,random_state=42)
    train,val=train_test_split(train_val,test_size=1/9,random_state=42)
    pred=model.predict_batch(z[test],zre[test],gamma[test],density[test],energy_arr[test],batch=16384)
    rlog=np.log10(pred/y[test])
    tdf=pd.DataFrame({
        'expanded_index':test,'environment_index':env_arr[test],
        'z':z[test],'z_re':zre[test],'Gamma12':gamma[test],
        'density_sigma':density[test],'energy_eV':energy_arr[test],
        'lambda_true_cMpc':y[test],'lambda_pred_cMpc':pred,
        'dlog10_lambda':rlog,'age_dz':zre[test]-z[test],
    })
    edge_map={}
    tdf['loglambda_bin']=-1
    for E in ENERGIES:
        mask=tdf.energy_eV==E
        edges=np.quantile(np.log10(tdf.loc[mask,'lambda_true_cMpc']),[0,1/3,2/3,1])
        edges[0]-=1e-9; edges[-1]+=1e-9
        edge_map[str(float(E))]=edges.tolist()
        tdf.loc[mask,'loglambda_bin']=pd.cut(
            np.log10(tdf.loc[mask,'lambda_true_cMpc']),edges,
            labels=False,include_lowest=True)
    tdf['age_bin']=pd.cut(tdf.age_dz,[-1e-9,.5,2,np.inf],labels=False,include_lowest=True)
    tdf['gamma_bin']=pd.cut(np.log10(tdf.Gamma12),[-np.inf,-.5,.5,np.inf],labels=False)
    tdf['density_bin']=pd.cut(tdf.density_sigma,[-np.inf,-.5,.5,np.inf],labels=False)
    keys=['energy_eV','loglambda_bin','age_bin','gamma_bin','density_bin']
    table=tdf.groupby(keys,observed=True).apply(stats,include_groups=False).reset_index()
    fallback=tdf.groupby(['energy_eV'],observed=True).apply(stats,include_groups=False).reset_index()
    table.to_csv(DATA_DIR/'empirical_residual_model.csv',index=False)
    fallback.to_csv(DATA_DIR/'empirical_residual_fallback_energy.csv',index=False)
    tdf.to_csv(DATA_DIR/'test_residuals.csv.gz',index=False,compression='gzip')
    # Pairwise residual correlation using only environments with both energies in public test split.
    pivot=tdf.pivot_table(index='environment_index',columns='energy_eV',values='dlog10_lambda',aggfunc='first')
    corr=pivot.corr(min_periods=30)
    counts=pd.DataFrame(index=ENERGIES,columns=ENERGIES,dtype=int)
    for e1 in ENERGIES:
        for e2 in ENERGIES:
            counts.loc[e1,e2]=pivot[[e1,e2]].dropna().shape[0] if e1 in pivot and e2 in pivot else 0
    corr.to_csv(DATA_DIR/'energy_residual_correlation.csv')
    counts.to_csv(DATA_DIR/'energy_residual_pair_counts.csv')
    meta={
        'checkpoint_sha256':model.sha256,'n_environments':nenv,
        'n_test':len(test),'split':'expanded-row public code split random_state=42',
        'bin_edges':edge_map,'runtime_s':time.time()-t0,
        'test_metrics':{
            'median_abs_relative_error':float(np.median(np.abs(pred/y[test]-1))),
            'mean_abs_relative_error':float(np.mean(np.abs(pred/y[test]-1))),
            'median_dlog10':float(np.median(rlog)),
            'std_dlog10':float(np.std(rlog,ddof=1)),
        }
    }
    (DATA_DIR/'residual_model_meta.json').write_text(json.dumps(meta,indent=2))
    print(json.dumps(meta,indent=2))

if __name__=='__main__': main()
