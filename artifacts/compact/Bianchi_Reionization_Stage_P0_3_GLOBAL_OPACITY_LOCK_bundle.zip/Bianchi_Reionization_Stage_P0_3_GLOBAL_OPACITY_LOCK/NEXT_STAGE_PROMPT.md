@Web+Wolfram Stage P0.4-DC-MODE-AND-MONOLITHIC-CHEMISTRY를 실행해줘.

P0.3의 global-opacity core, empirical checkpoint residual model, Q/x_e
firewall, high-energy atomic lane을 정본으로 유지한다.

1. Gnedin et al. 2011 DC-mode formalism과 D'Aloisio et al. 2020 simulation
   setup을 이용해 deposited density_sigma nodes에 대응하는 exact
   delta_NL(z)와 volume factor를 복원하고, public spherical-collapse 및
   paper-10%-diagnostic lanes를 대체하거나 정식 systematic으로 재분류해줘.
2. training simulation의 2 h^-1 cMpc DC-mode normalization과 sigma_box(z)를
   source-level로 잠그고, density integration의 약 10% MFP 감소를
   energy/redshift 전체에서 회귀검증해줘.
3. P0.3 kappa_g(z)를 R0-C full-OTS H/He chemistry와 하나의 implicit
   photon-conserving loop에서 결합하고, x_e^ion(z), T_b(z), Q(z), tau,
   dotN_gamma(z)를 동시 진화해줘.
4. measured-Gamma and fixed-emissivity lanes를 분리하고, checkpoint,
   Gamma measurement/history, Q-history, DC-mode, topology systematics를
   joint posterior ledger로 구성해줘.
5. Cloudy C25 high-energy/thermal auditor를 실제 실행하여 39.5 eV 이상
   Verner/Friedrich lane을 검증해줘.
6. 이 gate가 닫힌 뒤 full-frequency G1/P1와 Stebbins moments의
   monolithic Bianchi I/V/II audit로 복귀해줘.
