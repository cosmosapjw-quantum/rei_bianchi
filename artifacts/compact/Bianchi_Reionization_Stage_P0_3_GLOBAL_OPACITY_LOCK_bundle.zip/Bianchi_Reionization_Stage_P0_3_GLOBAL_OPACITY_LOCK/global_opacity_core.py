from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import os
import sys
import textwrap
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from scipy.integrate import quad, simpson
from scipy.optimize import brentq
from scipy.special import ndtri
from scipy.stats import binned_statistic_dd
from sklearn.model_selection import train_test_split

ROOT = Path('/mnt/data/Bianchi_Reionization_Stage_P0_3_GLOBAL_OPACITY_LOCK')
ROOT.mkdir(parents=True, exist_ok=True)
DATA_DIR = ROOT / 'data'
DATA_DIR.mkdir(exist_ok=True)

P02 = Path('/mnt/data/Bianchi_Reionization_Stage_P0_2_ZENODO_ASSET_LOCK')
P01 = Path('/mnt/data/Bianchi_Reionization_Stage_P0_1_PUBLIC_WORKAROUND_LOCK')
CHECKPOINT = P02 / 'trained_emulator_sanitized_v1.pt'
ORIGINAL_ZIP = Path('/mnt/data/An emulator for the ionizing photon mean free path code and trained model.zip')

# ------------------------------ constants ---------------------------------
MPC_CM = 3.085677581491367e24
C_LIGHT = 2.99792458e10
SIGMA_T = 6.6524587321e-25
G_NEWTON = 6.67430e-8
M_PROTON = 1.67262192369e-24
K_B = 1.380649e-16
EV_ERG = 1.602176634e-12
YEAR_S = 365.25 * 86400.0
OMEGA_M = 0.305
OMEGA_B = 0.048
OMEGA_L = 1.0 - OMEGA_M
HUBBLE_h = 0.68
H0 = 100.0 * HUBBLE_h * 1e5 / MPC_CM
NS = 0.9667
SIGMA8 = 0.82
Y_HE = 0.245
F_HE = Y_HE / (4.0 * (1.0 - Y_HE))
RHO_CRIT = 3 * H0**2 / (8 * math.pi * G_NEWTON)
N_H0 = OMEGA_B * RHO_CRIT * (1.0 - Y_HE) / M_PROTON
DELTA_C = 1.686
ENERGIES = np.array([13.6, 14.48, 16.7, 20.05, 25.5, 39.5])
DENSITY_REQUESTED = np.array([-math.sqrt(3.0), 0.0, math.sqrt(3.0)])
# The deposited table uses +/-1.73, slightly inside the exact roots.
DENSITY_EVAL = np.array([-1.73, 0.0, 1.73])
GH_WEIGHTS = np.array([1/6, 2/3, 1/6], dtype=float)
Z_VALUES = np.round(np.arange(5.0, 6.0001, 0.1), 1)
Z_MID = 6.58
DELTA_Z = 1.63
ALPHA_SOURCE = 1.5

GAMMA_DATA = {
    5.0:(0.557,0.376,0.218), 5.1:(0.508,0.324,0.192),
    5.2:(0.502,0.292,0.193), 5.3:(0.404,0.272,0.147),
    5.4:(0.372,0.217,0.126), 5.5:(0.344,0.219,0.130),
    5.6:(0.319,0.194,0.120), 5.7:(0.224,0.223,0.112),
    5.8:(0.178,0.194,0.078), 5.9:(0.151,0.151,0.079),
    6.0:(0.145,0.157,0.087),
}

# ------------------------------ checkpoint --------------------------------
class ResidualBlock(nn.Module):
    def __init__(self, d: int):
        super().__init__()
        self.fc1 = nn.Linear(d,d); self.fc2 = nn.Linear(d,d)
        self.norm1 = nn.LayerNorm(d); self.norm2 = nn.LayerNorm(d)
        self.act = nn.Mish()
    def forward(self, x):
        r=x
        return self.act(self.norm2(self.fc2(self.act(self.norm1(self.fc1(x)))))+r)

class ResidualMLP(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, n_blocks: int):
        super().__init__()
        self.fc_in=nn.Linear(input_dim,hidden_dim); self.norm_in=nn.LayerNorm(hidden_dim)
        self.act=nn.Mish(); self.blocks=nn.Sequential(*[ResidualBlock(hidden_dim) for _ in range(n_blocks)])
        self.fc_out=nn.Linear(hidden_dim,1)
    def forward(self,x):
        return self.fc_out(self.blocks(self.act(self.norm_in(self.fc_in(x)))))

class MFPModel:
    def __init__(self, checkpoint: Path):
        d=torch.load(checkpoint,map_location='cpu',weights_only=True)
        cfg=d['model_config']
        self.model=ResidualMLP(cfg['input_dim'],cfg['hidden_dim'],cfg['n_blocks'])
        self.model.load_state_dict(d['model_state']); self.model.eval()
        self.in_center=d['input_scaler_center'].numpy().astype(float)
        self.in_scale=d['input_scaler_scale'].numpy().astype(float)
        self.out_center=d['output_scaler_center'].numpy().astype(float)
        self.out_scale=d['output_scaler_scale'].numpy().astype(float)
        self.sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest()
    def predict_batch(self,z,zre,gamma,density,energy,batch=16384):
        z,zre,gamma,density,energy=np.broadcast_arrays(z,zre,gamma,density,energy)
        if np.any(z < 3.99) or np.any(z > 14.95) or np.any(z > zre):
            raise ValueError('z domain or z<=z_re violated')
        if np.any(zre < 5) or np.any(zre > 15): raise ValueError('z_re domain')
        if np.any(gamma < .03) or np.any(gamma > 30): raise ValueError('Gamma12 domain')
        if np.any(density < -1.73) or np.any(density > 1.73): raise ValueError('density domain')
        if np.any(energy < 13.6) or np.any(energy > 39.5): raise ValueError('energy domain')
        wave=1239.8/energy/100.0
        x=np.column_stack([z.ravel(),zre.ravel(),gamma.ravel(),density.ravel(),wave.ravel()])
        xs=((x-self.in_center)/self.in_scale).astype(np.float32)
        out=[]
        with torch.inference_mode():
            for i in range(0,len(xs),batch):
                ys=self.model(torch.from_numpy(xs[i:i+batch])).numpy()
                out.append(10**(ys[:,0]*self.out_scale[0]+self.out_center[0])-1e-6)
        return np.concatenate(out).reshape(z.shape)

# -------------------------- histories / quadrature -------------------------
def Q_history(z):
    return 0.5*(1+np.tanh((Z_MID-np.asarray(z))/DELTA_Z))

def minus_dQ_dz(z):
    u=(Z_MID-np.asarray(z))/DELTA_Z
    return 0.5/DELTA_Z/np.cosh(u)**2

def zre_quadrature(z: float, n: int=40):
    x,w=np.polynomial.legendre.leggauss(n)
    zr=.5*(15-z)*x+.5*(15+z)
    raw=.5*(15-z)*w*minus_dQ_dz(zr)/Q_history(z)
    norm=raw.sum()
    return zr,raw/norm,norm

def split_lognormal_nodes(center, plus, minus, n=16):
    lo=max(center-minus,0.0300001); hi=center+plus
    mu=math.log(center)
    sm=max(mu-math.log(lo),1e-6); sp=max(math.log(hi)-mu,1e-6)
    q=(np.arange(n)+0.5)/n
    vals=np.empty(n)
    left=q<.5
    vals[left]=np.exp(mu-sm*ndtri(1-q[left]))
    vals[~left]=np.exp(mu+sp*ndtri(q[~left]))
    vals=np.clip(vals,.03,30)
    return vals,np.full(n,1/n)

def weighted_quantile(values, weights, qs):
    order=np.argsort(values); v=np.asarray(values)[order]; w=np.asarray(weights)[order]
    c=np.cumsum(w); c/=c[-1]
    return np.interp(qs,c,v)

# ----------------------- spherical collapse fallback -----------------------
def E_of_a(a): return math.sqrt(OMEGA_M/a**3+OMEGA_L)
def growth_unnorm(a):
    return 2.5*OMEGA_M*E_of_a(a)*quad(lambda ap: 1/(ap**3*E_of_a(ap)**3),1e-6,a,epsabs=1e-10,epsrel=1e-8)[0]
_GROWTH0=growth_unnorm(1.0)
def growth(z): return growth_unnorm(1/(1+z))/_GROWTH0

def transfer_zero_baryon(k):
    theta=2.7255/2.7
    keq=0.0746*OMEGA_M*HUBBLE_h**2/theta**2
    q=k/(13.41*keq)
    L=np.log(2*np.e+1.8*q); C=14.2+731/(1+62.5*q)
    return L/(L+C*q*q)

def top_hat(x):
    x=np.asarray(x)
    return np.where(np.abs(x)<1e-4,1-x*x/10,3*(np.sin(x)-x*np.cos(x))/x**3)

def sigma_box0():
    k=np.logspace(-5,4,40000)
    base=k**NS*transfer_zero_baryon(k)**2
    def sig2(R,A=1): return A*simpson(k**3*base*top_hat(k*R)**2/(2*np.pi**2),x=np.log(k))
    R8=8/HUBBLE_h; A=SIGMA8**2/sig2(R8)
    L=2/HUBBLE_h
    Reff=(3*L**3/(4*np.pi))**(1/3)
    return math.sqrt(sig2(Reff,A)),Reff

SIGMA_BOX0, R_BOX_EFF = sigma_box0()

def spherical_density_weights(z,sigma0):
    dl=DENSITY_REQUESTED*sigma0*growth(z)
    if np.any(1-dl/DELTA_C<=0): raise ValueError('spherical-collapse singular lane')
    dnl=(1-dl/DELTA_C)**(-DELTA_C)-1
    vol=1/(1+dnl)
    eta=1/np.dot(GH_WEIGHTS,vol)
    eff=eta*GH_WEIGHTS*vol
    return eff,dnl,eta

# --------------------------- atomic high-E lane ----------------------------
VERNER={
 'HI':(13.60,0.4298,5.475e4,32.88,2.963,0.,0.,0.),
 'HeI':(24.59,13.61,949.2,1.469,3.188,2.039,0.4434,2.136),
 'HeII':(54.42,1.720,1.369e4,32.88,2.963,0.,0.,0.),
}
def verner_sigma(species,E):
    eth,e0,s0,ya,p,yw,y0,y1=VERNER[species]
    E=np.asarray(E,float); out=np.zeros_like(E)
    mask=E>=eth
    x=E[mask]/e0-y0; y=np.sqrt(x*x+y1*y1)
    out[mask]=1e-18*s0*((x-1)**2+yw*yw)*y**(p/2-5.5)/(1+np.sqrt(y/ya))**p
    return out

# ---------------------------- chemistry fixture ----------------------------
def alphaB_HII(T):
    l=315614/T
    return 2.753e-14*l**1.5/(1+(l/2.740)**.407)**2.242

def alphaB_HeII(T):
    l=570670/T
    base=1.26e-14*l**.750
    dr=1.9e-3*T**-1.5*math.exp(-473638/T)*(1+.3*math.exp(-94728/T)) if T>=1.5e4 else 0
    return base+dr

def alphaB_HeIII(T):
    l=1263030/T
    return 2*2.753e-14*l**1.5/(1+(l/2.740)**.407)**2.242

def solve_hhe_equilibrium(z,T,G_HI,G_HeI,G_HeII=0.0,Delta=1.0,Ceff=1.0):
    nH=N_H0*(1+z)**3*Delta; nHe=F_HE*nH
    xe=1+F_HE
    for _ in range(200):
        ne=nH*xe
        rH=G_HI/(Ceff*alphaB_HII(T)*ne+1e-300)
        xHII=rH/(1+rH)
        r1=G_HeI/(Ceff*alphaB_HeII(T)*ne+1e-300)
        r2=G_HeII/(Ceff*alphaB_HeIII(T)*ne+1e-300)
        den=1+r1+r1*r2
        xHeI=1/den; xHeII=r1/den; xHeIII=r1*r2/den
        new=xHII+F_HE*(xHeII+2*xHeIII)
        if abs(new-xe)<1e-13: break
        xe=.5*xe+.5*new
    return {'xHII':xHII,'xHeI':xHeI,'xHeII':xHeII,'xHeIII':xHeIII,'xe_per_H':new,'nH':nH,'ne':nH*new}

def Hubble(z): return H0*math.sqrt(OMEGA_M*(1+z)**3+OMEGA_L)

# --------------------------- residual model build --------------------------
def extract_training_data():
    target=DATA_DIR/'environment_mfp_energies.txt'
    if not target.exists():
        with zipfile.ZipFile(ORIGINAL_ZIP) as zf:
            with zf.open('environment_mfp_energies.txt') as src, open(target,'wb') as dst:
                dst.write(src.read())
    return target

def build_residual_model(model: MFPModel):
    path=extract_training_data(); data=np.loadtxt(path)
    X=[]; Y=[]; energy_col=[]; env_col=[]
    for j,E in enumerate(ENERGIES):
        X.append(np.column_stack([data[:,:4],np.full(len(data),1239.8/E/100)]))
        Y.append(data[:,4+j]); energy_col.append(np.full(len(data),E)); env_col.append(np.arange(len(data)))
    X=np.vstack(X); Y=np.concatenate(Y); energy_arr=np.concatenate(energy_col); env_arr=np.concatenate(env_col)
    idx=np.arange(len(X)); train_val,test=train_test_split(idx,test_size=.1,random_state=42)
    train,val=train_test_split(train_val,test_size=1/9,random_state=42)
    print('Residual model: predicting 387552 expanded samples', flush=True)
    chunks=[]
    for start in range(0,len(X),50000):
        end=min(len(X),start+50000)
        chunks.append(model.predict_batch(X[start:end,0],X[start:end,1],X[start:end,2],X[start:end,3],1239.8/X[start:end,4]/100))
        print(f'  predicted {end}/{len(X)}', flush=True)
    pred=np.concatenate(chunks)
    rlog=np.log10(pred/Y)
    tdf=pd.DataFrame({
        'z':X[test,0],'z_re':X[test,1],'Gamma12':X[test,2], 'density_sigma':X[test,3],
        'energy_eV':energy_arr[test], 'lambda_true_cMpc':Y[test], 'lambda_pred_cMpc':pred[test],
        'dlog10_lambda':rlog[test], 'age_dz':X[test,1]-X[test,0],
    })
    # Per-energy log-lambda tercile edges; other axes use physical fixed bins.
    edge_map={}
    tdf['loglambda_bin']=-1
    for E in ENERGIES:
        mask=tdf.energy_eV==E
        edges=np.quantile(np.log10(tdf.loc[mask,'lambda_true_cMpc']),[0,1/3,2/3,1])
        edges[0]-=1e-9; edges[-1]+=1e-9
        edge_map[str(E)]=edges.tolist()
        tdf.loc[mask,'loglambda_bin']=pd.cut(np.log10(tdf.loc[mask,'lambda_true_cMpc']),edges,labels=False,include_lowest=True)
    tdf['age_bin']=pd.cut(tdf.age_dz,[-1e-9,.5,2,np.inf],labels=False,include_lowest=True)
    tdf['gamma_bin']=pd.cut(np.log10(tdf.Gamma12),[-np.inf,-.5,.5,np.inf],labels=False)
    tdf['density_bin']=pd.cut(tdf.density_sigma,[-np.inf,-.5,.5,np.inf],labels=False)
    keys=['energy_eV','loglambda_bin','age_bin','gamma_bin','density_bin']
    def stats(g):
        x=g.dlog10_lambda.to_numpy()
        return pd.Series({'n':len(x),'mean':x.mean(),'std':x.std(ddof=1),'q025':np.quantile(x,.025),'q16':np.quantile(x,.16),'q50':np.quantile(x,.5),'q84':np.quantile(x,.84),'q975':np.quantile(x,.975)})
    table=tdf.groupby(keys,observed=True).apply(stats,include_groups=False).reset_index()
    # energy fallback
    fallback=tdf.groupby(['energy_eV'],observed=True).apply(stats,include_groups=False).reset_index()
    table.to_csv(DATA_DIR/'empirical_residual_model.csv',index=False)
    fallback.to_csv(DATA_DIR/'empirical_residual_fallback_energy.csv',index=False)
    tdf.to_parquet(DATA_DIR/'test_residuals.parquet',index=False)
    # Correlation across all environments/energies (structure diagnostic, not held-out metric).
    R=rlog.reshape(len(ENERGIES),len(data)).T
    corr=np.corrcoef(R,rowvar=False)
    pd.DataFrame(corr,index=ENERGIES,columns=ENERGIES).to_csv(DATA_DIR/'energy_residual_correlation.csv')
    print('Residual model: tables complete', flush=True)
    return {'table':table,'fallback':fallback,'edges':edge_map,'corr':corr,'test':tdf,'all_pred':pred,'all_true':Y,'data':data}

# ------------------------- global opacity calculations ---------------------
def residual_bin_ids(lam,z,zre,gamma,density,E,edges):
    ekey=str(float(E)); ed=np.array(edges[ekey])
    lb=np.clip(np.digitize(np.log10(lam),ed[1:-1]),0,2)
    age=np.clip(np.digitize(zre-z,[.5,2]),0,2)
    gb=np.clip(np.digitize(np.log10(gamma),[-.5,.5]),0,2)
    db=np.clip(np.digitize(density,[-.5,.5]),0,2)
    return list(zip(np.full(len(np.ravel(lam)),float(E)),np.ravel(lb),np.ravel(age),np.ravel(gb),np.ravel(db)))

def build_lookup(res):
    table=res['table']; fallback=res['fallback']
    lut={}
    for _,r in table.iterrows():
        key=(float(r.energy_eV),int(r.loglambda_bin),int(r.age_bin),int(r.gamma_bin),int(r.density_bin))
        if r.n>=20: lut[key]=r.to_dict()
    fb={float(r.energy_eV):r.to_dict() for _,r in fallback.iterrows()}
    return lut,fb

@dataclass
class QueryBlock:
    z: float; E: float; gamma_nodes: np.ndarray; gamma_weights: np.ndarray
    zre_nodes: np.ndarray; zre_weights: np.ndarray; lambdas: np.ndarray
    bin_keys: list


def prepare_queries(model,res):
    blocks={}
    all_arrays=[]; meta=[]
    for z in Z_VALUES:
        zr,wz,norm=zre_quadrature(float(z),40)
        gc,gp,gm=GAMMA_DATA[float(z)]
        gn,wg=split_lognormal_nodes(gc,gp,gm,16)
        for E in ENERGIES:
            shape=(len(gn),len(zr),3)
            Z=np.full(shape,z); ZR=np.broadcast_to(zr[None,:,None],shape)
            G=np.broadcast_to(gn[:,None,None],shape); S=np.broadcast_to(DENSITY_EVAL[None,None,:],shape)
            EE=np.full(shape,E)
            all_arrays.append((Z.ravel(),ZR.ravel(),G.ravel(),S.ravel(),EE.ravel()))
            meta.append((float(z),float(E),gn,wg,zr,wz,shape,norm))
    cat=[np.concatenate([a[i] for a in all_arrays]) for i in range(5)]
    print(f'Global opacity queries: predicting {len(cat[0])} points', flush=True)
    preds=model.predict_batch(*cat,batch=8192)
    print('Global opacity queries: predictions complete', flush=True)
    pos=0
    for z,E,gn,wg,zr,wz,shape,norm in meta:
        n=np.prod(shape); lam=preds[pos:pos+n].reshape(shape); pos+=n
        Z=np.full(shape,z); ZR=np.broadcast_to(zr[None,:,None],shape); G=np.broadcast_to(gn[:,None,None],shape); S=np.broadcast_to(DENSITY_EVAL[None,None,:],shape)
        keys=residual_bin_ids(lam,Z,ZR,G,S,E,res['edges'])
        blocks[(z,E)]=QueryBlock(z,E,gn,wg,zr,wz,lam,keys)
    return blocks

def density_weights(lane,z,sigma_cal=None):
    if lane=='mean_density': return np.array([0.,1.,0.]),np.zeros(3),1.
    if lane=='deltaNL_zero': return GH_WEIGHTS.copy(),np.zeros(3),1.
    if lane=='spherical_EH': return spherical_density_weights(z,SIGMA_BOX0)
    if lane=='paper10_calibrated': return spherical_density_weights(z,sigma_cal)
    raise KeyError(lane)

def integrate_block(block,lane,sigma_cal=None):
    wd,dnl,eta=density_weights(lane,block.z,sigma_cal)
    kap=np.sum((1/block.lambdas)*wd[None,None,:],axis=2) # gamma,zre
    kg=np.sum(kap*block.zre_weights[None,:],axis=1)
    kpost=np.sum(kg*block.gamma_weights)
    lam_gamma=1/kg
    q16,q50,q84=weighted_quantile(lam_gamma,block.gamma_weights,[.16,.5,.84])
    return {'kappa':kpost,'lambda':1/kpost,'gamma_q16':q16,'gamma_q50':q50,'gamma_q84':q84,'wd':wd,'dnl':dnl,'eta':eta,'kg':kg}

def solve_sigma_cal(blocks):
    zlist=list(Z_VALUES)
    def avg_effect(sig):
        eff=[]
        for z in zlist:
            mean=integrate_block(blocks[(float(z),13.6)],'mean_density')['lambda']
            val=integrate_block(blocks[(float(z),13.6)],'paper10_calibrated',sig)['lambda']
            eff.append(val/mean-1)
        return float(np.mean(eff))
    root=brentq(lambda s: avg_effect(s)+.10,.05,3.0)
    return root,avg_effect(root),avg_effect(SIGMA_BOX0),avg_effect(0.0)

def checkpoint_mc(block,lane,lut,fb,sigma_cal,nmc=300,seed=1234):
    wd,_,_=density_weights(lane,block.z,sigma_cal)
    # full integration weights flattened
    a=(block.gamma_weights[:,None,None]*block.zre_weights[None,:,None]*wd[None,None,:]).ravel()
    lam=block.lambdas.ravel(); kap=1/lam
    keys=block.bin_keys
    uniq={k:i for i,k in enumerate(sorted(set(keys)))}
    idx=np.array([uniq[k] for k in keys])
    means=np.empty(len(uniq)); stds=np.empty(len(uniq))
    for k,i in uniq.items():
        r=lut.get(k,fb[k[0]])
        means[i]=r['mean']; stds[i]=max(r['std'],1e-6)
    rng=np.random.default_rng(seed+int(block.z*100)+int(block.E*10))
    draws=rng.normal(size=(nmc,len(uniq)))*stds+means
    r=draws[:,idx]
    kdraw=np.sum(a[None,:]*kap[None,:]*10**r,axis=1)
    ldraw=1/kdraw
    return np.quantile(ldraw,[.16,.5,.84]),np.mean(ldraw),np.std(ldraw)

# ------------------------ emissivity / spectrum ----------------------------
def log_interp_lambda(E_nodes,lam_nodes,E):
    return np.exp(np.interp(np.log(E),np.log(E_nodes),np.log(lam_nodes)))

def source_phi(E,Emin,Emax,alpha=ALPHA_SOURCE):
    E=np.asarray(E)
    pow=alpha+1
    if abs(pow-1)>1e-12:
        norm=(Emin**(1-pow)-Emax**(1-pow))/(pow-1)
    else: norm=math.log(Emax/Emin)
    return E**(-pow)/norm

def emissivity_from_lambda(z,gamma12,lam_nodes,extend=False):
    Emax=54.4 if extend else 39.5
    E=np.geomspace(13.6,Emax,400)
    lam=np.empty_like(E)
    inmask=E<=39.5
    lam[inmask]=log_interp_lambda(ENERGIES,lam_nodes,E[inmask])
    if np.any(~inmask):
        k39=1/lam_nodes[-1]
        ratio=verner_sigma('HI',E[~inmask])/verner_sigma('HI',np.array([39.5]))[0]
        lam[~inmask]=1/(k39*ratio)
    phi=source_phi(E,13.6,Emax)
    integ=simpson(phi*verner_sigma('HI',E)*lam,x=E) # cm2*cMpc
    dotN=gamma12*1e-12*MPC_CM**2/((1+z)**2*integ)
    return dotN,integ

def spectral_rates(z,dotN,lam_nodes,Emax=54.4):
    E=np.geomspace(13.6,Emax,500)
    lam=np.empty_like(E); mask=E<=39.5
    lam[mask]=log_interp_lambda(ENERGIES,lam_nodes,E[mask])
    if np.any(~mask):
        k39=1/lam_nodes[-1]
        ratio=verner_sigma('HI',E[~mask])/verner_sigma('HI',np.array([39.5]))[0]
        lam[~mask]=1/(k39*ratio)
    phi=source_phi(E,13.6,Emax)
    pref=(1+z)**2*dotN/MPC_CM**2
    out={}
    for sp,eth in [('HI',13.6),('HeI',24.59),('HeII',54.42)]:
        sig=verner_sigma(sp,E)
        I=simpson(phi*sig*lam,x=E)
        G=pref*I
        if G>0:
            excess=simpson(phi*sig*lam*np.maximum(E-eth,0),x=E)/I
        else: excess=0
        out[sp]=(G,excess)
    return out

def chemistry_response(z,gamma12,lam_nodes,dotN_fixed=None,T0=1.5e4):
    if dotN_fixed is None:
        dotN,_=emissivity_from_lambda(z,gamma12,lam_nodes,extend=True)
    else: dotN=dotN_fixed
    rates=spectral_rates(z,dotN,lam_nodes,54.4)
    eq=solve_hhe_equilibrium(z,T0,rates['HI'][0],rates['HeI'][0],rates['HeII'][0])
    nH=eq['nH']; nHe=F_HE*nH
    nHI=nH*(1-eq['xHII']); nHeI=nHe*eq['xHeI']; nHeII=nHe*eq['xHeII']
    heating=(nHI*rates['HI'][0]*rates['HI'][1]+nHeI*rates['HeI'][0]*rates['HeI'][1]+nHeII*rates['HeII'][0]*rates['HeII'][1])*EV_ERG
    cooling=eq['ne']*(nH*eq['xHII']*K_B*T0*alphaB_HII(T0)+nHe*eq['xHeII']*K_B*T0*alphaB_HeII(T0)+nHe*eq['xHeIII']*K_B*T0*alphaB_HeIII(T0))
    ntot=nH*(1+F_HE)+eq['ne']
    dTdt=-2*Hubble(z)*T0+2*(heating-cooling)/(3*K_B*ntot)
    return {'dotN':dotN,'rates':rates,'eq':eq,'heating':heating,'cooling':cooling,'dTdt':dTdt,'T_after_1Myr':max(1,T0+dTdt*1e6*YEAR_S)}

def tau_from_Q(local_xe_override=None):
    def xe_ion(z):
        base=1+F_HE if z>3.5 else 1+2*F_HE
        if local_xe_override and 5<=z<=6:
            zs=np.array(sorted(local_xe_override)); vals=np.array([local_xe_override[x] for x in zs])
            return float(np.interp(z,zs,vals))
        return base
    def integrand(z):
        xe=Q_history(z)*xe_ion(z)+(1-Q_history(z))*2e-4
        ne=N_H0*(1+z)**3*xe
        return C_LIGHT*SIGMA_T*ne/((1+z)*Hubble(z))
    return quad(integrand,0,20,epsabs=1e-9,epsrel=1e-7,limit=300)[0]

