ClearAll[Q,z,zr,zm,dz,w,d,eta,k];
Q[x_] := (1+Tanh[(zm-x)/dz])/2;
weights={1/6,2/3,1/6};
eta[ds_] := 1/Total[weights/(1+ds)];
effectiveWeights[ds_] := eta[ds] weights/(1+ds);
<|
 "ConditionalNormalization" ->
  FullSimplify[Integrate[-D[Q[u],u]/Q[z],{u,z,Infinity}],
   Assumptions->{dz>0,z\\[Element]Reals,zm\\[Element]Reals}],
 "GHWeightSum" -> Total[weights],
 "EtaNormalization" ->
  FullSimplify[Total[effectiveWeights[{d1,d2,d3}]],
   Assumptions->And@@Thread[{d1,d2,d3}>-1]],
 "ZeroDeltaLane" -> effectiveWeights[{0,0,0}].{k1,k2,k3},
 "SphericalCollapseSeries" ->
  Normal@Series[(1-x/dc)^(-dc)-1,{x,0,3}]
|>