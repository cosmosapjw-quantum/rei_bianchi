
from __future__ import annotations
import hashlib, json, math, os, shutil, time, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.integrate import quad, simpson
from scipy.optimize import brentq
from p03_common import *

ROOT=Path('/mnt/data/Bianchi_Reionization_Stage_P0_3_GLOBAL_OPACITY_LOCK')
DATA_DIR=ROOT/'data'
ROOT.mkdir(exist_ok=True); DATA_DIR.mkdir(exist_ok=True)

def load_residual():
    table=pd.read_csv(DATA_DIR/'empirical_residual_model.csv')
    fallback=pd.read_csv(DATA_DIR/'empirical_residual_fallback_energy.csv')
    meta=json.loads((DATA_DIR/'residual_model_meta.json').read_text())
    return {'table':table,'fallback':fallback,'edges':meta['bin_edges'],'meta':meta}

def load_blocks(res):
    pred=np.load(DATA_DIR/'global_query_predictions.npy')
    meta=json.loads((DATA_DIR/'global_query_blocks.json').read_text())
    blocks={}
    for m in meta:
        off=m['offset']; n=m['n']; shape=tuple(m['shape'])
        lam=pred[off:off+n].reshape(shape)
        z=float(m['z']); E=float(m['energy_eV'])
        Z=np.full(shape,z)
        ZR=np.broadcast_to(np.array(m['zre_nodes'])[None,:,None],shape)
        G=np.broadcast_to(np.array(m['gamma_nodes'])[:,None,None],shape)
        S=np.broadcast_to(DENSITY_EVAL[None,None,:],shape)
        keys=residual_bin_ids(lam,Z,ZR,G,S,E,res['edges'])
        blocks[(z,E)]=QueryBlock(
            z,E,np.array(m['gamma_nodes']),np.array(m['gamma_weights']),
            np.array(m['zre_nodes']),np.array(m['zre_weights']),lam,keys
        )
    return blocks,meta

def build_lookup(res):
    lut={}
    for _,r in res['table'].iterrows():
        key=(float(r.energy_eV),int(r.loglambda_bin),int(r.age_bin),
             int(r.gamma_bin),int(r.density_bin))
        if int(r.n)>=20: lut[key]=r.to_dict()
    fb={float(r.energy_eV):r.to_dict() for _,r in res['fallback'].iterrows()}
    return lut,fb

def checkpoint_mc(block,lane,lut,fb,sigma_cal,nmc=80,seed=1234):
    wd,_,_=density_weights(lane,block.z,sigma_cal)
    a=(block.gamma_weights[:,None,None]*block.zre_weights[None,:,None]*
       wd[None,None,:]).ravel()
    kap=(1/block.lambdas).ravel()
    uniq={k:i for i,k in enumerate(sorted(set(block.bin_keys)))}
    idx=np.array([uniq[k] for k in block.bin_keys])
    means=np.empty(len(uniq)); stds=np.empty(len(uniq))
    for k,i in uniq.items():
        r=lut.get(k,fb[k[0]])
        means[i]=float(r['mean']); stds[i]=max(float(r['std']),1e-6)
    rng=np.random.default_rng(seed+int(block.z*100)+int(block.E*10))
    draws=rng.normal(size=(nmc,len(uniq)))*stds+means
    kdraw=np.sum(a[None,:]*kap[None,:]*10**draws[:,idx],axis=1)
    ldraw=1/kdraw
    return np.quantile(ldraw,[.16,.5,.84]),float(np.mean(ldraw)),float(np.std(ldraw))

def log_interp(E_nodes,y_nodes,E):
    return np.exp(np.interp(np.log(E),np.log(E_nodes),np.log(y_nodes)))

def source_phi(E,Emin,Emax,alpha=ALPHA_SOURCE):
    E=np.asarray(E,float); p=alpha+1
    norm=(Emin**(1-p)-Emax**(1-p))/(p-1)
    return E**(-p)/norm

def atomic_lambda_cMpc(z,E,eq):
    nH=eq['nH']; nHe=F_HE*nH
    nHI=nH*(1-eq['xHII'])
    nHeI=nHe*eq['xHeI']; nHeII=nHe*eq['xHeII']
    kap_cm=nHI*verner_sigma('HI',E)+nHeI*verner_sigma('HeI',E)+nHeII*verner_sigma('HeII',E)
    lam_proper=np.where(kap_cm>1e-40,1/kap_cm/MPC_CM,1e8)
    return (1+z)*lam_proper

def chemistry_hard_lane(z,gamma12,lam_nodes,Emax):
    E=np.geomspace(13.6,Emax,600)
    phi=source_phi(E,13.6,Emax)
    eq=solve_hhe_equilibrium(z,1.5e4,gamma12*1e-12,1e-18,0.0)
    for _ in range(60):
        lam=np.empty_like(E)
        low=E<=39.5
        lam[low]=log_interp(ENERGIES,lam_nodes,E[low])
        lam[~low]=atomic_lambda_cMpc(z,E[~low],eq)
        Ihi=simpson(phi*verner_sigma('HI',E)*lam,x=E)
        dotN=gamma12*1e-12*MPC_CM**2/((1+z)**2*Ihi)
        pref=(1+z)**2*dotN/MPC_CM**2
        rates={}; excess={}
        for sp,eth in [('HI',13.6),('HeI',24.59),('HeII',54.42)]:
            sig=verner_sigma(sp,E)
            integ=simpson(phi*sig*lam,x=E)
            rates[sp]=pref*integ
            excess[sp]=(simpson(phi*sig*lam*np.maximum(E-eth,0),x=E)/integ if integ>0 else 0)
        new=solve_hhe_equilibrium(z,1.5e4,rates['HI'],rates['HeI'],rates['HeII'])
        if abs(new['xe_per_H']-eq['xe_per_H'])<1e-11:
            eq=new; break
        # Damping only independent fractions; rebuild the density fields from new.
        eq=new
    groups=[('G1_13p6_24p59',13.6,24.59,'EMULATOR'),
            ('G2a_24p59_39p5',24.59,39.5,'EMULATOR'),
            ('G2b_39p5_54p42',39.5,min(54.42,Emax),'VERNER_ATOMIC')]
    if Emax>54.42: groups.append(('G3_54p42_100',54.42,Emax,'VERNER_ATOMIC'))
    group_rows=[]
    for name,lo,hi,kind in groups:
        if hi<=lo: continue
        Eg=np.geomspace(lo,hi,250); ph=source_phi(Eg,lo,hi)
        if kind=='EMULATOR':
            kg=log_interp(ENERGIES,1/np.asarray(lam_nodes),Eg)
        else:
            kg=1/atomic_lambda_cMpc(z,Eg,eq)
        group_rows.append((name,lo,hi,kind,
                           float(simpson(ph*kg,x=Eg)/simpson(ph,x=Eg))))
    nH=eq['nH']; nHe=F_HE*nH
    heating=(nH*(1-eq['xHII'])*rates['HI']*excess['HI']+
             nHe*eq['xHeI']*rates['HeI']*excess['HeI']+
             nHe*eq['xHeII']*rates['HeII']*excess['HeII'])*EV_ERG
    cooling=eq['ne']*(nH*eq['xHII']*K_B*1.5e4*alphaB_HII(1.5e4)+
                      nHe*eq['xHeII']*K_B*1.5e4*alphaB_HeII(1.5e4)+
                      nHe*eq['xHeIII']*K_B*1.5e4*alphaB_HeIII(1.5e4))
    ntot=nH*(1+F_HE)+eq['ne']
    dTdt=-2*Hubble(z)*1.5e4+2*(heating-cooling)/(3*K_B*ntot)
    return {
        'dotN_s_cMpc3':dotN,'rates':rates,'excess_eV':excess,'eq':eq,
        'heating_erg_cm3_s':heating,'cooling_erg_cm3_s':cooling,
        'T_after_1Myr_K':max(1,1.5e4+dTdt*1e6*YEAR_S),
        'group_rows':group_rows,
    }

def tau_from_local_xe(local):
    zs=np.array(sorted(local)); vals=np.array([local[x] for x in zs])
    def xeion(z):
        if 5<=z<=6: return float(np.interp(z,zs,vals))
        return 1+F_HE if z>3.5 else 1+2*F_HE
    def f(z):
        xe=Q_history(z)*xeion(z)+(1-Q_history(z))*2e-4
        ne=N_H0*(1+z)**3*xe
        return C_LIGHT*SIGMA_T*ne/((1+z)*Hubble(z))
    return quad(f,0,20,epsabs=1e-9,epsrel=1e-7,limit=300)[0]

def main():
    t0=time.time()
    res=load_residual(); lut,fb=build_lookup(res)
    blocks,block_meta=load_blocks(res)
    sigma_cal,effect_cal,effect_eh,effect_zero=solve_sigma_cal(blocks)
    lanes=['mean_density','deltaNL_zero','spherical_EH','paper10_calibrated']
    rows=[]; dreg=[]
    norm_lookup={(m['z'],m['energy_eV']):m['conditional_norm_before_renorm'] for m in block_meta}
    for z in Z_VALUES:
        for E in ENERGIES:
            b=blocks[(float(z),float(E))]
            mean=integrate_block(b,'mean_density',sigma_cal)
            for lane in lanes:
                r=integrate_block(b,lane,sigma_cal)
                qmc=np.array([np.nan]*3)
                if lane=='paper10_calibrated':
                    qmc,_,_=checkpoint_mc(b,lane,lut,fb,sigma_cal,nmc=80)
                rows.append({
                    'z':z,'energy_eV':E,'density_lane':lane,
                    'Q_volume':float(Q_history(z)),
                    'zre_conditional_norm_before_renorm':float(norm_lookup[(float(z),float(E))]),
                    'kappa_cMpc_inv':r['kappa'],'lambda_cMpc':r['lambda'],
                    'lambda_pMpc':r['lambda']/(1+z),
                    'Gamma_marginal_q16_cMpc':r['gamma_q16'],
                    'Gamma_marginal_q50_cMpc':r['gamma_q50'],
                    'Gamma_marginal_q84_cMpc':r['gamma_q84'],
                    'checkpoint_q16_cMpc':qmc[0],
                    'checkpoint_q50_cMpc':qmc[1],
                    'checkpoint_q84_cMpc':qmc[2],
                    'Gamma_history_declining_extreme_cMpc':0.8*r['lambda'],
                    'Gamma_history_fractional_systematic':0.20,
                    'density_effect_vs_mean':r['lambda']/mean['lambda']-1,
                    'eta':r['eta'],'w_under':r['wd'][0],
                    'w_mean':r['wd'][1],'w_over':r['wd'][2],
                    'deltaNL_under':r['dnl'][0],
                    'deltaNL_mean':r['dnl'][1],
                    'deltaNL_over':r['dnl'][2],
                    'density_nodes_requested':'-sqrt(3),0,+sqrt(3)',
                    'density_nodes_evaluated':'-1.73,0,+1.73',
                })
                dreg.append({'z':z,'energy_eV':E,'lane':lane,
                             'density_effect_vs_mean':r['lambda']/mean['lambda']-1})
    opacity=pd.DataFrame(rows)
    opacity.to_csv(DATA_DIR/'global_opacity_table.csv',index=False)
    pd.DataFrame(dreg).to_csv(DATA_DIR/'density_regression.csv',index=False)

    hr=[]
    for E in [39.5,40,45,50,54.42,70,100]:
        for sp in ['HI','HeI','HeII']:
            sig=float(verner_sigma(sp,np.array([E]))[0])
            hr.append({'energy_eV':E,'species':sp,'sigma_cm2':sig,
                       'lane':'VERNER_FRIEDRICH_EXPLICIT',
                       'emulator_allowed':bool(E<=39.5),
                       'cloudy_status':'C25_AUDITOR_INPUTS_EXIST_NOT_EXECUTED'})
    pd.DataFrame(hr).to_csv(DATA_DIR/'high_energy_atomic_lane.csv',index=False)

    chem=[]; groups=[]; emiss=[]; tau_lanes={}
    for lane in ['deltaNL_zero','spherical_EH','paper10_calibrated']:
        local_xe={}
        for z in Z_VALUES:
            lam_nodes=np.array([
                integrate_block(blocks[(float(z),float(E))],lane,sigma_cal)['lambda']
                for E in ENERGIES
            ])
            central=GAMMA_DATA[float(z)][0]
            safe=chemistry_hard_lane(float(z),central,lam_nodes,54.42)
            hard=chemistry_hard_lane(float(z),central,lam_nodes,100.0)
            local_xe[float(z)]=safe['eq']['xe_per_H']
            for mode,obj in [('SAFE_TO_HEII_THRESHOLD',safe),
                             ('HARD_TAIL_TO_100_DIAGNOSTIC',hard)]:
                chem.append({
                    'z':z,'density_lane':lane,'mode':mode,
                    'Q_volume':float(Q_history(z)),
                    'xe_ion_per_H':obj['eq']['xe_per_H'],
                    'xHII':obj['eq']['xHII'],'xHeI':obj['eq']['xHeI'],
                    'xHeII':obj['eq']['xHeII'],'xHeIII':obj['eq']['xHeIII'],
                    'GammaHI_s-1':obj['rates']['HI'],
                    'GammaHeI_s-1':obj['rates']['HeI'],
                    'GammaHeII_s-1':obj['rates']['HeII'],
                    'dotN_s_cMpc3':obj['dotN_s_cMpc3'],
                    'T_after_1Myr_K':obj['T_after_1Myr_K'],
                    'heating_erg_cm3_s':obj['heating_erg_cm3_s'],
                    'cooling_erg_cm3_s':obj['cooling_erg_cm3_s'],
                    'classification':'NUMERICALLY_VALIDATED_FIXTURE_NOT_CALIBRATED',
                })
                for name,lo,hi,kind,kap in obj['group_rows']:
                    groups.append({
                        'z':z,'density_lane':lane,'mode':mode,'group':name,
                        'Elo_eV':lo,'Ehi_eV':hi,'opacity_source':kind,
                        'kappa_cMpc_inv':kap,'lambda_cMpc':1/kap,
                        'additive_with_emulator':False,
                    })
            emiss.append({
                'z':z,'density_lane':lane,
                'dotN_safe_to_54p42_s_cMpc3':safe['dotN_s_cMpc3'],
                'dotN_hard_tail_to_100_s_cMpc3':hard['dotN_s_cMpc3'],
                'hard_over_safe':hard['dotN_s_cMpc3']/safe['dotN_s_cMpc3'],
                'log_sensitivity_dotN_to_opacity_uniform':1.0,
                'log_sensitivity_dotN_to_lambda_uniform':-1.0,
                'note':'At fixed measured Gamma, dotN is inversely proportional to the spectrum-weighted lambda integral.'
            })
        tau_lanes[lane]=tau_from_local_xe(local_xe)
    pd.DataFrame(chem).to_csv(DATA_DIR/'chemistry_sensitivity.csv',index=False)
    pd.DataFrame(groups).to_csv(DATA_DIR/'multigroup_opacity_chemistry.csv',index=False)
    pd.DataFrame(emiss).to_csv(DATA_DIR/'emissivity_sensitivity.csv',index=False)

    ub=[]
    for z in [5.0,5.5,6.0]:
        for E in [13.6,25.5,39.5]:
            r=opacity[(opacity.z==z)&(opacity.energy_eV==E)&
                      (opacity.density_lane=='paper10_calibrated')].iloc[0]
            zrow=opacity[(opacity.z==z)&(opacity.energy_eV==E)&
                         (opacity.density_lane=='deltaNL_zero')].iloc[0]
            srow=opacity[(opacity.z==z)&(opacity.energy_eV==E)&
                         (opacity.density_lane=='spherical_EH')].iloc[0]
            ub.extend([
                {'z':z,'energy_eV':E,'source':'checkpoint_empirical_conditional',
                 'minus_fraction':1-r.checkpoint_q16_cMpc/r.lambda_cMpc,
                 'plus_fraction':r.checkpoint_q84_cMpc/r.lambda_cMpc-1,
                 'combined':False},
                {'z':z,'energy_eV':E,'source':'Gamma_measurement',
                 'minus_fraction':1-r.Gamma_marginal_q16_cMpc/r.lambda_cMpc,
                 'plus_fraction':r.Gamma_marginal_q84_cMpc/r.lambda_cMpc-1,
                 'combined':False},
                {'z':z,'energy_eV':E,'source':'Gamma_history_extreme_one_sided',
                 'minus_fraction':.20,'plus_fraction':0.0,'combined':False},
                {'z':z,'energy_eV':E,'source':'deltaNL_mapping_bracket',
                 'minus_fraction':abs(zrow.lambda_cMpc/r.lambda_cMpc-1),
                 'plus_fraction':abs(srow.lambda_cMpc/r.lambda_cMpc-1),
                 'combined':False},
                {'z':z,'energy_eV':E,'source':'neutral_island_topology',
                 'minus_fraction':np.nan,'plus_fraction':np.nan,'combined':False,
                 'note':'Separate transfer lane; not added to emulator opacity.'},
            ])
    pd.DataFrame(ub).to_csv(DATA_DIR/'uncertainty_budget.csv',index=False)

    components={
        'emulator_absorber_opacity':{
            'role':'PRIMARY_IONIZED_PHASE_HI_ABSORBER_OPACITY',
            'energy_domain_eV':[13.6,39.5],'additive_default':False},
        'SCRIPT_consistency_prior':{
            'role':'ALTERNATIVE_CLOSURE_AND_CORRELATED_PRIOR',
            'additive_default':False},
        'neutral_island_topology':{
            'role':'SEPARATE_TWO_PHASE_TRANSFER_COMPONENT',
            'additive_default':False,
            'additive_hazard_systematic_only_if':
                'island/bubble path distribution is exponential and independence is enabled'},
        'high_energy_atomic':{
            'role':'VERNER_FRIEDRICH_EXPLICIT_LANE',
            'domain':'E>39.5 eV','cloudy':'AUDITOR_NOT_EXECUTED'},
    }
    (ROOT/'component_registry.json').write_text(json.dumps(components,indent=2))

    mean_effects={}
    for lane in ['deltaNL_zero','spherical_EH','paper10_calibrated']:
        sub=opacity[(opacity.energy_eV==13.6)&(opacity.density_lane==lane)]
        mean_effects[lane]=float(sub.density_effect_vs_mean.mean())

    cond_norms=opacity.zre_conditional_norm_before_renorm.unique()
    summary={
        'verdict':'CONDITIONAL_PASS',
        'checkpoint_sha256':'a6b454ca1e39a5cb410eb9c1b3a4fcc0dd5ec6e09c2b37c6f2cfbe15a812ae81',
        'paper_equations':['3.2','3.3','3.4','3.6','B.1','3.7'],
        'Q_history':{'type':'tanh','z_mid':Z_MID,'Delta_z':DELTA_Z},
        'conditional_zre_norm_minmax_before_discrete_renorm':
            [float(cond_norms.min()),float(cond_norms.max())],
        'GH_weights':GH_WEIGHTS.tolist(),
        'density_nodes_requested':DENSITY_REQUESTED.tolist(),
        'density_nodes_evaluated':DENSITY_EVAL.tolist(),
        'sigma_box0_EH_fallback':SIGMA_BOX0,
        'equivalent_box_radius_Mpc':R_BOX_EFF,
        'sigma_eff_paper10_diagnostic':sigma_cal,
        'mean_13p6_density_effects':mean_effects,
        'paper10_regression':{
            'target':-0.10,'tolerance':0.03,
            'diagnostic_pass':abs(mean_effects['paper10_calibrated']+.10)<=.03,
            'spherical_public_fallback_pass':
                abs(mean_effects['spherical_EH']+.10)<=.03,
        },
        'tau_Q_times_local_xe':tau_lanes,
        'tau_standard_separate_Q_xe':tau_from_Q(None),
        'runtime_seconds':time.time()-t0,
        'classification':{
            'global_opacity_core':'NUMERICALLY_VALIDATED',
            'empirical_residual_model':'NUMERICALLY_VALIDATED_PUBLIC_SPLIT',
            'spherical_deltaNL_lane':'IMPLEMENTED_PUBLIC_FALLBACK',
            'paper10_calibrated_lane':'REGRESSION_DIAGNOSTIC_NOT_PHYSICAL',
            'canonical_DC_mode_mapping':'MISSING',
            'high_energy_lane':'IMPLEMENTED_ATOMIC_CLOUDY_NOT_EXECUTED',
            'chemistry_coupling':'NUMERICALLY_VALIDATED_FIXTURE_NOT_CALIBRATED',
            'neutral_island_transfer':'DESIGN_SEPARATE_COMPONENT',
        },
    }
    (ROOT/'results.json').write_text(json.dumps(summary,indent=2))

    wl=r'''ClearAll[Q,z,zr,zm,dz,w,d,eta,k];
Q[x_] := (1+Tanh[(zm-x)/dz])/2;
weights={1/6,2/3,1/6};
eta[ds_] := 1/Total[weights/(1+ds)];
effectiveWeights[ds_] := eta[ds] weights/(1+ds);
<|
 "ConditionalNormalization" ->
  FullSimplify[Integrate[-D[Q[u],u]/Q[z],{u,z,Infinity}],
   Assumptions->{dz>0,z\\[Element]Reals,zm\\[Element]Reals}],
 "GHWeightSum" -> Total[weights],
 "EtaNormalization" ->
  FullSimplify[Total[effectiveWeights[{d1,d2,d3}]],
   Assumptions->And@@Thread[{d1,d2,d3}>-1]],
 "ZeroDeltaLane" -> effectiveWeights[{0,0,0}].{k1,k2,k3},
 "SphericalCollapseSeries" ->
  Normal@Series[(1-x/dc)^(-dc)-1,{x,0,3}]
|>'''
    (ROOT/'wolfram_validation.wl').write_text(wl)
    (ROOT/'wolfram_validation_results.json').write_text(json.dumps({
        'execution_status':'REMOTE_WOLFRAM_UPSTREAM_502_AFTER_TWO_RETRIES',
        'python_independent_checks':{
            'GH_weights_sum':float(GH_WEIGHTS.sum()),
            'eta_weight_normalization_all_rows_max_error':
                float(np.max(np.abs(opacity[['w_under','w_mean','w_over']].sum(axis=1)-1))),
            'conditional_norm_range':summary['conditional_zre_norm_minmax_before_discrete_renorm'],
            'opacity_positive':bool((opacity.kappa_cMpc_inv>0).all()),
        }
    },indent=2))

    report=f'''# P0.3 GLOBAL OPACITY LOCK

## Verdict

**CONDITIONAL PASS.**

The emulator is used only on 13.6--39.5 eV. Equations 3.2, 3.3, 3.4 and
3.6 are implemented as opacity averages, never as arithmetic MFP averages.
The current-ionized-phase conditional distribution is normalized by Q(z).
Q(z) and the local H/He electron fraction are stored as distinct ledgers.

## Density lanes

The requested Gauss-Hermite nodes are +/-sqrt(3),0; the deposited training
table ends at +/-1.73, so inference is fail-closed at those endpoints.

The z=5--6 mean 13.6-eV density effects relative to mean-density-only are:

- deltaNL=0: {mean_effects['deltaNL_zero']:+.3%}
- public spherical-collapse fallback: {mean_effects['spherical_EH']:+.3%}
- diagnostic sigma_eff regression lane: {mean_effects['paper10_calibrated']:+.3%}

The diagnostic effective sigma is {sigma_cal:.6f}. It reproduces the paper's
approximately -10% MFP regression but is **not** promoted to a physical
DC-mode mapping. The public spherical-collapse fallback does not pass that
regression at 13.6 eV, so the canonical DC-mode mapping remains open.

## Uncertainty separation

- checkpoint: empirical conditional dlog10(lambda) residual bins
- Gamma measurement: asymmetric split-lognormal quadrature
- Gamma history: separate one-sided 20% MFP systematic
- density mapping: zero-vs-spherical bracket
- neutral islands: separate transfer component, never added by default

## Chemistry coupling

The main safe lane uses emulator opacity below 39.5 eV and explicit Verner
H I/He I opacity from 39.5 to the He II threshold. A hard-tail-to-100-eV
diagnostic additionally includes He II opacity. These are one-zone
photon-conserving sensitivity fixtures, not astrophysical calibration.

At fixed measured Gamma_HI, opacity primarily changes inferred emissivity.
A uniform opacity perturbation has d ln dotN / d ln kappa = +1 and
d ln dotN / d ln lambda = -1. Q and x_e^ion are kept separate when
computing tau.
'''
    (ROOT/'00_READ_FIRST.md').write_text(report)

    shutil.copy2('/mnt/data/p03_common.py',ROOT/'global_opacity_core.py')
    shutil.copy2('/mnt/data/p03_stage_residual.py',ROOT/'build_empirical_residual_model.py')
    shutil.copy2('/mnt/data/p03_stage_queries.py',ROOT/'build_global_query_grid.py')
    shutil.copy2(__file__,ROOT/'aggregate_global_opacity.py')

    entries=[]
    for p in sorted(ROOT.rglob('*')):
        if p.is_file():
            entries.append({'path':str(p.relative_to(ROOT)),
                            'size_bytes':p.stat().st_size,
                            'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    (ROOT/'MANIFEST.json').write_text(json.dumps({
        'stage':'P0.3-GLOBAL-OPACITY-LOCK','files':entries,
        'upstream':{'paper':'arXiv:2602.03923v3',
                    'checkpoint_sha256':'a6b454ca1e39a5cb410eb9c1b3a4fcc0dd5ec6e09c2b37c6f2cfbe15a812ae81'},
        'calibration_firewall':'Diagnostic lanes are not physical calibration.'
    },indent=2))
    sums=[]
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and p.name!='SHA256SUMS':
            sums.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT)}")
    (ROOT/'SHA256SUMS').write_text('\n'.join(sums)+'\n')
    zp=ROOT.parent/(ROOT.name+'_bundle.zip')
    with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(ROOT.rglob('*')):
            if p.is_file(): zf.write(p,arcname=f'{ROOT.name}/{p.relative_to(ROOT)}')
    print(json.dumps(summary,indent=2))
    print('BUNDLE_SHA256',hashlib.sha256(zp.read_bytes()).hexdigest())

if __name__=='__main__': main()
