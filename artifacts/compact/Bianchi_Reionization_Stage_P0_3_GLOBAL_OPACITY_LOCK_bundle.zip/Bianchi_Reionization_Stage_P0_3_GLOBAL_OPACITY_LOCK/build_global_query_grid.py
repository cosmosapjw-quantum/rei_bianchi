
from __future__ import annotations
import json, time, os
from pathlib import Path
import numpy as np
import torch
from p03_common import *

def main():
    torch.set_num_threads(min(8, os.cpu_count() or 4))
    t0=time.time()
    model=MFPModel(CHECKPOINT)
    arrays=[]; block_meta=[]; offset=0
    for z in Z_VALUES:
        zr,wz,norm=zre_quadrature(float(z),40)
        gc,gp,gm=GAMMA_DATA[float(z)]
        gn,wg=split_lognormal_nodes(gc,gp,gm,16)
        for E in ENERGIES:
            shape=(len(gn),len(zr),3)
            Z=np.full(shape,z); ZR=np.broadcast_to(zr[None,:,None],shape)
            G=np.broadcast_to(gn[:,None,None],shape)
            S=np.broadcast_to(DENSITY_EVAL[None,None,:],shape)
            EE=np.full(shape,E)
            n=int(np.prod(shape))
            arrays.append((Z.ravel(),ZR.ravel(),G.ravel(),S.ravel(),EE.ravel()))
            block_meta.append({
                'z':float(z),'energy_eV':float(E),'offset':offset,'n':n,
                'shape':shape,'zre_nodes':zr.tolist(),'zre_weights':wz.tolist(),
                'gamma_nodes':gn.tolist(),'gamma_weights':wg.tolist(),
                'conditional_norm_before_renorm':float(norm)
            })
            offset+=n
    cat=[np.concatenate([a[i] for a in arrays]) for i in range(5)]
    pred=model.predict_batch(*cat,batch=16384)
    np.save(DATA_DIR/'global_query_predictions.npy',pred)
    np.savez_compressed(DATA_DIR/'global_query_features.npz',
                        z=cat[0],zre=cat[1],gamma=cat[2],density=cat[3],energy=cat[4])
    (DATA_DIR/'global_query_blocks.json').write_text(json.dumps(block_meta,indent=2))
    meta={'n_queries':len(pred),'runtime_s':time.time()-t0,
          'min_lambda_cMpc':float(pred.min()),'max_lambda_cMpc':float(pred.max()),
          'checkpoint_sha256':model.sha256}
    (DATA_DIR/'global_query_meta.json').write_text(json.dumps(meta,indent=2))
    print(json.dumps(meta,indent=2))
if __name__=='__main__': main()
