# P0.3 GLOBAL OPACITY LOCK

## Verdict

**CONDITIONAL PASS.**

The emulator is used only on 13.6--39.5 eV. Equations 3.2, 3.3, 3.4 and
3.6 are implemented as opacity averages, never as arithmetic MFP averages.
The current-ionized-phase conditional distribution is normalized by Q(z).
Q(z) and the local H/He electron fraction are stored as distinct ledgers.

## Density lanes

The requested Gauss-Hermite nodes are +/-sqrt(3),0; the deposited training
table ends at +/-1.73, so inference is fail-closed at those endpoints.

The z=5--6 mean 13.6-eV density effects relative to mean-density-only are:

- deltaNL=0: -27.554%
- public spherical-collapse fallback: +7.704%
- diagnostic sigma_eff regression lane: -10.000%

The diagnostic effective sigma is 1.326580. It reproduces the paper's
approximately -10% MFP regression but is **not** promoted to a physical
DC-mode mapping. The public spherical-collapse fallback does not pass that
regression at 13.6 eV, so the canonical DC-mode mapping remains open.

## Uncertainty separation

- checkpoint: empirical conditional dlog10(lambda) residual bins
- Gamma measurement: asymmetric split-lognormal quadrature
- Gamma history: separate one-sided 20% MFP systematic
- density mapping: zero-vs-spherical bracket
- neutral islands: separate transfer component, never added by default

## Chemistry coupling

The main safe lane uses emulator opacity below 39.5 eV and explicit Verner
H I/He I opacity from 39.5 to the He II threshold. A hard-tail-to-100-eV
diagnostic additionally includes He II opacity. These are one-zone
photon-conserving sensitivity fixtures, not astrophysical calibration.

At fixed measured Gamma_HI, opacity primarily changes inferred emissivity.
A uniform opacity perturbation has d ln dotN / d ln kappa = +1 and
d ln dotN / d ln lambda = -1. Q and x_e^ion are kept separate when
computing tau.

## Representative outputs

At z=5.5 and 13.6 eV, the diagnostic paper-10%-calibrated lane gives
lambda=18.9795 cMpc = 2.9199 pMpc. The checkpoint residual scatter is only
at the percent level, whereas the Gamma_12 measurement and delta_NL mapping
dominate the uncertainty budget.

The Q-times-local-x_e optical depths are 0.04449522 (deltaNL=0),
0.04449496 (public spherical collapse), and 0.04449508 (diagnostic
paper-10% lane). Thus at fixed measured Gamma_HI the opacity choice mainly
moves the inferred emissivity, not x_e or tau.
