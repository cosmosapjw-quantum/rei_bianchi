#!/usr/bin/env python3
"""Build and verify the source/evidence packet without executing science.

Run only after publication receipts are final. The packet directory remains the
ZIP's top-level directory, preserving all existing relative source paths.
Compiled artifacts are intentionally omitted; their recorded hashes remain.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import tempfile
import zipfile

SCHEMA = "research-sync.archive-payload.v1"
MANIFEST_REL = Path("publication/ARCHIVE_PAYLOAD_MANIFEST.json")
FIXED_ZIP_TIME = (1980, 1, 1, 0, 0, 0)
SKIP_DIRS = {"target", "runtime", "__pycache__", ".git"}
OUTER_RECEIPTS = {"BACKUP_RECEIPT.json", "DELIVERY_ACK.json"}
COMPILED_SUFFIXES = {".rlib", ".rmeta", ".o", ".obj", ".a", ".so",
                     ".dylib", ".dll", ".exe", ".pyc", ".pyo"}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


def exclusion(path: Path, relative: Path) -> str | None:
    parts = relative.parts
    if any(part in SKIP_DIRS for part in parts):
        return "rebuildable runtime, compiler target, or cache"
    if relative == MANIFEST_REL:
        return "generated manifest stored separately; no recursive self-hash"
    if relative.name in OUTER_RECEIPTS and relative.parent in {Path("."), Path("publication")}:
        return "outer backup/delivery receipt; avoids self-reference"
    upper = relative.name.upper()
    # Selected small source-tree extracts are evidence, not discovery indexes.
    if upper != "SELECTED_TREE.JSON" and re.search(
        r"(?:^|[._])(?:TREE|PRS|BRANCHES)\.JSON$", upper
    ):
        return "bulk repository discovery index"
    if parts and parts[0] == "publication":
        if any(p.lower() in {"payloads", "jobs", "prepared_payloads",
                              "publish_payloads", "packet_payloads"}
               for p in parts[1:-1]):
            return "duplicate publication payload/job"
        if upper.endswith(".TREE_JOB.JSON") or "EXPECTED_FILES" in upper:
            return "duplicate publication payload/job"
    if path.suffix.lower() in COMPILED_SUFFIXES:
        return "compiled executable or static/shared library"
    with path.open("rb") as stream:
        magic = stream.read(8)
    if (magic.startswith(b"\x7fELF") or magic.startswith(b"!<arch>\n")
            or magic.startswith(b"MZ")
            or magic[:4] in {b"\xfe\xed\xfa\xce", b"\xce\xfa\xed\xfe",
                             b"\xfe\xed\xfa\xcf", b"\xcf\xfa\xed\xfe"}):
        return "compiled binary magic"
    return None


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--packet-root", type=Path,
                        default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path, required=True,
                        help="ZIP path outside the packet directory")
    parser.add_argument("--identity", type=Path,
                        help="Outer ZIP identity JSON; default OUTPUT.IDENTITY.json")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    root = args.packet_root.resolve(strict=True)
    output = args.output.resolve()
    identity = (args.identity or output.with_suffix(".IDENTITY.json")).resolve()
    for destination in (output, identity):
        if destination == root or root in destination.parents:
            parser.error("ZIP and outer identity must be outside the packet root")
        if destination.exists() and not args.overwrite:
            parser.error(f"Destination exists; choose a new path: {destination}")
    if output == identity:
        parser.error("ZIP and identity destinations must differ")

    files: list[dict] = []
    omitted: list[dict] = []
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if path.is_symlink():
            raise ValueError(f"Symlink must be resolved explicitly: {relative}")
        if not path.is_file():
            continue
        reason = exclusion(path, relative)
        if reason:
            if relative != MANIFEST_REL:
                omitted.append({"path": relative.as_posix(), "reason": reason})
            continue
        data = path.read_bytes()
        files.append({"path": relative.as_posix(),
                      "archive_path": f"{root.name}/{relative.as_posix()}",
                      "bytes": len(data), "sha256": sha256(data),
                      "mode": "0755" if path.stat().st_mode & 0o111 else "0644"})
    if not files:
        raise ValueError("Refusing to build an empty packet")
    manifest = {
        "schema": SCHEMA, "packet_directory": root.name,
        "payload_files": len(files), "payload_bytes": sum(x["bytes"] for x in files),
        "self_hash_policy": "This manifest excludes itself; outer identity hashes it.",
        "reproduction": "Extract with the top-level directory intact; rebuild omitted binaries from the included exact source and instructions.",
        "verification_scope": "Byte identity and ZIP integrity only; no scientific execution or admission.",
        "zip_policy": {"entry_order": "lexicographic payload paths, then manifest",
                       "entry_timestamp": list(FIXED_ZIP_TIME),
                       "compression": "DEFLATE level 9"},
        "files": files, "excluded": omitted,
    }
    manifest_data = json_bytes(manifest)
    atomic_write(root / MANIFEST_REL, manifest_data)
    manifest_entry = f"{root.name}/{MANIFEST_REL.as_posix()}"
    output.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=output.name + ".", dir=output.parent)
    os.close(fd)
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED,
                             compresslevel=9, allowZip64=True) as archive:
            for row in files:
                data = (root / row["path"]).read_bytes()
                if len(data) != row["bytes"] or sha256(data) != row["sha256"]:
                    raise ValueError(f"File changed during snapshot: {row['path']}")
                entry = zipfile.ZipInfo(row["archive_path"], FIXED_ZIP_TIME)
                entry.create_system = 3
                entry.external_attr = (stat.S_IFREG | int(row["mode"], 8)) << 16
                archive.writestr(entry, data, compress_type=zipfile.ZIP_DEFLATED,
                                 compresslevel=9)
            entry = zipfile.ZipInfo(manifest_entry, FIXED_ZIP_TIME)
            entry.create_system = 3
            entry.external_attr = (stat.S_IFREG | 0o644) << 16
            archive.writestr(entry, manifest_data,
                             compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        with zipfile.ZipFile(temporary) as archive:
            bad = archive.testzip()
            if bad is not None:
                raise ValueError(f"ZIP CRC mismatch: {bad}")
            expected = [row["archive_path"] for row in files] + [manifest_entry]
            if archive.namelist() != expected:
                raise ValueError("ZIP entry identity/order mismatch")
            for row in files:
                data = archive.read(row["archive_path"])
                if len(data) != row["bytes"] or sha256(data) != row["sha256"]:
                    raise ValueError(f"ZIP payload digest mismatch: {row['path']}")
            if archive.read(manifest_entry) != manifest_data:
                raise ValueError("ZIP manifest bytes mismatch")
        archive_data = Path(temporary).read_bytes()
        result = {"schema": "research-sync.archive-identity.v1",
                  "archive_name": output.name, "archive_path": str(output),
                  "bytes": len(archive_data), "sha256": sha256(archive_data),
                  "entries": len(files) + 1, "payload_files": len(files),
                  "manifest_archive_path": manifest_entry,
                  "manifest_sha256": sha256(manifest_data),
                  "payload_sha256_verified": len(files), "zip_crc": "PASS",
                  "excluded_files": len(omitted),
                  "scientific_execution_performed": False,
                  "remote_backup_or_restore_claimed": False}
        os.replace(temporary, output)
        atomic_write(identity, json_bytes(result))
        print(json.dumps(result, ensure_ascii=False, indent=2))
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


if __name__ == "__main__":
    main()
