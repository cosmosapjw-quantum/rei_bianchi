"""Prepare only the coordinator-approved additive atomic repository files."""
from pathlib import Path
import argparse
import hashlib
import json


def digest(data):
    return {
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "git_blob_sha": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--central-commit", required=True)
    args = ap.parse_args()
    if len(args.central_commit) != 40 or any(c not in "0123456789abcdef" for c in args.central_commit):
        raise ValueError("actual immutable central commit required")
    root = Path(__file__).resolve().parents[2]
    out = Path(__file__).resolve().parent
    task = "REI-REC-BASS-SYNC02-20261005"
    remote = "docs/research_sync/" + task
    central = "https://github.com/cosmosapjw-quantum/rei_bianchi/blob/" + args.central_commit + "/" + remote
    shared = {
        "REVISED_DAG.json": "planning/REVISED_DAG.json",
        "LOW_COST_ENTRY.json": "publication/LOW_COST_ENTRY.json",
        "LOOP1_REVIEW.json": "review/LOOP1_REVIEW.json",
        "LOOP2_REVIEW.json": "review/LOOP2_REVIEW.json",
        "INDEPENDENT_HISTORY_RESULT.json": "loop2/evidence/INDEPENDENT_HISTORY_RESULT.json",
        "LATE_FLRW06_RESULT.json": "late_flrw06/native_result/NATIVE_EXECUTION_RECEIPT.json",
        "LATE_FLRW06_REVIEW.json": "review/LATE_FLRW06_REVIEW.json",
    }
    for repo in ["BASS_HE", "bass_cr", "WU088_HH"]:
        thread = root / "publication/threads" / repo
        state = json.loads((thread / "SYNC_STATE.json").read_text())
        state["central_packet"].update(immutable_commit=args.central_commit, immutable_url=central + "/README_KO.md")
        state["publication"]["status"] = "DELIVERY_RECEIPT_SEPARATE"
        state["publication"]["external_mutations"] = "SEE_DETACHED_ACTUAL_RECEIPT"
        state["finalization_todo"] = [x for x in state["finalization_todo"] if not x.startswith("Replace central")]
        state["evidence_path_base"] = central
        state["local_projection"] = "Root filenames in this folder are copied summary projections; detailed relative evidence pointers resolve under central_packet."
        handoff = (thread / "HANDOFF_KO.md").read_text().replace("/blob/PENDING/", "/blob/" + args.central_commit + "/")
        handoff = handoff.replace("— 실제 publication commit이 생긴 뒤 총괄이 교체한다.", "— 이 고정 central commit에 전체 증거가 있다.")
        content = {
            remote + "/HANDOFF_KO.md": handoff.encode(),
            remote + "/SYNC_STATE.json": (json.dumps(state, ensure_ascii=False, indent=2) + "\n").encode(),
        }
        for name, local in shared.items():
            content[remote + "/" + name] = (root / local).read_bytes()
        pointer = {
            "schema": "research-sync.atomic-consumer-pointer.v1",
            "task_id": task,
            "thread": repo,
            "repository_folder": remote,
            "read_first": [remote + "/HANDOFF_KO.md", remote + "/SYNC_STATE.json"],
            "central_immutable_commit": args.central_commit,
            "central_packet_url": central + "/README_KO.md",
            "claim": "Scoped actual native returns and reviewed two-loop benchmark; owner ACK and physical admission separate.",
            "original_task_state_preserved": True,
            "direct_chat_thread_delivery": "UNAVAILABLE_NOT_PERFORMED",
            "publication_receipt": "detached coordinator Git/backup receipt",
        }
        pointer_path = "docs/atomic_reionization_handoff_20261004_v1/threads/" + repo + "/consumer_returns/" + task + "/SYNC_POINTER.json"
        content[pointer_path] = (json.dumps(pointer, ensure_ascii=False, indent=2) + "\n").encode()
        if repo == "BASS_HE":
            for name, local in {
                "NATIVE_RESULT.json": "loop1/he_mixed/NATIVE_RESULT.json",
                "EXECUTION_CONTRACT.json": "loop1/he_mixed/EXECUTION_CONTRACT.json",
                "he_flrw02_absorption.rs": "loop1/he_mixed/supplier_reference/BASS_HE_FLRW02B_20261005/proposed_consumer/he_flrw02_absorption.rs",
            }.items():
                content[remote + "/he_mixed_evidence/" + name] = (root / local).read_bytes()
        entries = []
        identities = []
        for path, data in content.items():
            target = out / "payloads" / repo / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            entries.append({"path": path, "mode": "100644", "type": "blob", "content": data.decode()})
            identities.append({"path": path, "local_path": str(target), **digest(data)})
        (out / (repo + ".TREE_JOB.json")).write_text(json.dumps(entries, ensure_ascii=False) + "\n")
        (out / (repo + ".EXPECTED_FILES.json")).write_text(json.dumps(identities, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"central_commit": args.central_commit, "repositories": ["BASS_HE", "bass_cr", "WU088_HH"], "files": [13, 10, 10]}))


if __name__ == "__main__":
    main()
