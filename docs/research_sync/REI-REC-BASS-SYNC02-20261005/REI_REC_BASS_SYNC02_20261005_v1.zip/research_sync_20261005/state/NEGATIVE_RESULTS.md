# Preserved diagnostics

- GitHub fetch rejected URL with URL-encoded slash in BASS branch path; resolved from actual PR HEAD and Git tree. No source failure.
- Full BASS tree written as a single exec argument exceeded OS argument size; saved bounded native subset instead. No source or scientific change.
- Web raw HYREC URL fetch disabled; original exact source snapshot retained and primary GitHub connector available. No science gate inferred.
