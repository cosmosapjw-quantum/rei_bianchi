# REI-PB03 pointwise consumer contract

Observable outcome: a separate REI research crate calls the actual pinned REC
`hydrogen_peebles` public API. It exports the standard collapsed Peebles result
and the retained actual-ground result separately. No Case-A fallback, source
constant replacement, heat/photon-spectrum coupling, clipping, or QSS projection.

REC source: `cosmosapjw-quantum/rec_bianchi` at
`cd68764aacfeae9fe794d7966604ac6fbb80ba7f`; REI integration base:
`b553698a114fbff05640ab6ecb95d260410de492`. Intake's live Git tree and
SHA256 verification is `../../survey/rei_rec/SOURCE_LOCK.json` relative to this
packet's parent loop directory. Both selected branches have no applicable AGENTS.
Source producer profile remains `HYREC2_TLA_2020_PEEBLES_FUDGE1`.

Inputs are proper nH in m^-3, temperature in K with Tm exactly equal to Tr,
H>0 in s^-1, xp and x2 fractions with actual x1=1-xp-x2>0. Derivatives use
proper seconds. An explicit cgs constructor calls the REC density conversion
exactly once. No -3H x fraction sink is added.

Collapsed evaluation reassembles REC source at {xp,x2:0}. Retained evaluation
reassembles source at the actual {xp,x2}. Closure defect refers to retained RHS
minus Peebles RHS at the SAME retained rates, not minus standard collapsed-source
RHS. Their difference is exported separately as the source-assembly contribution.
No finite-shell trajectory or physical cosmology admission is claimed here.

Acceptance: real public API call; typed density/temperature/expansion boundaries;
native public behavior tests including independent fixed numeric benchmark,
unit factor, actual-ground ratio, species conservation, defect reconstruction,
redshift sign, and invalid-input rejection. The final independent numerical
oracle and history are coordinator-owned and not counted as this implementation's
own independent verification. Scientific PROMOTE awaits the bounded independent
reviewer. Existing strict local <2e-4, public width <2e-3, known [160,161] failure,
atomic/He/HH/RCT gates, and all existing REI crate files remain unchanged.

Harness: all four canonical locally available ZIPs were hash-checked and their
core/start/current-state/ultralight instructions read. Runtime model metadata is
unavailable; no model guessed. Shared requirements are applied; no differing
version rule changes this already authorized bounded work.

Write surface: this directory only. No external repository writes by subagent.
Native offline build uses rustc against all exact fetched REC source modules;
published Cargo declares the immutable Git dependency. Cargo network resolution
is not equivalent to this source-bound rustc check and is reported separately.
