#!/usr/bin/env python3
"""Compile exact fetched REC and this consumer without requiring network Cargo.

This is not a Cargo Git fetch test. REC source bytes must be verified separately
against the pinned Git source lock before using this command as provenance.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

parser=argparse.ArgumentParser()
parser.add_argument('--rustc',required=True)
parser.add_argument('--rec-crate',type=Path,required=True)
args=parser.parse_args()
root=Path(__file__).resolve().parent
runtime=root/'runtime'
runtime.mkdir(exist_ok=True)
rec=args.rec_crate.resolve()
rlib=runtime/'librec_microphysics.rlib'
consumer=runtime/'librei_peebles_reference.rlib'
commands=[
 [args.rustc,'--version'],
 [args.rustc,'--edition=2024','--crate-name','rec_microphysics','--crate-type','rlib',str(rec/'src/lib.rs'),'-o',str(rlib)],
 [args.rustc,'--edition=2024','--crate-name','rei_peebles_reference','--crate-type','rlib',str(root/'crate/src/lib.rs'),'--extern','rec_microphysics='+str(rlib),'-L',str(runtime),'-o',str(consumer)],
 [args.rustc,'--edition=2024','--test',str(root/'crate/tests/reference.rs'),'--extern','rei_peebles_reference='+str(consumer),'-L',str(runtime),'-o',str(runtime/'reference_tests')],
 [str(runtime/'reference_tests'),'--nocapture'],
 [args.rustc,'--edition=2024',str(root/'crate/examples/peebles_consumer_probe.rs'),'--extern','rei_peebles_reference='+str(consumer),'-L',str(runtime),'-o',str(runtime/'peebles_consumer_probe')],
]
records=[]
for command in commands:
    process=subprocess.run(command,capture_output=True,text=True)
    records.append(dict(command=command,exit_code=process.returncode,stdout=process.stdout,stderr=process.stderr))
    if process.returncode: break
identities=[]
for path in sorted(list((rec/'src').glob('*.rs'))+list((root/'crate').rglob('*.rs'))+[root/'crate/Cargo.toml']):
    identities.append(dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size))
if all(r['exit_code']==0 for r in records):
    path=runtime/'peebles_consumer_probe'
    identities.append(dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size))
result=dict(status='PASS' if all(r['exit_code']==0 for r in records) else 'FAIL',commands=records,identities=identities,
            cargo_git_dependency_resolution_tested=False,exact_source_rustc_build=True)
(root/'NATIVE_BUILD_AND_TEST.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
raise SystemExit(0 if result['status']=='PASS' else 1)
