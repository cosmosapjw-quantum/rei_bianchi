#!/usr/bin/env python3
"""Check generated literal identity, not Rust syntax, compilation, or execution."""
import ast
import hashlib
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
reference = json.loads((root / 'GOLDEN.json').read_text())
source = (root / 'proposed_consumer/he_flrw02_absorption.rs').read_text()
original = (root / 'inputs/he_flrw02_absorption.rs').read_text()
assert reference['input_sha256'] == hashlib.sha256((root / 'inputs/REFERENCE_INPUT.json').read_bytes()).hexdigest()
assert re.findall(r'#\[test\]\s*fn (\w+)', source) == re.findall(r'#\[test\]\s*fn (\w+)', original)
assert source.count('#[test]') == 2
assert 'absolute<=5e-14*scale+1e-300' in source
sigma = ast.literal_eval(re.search(r'const SIGMA:\[\[f64;3\];3\]=(.*);', source).group(1))
records = re.findall(r'Golden\{(photo:.*?)\},', source)
assert len(records) == 5
count = 0

def compare(actual, expected):
    global count
    if isinstance(expected, list):
        assert len(actual) == len(expected)
        for a, b in zip(actual, expected):
            compare(a, b)
    else:
        assert actual == float(expected), (actual, expected)
        count += 1

compare(sigma, reference['cases'][0]['values']['sigma'])
for record, case in zip(records, reference['cases']):
    parsed = ast.literal_eval('{' + re.sub(r'\b(photo|gamma|events|heat|binding|loss|absorbed):', r'"\1":', record) + '}')
    for key, value in parsed.items():
        compare(value, case['values'][key])
for path in root.rglob('*.json'):
    json.loads(path.read_text())
result = {'status': 'STATIC_DELIVERY_IDENTITY_PASS', 'binary64_literals_matched': count,
          'test_names_preserved': 2, 'test_case_records': len(records), 'input_hash_match': True,
          'scope': 'literal and JSON integrity only; NOT Rust compilation or execution',
          'rust_runs': 0}
(root / 'evidence/DELIVERY_CHECK.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
