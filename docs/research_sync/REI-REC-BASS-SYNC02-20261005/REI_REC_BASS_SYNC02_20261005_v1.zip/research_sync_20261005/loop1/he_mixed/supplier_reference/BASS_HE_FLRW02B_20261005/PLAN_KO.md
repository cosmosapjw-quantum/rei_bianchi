# HE-FLRW02B 실행 범위

1. 새 owner native 결과의 pure-H 범위를 수신한다. 혼합 He 연결이나 종전 두 scale 검사 실행으로 확대하지 않는다. 기존 84개 시험은 재실행하지 않는다.
2. 기존 두 검사와 같은 20/35/70 eV, 같은 밀도/분율/a0/lambda를 사용한다. Verner 공개 표의 세 행과 실제 소비기 상수를 고정하고 독립 Decimal/multiprecision 기준값을 만든다. 물리 source 변경이나 새 alpha/thermal closure는 없다.
3. 기존 두 Rust 제안에 기준값 비교만 보완한다. Rust 실행은 owner에 남긴다. Python 생성기 시험/고정밀 수렴/공통오류 반례만 여기서 실행하고 additive Git 및 create-only 이중백업한다.

사전 허용오차: 기존 native 5e-14 relative+1e-300 absolute를 유지한다. 이론/원자 fit 오차가 아니다. 고정밀 비교는 80/120자리 및 두 산술 표현의 상대차 <1e-65를 목표로 한다. 80자리 수렴은 rigorous interval certificate가 아니다. 소스 참조와 실행 로그를 분리한다.
