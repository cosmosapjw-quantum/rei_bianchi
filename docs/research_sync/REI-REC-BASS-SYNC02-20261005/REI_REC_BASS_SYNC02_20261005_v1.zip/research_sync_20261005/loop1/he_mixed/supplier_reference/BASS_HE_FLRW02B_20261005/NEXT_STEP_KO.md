# HE-FLRW02B owner native completion

BASS_HE는 연구/전달 supplier이며 rei_bianchi는 이 스레드에서 읽기 전용이다. 원자 source나 thermal closure를 바꾸지 않는다. HE-F2/RCT/HE-F3/legacy gate도 바꾸지 않는다.

1. rei_bianchi/forward/rust-reion-kernels-20260922의 실제 HEAD와 이 archive의 INPUT_IDENTITY.json을 대조한다. 입력은 3dceea736f9aaa363617a9a6a5bb2854d9ff9986이다. atomic_provider, homogeneous_rates, hhe_events, group_rates 및 관련 tests가 바뀌었으면 그 경로만 확인한다. 입력 pin과 게시 HEAD를 분리한다.
2. 이 패키지의 MANIFEST.json 및 detached receipt의 ZIP SHA를 확인한다. 이미 실행한 두 동일 검사나 충분한 mixed-species source-bound 결과가 있으면 그 반환을 재사용한다. 현재 수신한 native 84개 중 새 connected_cell bridge는 pure H이며 이 두 혼합 검사의 실행은 아니다.
3. 미실행일 때만 owner 작업공간에 proposed_consumer/he_flrw02_absorption.rs를 tests/he_flrw02_absorption.rs로 추가한다. 이전 제안이 있으면 이 버전으로 대체하고 두 버전을 함께 두지 않는다. 물리적 입력과 두 test 이름은 유지했다. 표의 값은 source fitted numerical references, physical truth bounds가 아니다.
4. 단일 명령을 실행한다:

cargo test --manifest-path rust/rei_microphysics/Cargo.toml --test he_flrw02_absorption --locked -- --nocapture

두 검사와 필요한 dependency compile만 수행한다. 준비 파일은 이 채팅에서 Rust compile/run하지 않았다. compile 실패면 import/시그니처/환경 문제를 먼저 분리한다. 수치 실패면 최초 종·채널·단위와 actual/reference를 보존한다. 5e-14 relative+1e-300 absolute는 기존 한계이며 2e-12로 확대하거나 fit를 clamp하지 않는다.

반환 항목: exact repo/commit/tree, 실행 전후 source/test identities, REFERENCE_INPUT/GOLDEN/proposal SHA256, 명령·exit·전체 stdout/stderr, FLRW02_RESIDUAL 및 FLRW02_REFERENCE의 최대 absolute/relative 값과 해당 label, 두 test 결과, NOT_RUN 목록. 실제 반환이 오기 전 HE-FLRW02B를 completed 또는 native-verified로 바꾸지 않는다.

이 검증의 목적은 source-matched 3species x 3nodes의 순간적 rate/ledger/scale 연결이다. 시간적분, redshift edge reconstruction, Q_V geometry, thermal closure 또는 physical admission을 인증하지 않는다. owner의 별도 허용된 FLRW03 이론 진행과 F04의 기존 인증 의무는 그대로다.
