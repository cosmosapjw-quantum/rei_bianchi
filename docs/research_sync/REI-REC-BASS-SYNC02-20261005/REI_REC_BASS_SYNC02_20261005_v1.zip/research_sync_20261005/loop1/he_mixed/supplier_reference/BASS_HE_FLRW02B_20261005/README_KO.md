# BASS_HE HE-FLRW02B 전달 패키지

먼저 REPORT_KO.md와 NEXT_STEP_KO.md를 읽는다. 현재 task는 partial이며 Rust 결과는 없다.

재현: python -B -W error oracle.py; python -B -W error check_identifiability.py; python -B -m pytest -q tests/test_oracle.py.

GOLDEN.json은 exact decimal source/fixture의 유한 기준값이다. proposed_consumer/he_flrw02_absorption.rs는 앞선 두 owner 검사에 독립 기준값을 추가한 완전한 파일이다. owner가 compile/run할 때 이전 제안과 대체 관계로 사용한다. 이미 source-matched 결과가 있으면 반복하지 않는다.

이 archive가 전체 코드·실패로그를 포함한다. Git projection만으로 native proposal이 존재한다고 추정하지 않는다. 상세 파일 identity는 MANIFEST.json, cloud 실재 객체는 detached DELIVERY_RECEIPT를 따른다.
