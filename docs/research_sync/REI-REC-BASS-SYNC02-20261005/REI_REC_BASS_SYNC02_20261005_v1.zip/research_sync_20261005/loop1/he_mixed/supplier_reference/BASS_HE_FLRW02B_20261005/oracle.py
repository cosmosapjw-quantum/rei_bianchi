#!/usr/bin/env python3
"""Finite reference values for the existing mixed-H/He absorption proposal.

This is neither a replacement microphysics provider nor a Rust execution.
Parameters are numerical rows from Verner et al. (1996), DOI 10.1086/177435.
Decimal evaluates a log formulation; mpmath evaluates the direct product.
"""
from __future__ import annotations
from decimal import Decimal as D, localcontext
import hashlib
import json
from pathlib import Path
import mpmath as mp

ROOT = Path(__file__).resolve().parent
DATA = json.loads((ROOT/'inputs/REFERENCE_INPUT.json').read_text())
ROWS = {r['species']: r for r in DATA['rows']}
SPECIES = ('HI', 'HeI', 'HeII')
CASES = (('proper','1'),('proper','0.5'),('proper','2'),('comoving','0.5'),('comoving','2'))


def token(value: str, lift: bool = False) -> D:
    """Lifting fixes input binary64 values only; intermediate rounding is not emulated."""
    return D.from_float(float(value)) if lift else D(value)


def sigma_decimal(species: str, energy_ev: str, precision: int = 80, lift: bool = False) -> D:
    if species not in ROWS or precision < 40:
        raise ValueError('unknown species or insufficient reference precision')
    with localcontext() as ctx:
        ctx.prec = precision
        r = {k: token(v,lift) for k,v in ROWS[species].items() if k not in ('species','Z','electrons')}
        e = token(energy_ev,lift)
        if not e.is_finite() or e < 0 or e > r['emax']:
            raise ValueError('energy outside adopted source guard')
        if e < r['eth']:
            return D(0)
        x=e/r['e0']-r['y0']
        y=(x*x+r['y1']*r['y1']).sqrt()
        shape=(x-1)*(x-1)+r['yw']*r['yw']
        # Independent algebraic representation, not the consumer's product evaluation.
        log_value=(r['sigma0_mb'].ln()+shape.ln()
                   +(r['p']/2-D('5.5'))*y.ln()
                   -r['p']*(1+(y/r['ya']).sqrt()).ln())
        return +(log_value.exp()*token('1e-18',lift))


def sigma_mpmath(species: str, energy_ev: str, precision: int = 100) -> D:
    with mp.workdps(precision):
        r={k:mp.mpf(v) for k,v in ROWS[species].items() if k not in ('species','Z','electrons')}
        e=mp.mpf(energy_ev)
        if not mp.isfinite(e) or e < 0 or e > r['emax']:
            raise ValueError('energy outside adopted source guard')
        if e < r['eth']:
            return D(0)
        x=e/r['e0']-r['y0']; y=mp.sqrt(x*x+r['y1']**2)
        value=(r['sigma0_mb']*((x-1)**2+r['yw']**2)
               *mp.power(y,r['p']/2-mp.mpf('5.5'))
               *mp.power(1+mp.sqrt(y/r['ya']),-r['p'])*mp.mpf('1e-18'))
        return D(mp.nstr(value,precision-5))


def reference_case(protocol: str, lam: str, precision: int = 80, lift: bool = False) -> dict:
    if protocol not in ('proper','comoving'):
        raise ValueError('unknown scaling protocol')
    with localcontext() as ctx:
        ctx.prec=precision
        f=DATA['fixture']; cv=lambda s:token(s,lift)
        la=cv(lam)
        if not la.is_finite() or la <= 0:
            raise ValueError('scale must be finite and positive')
        scale=la**3 if protocol=='comoving' else D(1)
        nh,ny=cv(f['n_h_cm3'])/scale,cv(f['n_he_cm3'])/scale
        h,y,z=map(cv,f['fractions'])
        lower=[nh*(1-h),ny*(1-(y+z)),ny*y]
        photons=[cv(v)/scale for v in f['photons_cm3']]
        energy=list(map(cv,f['energy_ev'])); binding=list(map(cv,f['binding_ev']))
        c,ev=cv(f['c_cm_s']),cv(f['ev_erg'])
        volume=(cv(f['a0'])*la*cv(f['mpc_cm']))**3
        sigma=[[sigma_decimal(s,e,precision,lift) for e in f['energy_ev']] for s in SPECIES]
        photo=[[c*lower[s]*sigma[s][g]*photons[g] for g in range(3)] for s in range(3)]
        gamma=[c*sum(sigma[s][g]*photons[g] for g in range(3)) for s in range(3)]
        events=[sum(row) for row in photo]
        heat=[sum(photo[s][g]*(energy[g]-binding[s])*ev for g in range(3)) for s in range(3)]
        bound=[events[s]*binding[s]*ev for s in range(3)]
        n_comoving=[volume*p for p in photons]
        # Recompute the photon sink from column opacities, not from row sums.
        loss=sum(c*sum(lower[s]*sigma[s][g] for s in range(3))*n_comoving[g] for g in range(3))
        absorbed=sum(photo[s][g]*energy[g]*ev for s in range(3) for g in range(3))
        return {'sigma':sigma,'photo':photo,'gamma':gamma,'events':events,'heat':heat,
                'binding':bound,'loss':loss,'absorbed':absorbed,'volume':volume,
                'n_comoving':n_comoving,'lower':lower,
                'fraction_photo_dot':[events[0]/nh,(events[1]-events[2])/ny,events[2]/ny],
                'electron_photo_dot':sum(events)}


def flatten(value, prefix='') -> dict[str,D]:
    if isinstance(value,dict):
        return {p:v for k,item in value.items() for p,v in flatten(item,prefix+'/'+k).items()}
    if isinstance(value,list):
        return {p:v for k,item in enumerate(value) for p,v in flatten(item,prefix+'/'+str(k)).items()}
    return {prefix:value}


def relative(a:D,b:D)->D:
    scale=max(abs(a),abs(b))
    return abs(a-b)/scale if scale else D(0)


def encode(value):
    if isinstance(value,D): return format(value,'.69E')
    if isinstance(value,list): return list(map(encode,value))
    if isinstance(value,dict): return {k:encode(v) for k,v in value.items()}
    return value


def build() -> dict:
    with localcontext() as ctx:
        ctx.prec=130
        records=[]; convergence=[]; rounding=[]; ledger=[]
        for protocol,lam in CASES:
            r80=reference_case(protocol,lam,80)
            r120=reference_case(protocol,lam,120)
            lifted=reference_case(protocol,lam,120,True)
            f80,f120,flift=map(flatten,(r80,r120,lifted))
            convergence.extend(relative(f80[k],v) for k,v in f120.items())
            rounding.extend(relative(flift[k],v) for k,v in f120.items())
            ledger += [relative(r120['loss'],r120['volume']*sum(r120['events'])),
                       relative(r120['absorbed'],sum(r120['heat'])+sum(r120['binding']))]
            records.append({'protocol':protocol,'lambda':lam,'values':encode(r120)})
        dual=[relative(sigma_decimal(s,e,120),sigma_mpmath(s,e,100))
              for s in SPECIES for e in DATA['fixture']['energy_ev']]
        assert max(convergence) < D('1e-65')
        assert max(dual) < D('1e-65')
        assert max(ledger) < D('1e-110')
        # Not a Rust/libm roundoff enclosure. This compares exact-real lifted inputs only.
        assert max(rounding) < D(DATA['expected_native_tolerance']['relative'])
        result={'schema':'bass-he.flrw02b.golden.v1','claim':'finite fitted-source reference values only',
                'species':list(SPECIES),'energies_ev':DATA['fixture']['energy_ev'],
                'input_sha256':hashlib.sha256((ROOT/'inputs/REFERENCE_INPUT.json').read_bytes()).hexdigest(),
                'cases':records}
        metrics={'precision_decimal':[80,120],'precision_mpmath':100,
                 'unique_sigma_points':9,'nonzero_sigma_points':6,'unique_fixture_cases':5,
                 'max_precision_change_relative':str(max(convergence)),
                 'max_decimal_mpmath_relative':str(max(dual)),
                 'max_ledger_relative':str(max(ledger)),
                 'max_binary64_input_lift_relative':str(max(rounding)),
                 'native_runs':0,'physical_accuracy_claim':False,'validated_interval_claim':False}
        (ROOT/'GOLDEN.json').write_text(json.dumps(result,indent=2)+'\n')
        (ROOT/'evidence/REFERENCE_RESULTS.json').write_text(json.dumps(metrics,indent=2)+'\n')
        return metrics


if __name__=='__main__':
    print(json.dumps(build(),indent=2))
