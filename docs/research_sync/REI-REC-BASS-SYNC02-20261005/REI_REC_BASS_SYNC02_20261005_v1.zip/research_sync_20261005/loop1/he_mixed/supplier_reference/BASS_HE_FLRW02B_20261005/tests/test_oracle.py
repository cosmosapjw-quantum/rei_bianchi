from decimal import Decimal as D, localcontext
import pytest
from oracle import sigma_decimal, reference_case


def test_helium_upper_open_channel_is_positive():
    assert sigma_decimal('HeII', '70') > D('1e-20')


@pytest.mark.parametrize('species,energy', [('HeI','20'),('HeII','20'),('HeII','35')])
def test_adopted_fit_closed_channels_return_exact_zero(species,energy):
    assert sigma_decimal(species,energy) == 0


@pytest.mark.parametrize('energy', ['-1','NaN','Infinity','50001'])
def test_outside_source_domain_is_rejected(energy):
    with pytest.raises(ValueError):
        sigma_decimal('HI',energy)


def test_reference_exposes_mixed_helium_photo_events_not_only_pure_h():
    r = reference_case('proper','1')
    assert 'photo' in r
    assert r['photo'][1][1] > 0 and r['photo'][2][2] > 0
    assert r['photo'][1][0] == 0


@pytest.mark.parametrize('protocol,scalings', [('proper',(D(1),D(1),D('0.125'))), ('comoving',(D(8),D(64),D(8)))])
def test_required_scale_laws_are_generated_from_transformed_inputs(protocol,scalings):
    a,b=reference_case('proper','1'),reference_case(protocol,'0.5')
    assert 'gamma' in a and 'loss' in a and 'events' in a
    for key,factor in zip(('gamma','events','loss'),scalings):
        av=a[key][0] if isinstance(a[key],list) else a[key]
        bv=b[key][0] if isinstance(b[key],list) else b[key]
        with localcontext() as ctx:
            ctx.prec = 100
            assert abs(bv/factor/av-1) < D('1e-65')
