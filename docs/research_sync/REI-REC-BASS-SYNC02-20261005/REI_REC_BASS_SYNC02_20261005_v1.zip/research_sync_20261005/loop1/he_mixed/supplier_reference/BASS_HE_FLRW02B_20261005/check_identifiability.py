#!/usr/bin/env python3
"""Exact finite-fixture observability and deliberately injected error controls."""
import json
from decimal import Decimal as D, localcontext
from pathlib import Path
import sympy as s
from oracle import reference_case, relative

# Active channels: HI20,HI35,HI70,HeI35,HeI70,HeII70.
photon=s.Matrix([[1,0,0,0,0,0],[0,1,0,1,0,0],[0,0,1,0,1,1]])
energy=s.Matrix([[20,35,70,35,70,70]])
electron=s.ones(1,6)
combined=photon.col_join(energy).col_join(electron)
null=combined.nullspace()
assert photon.rank()==3 and combined.rank()==3 and len(null)==3
for n in null:
    assert combined*n==s.zeros(5,1)
# The three direct species-channel observations suffice in addition to bin totals.
selected=s.Matrix([[0,0,0,1,0,0],[0,0,0,0,1,0],[0,0,0,0,0,1]])
assert photon.col_join(selected).rank()==6
with localcontext() as ctx:
    ctx.prec=120
    r=reference_case('proper','1',120)
    d=r['photo'][2][2]/2
    changed=[row.copy() for row in r['photo']]
    changed[1][2]-=d
    changed[2][2]+=d
    assert all(x>=0 for row in changed for x in row)
    col_original=[sum(r['photo'][a][g] for a in range(3)) for g in range(3)]
    col_mutated=[sum(changed[a][g] for a in range(3)) for g in range(3)]
    number_res=max(relative(x,y) for x,y in zip(col_original,col_mutated))
    energy_res=relative(sum(D(e)*v for e,v in zip(['20','35','70'],col_original)),
                        sum(D(e)*v for e,v in zip(['20','35','70'],col_mutated)))
    labelled=relative(changed[2][2],r['photo'][2][2])
    assert number_res<D('1e-110') and energy_res<D('1e-110')
    assert labelled>D('5e-14')
    common_scale=relative(2*r['events'][0],r['events'][0])
    assert common_scale==D('0.5')
    result={'active_channels':['HI20','HI35','HI70','HeI35','HeI70','HeII70'],
            'photon_projection_rank':3,'photon_plus_energy_plus_electron_rank':3,
            'undetected_redistribution_dimensions':3,
            'null_basis':[[int(v) for v in n] for n in null],
            'with_three_species_channel_anchors_rank':6,
            'positive_HeI70_to_HeII70_control':{'transfer_proper_cm3_s':str(d),
                'photon_bin_total_residual_relative':str(number_res),
                'total_absorbed_energy_residual_relative':str(energy_res),
                'HeII70_source_reference_residual_relative':str(labelled),
                'source_reference_rejects':True},
            'common_factor_two_sigma_control':{'source_reference_residual_relative':str(common_scale),
                'ledger_and_scaling_identities':'unchanged algebraically','source_reference_rejects':True},
            'scope':'finite-fixture comparison design; no defect alleged in current consumer',
            'native_runs':0}
Path(__file__).with_name('evidence').joinpath('IDENTIFIABILITY.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
