# HE-FLRW02B: 혼합 H/He 흡수의 source-bound 기준값과 보존 검사의 식별 한계

## 판정

이번 증분은 **독립 수치 기준값과 owner 검사 보완을 완료**했다. 상위 HE-FLRW02B_OWNER_NATIVE_MATCHED_ABSORPTION_REGRESSION은 **partial / OWNER_NATIVE_RESULT_PENDING**이다. 새 Rust 실행은 0회이고 기존 84개 소비기 시험도 여기서 재실행하지 않았다. source admission, HE-F2/HE-F3, RCT 제외 및 HE-L1/L2/L3의 상태는 바꾸지 않는다.

### 1. 새 소비기 반환의 수신과 범위

BASS_HE 입력은 기존 research/shared-c64-crossrepo-20260928의 21d5b8075429903d195d6e0e0c24a10c00b21063, tree 4061b29b74c70936433efcf6ff57ad5921489204다. 소비기 입력은 rei_bianchi/forward/rust-reion-kernels-20260922의 3dceea736f9aaa363617a9a6a5bb2854d9ff9986, tree ef1b3d833e0bef05b7c94b986625102db2c91613이다.

새 FINAL_INTEGRATION.json과 final_crate.log를 읽었다. 84개는 3+21+26+7+1+3+6+7+5+5의 native 시험 결과이며, 이 중 21개가 새 flrw_three_equations 시험이다. 이전 “소비기 native가 전혀 없다”는 전역 관측은 더 이상 현재 상태가 아니다. 이 수신을 독립 재실행/전체 과학 검토로 부르지 않는다.

실제 connected_cell은 model.n_he_cm3=0, alpha=[alpha_H,0,0], sigma의 HI 행만 활성화한다. 새 c_mpc_photo_bridge_is_same_actual_event_count는 순수 H에서 a=0.03,0.1,0.7,1의 bridge를 검사한다. 다른 기존 HHe fixture와 atomic provider 시험도 있으나, 이들을 이번 혼합 H/He의 source-matched 두 scale 검사의 실행으로 합쳐 주장하지 않는다. 새 native near()의 2e-12와 기존 HE-FLRW02 제안의 5e-14는 같지 않다. 허용오차를 완화하여 후자의 실행을 수락하지 않는다.

따라서 pure-H source-connected native 증거를 수신하되, 혼합 세 absorber의 20/35/70 eV 사건 배분과 기존 두 scale 검사의 실제 반환은 남긴다. 소비기 저장소는 이 루프에서 읽기 전용이다.

## 2. 정의와 source binding

흡수체 순서는 (HI, HeI, HeII), 광자 노드는 (20,35,70) eV다. proper n_H=1e-4 cm^-3, n_He=8.3e-6 cm^-3, 분율 (x_HII,y_HeII,y_HeIII)=(0.01,0.019,0.001), proper 광자수 p=(2e-5,2e-6,2e-7) cm^-3를 사용한다. 이는 직전 제안의 입력이며 관측값이나 선택한 실제 우주론 초기조건이 아니다.

흡수체 밀도는 l=(n_H(1-x), n_He(1-y-z), n_He*y)다. t는 proper time [s], c=2.99792458e10 cm/s, a0=0.25, MPC_CM=3.085677581491367e24 cm다. 새 geometry/tilt/thermal closure를 도입하지 않는다.

원자 단면적은 Verner et al. (1996), DOI 10.1086/177435의 공개 Table 1 첫 세 행과 현재 AtomicProvider.cross_section의 수치 파라미터를 결속한다. 에너지는 eV, sigma0는 Mb이고 1 Mb=1e-18 cm^2다. 채택한 식은

x=E/E0-y0, y=sqrt(x^2+y1^2),

sigma(E)=1e-18 sigma0 [(x-1)^2+yw^2] y^(P/2-5.5) [1+sqrt(y/ya)]^(-P).

채택한 threshold는 (13.60,24.59,54.42) eV, 상단 guard는 50000 eV다. source threshold 아래의 0은 이 fit/guard의 반환값이며 관측된 물리적 exact zero나 원자 오차 상한이 아니다. 열 장부의 binding energies (13.598434599702,24.587389011,54.41776) eV와 fit thresholds를 서로 교체하지 않는다.

이번 스레드가 새 원자 계산/모형을 채택한 것이 아니다. 기존 식의 유한한 합성 입력에 대한 독립 수치 기준값이다. 전체 원문·데이터 파일 byte download는 실패했으며, 공개 웹에서 실제 읽은 수치 세 행만 구조화해 보존했다. 전 표의 byte identity나 원 저자의 Fortran 실행을 주장하지 않는다.

## 3. 새 유도: 보존식만으로 종별 흡수를 식별할 수 없는 이유

같은 에너지·시점의 A_sg=c*l_s*sigma_sg*p_g는 proper 사건률 [cm^-3 s^-1]다. V=(a*MPC_CM)^3에 대해 N_g=V*p_g이며 comoving photon loss=V*sum_sg A_sg다. 가열 및 결합 에너지는 각각 sum_g A_sg(E_g-b_s)*EV_ERG, sum_g A_sg*b_s*EV_ERG다.

이 입력에서 활성 채널을 a=(A_HI,20,A_HI,35,A_HI,70,A_HeI,35,A_HeI,70,A_HeII,70)^T로 정렬하면, 그룹별 광자 흡수에 대한 사영은

P = [[1,0,0,0,0,0],
     [0,1,0,1,0,0],
     [0,0,1,0,1,1]].

전자 생성 총수의 행은 (1,1,1)P, 총 흡수 에너지의 행은 (20,35,70)P다. 가열+binding의 합을 쓰면 에너지 행은 추가 독립 제약이 아니다. 따라서 이 선형 관측 행렬의 rank는 3이고, 활성 6채널 공간의 nullity는 3이다. 한 기저는

v1=(0,-1,0,1,0,0),
v2=(0,0,-1,0,1,0),
v3=(0,0,-1,0,0,1).

충분히 작은 재분배는 모든 활성 사건의 양성을 유지한다. 즉 광자 그룹별 합·총 전자수·가열+binding 합이 정확해도 종별 흡수 배분은 틀릴 수 있다. 균일한 scale 변환에서도 사건 전체와 이 재분배를 같은 차수로 변환하면 기존 scale 관계를 보존한다. 이 명제는 현재 코드의 결함 판정이 아니라, 해당 검사의 정보량에 관한 직접 유도다. 이미 존재하는 F01 원자값 시험의 효용을 부정하거나 그것을 다시 실행한 것이 아니다.

그룹별 세 합에 (HeI,35), (HeI,70), (HeII,70)의 세 독립 source-bound 사건을 추가하면 rank=6이 되어 이 유한 채널 배분을 식별한다. 전달한 제안은 구현 단순성을 위해 활성 6개와 비활성 3개 모두를 직접 비교한다. 이것은 모든 에너지·온도·해석 모형에 대한 global 식별 정리가 아니다.

수치 control: 70 eV에서 HeII 사건률의 절반 d=3.78554525509848e-22 cm^-3 s^-1을 HeI 사건에서 빼 HeII 사건에 더했다. 그룹별 흡수·총 에너지는 그대로이고 모든 사건이 비음수다. 그러나 HeII 해당 채널의 symmetric relative source-reference residual은 1/3로, 5e-14 기준에서 거절된다. sigma를 두 구현에서 함께 두 배로 바꾸는 별도 control도 source-reference residual=1/2로 거절된다. 두 control 모두 의도적으로 주입한 오류이며 현행 소비기에서 발견한 오류가 아니다.

## 4. 수치 기준값

문헌 수치 파라미터와 입력을 정확한 십진수로 읽고 Decimal 80/120자리의 logarithmic form 및 mpmath 100자리의 direct-product form을 비교했다. 차이가 작은 것을 관찰했으며 rigorous interval arithmetic이나 65자리 물리적 정확도 증명은 아니다.

| sigma [cm^2] | 20 eV | 35 eV | 70 eV |
|---|---:|---:|---:|
| HI | 2.211102984039e-18 | 4.510161613293e-19 | 5.773427852434e-20 |
| HeI | 0 | 4.065326247237e-18 | 9.605457460781e-19 |
| HeII | 0 | 0 | 8.007114634423e-19 |

기준 proper 사건률은 (1.339601087581e-16,2.029515292093e-18,7.571090510197e-22) cm^-3 s^-1이며 총 흡수 에너지는 4.476159607231e-27 erg cm^-3 s^-1다. 이 합성 입력에서 He의 사건 비율은 약 0.01492952945522다. 개별 종의 gamma, heat, binding, 3x3 사건 행렬, 광자 손실 및 photo-only 분율 미분은 GOLDEN.json에 더 많은 자릿수로 있다.

유일한 상태는 5개다: base, a/a0=1/2 및 2에서 proper 밀도를 고정한 두 상태, 같은 a/a0에서 comoving 핵·광자 수를 고정한 두 상태. 후자는 proper 사건률이 lambda^-6, gamma와 comoving photon loss가 lambda^-3다. 원소·광자 에너지를 고정한 순간 검사이며 자유전파/팽창 이력이나 full dynamics가 아니다.

정확한 binary64 입력값을 실수로 lift한 별도 평가도 수행했다. 이는 입력 literal의 반올림 민감도만 비교하며, 각 연산의 중간 반올림이나 Rust/libm 오차를 모사·인증하지 않는다.

실측 진단:
- 80자리와 120자리 간 최대 상대차: 6.35990e-79.
- Decimal와 mpmath 단면적 간 최대 상대차: 1.72835e-95.
- reference number/energy 장부의 최대 상대잔차: 5.23431e-120.
- exact decimal 대 binary64 input-lift 간 최대 상대차: 5.15237e-16.

## 5. 구현·검증 및 실패 보존

oracle.py는 reference만 생성한다. check_identifiability.py는 정확 rank/nullspace와 두 주입 control을 검사한다. 생성기 시험은 11개 통과했다. 9개의 고유 종/에너지 조합 중 양수는 6개, 채택 guard의 0은 3개다. 이 개수를 함수 호출 총수나 새 관측 데이터 수로 부르지 않는다.

초기 scaffold에서 8개 행동 시험이 예상대로 실패했다. 구현 후 두 scale 비교가 1e-28 잔차를 보고한 원인은 시험식이 Decimal의 기본 28자리 문맥에서 중간 나눗셈을 수행했기 때문이다. 같은 값을 explicit 100자리 문맥에서 비교하면 잔차 0이었다. 검사 문맥만 수정했고, source·허용오차는 변경하지 않았다. 실패 로그와 진단을 삭제하지 않았다.

proposed_consumer/he_flrw02_absorption.rs는 직전 두 test 이름·물리 입력·허용오차를 유지하면서 독립 기준값 비교를 추가한 제안이다. 중복 세 번째 검사나 새 physics wrapper를 만들지 않았다. template는 이전 ZIP에서 그대로 회수했고 변경본은 새 파일에 보존했다. NOT_COMPILED_NOT_RUN 상태다.

현재 로컬 rustc/cargo 부재와 owner-only 소비기 실행 경계를 구분한다. 이 스레드의 검증은 Python reference 구현 및 수학적 유도뿐이다. native·전체 history·physical source admission·독립 scientific review는 이 작업에서 수행하지 않았다.

## 6. 다음 단일 실행과 공개 범위

다음은 동일 HE-FLRW02B의 **owner native completion**이다. owner는 최신 source/proposal identity를 대조하고 이미 같은 검사가 실행됐다면 그 결과를 수신한다. 없다면 기존 제안을 이번 파일로 대체해 두 검사만 실행한다. 실제 명령/exit/log, 실행 source와 test blob, GOLDEN/input hash, 종·채널별 최대 absolute/relative residual을 반환한다. 84개 전체 suite를 단순 전달 때문에 재실행하지 않는다. 실패하면 값·단위·배분·roundoff 원인을 분류하고 tolerance 확대/clamp는 하지 않는다.

이 미완료 항목이 소비기에서 허용된 별도 FLRW03 이론 진행을 막지는 않는다. 본 BASS_HE 루프에서는 expanding/full-history 노드를 새로 열지 않았다. RCT 포함·legacy 원자 계획도 재개하지 않았다.

Git에는 이번 보고·입력 identity·핵심 기준값·반환·owner 실행 지침을 additive로 게시한다. 전체 코드, 70자리 기준값, 새 native 제안, 입력 template, 실패/성공 로그는 detached ZIP에 있다. 따라서 Git 요약만으로 전체 native 제안이 재현된다고 하지 않는다. 최종 게시·Drive/Dropbox 성공 및 archive SHA는 detached delivery receipt가 소유한다.

## 원전·코드 provenance

Verner et al. 1996, ApJ 465,487, DOI 10.1086/177435. 공개 table 및 열 정의:
https://www.pa.uky.edu/~verner/dima/photo//photo.dat
https://www.pa.uky.edu/~verner/dima/photo//photo.txt

소비기 source/시험/로그의 exact commit/path/blob 및 읽은 범위는 INPUT_IDENTITY.json에 있다. derived 기준값의 근거는 같은 식·공개 파라미터에 대한 독립 산술이며 독립 물리 데이터는 아니다.

## 게시 직전 동기화

소비기 HEAD c433eaee7b120a5bfb7c35e802c4b218315bf210, tree bbcfa316824f67075f0f679b0aba74167c364a1e를 새로 읽었다. 입력 pin 3dceea736f9aaa363617a9a6a5bb2854d9ff9986 이후 3 commits는 FLRW02 CSV·게시 기록과 FLRW03 문서이며 Rust source는 변하지 않았다. NEXT_HANDOFF_KO.md(blob ecd473aae82a8d299e2e07296e9ffb723b5f161b)를 읽어 owner의 다음 이론 노드가 REI-CHAT-FLRW04_EVENT_WEIGHTED_CONSUMER_CONTRACT임을 반영했다. 이는 외부 REI-F04 sparse nonlinear remainder와 다른 노드다. 본 source reference와 native mixed-HHe 대기 상태는 변하지 않아 검산을 반복하지 않았다.

전달 직전 native 제안의 124개 binary64 literal을 GOLDEN.json에서 반올림한 값과 일대일 대조했고, 기존 두 test 이름·기준 입력 hash·허용오차의 보존을 확인했다. 이는 정적 내용 검증이며 Rust 문법·컴파일 검증이 아니다.
