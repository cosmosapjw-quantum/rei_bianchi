use bianchi_rustcore::microphysics::visibility_clock::{integrate_clock_visibility, RayClockGrid};
#[test]
fn explicit_clock_api_exists() {
 let result = integrate_clock_visibility(RayClockGrid::NormalSeconds { edges_seconds: &[0.0, 1.0] }, &[0.5], 0.0).unwrap();
 assert_eq!(result.visibility.optical_depth, vec![0.5, 0.0]);
}
