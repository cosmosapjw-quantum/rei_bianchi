//! Compiles actual host modules; not the full BASS crate.
pub mod microphysics;
