# BASS-REI-CLOCK01 — loop1 반환

기존 REI→BASS normal opacity 결과를 normal seconds/conformal seconds/conformal meters에서 명시적으로 적분하는 native API를 구현했다. 자세한 유도와 주장 범위는 `theory/DERIVATION_KO.md`, 기계 판독 반환은 `RETURN.json`이다.

변경파일은 `bass/`의 세 파일이다. `baseline_bass/`는 검증용 기존 source이며 native 변경파일이 아니다. `scoped_harness/`가 실제 native module을 컴파일한다. 전체 BASS 빌드 증거는 아니다.

30 scoped tests, 151 native probe cases 및 Decimal70 5001 checks가 통과했다. 최초 missing API 실패는 `evidence/RED_MISSING_CLOCK.log`에 보존했다. 다음 loop에서 actual expanding history의 같은 physical cells를 각 clock으로 전달하여 검증하면 된다. a_eff는 정확한 cell 시간비를 제공받는 계약이며 endpoint a를 정확한 값으로 승격하지 않는다.

재현 명령:

```bash
PATH=/tmp/rec_rust_1941/bin:$PATH cargo test --manifest-path scoped_harness/Cargo.toml --offline
PATH=/tmp/rec_rust_1941/bin:$PATH cargo build --manifest-path scoped_harness/Cargo.toml --offline --bin clock_probe
python research/independent_clock_check.py
```

상태: 국소 구현/수치검증 완료. independent decision은 root의 통합 review에 넘긴다. 기존 원자물리 확장 lane, finite-temperature/spectral admission, polarized collision generator 및 RCT stepper gate는 유지한다.
