"""Decimal70 oracle against compiled actual clock module; no Rust formulas imported."""
from pathlib import Path
from decimal import Decimal, localcontext
import json, subprocess, hashlib, time
ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT/'scoped_harness/target/debug/clock_probe'
C = Decimal(299792458)
RTOL = Decimal('2e-12'); ATOL = Decimal('2e-14')
D = lambda x: Decimal(str(x))

def oracle(case):
    e = list(map(D,case['edges'])); q = list(map(D,case['q'])); a = list(map(D,case['a']))
    scale = [Decimal(1) if case['clock']=='normal' else x if case['clock']=='eta' else x/C for x in a]
    rate = [x*y for x,y in zip(q,scale)]
    dt = [(r-l)*s for l,r,s in zip(e,e[1:],scale)]
    tau = [Decimal(0)]*len(e); tau[-1]=D(case['tail'])
    for i in range(len(q)-1,-1,-1): tau[i]=tau[i+1]+rate[i]*(e[i+1]-e[i])
    survival=[(-x).exp() for x in tau]
    probability=[s1-s0 for s0,s1 in zip(survival,survival[1:])]
    return {'rates':rate,'jacobian':scale,'dt':dt,'tau':tau,'survival':survival,'probability':probability}

def main():
    cases=[]; groups=[]
    for n in [1,3,7]:
        for a_base in [0.125,0.5,1.,4.]:
            for q_base in [1e-18,0.001,0.125,1000.]:
                eta=[0.]; t=[0.]; a=[a_base*(2. if i%2 else 1.) for i in range(n)]
                for i in range(n):
                    width=2.**((i%3)-1); eta.append(eta[-1]+width); t.append(t[-1]+a[i]*width)
                q=[q_base*(i+1) for i in range(n)]; group=[]
                for clock,edges in [('normal',t),('eta',eta),('chi',[v*float(C) for v in eta])]:
                    group.append(len(cases));cases.append({'id':len(cases),'clock':clock,'edges':edges,'q':q,'a':a,'tail':0.2,'valid':True})
                groups.append(group)
    bad=[
       ('eta',[0.,1.],[0.],[0.],0.),('eta',[0.,1.],[0.],[-1.],0.),
       ('chi',[0.,1.],[0.],[5e-324],0.),('eta',[0.,2.],[0.],[1.7976931348623157e308],0.),
       ('normal',[1.,0.],[1.],[1.],0.),('eta',[0.,1.],[-1.],[1.],0.),
       ('chi',[0.,1.],[1.],[1.],-1.)]
    for clock,e,q,a,tail in bad: cases.append({'id':len(cases),'clock':clock,'edges':e,'q':q,'a':a,'tail':tail,'valid':False})
    lines=[' '.join([c['clock'],str(c['tail']),str(len(c['q']))]+[repr(x) for x in c['edges']+c['q']+c['a']]) for c in cases]
    (ROOT/'evidence/DECIMAL_INPUT.json').write_text(json.dumps(cases,indent=2)+'\n')
    start=time.perf_counter();proc=subprocess.run([str(BIN)],input='\n'.join(lines)+'\n',capture_output=True,text=True); wall=time.perf_counter()-start
    (ROOT/'evidence/DECIMAL_NATIVE.stdout.jsonl').write_text(proc.stdout);(ROOT/'evidence/DECIMAL_NATIVE.stderr').write_text(proc.stderr)
    if proc.returncode: raise RuntimeError(f'native process exit={proc.returncode}')
    outputs=[json.loads(x) for x in proc.stdout.splitlines()];assert len(outputs)==len(cases)
    checks=0;max_abs={};max_rel={}
    with localcontext() as ctx:
        ctx.prec=70
        for case,out in zip(cases,outputs):
            checks+=1;assert out['ok']==case['valid'],case
            if not case['valid']:continue
            want=oracle(case)
            for key,values in want.items():
                assert len(out[key])==len(values)
                for got,target in zip(out[key],values):
                    err=abs(D(got)-target);scaled=err/abs(target) if target else Decimal(0)
                    max_abs[key]=max(max_abs.get(key,Decimal(0)),err);max_rel[key]=max(max_rel.get(key,Decimal(0)),scaled)
                    checks+=1;assert err<=max(ATOL,RTOL*abs(target)),(case['id'],key,got,str(target))
            checks+=1;assert abs(sum(map(D,out['probability']))+D(out['survival'][0])-(-D(case['tail'])).exp())<=ATOL
        invariance_max=Decimal(0)
        for ids in groups:
            ref=outputs[ids[0]]
            for i in ids[1:]:
                for key in ['tau','survival','probability']:
                    for a,b in zip(ref[key],outputs[i][key]):
                        err=abs(D(a)-D(b));invariance_max=max(invariance_max,err);checks+=1
                        assert err<=max(ATOL,RTOL*abs(D(a))),(ids,key,a,b)
        # Sensitivity controls use same analytic case with a deliberately wrong Jacobian.
        known={'clock':'eta','edges':[0.,2.],'q':[0.5],'a':[0.25],'tail':0.}
        right=oracle(known)['tau'][0]
        missing_a=D(known['q'][0])*D(known['edges'][1]);extra_c=right*C
        checks+=2;assert abs(right-missing_a)>Decimal('.1');assert abs(extra_c-right)>Decimal('1e6')
    result={'status':'PASS','actual_process_exit':proc.returncode,'cases':len(cases),'valid_clock_cases':144,'invalid_cases':7,'physical_grid_groups':48,'checks':checks,'precision_digits':70,'native_wall_seconds':wall,'relative_tolerance':str(RTOL),'absolute_tolerance':str(ATOL),'max_absolute_error':{k:str(v) for k,v in max_abs.items()},'max_relative_error':{k:str(v) for k,v in max_rel.items()},'clock_invariance_max_absolute_difference':str(invariance_max),'negative_controls':['omit scale factor','extra c factor'],'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(BIN.read_bytes()).hexdigest(),'independence':'Same analytic definitions and supplied input cells; independent Python Decimal70 arithmetic, no Rust source imports. Invariant test also compares three native coordinates.','claim_ceiling':'Piecewise frozen rates; no cosmological history or continuum discretization certificate.'}
    (ROOT/'evidence/DECIMAL_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
